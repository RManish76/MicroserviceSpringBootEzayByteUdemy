# Changelog

## 6.0.2 (2025-09-16)

* [bitnami/apisix] Fixed bug caused by inconsistent usage of context with dataPlane.extraEnvVars ([#36252](https://github.com/bitnami/charts/pull/36252))

## 6.0.0 (2025-08-20)

* [bitnami/apisix] major: Integrate apisix-dashboard into apisix (#36136) ([5a872ff](https://github.com/bitnami/charts/commit/5a872ffa25422b04ab276236293b8179268050ed)), closes [#36136](https://github.com/bitnami/charts/issues/36136)

## <small>5.1.6 (2025-08-18)</small>

* [bitnami/apisix] :zap: :arrow_up: Update dependency references (#36122) ([9ad91f7](https://github.com/bitnami/charts/commit/9ad91f789a864aaf7edde54e10a17118882b0e0b)), closes [#36122](https://github.com/bitnami/charts/issues/36122)

## <small>5.1.5 (2025-08-14)</small>

* [bitnami/apisix] :zap: :arrow_up: Update dependency references (#35868) ([3964047](https://github.com/bitnami/charts/commit/3964047593f995eb28692cdd6badc2d6cd0bc4e2)), closes [#35868](https://github.com/bitnami/charts/issues/35868)

## <small>5.1.4 (2025-08-08)</small>

* [bitnami/apisix] :zap: :arrow_up: Update dependency references (#35710) ([f90b579](https://github.com/bitnami/charts/commit/f90b57966df7d244891b4dba45ce23f65800fccd)), closes [#35710](https://github.com/bitnami/charts/issues/35710)

## <small>5.1.3 (2025-08-07)</small>

* [bitnami/apisix] :zap: :arrow_up: Update dependency references (#35639) ([3bf169f](https://github.com/bitnami/charts/commit/3bf169f4e8d47a924ba27fba164a81ea7aadbccd)), closes [#35639](https://github.com/bitnami/charts/issues/35639)

## <small>5.1.2 (2025-08-07)</small>

* [bitnami/apisix] :zap: :arrow_up: Update dependency references (#35540) ([3e3ba54](https://github.com/bitnami/charts/commit/3e3ba54845df9e372d80e7e24fa76b8882f7bd8b)), closes [#35540](https://github.com/bitnami/charts/issues/35540)

## <small>5.1.1 (2025-08-06)</small>

* [bitnami/apisix] :zap: :arrow_up: Update dependency references (#35452) ([434b20c](https://github.com/bitnami/charts/commit/434b20c1c9033779e91dbfba6994d970198fa89c)), closes [#35452](https://github.com/bitnami/charts/issues/35452)

## 5.1.0 (2025-08-01)

* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/apisix] fix: Apisix clean uds (#34987) ([917cf05](https://github.com/bitnami/charts/commit/917cf05244decd9934919e1e6bd5b0c6e4309277)), closes [#34987](https://github.com/bitnami/charts/issues/34987)

## <small>5.0.8 (2025-07-24)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/charts/issues/35218] Share context with apisix.etcd.authEnabled function (#35257) ([017722c](https://github.com/bitnami/charts/commit/017722ccd67a005d541e3aa72275d0484ba5838b)), closes [#35257](https://github.com/bitnami/charts/issues/35257)

## <small>5.0.7 (2025-07-15)</small>

* [bitnami/apisix] :zap: :arrow_up: Update dependency references (#35079) ([03f66b2](https://github.com/bitnami/charts/commit/03f66b2c6caaaf14477cb720e8dff0c43407f686)), closes [#35079](https://github.com/bitnami/charts/issues/35079)

## <small>5.0.6 (2025-07-08)</small>

* [bitnami/apisix] :zap: :arrow_up: Update dependency references (#34865) ([5c9287c](https://github.com/bitnami/charts/commit/5c9287c28a82889e83ab6390d5327fa53a9a0a9a)), closes [#34865](https://github.com/bitnami/charts/issues/34865)

## <small>5.0.5 (2025-07-07)</small>

* [bitnami/apisix]: Correct values comments (#34737) ([e9bc018](https://github.com/bitnami/charts/commit/e9bc018e6802e0a2ea92e7a5a53a1e89f95b7ba6)), closes [#34737](https://github.com/bitnami/charts/issues/34737)

## <small>5.0.4 (2025-06-27)</small>

* [bitnami/apisix] :zap: :arrow_up: Update dependency references (#34687) ([605be56](https://github.com/bitnami/charts/commit/605be569626e31e217e61c5dc96964b8cf861201)), closes [#34687](https://github.com/bitnami/charts/issues/34687)

## <small>5.0.3 (2025-06-13)</small>

* [bitnami/apisix] :zap: :arrow_up: Update dependency references (#34390) ([c6638d8](https://github.com/bitnami/charts/commit/c6638d85b4251c422aba1b1819d6f7c38906a637)), closes [#34390](https://github.com/bitnami/charts/issues/34390)

## <small>5.0.2 (2025-06-05)</small>

* [bitnami/apisix] :zap: :arrow_up: Update dependency references (#34131) ([6c92e2b](https://github.com/bitnami/charts/commit/6c92e2b43c77189862658dce993e624ab6ecb9ab)), closes [#34131](https://github.com/bitnami/charts/issues/34131)

## <small>5.0.1 (2025-05-29)</small>

* feat: [bitnami/apisix] Add dnsPolicy parameter support (#33926) ([62bffa4](https://github.com/bitnami/charts/commit/62bffa41d6c4ae2eb5d1ffb986d1b3993d9122ef)), closes [#33926](https://github.com/bitnami/charts/issues/33926)

## 5.0.0 (2025-05-26)

* [bitnami/apisix] Update ETCD subchart (#33878) ([8337a8c](https://github.com/bitnami/charts/commit/8337a8c86a942c0e88553964f7bce5edace0dbc2)), closes [#33878](https://github.com/bitnami/charts/issues/33878)

## <small>4.2.5 (2025-05-13)</small>

* [bitnami/apisix] :zap: :arrow_up: Update dependency references (#33651) ([60b9da0](https://github.com/bitnami/charts/commit/60b9da0e0543cac807058ac69e398b41b78f84a9)), closes [#33651](https://github.com/bitnami/charts/issues/33651)
* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)

## <small>4.2.4 (2025-05-06)</small>

* [bitnami/apisix] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#33335) ([21f0df7](https://github.com/bitnami/charts/commit/21f0df7910ce9f5849889a77e6c4923e165153ff)), closes [#33335](https://github.com/bitnami/charts/issues/33335)

## <small>4.2.3 (2025-05-01)</small>

* [bitnami/apisix] Release 4.2.3 (#33277) ([89b5e15](https://github.com/bitnami/charts/commit/89b5e15a29e6dbdcb8582e951ac9b647fbf96f27)), closes [#33277](https://github.com/bitnami/charts/issues/33277)

## <small>4.2.2 (2025-04-01)</small>

* [bitnami/apisix] Release 4.2.2 (#32695) ([1193919](https://github.com/bitnami/charts/commit/11939197e7f7cdb4c366bbb316db96ad54556c12)), closes [#32695](https://github.com/bitnami/charts/issues/32695)

## <small>4.2.1 (2025-03-20)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/apisix] Release 4.2.1 (#32540) ([740e6c3](https://github.com/bitnami/charts/commit/740e6c318f0cdd53e45a6ad0d9cedeb4a19b7248)), closes [#32540](https://github.com/bitnami/charts/issues/32540)

## 4.2.0 (2025-02-24)

* [bitnami/apisix] Add support for `usePasswordFiles` (#32077) ([cb5df90](https://github.com/bitnami/charts/commit/cb5df905951bede532a1ef73a88a0a66c67e5044)), closes [#32077](https://github.com/bitnami/charts/issues/32077)

## 4.1.0 (2025-02-20)

* [bitnami/apisix] feat: use new helper for checking API versions (#32045) ([c327f4b](https://github.com/bitnami/charts/commit/c327f4ba9cf6889d452e0f3fce495c10c6d1c106)), closes [#32045](https://github.com/bitnami/charts/issues/32045)

## <small>4.0.2 (2025-02-18)</small>

* [bitnami/apisix] Release 4.0.2 (#31972) ([d014094](https://github.com/bitnami/charts/commit/d014094260366d1b17e60bbc9a2aee09542d3147)), closes [#31972](https://github.com/bitnami/charts/issues/31972)

## <small>4.0.1 (2025-02-18)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/apisix] Release 4.0.1 (#31964) ([7870a08](https://github.com/bitnami/charts/commit/7870a082176ef14922db8d72a317ee490ba39747)), closes [#31964](https://github.com/bitnami/charts/issues/31964)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## 4.0.0 (2025-01-22)

* [bitnami/apisix] Update ETCD to major 11 (#31508) ([9561660](https://github.com/bitnami/charts/commit/9561660522ef445652d58becbf3a39bf29836464)), closes [#31508](https://github.com/bitnami/charts/issues/31508)

## <small>3.7.2 (2025-01-17)</small>

* [bitnami/apisix] feat: :recycle: Use os-shell for config generation (#31455) ([e808ba0](https://github.com/bitnami/charts/commit/e808ba010c008023c7dfc1c1ee5bafb2f9acf38c)), closes [#31455](https://github.com/bitnami/charts/issues/31455)

## <small>3.7.1 (2025-01-09)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/apisix] Release 3.7.1 (#31272) ([199b715](https://github.com/bitnami/charts/commit/199b7151ef54c3cc81ca09813e28e2b2ade50f2d)), closes [#31272](https://github.com/bitnami/charts/issues/31272)

## 3.7.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/*] docs: :memo: Unify "Securing Traffic using TLS" section (#30707) ([b572333](https://github.com/bitnami/charts/commit/b57233336e4fe9af928ecb4f2a5f334011efb1bc)), closes [#30707](https://github.com/bitnami/charts/issues/30707)
* [bitnami/apisix] Detect non-standard images (#30861) ([0c989ce](https://github.com/bitnami/charts/commit/0c989ce546a26e91a94df349630d1ee3e9fa2a2a)), closes [#30861](https://github.com/bitnami/charts/issues/30861)

## <small>3.6.1 (2024-11-30)</small>

* [bitnami/apisix] Release 3.6.1 (#30695) ([292979c](https://github.com/bitnami/charts/commit/292979cddcab9e5228ff2e52f06f7559530ea7cd)), closes [#30695](https://github.com/bitnami/charts/issues/30695)

## 3.6.0 (2024-11-29)

* [bitnami/*] docs: :memo: Add "Prometheus metrics" (batch 1) (#30660) ([7409ca4](https://github.com/bitnami/charts/commit/7409ca4c21869fabe1532dd4f3ff24895df71c6d)), closes [#30660](https://github.com/bitnami/charts/issues/30660)
* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/apisix] feat: :sparkles: :memo: Allow password update via values.yaml (#30682) ([e41a46c](https://github.com/bitnami/charts/commit/e41a46c06a70ddfe543c9afa1fd81cd8fd2d97cd)), closes [#30682](https://github.com/bitnami/charts/issues/30682)

## <small>3.5.2 (2024-10-21)</small>

* [bitnami/apisix] Release 3.5.2 (#30014) ([53d7503](https://github.com/bitnami/charts/commit/53d7503654c7179d92e4352fc85d50db202a15f8)), closes [#30014](https://github.com/bitnami/charts/issues/30014)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## <small>3.5.1 (2024-09-29)</small>

* [bitnami/apisix] Release 3.5.1 (#29652) ([d4851f4](https://github.com/bitnami/charts/commit/d4851f402eae31a590ec6275226b3cfb449a47c7)), closes [#29652](https://github.com/bitnami/charts/issues/29652)

## 3.5.0 (2024-09-23)

* [bitnami/apisix] Allow setting externalIPs for services (#29550) ([5b2d4c1](https://github.com/bitnami/charts/commit/5b2d4c132c34f01450069aec521b579a726708ec)), closes [#29550](https://github.com/bitnami/charts/issues/29550)

## 3.4.0 (2024-09-13)

* [bitnami/apisix] Allow IngressClass to be created conditionally (#29085) ([32f63b4](https://github.com/bitnami/charts/commit/32f63b4d1574d344e568db396accdeef0d795d6e)), closes [#29085](https://github.com/bitnami/charts/issues/29085)

## <small>3.3.11 (2024-09-04)</small>

* [bitnami/apisix] Added multi-auth plugin to the plugins list (#29170) ([69939ca](https://github.com/bitnami/charts/commit/69939ca7692fd60533132f03d039f5bd9db1f573)), closes [#29170](https://github.com/bitnami/charts/issues/29170)

## <small>3.3.10 (2024-08-20)</small>

* [bitnami/apisix] Release 3.3.10 (#28942) ([f7bd58e](https://github.com/bitnami/charts/commit/f7bd58e4b2842e0bf1bf2dcd0288beea98dd87a9)), closes [#28942](https://github.com/bitnami/charts/issues/28942)

## <small>3.3.9 (2024-07-25)</small>

* [bitnami/apisix] Release 3.3.9 (#28396) ([399e694](https://github.com/bitnami/charts/commit/399e69482bcb220bdd04fc18212de4ceafc83e46)), closes [#28396](https://github.com/bitnami/charts/issues/28396)

## <small>3.3.8 (2024-07-24)</small>

* [bitnami/apisix] Release 3.3.8 (#28267) ([1cfe3bc](https://github.com/bitnami/charts/commit/1cfe3bcd8be4dbff16ef68fd40037befe97bc656)), closes [#28267](https://github.com/bitnami/charts/issues/28267)

## <small>3.3.7 (2024-07-23)</small>

* [bitnami/apisix] Release 3.3.7 (#28227) ([fd667ad](https://github.com/bitnami/charts/commit/fd667ad8d2e343247b389e5f5f128a634c41d68e)), closes [#28227](https://github.com/bitnami/charts/issues/28227)

## <small>3.3.6 (2024-07-16)</small>

* [bitnami/apisix] Global StorageClass as default value (#27997) ([d280b1e](https://github.com/bitnami/charts/commit/d280b1e357dfb1db422ebd955260ada65071f3cb)), closes [#27997](https://github.com/bitnami/charts/issues/27997)

## <small>3.3.5 (2024-07-16)</small>

* [bitnami/apisix] Correct type at loadBalancerSourceRanges (#27985) ([fa74d4b](https://github.com/bitnami/charts/commit/fa74d4b7af146ec18c7f17776432016428422b68)), closes [#27985](https://github.com/bitnami/charts/issues/27985)

## <small>3.3.4 (2024-07-16)</small>

* [bitnami/apisix] wait container: support self-generated certificates at etcd (#27947) ([e816b4a](https://github.com/bitnami/charts/commit/e816b4a249e0212ea6378bd31657661c5ac234a3)), closes [#27947](https://github.com/bitnami/charts/issues/27947)

## <small>3.3.3 (2024-07-10)</small>

* [bitnami/apisix] Correct service port name in control plane ingress (#27839) ([769db5e](https://github.com/bitnami/charts/commit/769db5e671e228bf2c74cc7c1b7d7b9079ff1e2a)), closes [#27839](https://github.com/bitnami/charts/issues/27839)

## <small>3.3.2 (2024-07-08)</small>

* [bitnami/apisix] Updated jsonschema to allow string values for fields passed to tpl (#27441) ([d3967c3](https://github.com/bitnami/charts/commit/d3967c3c5308e70f54028e67328552523d2358b4)), closes [#27441](https://github.com/bitnami/charts/issues/27441)

## <small>3.3.1 (2024-07-03)</small>

* [bitnami/apisix] Release 3.3.1 (#27686) ([79fa0ac](https://github.com/bitnami/charts/commit/79fa0acb8beae9fa77fa0cb9081ea2e5fe0b0535)), closes [#27686](https://github.com/bitnami/charts/issues/27686)

## 3.3.0 (2024-06-28)

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/apisix] Add IngressClass for Ingress Controller (#27568) ([40b3153](https://github.com/bitnami/charts/commit/40b3153cf66e9c2dd9454c92c6d8f43b12ed5d42)), closes [#27568](https://github.com/bitnami/charts/issues/27568)

## <small>3.2.5 (2024-06-20)</small>

* [bitnami/apisix] Fix typo Mastodon -> APISIX (#27433) ([a5d7c12](https://github.com/bitnami/charts/commit/a5d7c12f999559bd982cf0516f93241f6db253a1)), closes [#27433](https://github.com/bitnami/charts/issues/27433)
* [bitnami/apisix] Fixes to support running Apisix in standalone mode (#27062) ([272a58e](https://github.com/bitnami/charts/commit/272a58e82291f619fed91936bd117151e3d68db4)), closes [#27062](https://github.com/bitnami/charts/issues/27062)

## <small>3.2.4 (2024-06-18)</small>

* [bitnami/apisix] Release 3.2.4 (#27329) ([991b820](https://github.com/bitnami/charts/commit/991b820e187ea80c4b16146128af9c4d06df03ee)), closes [#27329](https://github.com/bitnami/charts/issues/27329)

## <small>3.2.3 (2024-06-17)</small>

* [bitnami/apisix] Release 3.2.3 (#27199) ([1a6ef72](https://github.com/bitnami/charts/commit/1a6ef72e257eae3a9445085614ad7083d3f37930)), closes [#27199](https://github.com/bitnami/charts/issues/27199)

## <small>3.2.2 (2024-06-06)</small>

* [bitnami/apisix] Release 3.2.2 (#26936) ([b67410a](https://github.com/bitnami/charts/commit/b67410a9a295dd0ee8b81369acfe29dbfe3e5d50)), closes [#26936](https://github.com/bitnami/charts/issues/26936)

## <small>3.2.1 (2024-06-06)</small>

* [bitnami/apisix] Release 3.2.1 (#26891) ([50be215](https://github.com/bitnami/charts/commit/50be215d066511e6181ee874e51c5496a1b7a72c)), closes [#26891](https://github.com/bitnami/charts/issues/26891)

## 3.2.0 (2024-06-06)

* [bitnami/apisix] Enable PodDisruptionBudgets (#26711) ([72db65f](https://github.com/bitnami/charts/commit/72db65ff343d7522b8836bc2f112c43588c83912)), closes [#26711](https://github.com/bitnami/charts/issues/26711)

## <small>3.1.3 (2024-06-05)</small>

* [bitnami/apisix] Bump chart version (#26819) ([a68d34d](https://github.com/bitnami/charts/commit/a68d34d6314f9f2de578969146e62b33f42dc4a0)), closes [#26819](https://github.com/bitnami/charts/issues/26819)

## <small>3.1.2 (2024-06-05)</small>

* [bitnami/apisix] Bump chart version (#26761) ([85c6bf2](https://github.com/bitnami/charts/commit/85c6bf23151bdd8fc4a651152959fb05fed024ec)), closes [#26761](https://github.com/bitnami/charts/issues/26761)

## <small>3.1.1 (2024-05-23)</small>

* [bitnami/apisix] Use different liveness/readiness probes (#26337) ([b9e533c](https://github.com/bitnami/charts/commit/b9e533cb5bc8ee31882457136c00e4d253941797)), closes [#26337](https://github.com/bitnami/charts/issues/26337)

## 3.1.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/apisix] feat: :sparkles: :lock: Add warning when original images are replaced (#26180) ([ff34236](https://github.com/bitnami/charts/commit/ff34236e01aca549eeba0a9e67544d5d562a6da8)), closes [#26180](https://github.com/bitnami/charts/issues/26180)

## <small>3.0.6 (2024-05-17)</small>

* [bitnami/apisix] Release 3.0.6 updating components versions (#25998) ([8277ffb](https://github.com/bitnami/charts/commit/8277ffb22a4acb228f4970ff491e34a6db5a7195)), closes [#25998](https://github.com/bitnami/charts/issues/25998)

## <small>3.0.5 (2024-05-13)</small>

* [bitnami/apisix] Release 3.0.5 updating components versions (#25738) ([cbe8f03](https://github.com/bitnami/charts/commit/cbe8f03d95152df967b4c46b37c2312d84db0107)), closes [#25738](https://github.com/bitnami/charts/issues/25738)

## <small>3.0.4 (2024-05-13)</small>

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/apisix] Release 3.0.4 (#25695) ([7ee0ee7](https://github.com/bitnami/charts/commit/7ee0ee7d2de6235716d1f6c1eeceb1cfc697bc1c)), closes [#25695](https://github.com/bitnami/charts/issues/25695)
* [bitnami/multiple charts] Fix typo: "NetworkPolice" vs "NetworkPolicy" (#25348) ([6970c1b](https://github.com/bitnami/charts/commit/6970c1ba245873506e73d459c6eac1e4919b778f)), closes [#25348](https://github.com/bitnami/charts/issues/25348)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## <small>3.0.3 (2024-04-24)</small>

* [bitnami/apisix] Release 3.0.3 (#25355) ([933cba1](https://github.com/bitnami/charts/commit/933cba1d35db8b5c1c4146f0c7207dc30b170f1c)), closes [#25355](https://github.com/bitnami/charts/issues/25355)

## <small>3.0.2 (2024-04-09)</small>

* [bitnami/apisix] fix: :bug: :lock: Do not expose http-metrics unless metrics.enabled=true (#25041) ([e35f1d6](https://github.com/bitnami/charts/commit/e35f1d65e23e5a282f5e832cb279f3ba9eef3f8f)), closes [#25041](https://github.com/bitnami/charts/issues/25041)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## <small>3.0.1 (2024-03-22)</small>

* [bitnami/apisix] Fix disable tls on controlPlane and dataPlane (#24600) ([0a85409](https://github.com/bitnami/charts/commit/0a85409d3a32eb43ff3862b95a3a6d7d9c9450c5)), closes [#24600](https://github.com/bitnami/charts/issues/24600)

## 3.0.0 (2024-03-19)

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* [bitnami/apisix] feat!: :lock: :boom: Improve security defaults (#24509) ([25ba86e](https://github.com/bitnami/charts/commit/25ba86e67492acd60ab463d9ebd9a52ee72fe354)), closes [#24509](https://github.com/bitnami/charts/issues/24509)

## 2.10.0 (2024-03-06)

* [bitnami/apisix] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v2 SCC (# ([6e5bd3e](https://github.com/bitnami/charts/commit/6e5bd3ef90e457d6ee0f3b7984707b92fd014e03)), closes [#24061](https://github.com/bitnami/charts/issues/24061)

## 2.9.0 (2024-02-27)

* [bitnami/apisix] feat: :sparkles: :lock: Add runAsGroup (#23874) ([166932f](https://github.com/bitnami/charts/commit/166932f59c7625187cab5a04453582f5b169e1c0)), closes [#23874](https://github.com/bitnami/charts/issues/23874)

## <small>2.8.2 (2024-02-21)</small>

* [bitnami/apisix] Release 2.8.2 updating components versions (#23733) ([7946235](https://github.com/bitnami/charts/commit/7946235da8cf482a26ba7c4cbd3977d96056bc4d)), closes [#23733](https://github.com/bitnami/charts/issues/23733)

## <small>2.8.1 (2024-02-21)</small>

* [bitnami/apisix] Release 2.8.1 updating components versions (#23628) ([a5a7f2f](https://github.com/bitnami/charts/commit/a5a7f2f3f0c7621f1d443661896b8e1f8980b02b)), closes [#23628](https://github.com/bitnami/charts/issues/23628)

## 2.8.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## 2.7.0 (2024-02-16)

* [bitnami/apisix] feat: :sparkles: :lock: Add resource preset support (#23429) ([98bc8f0](https://github.com/bitnami/charts/commit/98bc8f0994b87bff7382d52268eaa1cdfb9b7730)), closes [#23429](https://github.com/bitnami/charts/issues/23429)

## <small>2.6.1 (2024-02-14)</small>

* fix: allow disabling tls for dashboard and ingressController properly (#23389) ([633d712](https://github.com/bitnami/charts/commit/633d7125d19e7c6cd672658fed4a7bf23f12f1b9)), closes [#23389](https://github.com/bitnami/charts/issues/23389)

## 2.6.0 (2024-02-13)

* [bitnami/apisix] feat: :lock: Enable networkPolicy (#23365) ([98d94a8](https://github.com/bitnami/charts/commit/98d94a899968ea8369c385e965f73623bea28bf6)), closes [#23365](https://github.com/bitnami/charts/issues/23365)

## <small>2.5.8 (2024-02-09)</small>

* [bitnami/apisix] Release 2.5.8 updating components versions (#23367) ([0ab18bd](https://github.com/bitnami/charts/commit/0ab18bd9efb01fb2b1c0310148970593b0259cee)), closes [#23367](https://github.com/bitnami/charts/issues/23367)

## <small>2.5.7 (2024-02-09)</small>

* [bitnami/apisix] Release 2.5.7 updating components versions (#23366) ([20003a3](https://github.com/bitnami/charts/commit/20003a38cfd0ee96121f2c99ddfef1dc60dec9e6)), closes [#23366](https://github.com/bitnami/charts/issues/23366)

## <small>2.5.6 (2024-02-05)</small>

* [bitnami/apisix] Release 2.5.6 updating components versions (#23154) ([9b5de30](https://github.com/bitnami/charts/commit/9b5de30e9a21520dab21ae5bd3d3c022cda5b7c8)), closes [#23154](https://github.com/bitnami/charts/issues/23154)

## <small>2.5.5 (2024-02-01)</small>

* [bitnami/apisix] Release 2.5.5 updating components versions (#23011) ([a3944a2](https://github.com/bitnami/charts/commit/a3944a21a4a8cc75879255dc9464381ed5e0e90d)), closes [#23011](https://github.com/bitnami/charts/issues/23011)

## <small>2.5.4 (2024-01-31)</small>

* [bitnami/apisix] Update CRDs and add headers for automatic update (#22883) ([f827a92](https://github.com/bitnami/charts/commit/f827a927d9013930d94e60a7fd82c0edfe078faf)), closes [#22883](https://github.com/bitnami/charts/issues/22883)

## <small>2.5.3 (2024-01-30)</small>

* [bitnami/apisix] Release 2.5.3 updating components versions (#22845) ([f9819d9](https://github.com/bitnami/charts/commit/f9819d96fe31818230285670de2b50996fc09739)), closes [#22845](https://github.com/bitnami/charts/issues/22845)

## <small>2.5.2 (2024-01-25)</small>

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/apisix] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22567) ([6829af8](https://github.com/bitnami/charts/commit/6829af8b96ee8ce999da4230103b1c7c4b77622e)), closes [#22567](https://github.com/bitnami/charts/issues/22567)

## <small>2.5.1 (2024-01-22)</small>

* [bitnami/apisix] fix: :bug: Enable liveness probe (#22520) ([37434b9](https://github.com/bitnami/charts/commit/37434b9b3871354630be44e12f484a630ef97713)), closes [#22520](https://github.com/bitnami/charts/issues/22520)

## 2.5.0 (2024-01-19)

* [bitnami/apisix] fix: :lock: Move service-account token auto-mount to pod declaration (#22383) ([b0d9555](https://github.com/bitnami/charts/commit/b0d955566b932bdd30d1eec409caea91a77c0f07)), closes [#22383](https://github.com/bitnami/charts/issues/22383)

## <small>2.4.3 (2024-01-18)</small>

* [bitnami/apisix] Release 2.4.3 updating components versions (#22342) ([a86706d](https://github.com/bitnami/charts/commit/a86706d2e52ea0ee9e56be4da49eec46a0ba94c6)), closes [#22342](https://github.com/bitnami/charts/issues/22342)

## <small>2.4.2 (2024-01-17)</small>

* Revert "[bitnami/apisix] feat: :lock: Allow limit access to secrets by namespace (#22224)" ([85fc083](https://github.com/bitnami/charts/commit/85fc083c026c8ded296c609be884848770dae769)), closes [#22224](https://github.com/bitnami/charts/issues/22224)

## <small>2.4.1 (2024-01-17)</small>

* [bitnami/apisix] Fixed the bug of disabling control-plane TLS (#22240) ([8dea304](https://github.com/bitnami/charts/commit/8dea3046ebfc70fd1e758486ad8b31fd13ce7ad8)), closes [#22240](https://github.com/bitnami/charts/issues/22240)

## 2.4.0 (2024-01-16)

* [bitnami/apisix] feat: :lock: Allow limit access to secrets by namespace (#22224) ([1866370](https://github.com/bitnami/charts/commit/18663701847c800ae088a774e6dcc959610fcb5f)), closes [#22224](https://github.com/bitnami/charts/issues/22224)

## 2.3.0 (2024-01-16)

* [bitnami/apisix] fix: :lock: Improve podSecurityContext and containerSecurityContext with essential  ([cb687e3](https://github.com/bitnami/charts/commit/cb687e363fefbe4a64761c7e05861b3aa69bdcf4)), closes [#22098](https://github.com/bitnami/charts/issues/22098)

## <small>2.2.9 (2024-01-15)</small>

* [bitnami/*] Fix docs.bitnami.com broken links (#21901) ([f35506d](https://github.com/bitnami/charts/commit/f35506d2dadee4f097986e7792df1f53ab215b5d)), closes [#21901](https://github.com/bitnami/charts/issues/21901)
* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)
* [bitnami/apisix] fix: :lock: Do not mount service account token unless necessary (#21986) ([c6414aa](https://github.com/bitnami/charts/commit/c6414aa21e14d17cb407677d2cf515d1ecb78371)), closes [#21986](https://github.com/bitnami/charts/issues/21986)

## <small>2.2.8 (2023-12-31)</small>

* [bitnami/apisix] Release 2.2.8 updating components versions (#21798) ([56a7592](https://github.com/bitnami/charts/commit/56a7592a7d26c70a7716f741415cfc0d4f485759)), closes [#21798](https://github.com/bitnami/charts/issues/21798)

## <small>2.2.7 (2023-11-21)</small>

* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/apisix] Release 2.2.7 updating components versions (#21098) ([45ac9e1](https://github.com/bitnami/charts/commit/45ac9e142aeb2b56527570496b2ad348930ad269)), closes [#21098](https://github.com/bitnami/charts/issues/21098)

## <small>2.2.6 (2023-11-21)</small>

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/apisix] Release 2.2.6 updating components versions (#21077) ([99be4bf](https://github.com/bitnami/charts/commit/99be4bf4c1326fcf0592f26b7cd04d06d10d3152)), closes [#21077](https://github.com/bitnami/charts/issues/21077)

## <small>2.2.5 (2023-11-10)</small>

* [bitnami/apisix] fix: add missing etcd config for data-plane (#20576) ([301d9da](https://github.com/bitnami/charts/commit/301d9daa72b1e6428cbc785e4b52068dfc67a537)), closes [#20576](https://github.com/bitnami/charts/issues/20576)

## <small>2.2.4 (2023-11-08)</small>

* [bitnami/apisix] Release 2.2.4 updating components versions (#20720) ([fd561e1](https://github.com/bitnami/charts/commit/fd561e104f40f2cb1ff219b5c0b95bde469d3ee3)), closes [#20720](https://github.com/bitnami/charts/issues/20720)

## <small>2.2.3 (2023-11-06)</small>

* [bitnami/apisix] Fix ingress template (#18255) ([41bc0e3](https://github.com/bitnami/charts/commit/41bc0e3015c7a7ce103261d51d137251aa85dcd3)), closes [#18255](https://github.com/bitnami/charts/issues/18255)

## <small>2.2.2 (2023-11-04)</small>

* [bitnami/apisix] Release 2.2.2 updating components versions (#20620) ([20f8a17](https://github.com/bitnami/charts/commit/20f8a17543c4ca6efd9b9859c1a90aaef596f77f)), closes [#20620](https://github.com/bitnami/charts/issues/20620)

## <small>2.2.1 (2023-11-04)</small>

* [bitnami/apisix] Release 2.2.1 updating components versions (#20619) ([a433454](https://github.com/bitnami/charts/commit/a433454acfc19a579797df861563cb1e45962cc2)), closes [#20619](https://github.com/bitnami/charts/issues/20619)

## 2.2.0 (2023-10-31)

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [bitnami/apisix] feat: :sparkles: Add support for PSA restricted policy (#20419) ([a82dad6](https://github.com/bitnami/charts/commit/a82dad6b879481868097cdc7360225be30b4e36d)), closes [#20419](https://github.com/bitnami/charts/issues/20419)

## <small>2.1.4 (2023-10-15)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/apisix] Release 2.1.4 (#20178) ([f645841](https://github.com/bitnami/charts/commit/f645841ba6245eb47c72c51ed55b82c65a98c748)), closes [#20178](https://github.com/bitnami/charts/issues/20178)

## <small>2.1.3 (2023-09-19)</small>

* [bitnami/*] Update readme files (#19277) ([e56aeb2](https://github.com/bitnami/charts/commit/e56aeb2fbfbf5b6e42375db48cc7ae1ef1c3a823)), closes [#19277](https://github.com/bitnami/charts/issues/19277)
* [bitnami/apisix] Use different app.kubernetes.io/version label on subcomponents (#19325) ([61653c9](https://github.com/bitnami/charts/commit/61653c9b9f19ad7d15ace79980e913b7267d7059)), closes [#19325](https://github.com/bitnami/charts/issues/19325)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>2.1.2 (2023-09-08)</small>

* [bitnami/apisix]: Use merge helper (#19020) ([3fa3cb4](https://github.com/bitnami/charts/commit/3fa3cb4ae9cabe1cc9745f42214475542c889f72)), closes [#19020](https://github.com/bitnami/charts/issues/19020)

## <small>2.1.1 (2023-09-01)</small>

* [bitnami/apisix] Release 2.1.1 (#18986) ([6d142f7](https://github.com/bitnami/charts/commit/6d142f7693b17631b042d8369a431008b4ff130a)), closes [#18986](https://github.com/bitnami/charts/issues/18986)

## 2.1.0 (2023-08-29)

* [bitnami/apisix] Support for customizing standard labels (#18456) ([8f45915](https://github.com/bitnami/charts/commit/8f45915be3481a9184a9940530dab1d3e1dcaf0d)), closes [#18456](https://github.com/bitnami/charts/issues/18456)

## <small>2.0.10 (2023-08-19)</small>

* [bitnami/apisix] Release 2.0.10 (#18644) ([f0494e8](https://github.com/bitnami/charts/commit/f0494e86f6f7d4c0b2f839ea6b1639f40a00945c)), closes [#18644](https://github.com/bitnami/charts/issues/18644)

## <small>2.0.9 (2023-08-17)</small>

* [bitnami/apisix] Release 2.0.9 (#18497) ([ab7de5c](https://github.com/bitnami/charts/commit/ab7de5c0183582c52b68a11a176ebbc48962316b)), closes [#18497](https://github.com/bitnami/charts/issues/18497)

## <small>2.0.8 (2023-08-08)</small>

* [bitnami/apisix] chore: :page_facing_up: Remove license in CRDs (#18257) ([ca830ba](https://github.com/bitnami/charts/commit/ca830ba72226e923335c49928810202a9129d440)), closes [#18257](https://github.com/bitnami/charts/issues/18257)

## <small>2.0.7 (2023-07-25)</small>

* [bitnami/apisix] Release 2.0.7 (#17856) ([1db0ec6](https://github.com/bitnami/charts/commit/1db0ec66d32dabe036934c1fafcb43445c30bc18)), closes [#17856](https://github.com/bitnami/charts/issues/17856)

## <small>2.0.6 (2023-07-20)</small>

* [bitnami/apisix] Release 2.0.6 (#17801) ([9660e28](https://github.com/bitnami/charts/commit/9660e28fcf3add80ca7ef96cd9a84dda62ac82c5)), closes [#17801](https://github.com/bitnami/charts/issues/17801)

## <small>2.0.5 (2023-07-20)</small>

* [bitnami/apisix] Release 2.0.5 (#17792) ([7ea0ee3](https://github.com/bitnami/charts/commit/7ea0ee395e68db6d41774b10b38b172f6724e5eb)), closes [#17792](https://github.com/bitnami/charts/issues/17792)

## <small>2.0.4 (2023-07-15)</small>

* [bitnami/apisix] Release 2 (#17599) ([d76f9b7](https://github.com/bitnami/charts/commit/d76f9b7860be1a2ae7ea509f9a1562f48f436766)), closes [#17599](https://github.com/bitnami/charts/issues/17599)

## <small>2.0.3 (2023-07-12)</small>

* [bitnami/apisix] Reorder chart dependencies (#17583) ([31e5bc6](https://github.com/bitnami/charts/commit/31e5bc60ee2422a528f987ec066b453ab847da2a)), closes [#17583](https://github.com/bitnami/charts/issues/17583)
* Use os-shell in tempate and Jaeger runtime params (#17557) ([91a49eb](https://github.com/bitnami/charts/commit/91a49eb1e3c81c7b7c6c28d1bc5d6d6ae698c1e2)), closes [#17557](https://github.com/bitnami/charts/issues/17557)

## <small>2.0.2 (2023-06-29)</small>

* [bitnami/apisix] Add the plugins list to the dashboard default config (#17289) ([45a6c7d](https://github.com/bitnami/charts/commit/45a6c7d5a762eae814334c7781a5b6666df5a66b)), closes [#17289](https://github.com/bitnami/charts/issues/17289)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)

## <small>2.0.1 (2023-06-22)</small>

* [bitnami/apisix] Release 2.0.1 (#17316) ([eba8256](https://github.com/bitnami/charts/commit/eba825681f1f9fe8f186d041982012335032da08)), closes [#17316](https://github.com/bitnami/charts/issues/17316)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## 2.0.0 (2023-06-19)

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/apisix] Upgrade etcd dependency (#17185) ([d3f1c61](https://github.com/bitnami/charts/commit/d3f1c61666183cd6d35b82b1bafca3b967553747)), closes [#17185](https://github.com/bitnami/charts/issues/17185)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)

## <small>1.0.1 (2023-05-23)</small>

* [bitnami/apisix] Release 1.0.1 (#16886) ([2369235](https://github.com/bitnami/charts/commit/2369235265dec7ce93488dda949a405c57a6e885)), closes [#16886](https://github.com/bitnami/charts/issues/16886)

## 1.0.0 (2023-05-23)

* [bitnami/apisix] Release 1.0.0 (#16884) ([3e55063](https://github.com/bitnami/charts/commit/3e55063583a6fa68fead339c86f83c51b6b8a6ad)), closes [#16884](https://github.com/bitnami/charts/issues/16884)

## 0.1.0 (2023-05-23)

* [bitnami/apisix] feat: :tada: Add chart (#16851) ([a289c26](https://github.com/bitnami/charts/commit/a289c260d4ff8e9092e4ea000cbc3872e4f9a8de)), closes [#16851](https://github.com/bitnami/charts/issues/16851)
