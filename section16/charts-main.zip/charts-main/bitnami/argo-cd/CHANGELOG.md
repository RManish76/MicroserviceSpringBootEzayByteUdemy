# Changelog

## 11.0.2 (2025-10-22)

* [bitnami/argo-cd] Fix check for ArgoCD controller replica count ([#36347](https://github.com/bitnami/charts/pull/36347))

## 11.0.0 (2025-08-26)

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#36194) ([fadecb6](https://github.com/bitnami/charts/commit/fadecb6be452fe2abf2e0b57df4bd40d4961521d)), closes [#36194](https://github.com/bitnami/charts/issues/36194)

## <small>10.0.4 (2025-08-25)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#36186) ([d52d321](https://github.com/bitnami/charts/commit/d52d3216422331ce38a436a54fcaccc39674b0dc)), closes [#36186](https://github.com/bitnami/charts/issues/36186)

## <small>10.0.3 (2025-08-18)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#36130) ([cc7aefa](https://github.com/bitnami/charts/commit/cc7aefa743f0a1dcdd5b483e02fc8b8d3731fcd8)), closes [#36130](https://github.com/bitnami/charts/issues/36130)

## <small>10.0.2 (2025-08-13)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#35798) ([6a1c34b](https://github.com/bitnami/charts/commit/6a1c34bbf0f441b5642905e16fb9ce0f1e41ba7d)), closes [#35798](https://github.com/bitnami/charts/issues/35798)

## <small>10.0.1 (2025-08-13)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#35792) ([5298baa](https://github.com/bitnami/charts/commit/5298baa73c61b7d41c766fda78d126afd0de0902)), closes [#35792](https://github.com/bitnami/charts/issues/35792)

## 10.0.0 (2025-08-11)

* [bitnami/argo-cd] Upgrade to Redis subchart 22 (#35727) ([2275937](https://github.com/bitnami/charts/commit/227593706189bbdb56c06a8615d05977929e9784)), closes [#35727](https://github.com/bitnami/charts/issues/35727)

## <small>9.0.39 (2025-08-08)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#35701) ([f5de559](https://github.com/bitnami/charts/commit/f5de5597eda831d60f77bf7c1d879c0b8fd50ba9)), closes [#35701](https://github.com/bitnami/charts/issues/35701)

## <small>9.0.38 (2025-08-07)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#35671) ([1e61465](https://github.com/bitnami/charts/commit/1e614652266eb47286db3b8294071ccbc9020b17)), closes [#35671](https://github.com/bitnami/charts/issues/35671)

## <small>9.0.37 (2025-08-07)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#35638) ([5602459](https://github.com/bitnami/charts/commit/56024596e95ccf3bb09da962e3d6f3bdb302e3dd)), closes [#35638](https://github.com/bitnami/charts/issues/35638)

## <small>9.0.36 (2025-08-07)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#35541) ([0141dce](https://github.com/bitnami/charts/commit/0141dce1eafcb941c6d97fd74d8776545c927383)), closes [#35541](https://github.com/bitnami/charts/issues/35541)

## <small>9.0.35 (2025-08-07)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#35464) ([35609aa](https://github.com/bitnami/charts/commit/35609aa010255463bc6637582adb190d49cb82c2)), closes [#35464](https://github.com/bitnami/charts/issues/35464)

## <small>9.0.34 (2025-08-06)</small>

* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#35453) ([4f31154](https://github.com/bitnami/charts/commit/4f31154d3e045bc63be0f7065d78204159371f7f)), closes [#35453](https://github.com/bitnami/charts/issues/35453)

## <small>9.0.33 (2025-07-25)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#35302) ([0ea2210](https://github.com/bitnami/charts/commit/0ea2210a304ed3f8ca8f614f5db78b3527f26315)), closes [#35302](https://github.com/bitnami/charts/issues/35302)

## <small>9.0.32 (2025-07-23)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#35264) ([62ff532](https://github.com/bitnami/charts/commit/62ff5324436c6fce6a8423f3eed49dc8c9fd43cf)), closes [#35264](https://github.com/bitnami/charts/issues/35264)

## <small>9.0.31 (2025-07-22)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/argo-cd] Remove duplicate `matchLabels` from applicationset `ServiceMonitor` (#35221) ([8a5b631](https://github.com/bitnami/charts/commit/8a5b631db38db4c9b9fd411c205746549759491e)), closes [#35221](https://github.com/bitnami/charts/issues/35221)

## <small>9.0.30 (2025-07-15)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#35083) ([c0e11e9](https://github.com/bitnami/charts/commit/c0e11e996e67659b2bb335a051fd8c525cbcbf01)), closes [#35083](https://github.com/bitnami/charts/issues/35083)

## <small>9.0.29 (2025-07-10)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34993) ([e40a5c2](https://github.com/bitnami/charts/commit/e40a5c2288a2472c8a4a8b7e4979414b817fe563)), closes [#34993](https://github.com/bitnami/charts/issues/34993)

## <small>9.0.28 (2025-07-08)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34885) ([303e461](https://github.com/bitnami/charts/commit/303e4619e9fefd4aaa788c988ecdc5225268d0c7)), closes [#34885](https://github.com/bitnami/charts/issues/34885)

## <small>9.0.27 (2025-07-08)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34873) ([a0b52e5](https://github.com/bitnami/charts/commit/a0b52e54449e17de8d30d4e9e9034163ed9eba93)), closes [#34873](https://github.com/bitnami/charts/issues/34873)

## <small>9.0.26 (2025-07-06)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34817) ([79386fb](https://github.com/bitnami/charts/commit/79386fbc2708eff04a811e86e4ce162bd2fd5c6a)), closes [#34817](https://github.com/bitnami/charts/issues/34817)

## <small>9.0.25 (2025-06-28)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34700) ([fda645b](https://github.com/bitnami/charts/commit/fda645b0fd169b6b86f6f12afadb2887f4495802)), closes [#34700](https://github.com/bitnami/charts/issues/34700)

## <small>9.0.24 (2025-06-26)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34646) ([7cfd3de](https://github.com/bitnami/charts/commit/7cfd3dec72e774a2ce96eaf4e8eef8fc82ef032f)), closes [#34646](https://github.com/bitnami/charts/issues/34646)

## <small>9.0.23 (2025-06-25)</small>

* [bitnami/argo-cd] Update dependencies (#34617) ([860d135](https://github.com/bitnami/charts/commit/860d135a63fe4c9321676bcd73fc9a6299b7ac67)), closes [#34617](https://github.com/bitnami/charts/issues/34617)

## <small>9.0.22 (2025-06-18)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34538) ([344ec9f](https://github.com/bitnami/charts/commit/344ec9fcb5fa865d6fed6e5fc9cc4d497babe34d)), closes [#34538](https://github.com/bitnami/charts/issues/34538)

## <small>9.0.21 (2025-06-16)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34523) ([e440e5d](https://github.com/bitnami/charts/commit/e440e5d030876af7f8487b4cc7c1bc35e6c5abaf)), closes [#34523](https://github.com/bitnami/charts/issues/34523)

## <small>9.0.20 (2025-06-13)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34420) ([c169d18](https://github.com/bitnami/charts/commit/c169d180cb7fdcb9d2ec182506039897a803e58a)), closes [#34420](https://github.com/bitnami/charts/issues/34420)

## <small>9.0.19 (2025-06-13)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34396) ([f5ae584](https://github.com/bitnami/charts/commit/f5ae5849ee41983a5ce5a6c8269bff80a4edd96c)), closes [#34396](https://github.com/bitnami/charts/issues/34396)

## <small>9.0.18 (2025-06-09)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34285) ([067dd02](https://github.com/bitnami/charts/commit/067dd02367db81d5664ad0f989064e7a0251cead)), closes [#34285](https://github.com/bitnami/charts/issues/34285)

## <small>9.0.17 (2025-06-05)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34149) ([2ecca7a](https://github.com/bitnami/charts/commit/2ecca7a1ec00b60e74a8e4c419848f683c6de7d2)), closes [#34149](https://github.com/bitnami/charts/issues/34149)

## <small>9.0.16 (2025-06-05)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34139) ([9fa5c2f](https://github.com/bitnami/charts/commit/9fa5c2fe7d5bce4dca4dac07e62c01ad7b741d75)), closes [#34139](https://github.com/bitnami/charts/issues/34139)

## <small>9.0.15 (2025-05-30)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#34003) ([700b878](https://github.com/bitnami/charts/commit/700b878fadaf49b13a30b9012bbe78b5b8fb3bef)), closes [#34003](https://github.com/bitnami/charts/issues/34003)

## <small>9.0.14 (2025-05-29)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33980) ([604b71b](https://github.com/bitnami/charts/commit/604b71bad0db06d5393c959649f0485febe61b8c)), closes [#33980](https://github.com/bitnami/charts/issues/33980)

## <small>9.0.13 (2025-05-29)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33961) ([4cbfb93](https://github.com/bitnami/charts/commit/4cbfb93c445071af5e01ed89a7302c57649d7082)), closes [#33961](https://github.com/bitnami/charts/issues/33961)

## <small>9.0.12 (2025-05-28)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33941) ([4dd248e](https://github.com/bitnami/charts/commit/4dd248ea43da92b65a2d8eaacb0863c913c8d216)), closes [#33941](https://github.com/bitnami/charts/issues/33941)

## <small>9.0.11 (2025-05-27)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33913) ([ea83baa](https://github.com/bitnami/charts/commit/ea83baa53cf47ad605791dd96b28a5beb2c2f50a)), closes [#33913](https://github.com/bitnami/charts/issues/33913)

## <small>9.0.10 (2025-05-22)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33835) ([0ffafa3](https://github.com/bitnami/charts/commit/0ffafa362c5aae46e7ff9f91a28f5e2e89cf6029)), closes [#33835](https://github.com/bitnami/charts/issues/33835)

## <small>9.0.9 (2025-05-21)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33822) ([16598ac](https://github.com/bitnami/charts/commit/16598acabe1ad0194d7775c5212e21b451fc7a6e)), closes [#33822](https://github.com/bitnami/charts/issues/33822)

## <small>9.0.8 (2025-05-19)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33783) ([9f3119f](https://github.com/bitnami/charts/commit/9f3119fb789ab032492fb40b63f0bd3c3b761a72)), closes [#33783](https://github.com/bitnami/charts/issues/33783)

## <small>9.0.7 (2025-05-19)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33780) ([4f26bc1](https://github.com/bitnami/charts/commit/4f26bc10d6a8d87f7df58f56b5a43bc30eed9fe0)), closes [#33780](https://github.com/bitnami/charts/issues/33780)

## <small>9.0.6 (2025-05-16)</small>

* [bitnami/*] Update CNAB tip (#33741) ([2bc74f3](https://github.com/bitnami/charts/commit/2bc74f3f539481ceaa12833c114047583912b748)), closes [#33741](https://github.com/bitnami/charts/issues/33741)
* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33745) ([91cdd71](https://github.com/bitnami/charts/commit/91cdd7109c5d6af658b434494fdc650a12e097d3)), closes [#33745](https://github.com/bitnami/charts/issues/33745)

## <small>9.0.5 (2025-05-15)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33721) ([e9c7d52](https://github.com/bitnami/charts/commit/e9c7d52b630d75698ee5278aa704efc97be64ecf)), closes [#33721](https://github.com/bitnami/charts/issues/33721)

## <small>9.0.4 (2025-05-14)</small>

* [bitnami/*] Add CNAB link for charts on Azure MP (#33695) ([6312371](https://github.com/bitnami/charts/commit/63123718de94dbedd798d380807b57031e98ed4f)), closes [#33695](https://github.com/bitnami/charts/issues/33695)
* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33700) ([90355e1](https://github.com/bitnami/charts/commit/90355e188f6e26183edfcbd6d6076e3a3b52dcb5)), closes [#33700](https://github.com/bitnami/charts/issues/33700)

## <small>9.0.3 (2025-05-13)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33675) ([3a0ecb4](https://github.com/bitnami/charts/commit/3a0ecb462a567a195f599b4199c6086a513ff877)), closes [#33675](https://github.com/bitnami/charts/issues/33675)

## <small>9.0.2 (2025-05-13)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33665) ([4d1d7c3](https://github.com/bitnami/charts/commit/4d1d7c379fd42c0a196925816cd7b2f0a1770898)), closes [#33665](https://github.com/bitnami/charts/issues/33665)

## <small>9.0.1 (2025-05-13)</small>

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33662) ([7338c3c](https://github.com/bitnami/charts/commit/7338c3c3e735052654bdf2aa34aa031869db8755)), closes [#33662](https://github.com/bitnami/charts/issues/33662)
* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)

## 9.0.0 (2025-05-08)

* [bitnami/argo-cd] :zap: :arrow_up: Update dependency references (#33561) ([dc9d93c](https://github.com/bitnami/charts/commit/dc9d93c0a6f8fa77f3aa7475428904f2ace3b365)), closes [#33561](https://github.com/bitnami/charts/issues/33561)

## 8.0.0 (2025-05-07)

* [bitnami/argo-cd] feat!: :arrow_up: :boom: Bump Redis(R) to 8.0 (#33500) ([8a930f5](https://github.com/bitnami/charts/commit/8a930f5bf8e24160c337799d4d2da411db479de8)), closes [#33500](https://github.com/bitnami/charts/issues/33500)

## <small>7.3.8 (2025-05-07)</small>

* [bitnami/argo-cd] Release 7.3.8 (#33506) ([a6ea6f0](https://github.com/bitnami/charts/commit/a6ea6f0975c92a1430895f5d813ad92dbc20f7f9)), closes [#33506](https://github.com/bitnami/charts/issues/33506)

## <small>7.3.7 (2025-05-06)</small>

* [bitnami/argo-cd] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#33337 ([81eeb64](https://github.com/bitnami/charts/commit/81eeb64efc5548ed46b369612b23abe401644670)), closes [#33337](https://github.com/bitnami/charts/issues/33337)

## <small>7.3.6 (2025-04-22)</small>

* [bitnami/argo-cd] Release 7.3.6 (#33128) ([5468fc3](https://github.com/bitnami/charts/commit/5468fc3144ea9ccc2733c21b030cf5c0c11474ef)), closes [#33128](https://github.com/bitnami/charts/issues/33128)

## <small>7.3.5 (2025-04-09)</small>

* [bitnami/argo-cd] Release 7.3.5 (#32900) ([44eec2f](https://github.com/bitnami/charts/commit/44eec2f87473b4b9e2ff68d766cc3ca51f889487)), closes [#32900](https://github.com/bitnami/charts/issues/32900)

## <small>7.3.4 (2025-04-04)</small>

* [bitnami/argo-cd] Release 7.3.4 (#32817) ([5e5f51d](https://github.com/bitnami/charts/commit/5e5f51da2ebf0fdfa867e59673721b6a19a457e3)), closes [#32817](https://github.com/bitnami/charts/issues/32817)

## <small>7.3.3 (2025-04-02)</small>

* [bitnami/argo-cd] Release 7.3.3 (#32787) ([7908e5f](https://github.com/bitnami/charts/commit/7908e5faf01c42428a497d93f0aadd5af9bfbb3e)), closes [#32787](https://github.com/bitnami/charts/issues/32787)

## <small>7.3.2 (2025-04-01)</small>

* [bitnami/argo-cd] Release 7.3.2 (#32717) ([50928db](https://github.com/bitnami/charts/commit/50928db539e9e5e3a6667914b37054aabe8fbd77)), closes [#32717](https://github.com/bitnami/charts/issues/32717)

## <small>7.3.1 (2025-03-24)</small>

* [bitnami/argo-cd] Release 7.3.1 (#32585) ([bbe5469](https://github.com/bitnami/charts/commit/bbe546947f67cd71da25fafbf7920b888b93e8cd)), closes [#32585](https://github.com/bitnami/charts/issues/32585)

## 7.3.0 (2025-03-20)

* [bitnami/argo-cd] Revert usePasswordFiles (#32514) ([016a597](https://github.com/bitnami/charts/commit/016a597e764b446d97c17b1afff359ea778ecbd1)), closes [#32514](https://github.com/bitnami/charts/issues/32514)

## <small>7.2.6 (2025-03-19)</small>

* [bitnami/argo-cd] Release 7.2.6 (#32519) ([d87cdeb](https://github.com/bitnami/charts/commit/d87cdeb893d9d3648c633506688e5961a5c88a1c)), closes [#32519](https://github.com/bitnami/charts/issues/32519)

## <small>7.2.5 (2025-03-18)</small>

* [bitnami/argo-cd] Release 7.2.5 (#32500) ([fbd0309](https://github.com/bitnami/charts/commit/fbd03096412bb47cfcea68313db5b6bc4b26da42)), closes [#32500](https://github.com/bitnami/charts/issues/32500)

## <small>7.2.4 (2025-03-18)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/argo-cd] Fix redis password not read when using passwordFiles (#32477) ([12ba544](https://github.com/bitnami/charts/commit/12ba544f66f96aaf966851129f1da684dd19363a)), closes [#32477](https://github.com/bitnami/charts/issues/32477)

## <small>7.2.3 (2025-03-11)</small>

* [bitnami/argo-cd] Release 7.2.3 (#32390) ([a2c149b](https://github.com/bitnami/charts/commit/a2c149b171e9dcb86ac2d67d06c08be894b4ca76)), closes [#32390](https://github.com/bitnami/charts/issues/32390)

## <small>7.2.2 (2025-03-04)</small>

* [bitnami/argo-cd] Release 7.2.2 (#32282) ([1ade191](https://github.com/bitnami/charts/commit/1ade1913a84d4c1547700e80fe11366bcbe943c2)), closes [#32282](https://github.com/bitnami/charts/issues/32282)

## <small>7.2.1 (2025-02-28)</small>

* [bitnami/argo-cd] Release 7.2.1 (#32207) ([35852d5](https://github.com/bitnami/charts/commit/35852d579f9f1a4e533a11da606da30b565211ef)), closes [#32207](https://github.com/bitnami/charts/issues/32207)

## 7.2.0 (2025-02-24)

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/argo-cd] Add support for `usePasswordFiles` (#32079) ([d9a4702](https://github.com/bitnami/charts/commit/d9a4702bfd5ac892d2cebaa9fc076dc39d0ca792)), closes [#32079](https://github.com/bitnami/charts/issues/32079)

## <small>7.1.10 (2025-02-06)</small>

* [bitnami/argo-cd] Release 7.1.10 (#31804) ([c0db7b0](https://github.com/bitnami/charts/commit/c0db7b02d6129b86c343c8d65fa920b8e848670f)), closes [#31804](https://github.com/bitnami/charts/issues/31804)

## <small>7.1.9 (2025-02-04)</small>

* [bitnami/argo-cd] Release 7.1.9 (#31742) ([9b9fcab](https://github.com/bitnami/charts/commit/9b9fcab97ce33907aa00c9eed1df6b34cd523db6)), closes [#31742](https://github.com/bitnami/charts/issues/31742)

## <small>7.1.8 (2025-02-03)</small>

* [bitnami/argo-cd] Release 7.1.8 (#31722) ([3db13e6](https://github.com/bitnami/charts/commit/3db13e640b2abcc8a44e0048876ce18af6e6c89c)), closes [#31722](https://github.com/bitnami/charts/issues/31722)

## <small>7.1.7 (2025-02-03)</small>

* [bitnami/argo-cd] Release 7.1.7 (#31720) ([6582c58](https://github.com/bitnami/charts/commit/6582c58974517ed00e5fe29396f2158944a54ac5)), closes [#31720](https://github.com/bitnami/charts/issues/31720)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## <small>7.1.6 (2025-01-29)</small>

* [bitnami/argo-cd] Release 7.1.6 (#31669) ([6408979](https://github.com/bitnami/charts/commit/640897954d9a69e87b9f6de76bde9db27e1d3454)), closes [#31669](https://github.com/bitnami/charts/issues/31669)

## <small>7.1.5 (2025-01-24)</small>

* [bitnami/argo-cd] Release 7.1.5 (#31541) ([71993b6](https://github.com/bitnami/charts/commit/71993b6e801a3c0d1308e4be88d8f14ce26a8cab)), closes [#31541](https://github.com/bitnami/charts/issues/31541)

## <small>7.1.4 (2025-01-16)</small>

* [bitnami/argo-cd] Release 7.1.4 (#31407) ([aef6466](https://github.com/bitnami/charts/commit/aef6466f8b9ee9d19b37dccd89d612673b487723)), closes [#31407](https://github.com/bitnami/charts/issues/31407)

## <small>7.1.3 (2025-01-14)</small>

* [bitnami/argo-cd] Release 7.1.3 (#31363) ([a6f0eb1](https://github.com/bitnami/charts/commit/a6f0eb19404e6760719e2f41c1f84c42adf49005)), closes [#31363](https://github.com/bitnami/charts/issues/31363)

## <small>7.1.2 (2025-01-03)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/argo-cd] Release 7.1.2 (#31213) ([315299e](https://github.com/bitnami/charts/commit/315299e498e0b75494787fe330da6a029d4b8f7d)), closes [#31213](https://github.com/bitnami/charts/issues/31213)

## <small>7.1.1 (2024-12-11)</small>

* [bitnami/argo-cd] Release 7.1.1 (#30999) ([bff1f8c](https://github.com/bitnami/charts/commit/bff1f8c9c8a57a9dedd26997253ad122671d0153)), closes [#30999](https://github.com/bitnami/charts/issues/30999)

## 7.1.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/argo-cd] Detect non-standard images (#30862) ([bfac8cc](https://github.com/bitnami/charts/commit/bfac8cc4ac38af311b6f5d0eab29028a2431b68c)), closes [#30862](https://github.com/bitnami/charts/issues/30862)

## <small>7.0.26 (2024-12-03)</small>

* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/*] docs: :memo: Add "Prometheus metrics" (batch 1) (#30660) ([7409ca4](https://github.com/bitnami/charts/commit/7409ca4c21869fabe1532dd4f3ff24895df71c6d)), closes [#30660](https://github.com/bitnami/charts/issues/30660)
* [bitnami/*] docs: :memo: Unify "Securing Traffic using TLS" section (#30707) ([b572333](https://github.com/bitnami/charts/commit/b57233336e4fe9af928ecb4f2a5f334011efb1bc)), closes [#30707](https://github.com/bitnami/charts/issues/30707)
* [bitnami/argo-cd] Release 7.0.26 (#30743) ([70bd184](https://github.com/bitnami/charts/commit/70bd184d88136b8a2e87c9eab5c11371c14d922d)), closes [#30743](https://github.com/bitnami/charts/issues/30743)

## <small>7.0.25 (2024-11-20)</small>

* [bitnami/argo-cd] Release 7.0.25 (#30549) ([eaccca8](https://github.com/bitnami/charts/commit/eaccca888523fc41578e5f5c0f16e200e94c61e2)), closes [#30549](https://github.com/bitnami/charts/issues/30549)

## <small>7.0.24 (2024-11-15)</small>

* [bitnami/argo-cd] Release 7.0.24 (#30471) ([7e640aa](https://github.com/bitnami/charts/commit/7e640aa47963982bd3432301a72ea8ee48573b97)), closes [#30471](https://github.com/bitnami/charts/issues/30471)

## <small>7.0.23 (2024-11-14)</small>

* [bitnami/argo-cd] Fix repo-server PDB label selector (#30391) ([d2b71c2](https://github.com/bitnami/charts/commit/d2b71c2cc92ea4c46c27c40781106b948d2194a6)), closes [#30391](https://github.com/bitnami/charts/issues/30391)

## <small>7.0.22 (2024-11-07)</small>

* [bitnami/argo-cd] Release 7.0.22 (#30253) ([981c935](https://github.com/bitnami/charts/commit/981c9350763c152831eaa8dc310b3abd585fd705)), closes [#30253](https://github.com/bitnami/charts/issues/30253)

## <small>7.0.21 (2024-11-04)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/argo-cd] Release 7.0.21 (#30196) ([f6e62be](https://github.com/bitnami/charts/commit/f6e62be0823be6af54b6cad537adf03a91630e0d)), closes [#30196](https://github.com/bitnami/charts/issues/30196)

## <small>7.0.20 (2024-10-18)</small>

* [bitnami/argo-cd] Release 7.0.20 (#29997) ([668f286](https://github.com/bitnami/charts/commit/668f286b78912244294a66ca4d081a07e79634a8)), closes [#29997](https://github.com/bitnami/charts/issues/29997)

## <small>7.0.19 (2024-10-17)</small>

* [bitnami/argo-cd] Release 7.0.19 (#29977) ([83436f5](https://github.com/bitnami/charts/commit/83436f524ace533fd20d0bafec4b8411b444985f)), closes [#29977](https://github.com/bitnami/charts/issues/29977)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## <small>7.0.18 (2024-10-09)</small>

* [bitnami/argo-cd] Release 7.0.18 (#29845) ([0e2b67f](https://github.com/bitnami/charts/commit/0e2b67f8038c03b13c9f5e6ac200e38a853b5b8a)), closes [#29845](https://github.com/bitnami/charts/issues/29845)

## <small>7.0.17 (2024-10-09)</small>

* [bitnami/argo-cd] Release 7.0.17 (#29843) ([7cec653](https://github.com/bitnami/charts/commit/7cec653341ff906ef61ffc70bc30b1a5583d1dba)), closes [#29843](https://github.com/bitnami/charts/issues/29843)

## <small>7.0.16 (2024-10-09)</small>

* [bitnami/argo-cd] fix: provide a functional validation function for validation (#29724) ([6eac077](https://github.com/bitnami/charts/commit/6eac07766d63a2d2ec9713a8716d1ea394441e14)), closes [#29724](https://github.com/bitnami/charts/issues/29724)

## <small>7.0.15 (2024-10-01)</small>

* [bitnami/argo-cd] Release 7.0.15 (#29682) ([6b89f04](https://github.com/bitnami/charts/commit/6b89f04f14ccd7aa78811dea9642754899c102da)), closes [#29682](https://github.com/bitnami/charts/issues/29682)

## <small>7.0.14 (2024-09-26)</small>

* [bitnami/argo-cd] Release 7.0.14 (#29618) ([6f1e155](https://github.com/bitnami/charts/commit/6f1e1550bad7dcb0d5cf63e8280baa2d9d7787da)), closes [#29618](https://github.com/bitnami/charts/issues/29618)

## <small>7.0.13 (2024-09-19)</small>

* [bitnami/argo-cd] Release 7.0.13 (#29507) ([f590500](https://github.com/bitnami/charts/commit/f590500e460485aab7ac50f5e51fefb0d3ade9bd)), closes [#29507](https://github.com/bitnami/charts/issues/29507)

## <small>7.0.12 (2024-09-15)</small>

* [bitnami/argo-cd] Release 7.0.12 (#29429) ([0e6235b](https://github.com/bitnami/charts/commit/0e6235be7f2d0c76bc99785ae39eb9ac44fa0dd5)), closes [#29429](https://github.com/bitnami/charts/issues/29429)

## <small>7.0.11 (2024-09-13)</small>

* [bitnami/argo-cd] Fix duplicate `selector:` in applicationset deployment (#29386) ([dc6905f](https://github.com/bitnami/charts/commit/dc6905f9ca3d7ffaa59c0ac7d689ab91ade53a27)), closes [#29386](https://github.com/bitnami/charts/issues/29386)

## <small>7.0.10 (2024-09-05)</small>

* [bitnami/argo-cd] Release 7.0.10 (#29224) ([92a32cb](https://github.com/bitnami/charts/commit/92a32cbbf02f492afaa562a98303cd7921348827)), closes [#29224](https://github.com/bitnami/charts/issues/29224)

## <small>7.0.9 (2024-09-04)</small>

* [bitnami/argo-cd] Missing namespace in ArgoCD known-hosts cm (#28877) ([4780e8f](https://github.com/bitnami/charts/commit/4780e8fe5b70651fd1fc2c3c614583c42eacf150)), closes [#28877](https://github.com/bitnami/charts/issues/28877)

## <small>7.0.8 (2024-08-28)</small>

* [bitnami/argo-cd] Release 7.0.8 (#29074) ([cb56c0e](https://github.com/bitnami/charts/commit/cb56c0ed43ffc75df71571dd2e032dadfaa9face)), closes [#29074](https://github.com/bitnami/charts/issues/29074)

## <small>7.0.7 (2024-08-27)</small>

* [bitnami/argo-cd] Release 7.0.7 (#29042) ([b4c9c5f](https://github.com/bitnami/charts/commit/b4c9c5fb6b48a20b04ed0cfe7cc56e559773e151)), closes [#29042](https://github.com/bitnami/charts/issues/29042)

## <small>7.0.6 (2024-08-23)</small>

* [bitnami/argo-cd] Release 7.0.6 (#28994) ([1ec7b5c](https://github.com/bitnami/charts/commit/1ec7b5c14a818bdc4f26fcf3ad53e78c102d10b2)), closes [#28994](https://github.com/bitnami/charts/issues/28994)

## <small>7.0.5 (2024-08-23)</small>

* [bitnami/argo-cd] fix: Add namespace to service account's bindings (#28737) ([b75dcd7](https://github.com/bitnami/charts/commit/b75dcd716410ec623eb832104ffe6f25df0e5a13)), closes [#28737](https://github.com/bitnami/charts/issues/28737)

## <small>7.0.4 (2024-08-23)</small>

* [bitnami/argo-cd] Release 7.0.4 (#28987) ([dd40e6e](https://github.com/bitnami/charts/commit/dd40e6e3dc01ef62a9e631540e660416bc6cadf6)), closes [#28987](https://github.com/bitnami/charts/issues/28987)

## <small>7.0.3 (2024-08-20)</small>

* [bitnami/argo-cd] test: :white_check_mark: Improve resilience of cypress test (#28936) ([b290de1](https://github.com/bitnami/charts/commit/b290de196fdd3e0aa5bc55c5257fe5384dde39d1)), closes [#28936](https://github.com/bitnami/charts/issues/28936)

## <small>7.0.2 (2024-08-19)</small>

* [bitnami/argo-cd] Add missing verbs to ApplicationSet role (#28914) ([69e8d7b](https://github.com/bitnami/charts/commit/69e8d7bfa54ff1892f0405d31d29aa988bd79440)), closes [#28914](https://github.com/bitnami/charts/issues/28914)

## <small>7.0.1 (2024-08-16)</small>

* [bitnami/argo-cd] Release 7.0.1 (#28911) ([179665c](https://github.com/bitnami/charts/commit/179665c13f0dc2baaf3432655ed62ca1b81cbf4d)), closes [#28911](https://github.com/bitnami/charts/issues/28911)

## 7.0.0 (2024-08-13)

* [bitnami/argo-cd] Update dependencies (#28851) ([7789c76](https://github.com/bitnami/charts/commit/7789c76851b38db4a34ab0a079fbe636923efbec)), closes [#28851](https://github.com/bitnami/charts/issues/28851)

## <small>6.6.12 (2024-08-12)</small>

* [bitnami/argo-cd] Release 6.6.12 (#28828) ([e3c8931](https://github.com/bitnami/charts/commit/e3c893177b27a510e933db97d4f57f1d80d1bfc7)), closes [#28828](https://github.com/bitnami/charts/issues/28828)

## <small>6.6.11 (2024-08-09)</small>

* [bitnami/argo-cd] Release 6.6.11 (#28762) ([6c7ef92](https://github.com/bitnami/charts/commit/6c7ef92618d321e18fd1a7e20ba8faf90f3661a2)), closes [#28762](https://github.com/bitnami/charts/issues/28762)

## <small>6.6.10 (2024-08-05)</small>

* [bitnami/argo-cd] Remove usage of health check that does not exist (#26547) (#28348) ([9e03640](https://github.com/bitnami/charts/commit/9e0364083d0fdf0c7126b90b54fbe184bff71741)), closes [#26547](https://github.com/bitnami/charts/issues/26547) [#28348](https://github.com/bitnami/charts/issues/28348)

## <small>6.6.9 (2024-07-26)</small>

* [bitnami/argo-cd] Bugfix cluster-config.yaml nil pointer evaluating interface {}.XXX (#28522) ([1e2a00d](https://github.com/bitnami/charts/commit/1e2a00dda16d30472078b762aa399cf353ba840a)), closes [#28522](https://github.com/bitnami/charts/issues/28522)

## <small>6.6.8 (2024-07-25)</small>

* [bitnami/argo-cd] Release 6.6.8 (#28399) ([2c1ca0f](https://github.com/bitnami/charts/commit/2c1ca0fa691652683f0a644b67f4b08bc24fdc09)), closes [#28399](https://github.com/bitnami/charts/issues/28399)

## <small>6.6.7 (2024-07-24)</small>

* [bitnami/argo-cd] Release 6.6.7 (#28363) ([4d99194](https://github.com/bitnami/charts/commit/4d99194aa1da4c00d2838540770bc7befe982683)), closes [#28363](https://github.com/bitnami/charts/issues/28363)

## <small>6.6.6 (2024-07-24)</small>

* [bitnami/argo-cd] Release 6.6.6 (#28344) ([95e78c0](https://github.com/bitnami/charts/commit/95e78c03303a22ff50bc639d06548bc1eaa0095f)), closes [#28344](https://github.com/bitnami/charts/issues/28344)

## <small>6.6.5 (2024-07-24)</small>

* [bitnami/argo-cd] Release 6.6.5 (#28232) ([5e5bd07](https://github.com/bitnami/charts/commit/5e5bd0720ad4d4c40287ef412c019186a073ffe3)), closes [#28232](https://github.com/bitnami/charts/issues/28232)

## <small>6.6.4 (2024-07-23)</small>

* [bitnami/argo-cd] Release 6.6.4 (#28208) ([374fda5](https://github.com/bitnami/charts/commit/374fda56e3d11e5fa75710b58f92b85e6fc14aff)), closes [#28208](https://github.com/bitnami/charts/issues/28208)

## <small>6.6.3 (2024-07-18)</small>

* [bitnami/argo-cd] Global StorageClass as default value (#27999) ([61c4086](https://github.com/bitnami/charts/commit/61c408671f7e016213ca8ac1e129c44b8ae96bc9)), closes [#27999](https://github.com/bitnami/charts/issues/27999)

## <small>6.6.2 (2024-07-16)</small>

* [bitnami/argo-cd] Fix issue when using imagePullSecrets (#27983) ([f716e12](https://github.com/bitnami/charts/commit/f716e12ccc46a838fee203a137e15ab5a1791b32)), closes [#27983](https://github.com/bitnami/charts/issues/27983)

## <small>6.6.1 (2024-07-15)</small>

* [bitnami/argo-cd] Release 6.6.1 (#27987) ([1e0fade](https://github.com/bitnami/charts/commit/1e0fadee59b7e7f30c68ce39c33acaab78341045)), closes [#27987](https://github.com/bitnami/charts/issues/27987)

## 6.6.0 (2024-07-12)

* [bitnami/argo-cd] Make it possible to run ArgoCD in HA mode (#27585) ([8d231f8](https://github.com/bitnami/charts/commit/8d231f86e78a6ad07b5f588a0eedebf7c21d0f9b)), closes [#27585](https://github.com/bitnami/charts/issues/27585)

## <small>6.5.8 (2024-07-08)</small>

* [bitnami/argo-cd] fix: Use the right port name for livenessProbe. (#27253) ([516d67a](https://github.com/bitnami/charts/commit/516d67a0e6c7f6a24fab5d6c000c0c0de27bdd58)), closes [#27253](https://github.com/bitnami/charts/issues/27253)

## <small>6.5.7 (2024-07-05)</small>

* [bitnami/argo-cd] Release 6.5.7 (#27809) ([cb5ab65](https://github.com/bitnami/charts/commit/cb5ab651c4ac02d80d6ab30e3d5b2ccda4e261ac)), closes [#27809](https://github.com/bitnami/charts/issues/27809)

## <small>6.5.6 (2024-07-05)</small>

* [bitnami/argo-cd] Render PDBs and NetworkPolicies only if apps are enabled as well (#27614) ([a8343fd](https://github.com/bitnami/charts/commit/a8343fd3563c76ba4d1eb7e8b37ed4f270b06c53)), closes [#27614](https://github.com/bitnami/charts/issues/27614)

## <small>6.5.5 (2024-07-05)</small>

* [bitnami/argo-cd] Use correct port in NetworkPolicy of Repo Server (#27615) ([afe2d37](https://github.com/bitnami/charts/commit/afe2d3707912e9717615a38e5a54741800b443a1)), closes [#27615](https://github.com/bitnami/charts/issues/27615)

## <small>6.5.4 (2024-07-04)</small>

* [bitnami/argo-cd] Release 6.5.4 (#27756) ([f5d8265](https://github.com/bitnami/charts/commit/f5d8265fa7f9f1ed69bcea1b64817d0f50274b3d)), closes [#27756](https://github.com/bitnami/charts/issues/27756)

## <small>6.5.3 (2024-07-03)</small>

* [bitnami/argo-cd] Release 6.5.3 (#27652) ([8540d55](https://github.com/bitnami/charts/commit/8540d55d2fb45254852efd8ed802b820787f35f0)), closes [#27652](https://github.com/bitnami/charts/issues/27652)

## <small>6.5.2 (2024-07-02)</small>

* [bitnami/argo-cd] Release 6.5.2 (#27641) ([ebc1f0b](https://github.com/bitnami/charts/commit/ebc1f0bdf864ea61a87b61c7e621a221511392f5)), closes [#27641](https://github.com/bitnami/charts/issues/27641)

## <small>6.5.1 (2024-06-28)</small>

* [bitnami/argo-cd] Release 6.5.1 (#27575) ([52adaa6](https://github.com/bitnami/charts/commit/52adaa699e5dd45ef38e03f583342ec384e4c1de)), closes [#27575](https://github.com/bitnami/charts/issues/27575)

## 6.5.0 (2024-06-27)

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/argo-cd] Fix #27108, #27108 (#27450) ([f331dd2](https://github.com/bitnami/charts/commit/f331dd2ef0f901ad51c6af00866e82e401308cbb)), closes [#27108](https://github.com/bitnami/charts/issues/27108) [#27108](https://github.com/bitnami/charts/issues/27108) [#27450](https://github.com/bitnami/charts/issues/27450) [#27108](https://github.com/bitnami/charts/issues/27108)

## <small>6.4.8 (2024-06-18)</small>

* [bitnami/argo-cd] Release 6.4.8 (#27328) ([5764b48](https://github.com/bitnami/charts/commit/5764b4815b5ad230ea1aa617d939be96e04d1d81)), closes [#27328](https://github.com/bitnami/charts/issues/27328)

## <small>6.4.7 (2024-06-17)</small>

* [bitnami/argo-cd] Release 6.4.7 (#27202) ([0704678](https://github.com/bitnami/charts/commit/0704678902cff3c340e2e1998151acc9ba993256)), closes [#27202](https://github.com/bitnami/charts/issues/27202)

## <small>6.4.6 (2024-06-11)</small>

* [bitnami/argo-cd] Typo in notifications service (#27054) ([9012640](https://github.com/bitnami/charts/commit/901264004c90fda66a5ea024235b28ecc03b4a21)), closes [#27054](https://github.com/bitnami/charts/issues/27054)

## <small>6.4.5 (2024-06-06)</small>

* [bitnami/argo-cd] Release 6.4.5 (#26938) ([7233063](https://github.com/bitnami/charts/commit/72330635af507b167ed585844d2c3beb09191378)), closes [#26938](https://github.com/bitnami/charts/issues/26938)

## <small>6.4.4 (2024-06-06)</small>

* [bitnami/argo-cd] Release 6.4.4 (#26883) ([e8de061](https://github.com/bitnami/charts/commit/e8de0612539c6b0e4b1bad432378cd2a5a5767cb)), closes [#26883](https://github.com/bitnami/charts/issues/26883)

## <small>6.4.3 (2024-06-05)</small>

* [bitnami/argo-cd] Bump chart version (#26821) ([1c97a4c](https://github.com/bitnami/charts/commit/1c97a4c38cf2cc71c1c3525fc0feade3fae8dfa3)), closes [#26821](https://github.com/bitnami/charts/issues/26821)

## <small>6.4.2 (2024-06-05)</small>

* [bitnami/argo-cd] Bump chart version (#26763) ([179050f](https://github.com/bitnami/charts/commit/179050f2fa0e8c5e661213c6e9690d628cac4bd6)), closes [#26763](https://github.com/bitnami/charts/issues/26763)

## <small>6.4.1 (2024-06-05)</small>

* [bitnami/argo-cd] Release 6.4.1 (#26720) ([834b448](https://github.com/bitnami/charts/commit/834b4487c5e0d2356625ecc2923ee02865b41fb0)), closes [#26720](https://github.com/bitnami/charts/issues/26720)

## 6.4.0 (2024-05-30)

* [bitnami/argo-cd] Enable PodDisruptionBudgets (#26419) ([c2b50f2](https://github.com/bitnami/charts/commit/c2b50f25b5a553fe180784947091673093757a81)), closes [#26419](https://github.com/bitnami/charts/issues/26419)

## <small>6.3.4 (2024-05-28)</small>

* [bitnami/argo-cd] Define port for notifications probes (#26485) ([4500caf](https://github.com/bitnami/charts/commit/4500cafc0aab84295f85bd839978929e5dfc8773)), closes [#26485](https://github.com/bitnami/charts/issues/26485)

## <small>6.3.3 (2024-05-24)</small>

* [bitnami/argo-cd] Release 6.3.3 (#26415) ([e4f57d1](https://github.com/bitnami/charts/commit/e4f57d1a1a2c32bb471bb50d28f1241cbac421d3)), closes [#26415](https://github.com/bitnami/charts/issues/26415)

## <small>6.3.2 (2024-05-24)</small>

* [bitnami/argo-cd] Use different liveness/readiness probes (#26367) ([6416961](https://github.com/bitnami/charts/commit/641696157e9dcb47341bb68d04c62e7d49181312)), closes [#26367](https://github.com/bitnami/charts/issues/26367)

## <small>6.3.1 (2024-05-23)</small>

* [bitnami/argo-cd] fix: :bug: :ambulance: Remove non-existent image in replacedImages check (#26371) ([d635edc](https://github.com/bitnami/charts/commit/d635edc8fc38e1a6c24d0c538e1906dc1656de08)), closes [#26371](https://github.com/bitnami/charts/issues/26371)

## 6.3.0 (2024-05-21)

* [bitnami/argo-cd] feat: :sparkles: :lock: Add warning when original images are replaced (#26182) ([a2f3186](https://github.com/bitnami/charts/commit/a2f318614a312f8b4b6914460a77e37be25b2c3a)), closes [#26182](https://github.com/bitnami/charts/issues/26182)

## <small>6.2.4 (2024-05-21)</small>

* [bitnami/argo-cd] Release 6.2.4 (#26155) ([07644cf](https://github.com/bitnami/charts/commit/07644cf6612fa9e2844d3f28df17798974aa4476)), closes [#26155](https://github.com/bitnami/charts/issues/26155)

## <small>6.2.3 (2024-05-21)</small>

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/argo-cd] Release 6.2.3 (#26100) ([881a692](https://github.com/bitnami/charts/commit/881a692d0e84876e7ee21c116a463e1c2fea90dd)), closes [#26100](https://github.com/bitnami/charts/issues/26100)

## <small>6.2.2 (2024-05-13)</small>

* [bitnami/argo-cd] Release 6.2.2 updating components versions (#25749) ([9bc1029](https://github.com/bitnami/charts/commit/9bc102975916b632d9eff286f7dcf616a0d0df44)), closes [#25749](https://github.com/bitnami/charts/issues/25749)

## <small>6.2.1 (2024-05-13)</small>

* [bitnami/argo-cd] Release 6.2.1 updating components versions (#25704) ([8a7ddd7](https://github.com/bitnami/charts/commit/8a7ddd7260d732b0ebc05640e60889bcfbbe53e0)), closes [#25704](https://github.com/bitnami/charts/issues/25704)

## 6.2.0 (2024-05-08)

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/argo-cd] Chart modification to activate external Redis (#25566) ([0f95fcf](https://github.com/bitnami/charts/commit/0f95fcf8900f8e4a884b884df5cdc1767946dc15)), closes [#25566](https://github.com/bitnami/charts/issues/25566)

## <small>6.1.1 (2024-05-07)</small>

* [bitnami/argo-cd] Release 6.1.1 (#25584) ([b9c7961](https://github.com/bitnami/charts/commit/b9c79615e02b98d41ff15f4320c8ed1b82570147)), closes [#25584](https://github.com/bitnami/charts/issues/25584)

## 6.1.0 (2024-05-06)

* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/argo-cd] Add automountserviceAccount for notifications (#25561) ([8568db0](https://github.com/bitnami/charts/commit/8568db0ec0b217adb7ed53d615af3bfdb5de22f6)), closes [#25561](https://github.com/bitnami/charts/issues/25561)

## <small>6.0.15 (2024-04-30)</small>

* [bitnami/argo-cd] Release 6.0.15 (#25477) ([b0dc492](https://github.com/bitnami/charts/commit/b0dc49260c44b9adc414b5e121319799d9d948e1)), closes [#25477](https://github.com/bitnami/charts/issues/25477)

## <small>6.0.14 (2024-04-26)</small>

* [bitnami/argo-cd] Release 6.0.14 (#25427) ([8d10e2d](https://github.com/bitnami/charts/commit/8d10e2d90ddaf91b473456c4c6f5fdcf15731a38)), closes [#25427](https://github.com/bitnami/charts/issues/25427)

## <small>6.0.13 (2024-04-26)</small>

* [bitnami/argo-cd] Release 6.0.13 updating components versions (#25404) ([5045b7a](https://github.com/bitnami/charts/commit/5045b7a3d8fd6a5f6f32c46e83cd61355f641ab1)), closes [#25404](https://github.com/bitnami/charts/issues/25404)
* [bitnami/multiple charts] Fix typo: "NetworkPolice" vs "NetworkPolicy" (#25348) ([6970c1b](https://github.com/bitnami/charts/commit/6970c1ba245873506e73d459c6eac1e4919b778f)), closes [#25348](https://github.com/bitnami/charts/issues/25348)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## <small>6.0.12 (2024-04-24)</small>

* fix: :bug: automountServiceAccount attribute was missing (#24815) ([91fca62](https://github.com/bitnami/charts/commit/91fca6249f6e2b6839b96322d41dc16e27d62f67)), closes [#24815](https://github.com/bitnami/charts/issues/24815)

## <small>6.0.11 (2024-04-23)</small>

* [bitnami/argo-cd] Remove null port in application-controller NetworkPolicy (#25309) ([fcce78f](https://github.com/bitnami/charts/commit/fcce78faba5d5e4c547128e3b759cdb920f67eb4)), closes [#25309](https://github.com/bitnami/charts/issues/25309)

## <small>6.0.10 (2024-04-15)</small>

* [bitnami/argo-cd] Release 6.0.10 (#25170) ([eb1ef30](https://github.com/bitnami/charts/commit/eb1ef30b135c65502eba1689db32782144f9160d)), closes [#25170](https://github.com/bitnami/charts/issues/25170)

## <small>6.0.9 (2024-04-10)</small>

* [bitnami/argo-cd] Release 6.0.9 updating components versions (#25122) ([c85e53d](https://github.com/bitnami/charts/commit/c85e53da301d4f1f2938251f9d22f8fb9c4b7a6c)), closes [#25122](https://github.com/bitnami/charts/issues/25122)

## <small>6.0.8 (2024-04-10)</small>

* [bitnami/argo-cd] fix: :bug: :lock: Expose metrics port in deployment definition (#25043) ([8e2e712](https://github.com/bitnami/charts/commit/8e2e712c9d897293b00914657b0dc18984f91d51)), closes [#25043](https://github.com/bitnami/charts/issues/25043)
* [bitnami/argo-cd] Increase controller resource presets (#25105) ([3e9ec6f](https://github.com/bitnami/charts/commit/3e9ec6fa85cb39d02031be0fc153e9a36e4e1c64)), closes [#25105](https://github.com/bitnami/charts/issues/25105)

## <small>6.0.7 (2024-04-10)</small>

* [bitnami/argo-cd]: fixing creation of service monitors (#25046) ([79e4670](https://github.com/bitnami/charts/commit/79e46701f710b8c1126f2c40850ea7f33f5e8101)), closes [#25046](https://github.com/bitnami/charts/issues/25046)

## <small>6.0.6 (2024-04-05)</small>

* [bitnami/argo-cd] Release 6.0.6 updating components versions (#24970) ([5a83dde](https://github.com/bitnami/charts/commit/5a83dde84fd7fe661714537665aa25e1b868825f)), closes [#24970](https://github.com/bitnami/charts/issues/24970)

## <small>6.0.5 (2024-04-05)</small>

* [bitnami/argo-cd] Release 6.0.5 (#24927) ([56a341f](https://github.com/bitnami/charts/commit/56a341f619ecee40dff71679dca21f5c0f78c752)), closes [#24927](https://github.com/bitnami/charts/issues/24927)

## <small>6.0.4 (2024-04-04)</small>

* [bitnami/argo-cd] Release 6.0.4 updating components versions (#24916) ([59286ba](https://github.com/bitnami/charts/commit/59286bac08351b5d4a11f1ab85035f6bec97f1b1)), closes [#24916](https://github.com/bitnami/charts/issues/24916)

## <small>6.0.3 (2024-04-04)</small>

* [bitnami/argo-cd] Release 6.0.3 updating components versions (#24898) ([8d652fb](https://github.com/bitnami/charts/commit/8d652fbcb713bc479712c5b48cdff30f3c3e03e1)), closes [#24898](https://github.com/bitnami/charts/issues/24898)

## <small>6.0.2 (2024-04-04)</small>

* [bitnami/argo-cd] Release 6.0.2 (#24868) ([b513865](https://github.com/bitnami/charts/commit/b513865b45cfb3c12308bab6cb6223204cccd4f9)), closes [#24868](https://github.com/bitnami/charts/issues/24868)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## <small>6.0.1 (2024-03-28)</small>

* [bitnami/argo-cd] Release 6.0.1 (#24741) ([5b3d0cf](https://github.com/bitnami/charts/commit/5b3d0cf0ff9a310ee98c3014812fdff389c152b1)), closes [#24741](https://github.com/bitnami/charts/issues/24741)

## 6.0.0 (2024-03-20)

* [bitnami/argo-cd] feat!: :lock: :boom: Improve security defaults (#24557) ([9dd62d4](https://github.com/bitnami/charts/commit/9dd62d4d995f470ac105578b0084e18f047d4cd2)), closes [#24557](https://github.com/bitnami/charts/issues/24557)

## <small>5.10.6 (2024-03-18)</small>

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* [bitnami/argo-cd] Release 5.10.6 (#24496) ([d87171e](https://github.com/bitnami/charts/commit/d87171e28b745e6b299689f4b250e4a697602b95)), closes [#24496](https://github.com/bitnami/charts/issues/24496)

## <small>5.10.5 (2024-03-13)</small>

* [bitnami/argo-cd] Release 5.10.5 (#24417) ([e5b4a72](https://github.com/bitnami/charts/commit/e5b4a729c4c3742c2763d84c592f917eba9873b5)), closes [#24417](https://github.com/bitnami/charts/issues/24417)

## <small>5.10.4 (2024-03-13)</small>

* [bitnami/argo-cd] Update chart deps (#24390) ([c2a1a49](https://github.com/bitnami/charts/commit/c2a1a49b8eb4c539a08af6cc91576ac37d45439a)), closes [#24390](https://github.com/bitnami/charts/issues/24390)

## <small>5.10.3 (2024-03-11)</small>

*  [bitnami/argo-cd] fix: add missing brackets (#24313) ([ff865c5](https://github.com/bitnami/charts/commit/ff865c5f3764f00ea83d7ac36d747b60f511a272)), closes [#24313](https://github.com/bitnami/charts/issues/24313)

## <small>5.10.2 (2024-03-08)</small>

* [bitnami/argo-cd] Release 5.10.2 updating components versions (#24296) ([44e932e](https://github.com/bitnami/charts/commit/44e932ed227538466cef001fe87dc9f6bdfd8a32)), closes [#24296](https://github.com/bitnami/charts/issues/24296)

## <small>5.10.1 (2024-03-06)</small>

* [bitnami/argo-cd] Release 5.10.1 updating components versions (#24184) ([c8c6d4d](https://github.com/bitnami/charts/commit/c8c6d4dfd8331edc01630decbf54018112bff40e)), closes [#24184](https://github.com/bitnami/charts/issues/24184)

## 5.10.0 (2024-03-06)

* [bitnami/argo-cd] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v2 SCC ( ([75d166a](https://github.com/bitnami/charts/commit/75d166a464e6a8993eb6f3b99e9f312c95bf96af)), closes [#24064](https://github.com/bitnami/charts/issues/24064)

## <small>5.9.2 (2024-03-01)</small>

* [bitnami/argo-cd] Release 5.9.2 (#24013) ([2a04bbe](https://github.com/bitnami/charts/commit/2a04bbeae2a994a7dceb6544ce96b90328a87e9b)), closes [#24013](https://github.com/bitnami/charts/issues/24013)

## <small>5.9.1 (2024-02-26)</small>

* [bitnami/argo-cd] Release 5.9.1 (#23920) ([060870b](https://github.com/bitnami/charts/commit/060870b037171b354e874bcfa08ffb9aeafd60ff)), closes [#23920](https://github.com/bitnami/charts/issues/23920)

## 5.9.0 (2024-02-23)

* [bitnami/argo-cd] feat: :sparkles: :lock: Add readOnlyRootFilesystem support (#23875) ([e577a7d](https://github.com/bitnami/charts/commit/e577a7d2a9c8563ba0ddfc34be0c03eb53a1e1ca)), closes [#23875](https://github.com/bitnami/charts/issues/23875)

## <small>5.8.1 (2024-02-21)</small>

* [bitnami/argo-cd] Release 5.8.1 updating components versions (#23635) ([dfbfb77](https://github.com/bitnami/charts/commit/dfbfb77903fa0f7d73d22aa381c6df9e8e244b2c)), closes [#23635](https://github.com/bitnami/charts/issues/23635)

## 5.8.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## 5.7.0 (2024-02-15)

* [bitnami/argo-cd] feat: :sparkles: :lock: Add resource preset support (#23431) ([2c89ff7](https://github.com/bitnami/charts/commit/2c89ff79886740978f9809ab1aefdad7d45f7b9b)), closes [#23431](https://github.com/bitnami/charts/issues/23431)

## 5.6.0 (2024-02-13)

* [bitnami/argo-cd] feat: :lock: Enable networkPolicy (#23359) ([3cc212a](https://github.com/bitnami/charts/commit/3cc212a1aad96e4f12fee881885bc730f0a4b96e)), closes [#23359](https://github.com/bitnami/charts/issues/23359)

## <small>5.5.6 (2024-02-07)</small>

* [bitnami/argo-cd] Release 5.5.6 updating components versions (#23266) ([d327b96](https://github.com/bitnami/charts/commit/d327b964789d3d4972ea5bf99a9354de005e8e10)), closes [#23266](https://github.com/bitnami/charts/issues/23266)

## <small>5.5.5 (2024-02-07)</small>

* [bitnami/argo-cd] Release 5.5.5 (#23221) ([f45043e](https://github.com/bitnami/charts/commit/f45043e2bd383e1e93ff07f7033632799c566b0e)), closes [#23221](https://github.com/bitnami/charts/issues/23221)

## <small>5.5.4 (2024-02-05)</small>

* [bitnami/argo-cd] Release 5.5.4 updating components versions (#23189) ([8d3e19a](https://github.com/bitnami/charts/commit/8d3e19a28fde00a4b73d7177a2c4ca5fa547d93a)), closes [#23189](https://github.com/bitnami/charts/issues/23189)

## <small>5.5.3 (2024-02-03)</small>

* [bitnami/argo-cd] Release 5.5.3 (#23148) ([037c551](https://github.com/bitnami/charts/commit/037c551309632bd40a0406d8c43d76f64ccd75ef)), closes [#23148](https://github.com/bitnami/charts/issues/23148)

## <small>5.5.2 (2024-01-31)</small>

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/argo-cd] Release 5.5.2 updating components versions (#22951) ([ef00737](https://github.com/bitnami/charts/commit/ef00737697c352c14581ae46c7520b7766334004)), closes [#22951](https://github.com/bitnami/charts/issues/22951)

## <small>5.5.1 (2024-01-24)</small>

* [bitnami/argo-cd] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22569) ([66e2762](https://github.com/bitnami/charts/commit/66e27626ade476d47beb756332b73d3cb135e033)), closes [#22569](https://github.com/bitnami/charts/issues/22569)

## 5.5.0 (2024-01-22)

* [bitnami/argo-cd] fix: :lock: Move service-account token auto-mount to pod declaration (#22386) ([fed1a60](https://github.com/bitnami/charts/commit/fed1a6081903643d0008572f33ceb822bb57247c)), closes [#22386](https://github.com/bitnami/charts/issues/22386)

## <small>5.4.5 (2024-01-20)</small>

* [bitnami/argo-cd] Release 5.4.5 (#22527) ([0e6b8ed](https://github.com/bitnami/charts/commit/0e6b8edaf2a48d36a717bf90292b302917ac08e4)), closes [#22527](https://github.com/bitnami/charts/issues/22527)

## <small>5.4.4 (2024-01-18)</small>

* [bitnami/argo-cd] Release 5.4.4 (#22508) ([b1f7864](https://github.com/bitnami/charts/commit/b1f7864afefc9d16b6fd074101d474edd261d623)), closes [#22508](https://github.com/bitnami/charts/issues/22508)

## <small>5.4.3 (2024-01-18)</small>

* [bitnami/argo-cd] Update CRDs and add source header (#22367) ([491d7aa](https://github.com/bitnami/charts/commit/491d7aa01d6e00ab3b43d9f8c89de3d7eec6bda5)), closes [#22367](https://github.com/bitnami/charts/issues/22367)

## <small>5.4.2 (2024-01-18)</small>

* [bitnami/argo-cd] Release 5.4.2 updating components versions (#22384) ([2f25e34](https://github.com/bitnami/charts/commit/2f25e3470ef4fc397da980670c347a4abe3c3dae)), closes [#22384](https://github.com/bitnami/charts/issues/22384)

## <small>5.4.1 (2024-01-18)</small>

* [bitnami/argo-cd] Release 5.4.1 updating components versions (#22276) ([4aaa8cd](https://github.com/bitnami/charts/commit/4aaa8cd374b57a2d941c4fb69f12660c79416726)), closes [#22276](https://github.com/bitnami/charts/issues/22276)

## 5.4.0 (2024-01-17)

* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/argo-cd] fix: :lock: Improve podSecurityContext and containerSecurityContext with essential ([82c7c3b](https://github.com/bitnami/charts/commit/82c7c3b74fa90415443d8c6c50b1f7128aa230c4)), closes [#22100](https://github.com/bitnami/charts/issues/22100)

## 5.3.0 (2024-01-10)

* [bitnami/argo-cd] feat: :sparkles: Add missing health probes (#21642) ([649b712](https://github.com/bitnami/charts/commit/649b712162b18229db0b24a2c8e2e4f9e88f8cb3)), closes [#21642](https://github.com/bitnami/charts/issues/21642)

## <small>5.2.12 (2024-01-10)</small>

* [bitnami/argo-cd] Release 5.2.12 updating components versions (#21928) ([8f36862](https://github.com/bitnami/charts/commit/8f36862d85611d65a6a0662200e743b7d9c4b735)), closes [#21928](https://github.com/bitnami/charts/issues/21928)

## <small>5.2.11 (2024-01-09)</small>

* [bitnami/*] Fix docs.bitnami.com broken links (#21901) ([f35506d](https://github.com/bitnami/charts/commit/f35506d2dadee4f097986e7792df1f53ab215b5d)), closes [#21901](https://github.com/bitnami/charts/issues/21901)
* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)
* [bitnami/argo-cd] Release 5.2.11 updating components versions (#21590) ([7fc6b34](https://github.com/bitnami/charts/commit/7fc6b3451d92a3bdf8a3a79d715cc2e3880b8d7e)), closes [#21590](https://github.com/bitnami/charts/issues/21590)

## <small>5.2.10 (2023-12-12)</small>

* [bitnami/argo-cd] Release 5.2.10 updating components versions (#21526) ([6a42626](https://github.com/bitnami/charts/commit/6a42626bc8745bee0fd2413f2bc6a03f5b495a13)), closes [#21526](https://github.com/bitnami/charts/issues/21526)

## <small>5.2.9 (2023-12-05)</small>

* [bitnami/argo-cd] Replace deprecated pull secret partial (#21369) ([bfb7d93](https://github.com/bitnami/charts/commit/bfb7d9348a0fa8e50da2f63e3a2b1cb2d3374df1)), closes [#21369](https://github.com/bitnami/charts/issues/21369)

## <small>5.2.8 (2023-11-21)</small>

* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/argo-cd] Release 5.2.8 updating components versions (#21094) ([06bc239](https://github.com/bitnami/charts/commit/06bc239a2590ef37132b52aa83e136a74fd1341b)), closes [#21094](https://github.com/bitnami/charts/issues/21094)

## <small>5.2.7 (2023-11-20)</small>

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/argo-cd] Release 5.2.7 updating components versions (#21067) ([22716a5](https://github.com/bitnami/charts/commit/22716a5e3bf82e28a38f930236c56b139b536679)), closes [#21067](https://github.com/bitnami/charts/issues/21067)

## <small>5.2.6 (2023-11-15)</small>

* [bitnami/argo-cd] Release 5.2.6 updating components versions (#20981) ([eab363e](https://github.com/bitnami/charts/commit/eab363ec32b6db684be6670daa036260dd091a6e)), closes [#20981](https://github.com/bitnami/charts/issues/20981)

## <small>5.2.5 (2023-11-14)</small>

* [bitnami/argo-cd] Release 5.2.5 updating components versions (#20949) ([29781a1](https://github.com/bitnami/charts/commit/29781a1de246c911b6891e2f08c922f7db072a27)), closes [#20949](https://github.com/bitnami/charts/issues/20949)

## <small>5.2.4 (2023-11-09)</small>

* [bitnami/argo-cd] Release 5.2.4 updating components versions (#20804) ([a1eb299](https://github.com/bitnami/charts/commit/a1eb299e06b8823850663d7cac5d35b454d463cb)), closes [#20804](https://github.com/bitnami/charts/issues/20804)

## <small>5.2.3 (2023-11-08)</small>

* [bitnami/argo-cd] Release 5.2.3 updating components versions (#20794) ([b3d3e4b](https://github.com/bitnami/charts/commit/b3d3e4b76ad8e1ce1d8a70f9c37f3b801916ff61)), closes [#20794](https://github.com/bitnami/charts/issues/20794)

## <small>5.2.2 (2023-11-08)</small>

* [bitnami/argo-cd] Release 5.2.2 updating components versions (#20721) ([1d51e0c](https://github.com/bitnami/charts/commit/1d51e0c8af367851874987bc2ed227c935cd3465)), closes [#20721](https://github.com/bitnami/charts/issues/20721)

## <small>5.2.1 (2023-11-06)</small>

* [bitnami/argo-cd] Release 5.2.1 updating components versions (#20630) ([55a84ad](https://github.com/bitnami/charts/commit/55a84ad9d025d300c570ce5fabbd2c7af36f075d)), closes [#20630](https://github.com/bitnami/charts/issues/20630)

## 5.2.0 (2023-10-31)

* [bitnami/argo-cd] feat: :sparkles: Add support for PSA restricted policy (#20383) ([8e9327c](https://github.com/bitnami/charts/commit/8e9327c678920c19e5576bbfd2011b291456eb1c)), closes [#20383](https://github.com/bitnami/charts/issues/20383)

## <small>5.1.17 (2023-10-26)</small>

* [bitnami/argo-cd] Release 5.1.17 updating components versions (#20460) ([e54752f](https://github.com/bitnami/charts/commit/e54752f29f1f09b1f2832882d6bc2661475157a9)), closes [#20460](https://github.com/bitnami/charts/issues/20460)

## <small>5.1.16 (2023-10-26)</small>

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [bitnami/argo-cd] Release 5.1.16 updating components versions (#20456) ([53a4a91](https://github.com/bitnami/charts/commit/53a4a91eb0cd4d8ca0a554f9fd4afad2e165f3e6)), closes [#20456](https://github.com/bitnami/charts/issues/20456)

## <small>5.1.15 (2023-10-19)</small>

* [bitnami/argo-cd] Release 5.1.15 (#20333) ([3e0672c](https://github.com/bitnami/charts/commit/3e0672c0ad9bfd3282f1a1fc2ff012d17eef67fd)), closes [#20333](https://github.com/bitnami/charts/issues/20333)

## <small>5.1.14 (2023-10-19)</small>

* [bitnami/argo-cd] Release 5.1.14 (#20331) ([454efd2](https://github.com/bitnami/charts/commit/454efd29fda3d75dc7f40994dbc8c4a977b56c43)), closes [#20331](https://github.com/bitnami/charts/issues/20331)

## <small>5.1.13 (2023-10-12)</small>

* [bitnami/argo-cd] Release 5.1.13 (#20206) ([15bfc42](https://github.com/bitnami/charts/commit/15bfc4224ea6c8e7293f869291ae33f09ce243a6)), closes [#20206](https://github.com/bitnami/charts/issues/20206)

## <small>5.1.12 (2023-10-12)</small>

* [bitnami/argo-cd] Release 5.1.12 (#20123) ([cecdfbb](https://github.com/bitnami/charts/commit/cecdfbb987ab9b5a600ea82067beda9a47e5cac0)), closes [#20123](https://github.com/bitnami/charts/issues/20123)

## <small>5.1.11 (2023-10-11)</small>

* [bitnami/argo-cd] Release 5.1.11 (#20031) ([4156ea9](https://github.com/bitnami/charts/commit/4156ea9a47f847de7ddb1464ebce05b8d33f3690)), closes [#20031](https://github.com/bitnami/charts/issues/20031)

## <small>5.1.10 (2023-10-10)</small>

* [bitnami/argo-cd] Release 5.1.10 (#19949) ([7ecabe5](https://github.com/bitnami/charts/commit/7ecabe57504726ae38f2f3b78f3b3347c073b61a)), closes [#19949](https://github.com/bitnami/charts/issues/19949)

## <small>5.1.9 (2023-10-09)</small>

* [bitnami/argo-cd] Release 5.1.9 (#19902) ([db84b61](https://github.com/bitnami/charts/commit/db84b61c50d301c00313846fbad8b892330ffd12)), closes [#19902](https://github.com/bitnami/charts/issues/19902)

## <small>5.1.8 (2023-10-09)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/argo-cd] Release 5.1.8 (#19812) ([ca24031](https://github.com/bitnami/charts/commit/ca24031e8a368fc753f05a4d96cf64ffa1c23959)), closes [#19812](https://github.com/bitnami/charts/issues/19812)

## <small>5.1.7 (2023-10-03)</small>

* [bitnami/argo-cd] Release 5.1.7 (#19686) ([a3a71d1](https://github.com/bitnami/charts/commit/a3a71d171674423dda535aa02314f0092928cf32)), closes [#19686](https://github.com/bitnami/charts/issues/19686)

## <small>5.1.6 (2023-09-29)</small>

* [bitnami/argo-cd] Release 5.1.6 (#19650) ([20a48c7](https://github.com/bitnami/charts/commit/20a48c78e95693d06b03e50fe5719e5b30610507)), closes [#19650](https://github.com/bitnami/charts/issues/19650)

## <small>5.1.5 (2023-09-28)</small>

* [bitnami/argo-cd] Release 5.1.5 (#19589) ([951f6db](https://github.com/bitnami/charts/commit/951f6db70d0dec7314a42370cac50ea64a1ad1d8)), closes [#19589](https://github.com/bitnami/charts/issues/19589)

## <small>5.1.4 (2023-09-25)</small>

* [bitnami/*] Update readme files (#19277) ([e56aeb2](https://github.com/bitnami/charts/commit/e56aeb2fbfbf5b6e42375db48cc7ae1ef1c3a823)), closes [#19277](https://github.com/bitnami/charts/issues/19277)
* [bitnami/argo-cd] Release 5.1.4 (#19511) ([07134d6](https://github.com/bitnami/charts/commit/07134d6be22a9539ef93c8da1c3c16247463b621)), closes [#19511](https://github.com/bitnami/charts/issues/19511)

## <small>5.1.3 (2023-09-18)</small>

* [bitnami/argo-cd] Use different app.kubernetes.io/version label on subcomponents (#19326) ([1b370c5](https://github.com/bitnami/charts/commit/1b370c5f6684acd89821ed3689f632d72fc8b98f)), closes [#19326](https://github.com/bitnami/charts/issues/19326)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>5.1.2 (2023-09-07)</small>

* [bitnami/argo-cd] Release 5.1.2 (#19182) ([2556c72](https://github.com/bitnami/charts/commit/2556c72a207d8e0c005ec9770ba130aeeb9eeb53)), closes [#19182](https://github.com/bitnami/charts/issues/19182)

## <small>5.1.1 (2023-09-07)</small>

* [bitnami/argo-cd: Use merge helper]: (#19022) ([cde7091](https://github.com/bitnami/charts/commit/cde7091a8a8403242cee7863c001cd5830e48877)), closes [#19022](https://github.com/bitnami/charts/issues/19022)
* [bitnami/argo-cd] Document how to install a Config Management Plugin (#18859) ([57419c4](https://github.com/bitnami/charts/commit/57419c4d50ab2cb9da77a41c653055b2da245a49)), closes [#18859](https://github.com/bitnami/charts/issues/18859)

## 5.1.0 (2023-08-29)

* [bitnami/argo-cd] Support for customizing standard labels (#18458) ([4c43401](https://github.com/bitnami/charts/commit/4c4340135505a0c53a02cfa5d89fac659f2ac0b2)), closes [#18458](https://github.com/bitnami/charts/issues/18458)

## <small>5.0.1 (2023-08-28)</small>

* [bitnami/argo-cd] Release 5.0.1 (#18909) ([9111598](https://github.com/bitnami/charts/commit/9111598b9bad355a2cbc9795bd5d9e62acb83ca1)), closes [#18909](https://github.com/bitnami/charts/issues/18909)

## 5.0.0 (2023-08-28)

* [bitnami/argo-cd] Update Redis' subchart (#18897) ([0372edc](https://github.com/bitnami/charts/commit/0372edc40cb85e3a12823ad9eb91f66bda06676b)), closes [#18897](https://github.com/bitnami/charts/issues/18897)

## <small>4.8.1 (2023-08-24)</small>

* [bitnami/argo-cd] Release 4.8.1 (#18833) ([4a0cb1a](https://github.com/bitnami/charts/commit/4a0cb1acb132eb98b73c843df7b629b636b56036)), closes [#18833](https://github.com/bitnami/charts/issues/18833)

## 4.8.0 (2023-08-22)

* [bitnami/argo-cd] Provide configmap for rbac configuration (#18624) ([b51f9fe](https://github.com/bitnami/charts/commit/b51f9fe2b40e7fdba1e3aebd223c40729bc3b8d5)), closes [#18624](https://github.com/bitnami/charts/issues/18624)

## <small>4.7.25 (2023-08-22)</small>

* [bitnami/argo-cd] Release 4.7.25 (#18772) ([d169abb](https://github.com/bitnami/charts/commit/d169abb01e9b95f510af729ccbc0431d994ecf5c)), closes [#18772](https://github.com/bitnami/charts/issues/18772)

## <small>4.7.24 (2023-08-21)</small>

* [bitnami/argo-cd] Release 4.7.24 (#18759) ([bd8dccd](https://github.com/bitnami/charts/commit/bd8dccdec908ad09032178f6ac08d92966f56e48)), closes [#18759](https://github.com/bitnami/charts/issues/18759)

## <small>4.7.23 (2023-08-17)</small>

* [bitnami/argo-cd] Release 4.7.23 (#18499) ([27f206b](https://github.com/bitnami/charts/commit/27f206b5cacbaaa6cf64b1a494d06a6986d88613)), closes [#18499](https://github.com/bitnami/charts/issues/18499)

## <small>4.7.22 (2023-08-11)</small>

* [bitnami/argo-cd] Release 4.7.22 (#18367) ([92933f0](https://github.com/bitnami/charts/commit/92933f00a82f88af5ef9736d3496210ad0af92e0)), closes [#18367](https://github.com/bitnami/charts/issues/18367)

## <small>4.7.21 (2023-08-09)</small>

* [bitnami/argo-cd] Release 4.7.20 (#18245) ([a53d198](https://github.com/bitnami/charts/commit/a53d1986fa3108b45e24cc56e39716050a0508ac)), closes [#18245](https://github.com/bitnami/charts/issues/18245)

## <small>4.7.20 (2023-08-08)</small>

* [bitnami/argo-cd] chore: :page_facing_up: Remove license in CRDs (#18258) ([0d87d8f](https://github.com/bitnami/charts/commit/0d87d8f19e55c697421f0017710f48bc61dc2aa0)), closes [#18258](https://github.com/bitnami/charts/issues/18258)

## <small>4.7.19 (2023-08-01)</small>

* [bitnami/argo-cd] Release 4.7.19 (#18076) ([fe93299](https://github.com/bitnami/charts/commit/fe93299c042fe2f93e3d7beff58b0077a5fafbb3)), closes [#18076](https://github.com/bitnami/charts/issues/18076)

## <small>4.7.18 (2023-07-25)</small>

* [bitnami/argo-cd] Release 4.7.18 (#17858) ([8f478a1](https://github.com/bitnami/charts/commit/8f478a1df31af44f3807172286b91b7677287df9)), closes [#17858](https://github.com/bitnami/charts/issues/17858)

## <small>4.7.17 (2023-07-19)</small>

* [bitnami/argo-cd] Release 4.7.17 (#17788) ([982dc79](https://github.com/bitnami/charts/commit/982dc79c493c67fd54975ba4a1c23bc44d9f417b)), closes [#17788](https://github.com/bitnami/charts/issues/17788)

## <small>4.7.16 (2023-07-14)</small>

* [bitnami/argo-cd] Release 4.7.16 (#17698) ([59ddcc8](https://github.com/bitnami/charts/commit/59ddcc8556f77db3399b1fba13aad4745644ecd2)), closes [#17698](https://github.com/bitnami/charts/issues/17698)

## <small>4.7.15 (2023-07-13)</small>

* [bitnami/argo-cd] Release 4.7.15 (#17635) ([c614f31](https://github.com/bitnami/charts/commit/c614f318fce6c2c704a2fd5dce1e1a6a50ff9f3c)), closes [#17635](https://github.com/bitnami/charts/issues/17635)
* Use os-shell in tempate and Jaeger runtime params (#17557) ([91a49eb](https://github.com/bitnami/charts/commit/91a49eb1e3c81c7b7c6c28d1bc5d6d6ae698c1e2)), closes [#17557](https://github.com/bitnami/charts/issues/17557)

## <small>4.7.14 (2023-07-06)</small>

* [bitnami/argo-cd] Release 4.7.14 (#17511) ([bb842cd](https://github.com/bitnami/charts/commit/bb842cd4ef0cccfbc540e96d8fbf5f231995105d)), closes [#17511](https://github.com/bitnami/charts/issues/17511)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)

## <small>4.7.13 (2023-06-22)</small>

* [bitnami/argo-cd] Release 4.7.13 (#17251) ([77a5275](https://github.com/bitnami/charts/commit/77a52754432ff61c574c541de00fd394ed7db98f)), closes [#17251](https://github.com/bitnami/charts/issues/17251)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## <small>4.7.12 (2023-06-20)</small>

* [bitnami/argo-cd] Release 4.7.12 (#17191) ([4783662](https://github.com/bitnami/charts/commit/4783662a9111036522ecd8302a51b463d28ef49e)), closes [#17191](https://github.com/bitnami/charts/issues/17191)

## <small>4.7.11 (2023-06-19)</small>

* [bitnami/argo-cd] Release 4.7.11 (#17189) ([3b07034](https://github.com/bitnami/charts/commit/3b07034e1a5008e14776ad4594c32f257af77379)), closes [#17189](https://github.com/bitnami/charts/issues/17189)

## <small>4.7.10 (2023-06-19)</small>

* [bitnami/argo-cd] Release 4.7.10 (#17156) ([3c000d5](https://github.com/bitnami/charts/commit/3c000d5837a966ce7790190174436df7c3024a53)), closes [#17156](https://github.com/bitnami/charts/issues/17156)

## <small>4.7.9 (2023-06-15)</small>

* [bitnami/argo-cd] Release 4.7.9 (#17141) ([aec0bbb](https://github.com/bitnami/charts/commit/aec0bbb6b768593147f2b4768b6c1d48f9c76630)), closes [#17141](https://github.com/bitnami/charts/issues/17141)

## <small>4.7.8 (2023-06-14)</small>

* [bitnami/argo-cd] Update subcharts (redis) (#17120) ([d4b8ca1](https://github.com/bitnami/charts/commit/d4b8ca1db7eb9efc86138e4f4aa9efe0d52a3a6c)), closes [#17120](https://github.com/bitnami/charts/issues/17120)

## <small>4.7.7 (2023-06-13)</small>

* [bitnami/argo-cd] Release 4.7.7 (#17105) ([3052140](https://github.com/bitnami/charts/commit/3052140586565092c8fff08642105b8cf91c17aa)), closes [#17105](https://github.com/bitnami/charts/issues/17105)

## <small>4.7.6 (2023-06-05)</small>

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/argo-cd] Release 4.7.6 (#17034) ([0e82446](https://github.com/bitnami/charts/commit/0e8244664128b63bbbb60a8a2f8375082da9e96b)), closes [#17034](https://github.com/bitnami/charts/issues/17034)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)

## <small>4.7.5 (2023-05-25)</small>

* [bitnami/argo-cd] Release 4.7.5 (#16902) ([987a173](https://github.com/bitnami/charts/commit/987a1733ebb3971afad97fc5432976d50b586487)), closes [#16902](https://github.com/bitnami/charts/issues/16902)

## <small>4.7.4 (2023-05-21)</small>

* [bitnami/argo-cd] Release 4.7.4 (#16755) ([5aeb26b](https://github.com/bitnami/charts/commit/5aeb26b1b0508b91ac73fd4bccd98196d0c26a1e)), closes [#16755](https://github.com/bitnami/charts/issues/16755)

## <small>4.7.3 (2023-05-16)</small>

* [bitnami/argo-cd] Release 4.7.3 (#16682) ([5969ba2](https://github.com/bitnami/charts/commit/5969ba2f78831dd2fba603c4a5007efa35cfb4a9)), closes [#16682](https://github.com/bitnami/charts/issues/16682)

## <small>4.7.2 (2023-05-12)</small>

* [bitnami/argo-cd] Release 4.7.2 (#16613) ([85e10ea](https://github.com/bitnami/charts/commit/85e10ea3b7f52bda2b237f8078c186646c8c0009)), closes [#16613](https://github.com/bitnami/charts/issues/16613)

## <small>4.7.1 (2023-05-11)</small>

* [bitnami/argo-cd] Release 4.7.1 (#16587) ([9049f95](https://github.com/bitnami/charts/commit/9049f95b9a7c23ba48205348c710702225542e4b)), closes [#16587](https://github.com/bitnami/charts/issues/16587)
* Add wording for enterprise page (#16560) ([8f22774](https://github.com/bitnami/charts/commit/8f2277440b976d52785ba9149762ad8620a73d1f)), closes [#16560](https://github.com/bitnami/charts/issues/16560)

## 4.7.0 (2023-05-09)

* [bitnami/several] Adapt Chart.yaml to set desired OCI annotations (#16546) ([fc9b18f](https://github.com/bitnami/charts/commit/fc9b18f2e98805d4df629acbcde696f44f973344)), closes [#16546](https://github.com/bitnami/charts/issues/16546)

## <small>4.6.3 (2023-05-09)</small>

* [bitnami/argo-cd] Release 4.6.3 (#16527) ([9a11833](https://github.com/bitnami/charts/commit/9a11833340746234084a8211154213cde4fc6181)), closes [#16527](https://github.com/bitnami/charts/issues/16527)

## <small>4.6.2 (2023-04-29)</small>

* [bitnami/argo-cd] Release 4.6.2 (#16279) ([4dd6a2f](https://github.com/bitnami/charts/commit/4dd6a2f2a13875a11beab313cef13cd87a96a9c4)), closes [#16279](https://github.com/bitnami/charts/issues/16279)

## <small>4.6.1 (2023-04-25)</small>

* [bitnami/argo-cd] Add helper for the redis image (#16214) ([b357b16](https://github.com/bitnami/charts/commit/b357b169657792f994c03b6be0602c8f841c7020)), closes [#16214](https://github.com/bitnami/charts/issues/16214)

## 4.6.0 (2023-04-20)

* [bitnami/*] Make Helm charts 100% OCI (#15998) ([8841510](https://github.com/bitnami/charts/commit/884151035efcbf2e1b3206e7def85511073fb57d)), closes [#15998](https://github.com/bitnami/charts/issues/15998)

## <small>4.5.7 (2023-04-17)</small>

* [bitnami/argo-cd] Fix Dex probes and switch to https (#16085) ([e165b09](https://github.com/bitnami/charts/commit/e165b093fc0c6eb4c4ae3971ae0c918f2c64dadc)), closes [#16085](https://github.com/bitnami/charts/issues/16085)

## <small>4.5.6 (2023-04-11)</small>

* [bitnami/argo-cd] Fix wrong variable name (#15999) ([db3d083](https://github.com/bitnami/charts/commit/db3d08360f6569ad0e33803f80032a90b23236ec)), closes [#15999](https://github.com/bitnami/charts/issues/15999)

## <small>4.5.5 (2023-04-06)</small>

* [bitnami/argo-cd] Fix issue with crds version #15637 (#15709) ([9c87106](https://github.com/bitnami/charts/commit/9c8710608fc84a4bc168409f2b2431731a7ca6eb)), closes [#15637](https://github.com/bitnami/charts/issues/15637) [#15709](https://github.com/bitnami/charts/issues/15709)
* Change argo-cd document link to latest (#15833) ([f3294dc](https://github.com/bitnami/charts/commit/f3294dc27605f0741f5484b0070db49205466e7f)), closes [#15833](https://github.com/bitnami/charts/issues/15833)
* fix(argo-cd): remove namespace field for cluster wide resources (#15801) ([3c2df5b](https://github.com/bitnami/charts/commit/3c2df5bd7ef760095314e6853907eb0d317ac69a)), closes [#15801](https://github.com/bitnami/charts/issues/15801)

## <small>4.5.4 (2023-04-01)</small>

* [bitnami/argo-cd] Release 4.5.4 (#15840) ([dec15f2](https://github.com/bitnami/charts/commit/dec15f21ce42d645638249b1fee018839561fe19)), closes [#15840](https://github.com/bitnami/charts/issues/15840)

## <small>4.5.3 (2023-03-30)</small>

* [bitnami/argo-cd] Fix argocd-tls-certs-cm and argocd-gpg-keys-cm not found (#15754) ([8aae205](https://github.com/bitnami/charts/commit/8aae205d5e9bb909ffc5c642bd9effa4935e89cc)), closes [#15754](https://github.com/bitnami/charts/issues/15754)

## <small>4.5.2 (2023-03-23)</small>

* [bitnami/argo-cd] Release 4.5.2 (#15711) ([464d8d2](https://github.com/bitnami/charts/commit/464d8d2e4d0ee39f4a31a4c9efe3531ea1161f62)), closes [#15711](https://github.com/bitnami/charts/issues/15711)

## <small>4.5.1 (2023-03-23)</small>

* [bitnami/argo-cd] Fix issue with applicationset-controller + minor fixes (#15699) ([45349ae](https://github.com/bitnami/charts/commit/45349ae1010efd52e9c89abaf1097a48e45bfc74)), closes [#15699](https://github.com/bitnami/charts/issues/15699)

## 4.5.0 (2023-03-20)

* [bitnami/argo-cd] Add the notifications service to the solution (#15633) ([68fa931](https://github.com/bitnami/charts/commit/68fa931c3de3260c6b4472329aa9de60784b057a)), closes [#15633](https://github.com/bitnami/charts/issues/15633)

## <small>4.4.16 (2023-03-18)</small>

* [bitnami/argo-cd] Release 4.4.16 (#15553) ([a17f380](https://github.com/bitnami/charts/commit/a17f380649db8f1cc35d5073dec4cf4122319568)), closes [#15553](https://github.com/bitnami/charts/issues/15553)
* Fix typo applicationSet name on ServiceMonitor (#15478) ([5bf30f1](https://github.com/bitnami/charts/commit/5bf30f16793e1b7c12b379f98ad90fe9185a5a41)), closes [#15478](https://github.com/bitnami/charts/issues/15478)

## <small>4.4.15 (2023-03-14)</small>

* [bitnami/argo-cd] Release 4.4.15 (#15499) ([f8e2cbe](https://github.com/bitnami/charts/commit/f8e2cbe7d4cba906197da5b18533a74911b9d170)), closes [#15499](https://github.com/bitnami/charts/issues/15499)

## <small>4.4.14 (2023-03-09)</small>

* [bitnami/argo-cd] Release 4.4.14 (#15406) ([324444d](https://github.com/bitnami/charts/commit/324444d52fde734632fc3a6feec7a366acd53970)), closes [#15406](https://github.com/bitnami/charts/issues/15406)

## <small>4.4.13 (2023-03-08)</small>

* [bitnami/argo-cd] Release 4.4.13 (#15382) ([b24221f](https://github.com/bitnami/charts/commit/b24221ffc80a72ed4ab9f916cd3dfef0e8d79a0a)), closes [#15382](https://github.com/bitnami/charts/issues/15382)
* [bitnami/charts] Apply linter to README files (#15357) ([0e29e60](https://github.com/bitnami/charts/commit/0e29e600d3adc8b1b46e506eccb3decfab3b4e63)), closes [#15357](https://github.com/bitnami/charts/issues/15357)

## <small>4.4.12 (2023-03-01)</small>

* [bitnami/argo-cd] Release 4.4.12 (#15254) ([e901fce](https://github.com/bitnami/charts/commit/e901fce1cd10617a77424cf5f11fa58381eb4893)), closes [#15254](https://github.com/bitnami/charts/issues/15254)

## <small>4.4.11 (2023-02-27)</small>

* [bitnami/argo-cd] Release 4.4.11 (#15166) ([9a2507f](https://github.com/bitnami/charts/commit/9a2507f726ee06d18b3c8ed105cb73aaab78098a)), closes [#15166](https://github.com/bitnami/charts/issues/15166)

## <small>4.4.10 (2023-02-17)</small>

* [bitnami/*] Fix markdown linter issues (#14874) ([a51e0e8](https://github.com/bitnami/charts/commit/a51e0e8d35495b907f3e70dd2f8e7c3bcbf4166a)), closes [#14874](https://github.com/bitnami/charts/issues/14874)
* [bitnami/*] Fix markdown linter issues 2 (#14890) ([aa96572](https://github.com/bitnami/charts/commit/aa9657237ee8df4a46db0d7fdf8a23230dd6902a)), closes [#14890](https://github.com/bitnami/charts/issues/14890)
* [bitnami/*] Remove unexpected extra spaces (#14873) ([c97c714](https://github.com/bitnami/charts/commit/c97c714887380d47eae7bfeff316bf01595ecd1d)), closes [#14873](https://github.com/bitnami/charts/issues/14873)
* [bitnami/argo-cd] Release 4.4.10 (#14946) ([20dc13b](https://github.com/bitnami/charts/commit/20dc13b5983e6b1a725ce17fcd4f5b9d1fc8282d)), closes [#14946](https://github.com/bitnami/charts/issues/14946)

## <small>4.4.9 (2023-02-09)</small>

* [bitnami/argo-cd] Release 4.4.9 (#14810) ([7759d1a](https://github.com/bitnami/charts/commit/7759d1a9c0931897dd5667cefecc0894bf8d3955)), closes [#14810](https://github.com/bitnami/charts/issues/14810)

## <small>4.4.8 (2023-02-08)</small>

* [bitnami/argo-cd] Release 4.4.8 (#14802) ([91f9132](https://github.com/bitnami/charts/commit/91f91327620574db4ee7c5126d44673dc90b7296)), closes [#14802](https://github.com/bitnami/charts/issues/14802)

## <small>4.4.7 (2023-02-07)</small>

* [bitnami/argo-cd] Release 4.4.7 (#14769) ([4025569](https://github.com/bitnami/charts/commit/40255697cd5f57e4128c73435d1b9134bc5437ce)), closes [#14769](https://github.com/bitnami/charts/issues/14769)

## <small>4.4.6 (2023-02-02)</small>

* [bitnami/argo-cd] Release 4.4.6 (#14730) ([a8c1d42](https://github.com/bitnami/charts/commit/a8c1d4206cbc78c53a90f4001ee245e121708dc3)), closes [#14730](https://github.com/bitnami/charts/issues/14730)

## <small>4.4.5 (2023-01-31)</small>

* [bitnami/*] Change copyright date (#14682) ([add4ec7](https://github.com/bitnami/charts/commit/add4ec701108ac36ed4de2dffbdf407a0d091067)), closes [#14682](https://github.com/bitnami/charts/issues/14682)
* [bitnami/argo-cd] Don't regenerate self-signed certs on upgrade (#14608) ([1a5c770](https://github.com/bitnami/charts/commit/1a5c77099bf2b26df0e1fc3c8cfd707ee5f9ce69)), closes [#14608](https://github.com/bitnami/charts/issues/14608)

## <small>4.4.4 (2023-01-29)</small>

* [bitnami/argo-cd] Release 4.4.4 (#14579) ([bb91f3c](https://github.com/bitnami/charts/commit/bb91f3c0e5763b31f003b49e25e5124b23d145a1)), closes [#14579](https://github.com/bitnami/charts/issues/14579)

## <small>4.4.3 (2023-01-26)</small>

* [bitnami/*] Unify READMEs (#14472) ([2064fb8](https://github.com/bitnami/charts/commit/2064fb8dcc78a845cdede8211af8c3cc52551161)), closes [#14472](https://github.com/bitnami/charts/issues/14472)
* [bitnami/argo-cd] Release 4.4.3 (#14548) ([594905a](https://github.com/bitnami/charts/commit/594905a40ba30456228639f5b9cbe5462b353e2d)), closes [#14548](https://github.com/bitnami/charts/issues/14548)

## <small>4.4.2 (2023-01-18)</small>

* [bitnami/*] Add license annotation and remove obsolete engine parameter (#14293) ([da2a794](https://github.com/bitnami/charts/commit/da2a7943bae95b6e9b5b4ed972c15e990b69fdb0)), closes [#14293](https://github.com/bitnami/charts/issues/14293)
* [bitnami/*] Change licenses annotation format (#14377) ([0ab7608](https://github.com/bitnami/charts/commit/0ab760862c660fcc78cffadf8e1d8cdd70881473)), closes [#14377](https://github.com/bitnami/charts/issues/14377)
* [bitnami/argo-cd] Release 4.4.2 (#14414) ([bd70366](https://github.com/bitnami/charts/commit/bd70366fdaa1516eb24bea5c4e9a30380b2baaea)), closes [#14414](https://github.com/bitnami/charts/issues/14414)

## <small>4.4.1 (2023-01-10)</small>

* [bitnami/argo-cd] Release 4.4.1 (#14269) ([2a3fb29](https://github.com/bitnami/charts/commit/2a3fb29a1e5e089a53cfb205535e35116fcf4887)), closes [#14269](https://github.com/bitnami/charts/issues/14269)

## 4.4.0 (2022-12-21)

* [bitnami/argo-cd] Add applicationSet deployment to the chart (#13723) ([69e34ff](https://github.com/bitnami/charts/commit/69e34ffa40131063e936d9831af20e9cc8b1801d)), closes [#13723](https://github.com/bitnami/charts/issues/13723)

## <small>4.3.8 (2022-12-19)</small>

* [bitnami/argo-cd] Release 4.3.8 (#13998) ([c3f25ac](https://github.com/bitnami/charts/commit/c3f25aceb533aa3ad3039f9225ab052965bd3861)), closes [#13998](https://github.com/bitnami/charts/issues/13998)

## <small>4.3.7 (2022-12-07)</small>

* [bitnami/argo-cd] Release 4.3.7 (#13853) ([1339c1d](https://github.com/bitnami/charts/commit/1339c1da6d9f4518d2f24001440a8c216ed91ca4)), closes [#13853](https://github.com/bitnami/charts/issues/13853)

## <small>4.3.6 (2022-11-28)</small>

* [bitnami/argo-cd] Release 4.3.6 (#13726) ([9823c4f](https://github.com/bitnami/charts/commit/9823c4f17472b2e87706edbcaee90aba9e1ed7a3)), closes [#13726](https://github.com/bitnami/charts/issues/13726)

## <small>4.3.5 (2022-11-24)</small>

* Use correct secret annotations in argocd-secret (#13664) ([204c569](https://github.com/bitnami/charts/commit/204c569c49b435da55b9038116efb64d50bb2eb9)), closes [#13664](https://github.com/bitnami/charts/issues/13664)

## <small>4.3.4 (2022-11-22)</small>

* [binami/argo-cd] fix apiversion hardcode ClusterRoleBinding (#13615) ([37d8717](https://github.com/bitnami/charts/commit/37d87173534ee95a8c578e02015ebcfdda4b98c2)), closes [#13615](https://github.com/bitnami/charts/issues/13615)

## <small>4.3.3 (2022-11-09)</small>

* [bitnami/argo-cd] Release 4.3.3 (#13438) ([15e6daa](https://github.com/bitnami/charts/commit/15e6daa7fa4beaa74918b941eba744894e0ae73e)), closes [#13438](https://github.com/bitnami/charts/issues/13438)

## <small>4.3.2 (2022-11-08)</small>

* [bitnami/argo-cd] Release 4.3.2 (#13389) ([604efff](https://github.com/bitnami/charts/commit/604efffd1a4810b4f5421d44df45b69e6a8b48d0)), closes [#13389](https://github.com/bitnami/charts/issues/13389)

## <small>4.3.1 (2022-11-02)</small>

* [bitnami/argo-cd] Release 4.3.1 (#13301) ([51ef105](https://github.com/bitnami/charts/commit/51ef1052975fdb18b64730b672d903d7382780dc)), closes [#13301](https://github.com/bitnami/charts/issues/13301)

## 4.3.0 (2022-10-31)

* [bitnami/argo-cd] Add tests and publishing using VIB (#13177) ([956b34f](https://github.com/bitnami/charts/commit/956b34f46364c4fe84bd0220d68700d44e5097b3)), closes [#13177](https://github.com/bitnami/charts/issues/13177)

## <small>4.2.7 (2022-10-26)</small>

* [bitnami/argo-cd] Release 4.2.7 updating components versions ([747dbc5](https://github.com/bitnami/charts/commit/747dbc575bd123bf650694e40ceeaea756f2251e))

## <small>4.2.6 (2022-10-24)</small>

* [bitnami/argo-cd] Fix volume-permissions initContainer definitions (#12853) ([5c5257d](https://github.com/bitnami/charts/commit/5c5257d7f9255791e93ab4d7d43f165d40fef2b0)), closes [#12853](https://github.com/bitnami/charts/issues/12853)

## <small>4.2.5 (2022-10-18)</small>

* [bitnami/*] Use new default branch name in links (#12943) ([a529e02](https://github.com/bitnami/charts/commit/a529e02597d49d944eba1eb0f190713293247176)), closes [#12943](https://github.com/bitnami/charts/issues/12943)
* [bitnami/argo-cd] Release 4.2.5 updating components versions ([388a4b0](https://github.com/bitnami/charts/commit/388a4b0151d2c68c635859c09adcc4235684b81f))

## <small>4.2.4 (2022-10-13)</small>

* fix(metrics-svc-annotations): Fix wrong value reference (#12918) ([80cd2ea](https://github.com/bitnami/charts/commit/80cd2ea93d04f5d707d2f9bbdee5ddc82309a1bf)), closes [#12918](https://github.com/bitnami/charts/issues/12918)

## <small>4.2.3 (2022-10-05)</small>

* [bitnami/argo-cd] Release 4.2.3 updating components versions ([ac9cd57](https://github.com/bitnami/charts/commit/ac9cd57e637e66b46ff65e2e1636d4b313345bab))
* Generic README instructions related to the repo (#12792) ([3cf6b10](https://github.com/bitnami/charts/commit/3cf6b10e10e60df4b3e191d6b99aa99a9f597755)), closes [#12792](https://github.com/bitnami/charts/issues/12792)

## <small>4.2.2 (2022-10-04)</small>

* [bitnami/argo-cd] Release 4.2.2 updating components versions ([8765b3a](https://github.com/bitnami/charts/commit/8765b3a4bd5be9d1fd42206a9b9dfe714a0276e0))

## <small>4.2.1 (2022-10-03)</small>

* [bitnami/argo-cd] Add shareProccessNamespace value (#12790) ([4f0d0ba](https://github.com/bitnami/charts/commit/4f0d0badd407c695e203e84215e232333cded99a)), closes [#12790](https://github.com/bitnami/charts/issues/12790)

## 4.2.0 (2022-09-26)

* [bitnami/argocd] Additional configuration for wait-for-redis container (#12647) ([8d8a928](https://github.com/bitnami/charts/commit/8d8a928984d7864182d457ad1dc797d139cc68ac)), closes [#12647](https://github.com/bitnami/charts/issues/12647)

## <small>4.1.5 (2022-09-21)</small>

* [bitnami/argo-cd] Use custom probes if given (#12480) ([067b084](https://github.com/bitnami/charts/commit/067b084f0a7fdef3ff214845482b17170747d8ae)), closes [#12480](https://github.com/bitnami/charts/issues/12480) [#12354](https://github.com/bitnami/charts/issues/12354)

## <small>4.1.4 (2022-09-16)</small>

* [bitnami/argo-cd] Release 4.1.4 updating components versions ([4b852a4](https://github.com/bitnami/charts/commit/4b852a409b0ab5659b8e7c1b2334a1cca458cf84))

## <small>4.1.3 (2022-09-03)</small>

* [bitnami/argo-cd] Release 4.1.3 updating components versions ([ce6d222](https://github.com/bitnami/charts/commit/ce6d2222b170c504ae6286bbfe1e06da1cabae03))

## <small>4.1.2 (2022-08-23)</small>

* [bitnami/argo-cd] Update Chart.lock (#12104) ([3edb083](https://github.com/bitnami/charts/commit/3edb083670734b5d9ac100ec007d03d7b026ad8d)), closes [#12104](https://github.com/bitnami/charts/issues/12104)

## <small>4.1.1 (2022-08-22)</small>

* [bitnami/argo-cd] Update Chart.lock (#11995) ([1f7d99a](https://github.com/bitnami/charts/commit/1f7d99a08ab112530c49e583477b9e76a3244daf)), closes [#11995](https://github.com/bitnami/charts/issues/11995)

## 4.1.0 (2022-08-22)

* [bitnami/argo-cd] Add support for image digest apart from tag (#11880) ([df963a8](https://github.com/bitnami/charts/commit/df963a80a240916fe7a4df11a36e8bc87dd03c0f)), closes [#11880](https://github.com/bitnami/charts/issues/11880)

## <small>4.0.6 (2022-08-04)</small>

* [bitnami/argo-cd] Release 4.0.6 updating components versions ([aff50f7](https://github.com/bitnami/charts/commit/aff50f76b6d2d42e42ae9066a98301ade4d38992))

## <small>4.0.5 (2022-08-04)</small>

* [bitnami/argo-cd] Release 4.0.5 updating components versions ([31000a4](https://github.com/bitnami/charts/commit/31000a478524277e891454f2f6936f1217e1487e))

## <small>4.0.4 (2022-08-02)</small>

* [bitnami/argo-cd] Release 4.0.4 updating components versions ([5f70cd8](https://github.com/bitnami/charts/commit/5f70cd8904a24921f53b2c7de73f77992dff480e))

## <small>4.0.3 (2022-07-29)</small>

* [bitnami/*] Update URLs to point to the new bitnami/containers monorepo (#11352) ([d665af0](https://github.com/bitnami/charts/commit/d665af0c708846192d8d5fb2f5f9ea65dd464ab0)), closes [#11352](https://github.com/bitnami/charts/issues/11352)
* [bitnami/argo-cd] Fix link to upgrade notes. (#11356) ([c8240dd](https://github.com/bitnami/charts/commit/c8240ddf458fb9fc48b84c5334c8132bf05aa91a)), closes [#11356](https://github.com/bitnami/charts/issues/11356)
* [bitnami/argo-cd] Release 4.0.3 updating components versions ([5223c9c](https://github.com/bitnami/charts/commit/5223c9ce5a64ffbc6bffb76e0ca1c1a62d2e5082))

## <small>4.0.2 (2022-07-19)</small>

* [bitnami/argo-cd] Release 4.0.2 updating components versions ([83cc1a6](https://github.com/bitnami/charts/commit/83cc1a6f838827badc0e53a59290eabc76753663))

## <small>4.0.1 (2022-07-14)</small>

* [bitnami/argo-cd] Release 4.0.1 updating components versions ([ee6885c](https://github.com/bitnami/charts/commit/ee6885c61e08e5259072bdd6eb83d57d2b2ccaa7))

## 4.0.0 (2022-07-13)

* [bitnami/argo-cd] Update Redis subchart (#11172) ([0390285](https://github.com/bitnami/charts/commit/039028532e7a5105f9cf2f894ab8567090d782ed)), closes [#11172](https://github.com/bitnami/charts/issues/11172)

## <small>3.4.6 (2022-07-13)</small>

* [bitnami/argo-cd] Release 3.4.6 updating components versions ([5b8786c](https://github.com/bitnami/charts/commit/5b8786ceb014f162f1c970e737b3183d8d07efc8))
* fix(argocd): persistent admin password on upgrade (#10989) ([c5283e5](https://github.com/bitnami/charts/commit/c5283e54f4df831e48cbf5a93ca8048a05b0ffe7)), closes [#10989](https://github.com/bitnami/charts/issues/10989)

## <small>3.4.5 (2022-07-08)</small>

* [bitnami/argo-cd] docs: :memo: Remove unnecessary whitespace (#10973) ([6538700](https://github.com/bitnami/charts/commit/65387009cf266b900b52898c1457d1625d2434f8)), closes [#10973](https://github.com/bitnami/charts/issues/10973)
* [bitnami/argo-cd] Release 3.4.5 updating components versions ([1df98d5](https://github.com/bitnami/charts/commit/1df98d5545173aa23750944c9df6143befd8be55))

## <small>3.4.4 (2022-06-28)</small>

* [bitnami/argo-cd] Release 3.4.4 updating components versions ([299d225](https://github.com/bitnami/charts/commit/299d225555419742d7da06e864e61c4b0fcb5441))

## <small>3.4.3 (2022-06-25)</small>

* [bitnami/argo-cd] Release 3.4.3 updating components versions ([e778898](https://github.com/bitnami/charts/commit/e7788982318c75a04833de7720439f7b3c659c09))

## <small>3.4.2 (2022-06-22)</small>

* [bitnami/argo-cd] Release 3.4.2 updating components versions ([230e5f8](https://github.com/bitnami/charts/commit/230e5f871600e29fc367a7fa0389f4edf1f680b8))

## <small>3.4.1 (2022-06-14)</small>

* [bitnami/argo-cd] Release 3.4.1 updating components versions ([116485b](https://github.com/bitnami/charts/commit/116485b11b30ed0a4c96084b4f1efccb01fd3ec9))

## 3.4.0 (2022-06-13)

* [bitnami/*] Replace Kubeapps URL in READMEs (and kubeapps Chart.yaml) and remove BKPR references (#1 ([c6a7914](https://github.com/bitnami/charts/commit/c6a7914361e5aea6016fb45bf4d621edfd111d32)), closes [#10600](https://github.com/bitnami/charts/issues/10600)
* [bitnami/argo-cd] add runtime class support (#10695) ([ece7709](https://github.com/bitnami/charts/commit/ece770955d303a96b363cbd8addd0587dc38fbc0)), closes [#10695](https://github.com/bitnami/charts/issues/10695)

## <small>3.3.9 (2022-06-06)</small>

* [bitnami/argo-cd] Release 3.3.9 updating components versions ([57c8f10](https://github.com/bitnami/charts/commit/57c8f107d90b2da897268685bb216e6ddf53fc34))

## <small>3.3.8 (2022-06-02)</small>

* Update Redis trademark references ([2cada87](https://github.com/bitnami/charts/commit/2cada87ed4967d5cb578b0409a0bb1edee79029a))

## <small>3.3.7 (2022-06-01)</small>

* [bitnami/several] Replace maintainers email by url (#10523) ([ff3cf61](https://github.com/bitnami/charts/commit/ff3cf617a1680509b0f3855d17c4ccff7b29a0ff)), closes [#10523](https://github.com/bitnami/charts/issues/10523)

## <small>3.3.6 (2022-05-26)</small>

* [bitnami/argo-cd] Release 3.3.6 updating components versions ([957eb3c](https://github.com/bitnami/charts/commit/957eb3c0f3ad2718d3c23a94f7517e28d58d32d0))

## <small>3.3.5 (2022-05-23)</small>

* [bitnami/argo-cd] Use the new helper for HPA API version (#10193) ([712c4fa](https://github.com/bitnami/charts/commit/712c4fa8e6125ce5518e97dee3d06299ea09ed73)), closes [#10193](https://github.com/bitnami/charts/issues/10193)

## <small>3.3.4 (2022-05-22)</small>

* [bitnami/argo-cd] Release 3.3.4 updating components versions ([dcab824](https://github.com/bitnami/charts/commit/dcab8240d66d8105a9ecd9f99cd63af6f749629e))

## <small>3.3.3 (2022-05-21)</small>

* [bitnami/argo-cd] Release 3.3.3 updating components versions ([f8d4593](https://github.com/bitnami/charts/commit/f8d45934583cc12542d3e8e481dc54fdf49ace66))

## <small>3.3.2 (2022-05-19)</small>

* [bitnami/argo-cd] Release 3.3.2 updating components versions ([ebe1043](https://github.com/bitnami/charts/commit/ebe1043ca87359aadc7e8d775e31c15a6d876710))

## <small>3.3.1 (2022-05-18)</small>

* [bitnami/argo-cd] Release 3.3.1 updating components versions ([4847662](https://github.com/bitnami/charts/commit/48476621ea378b959bfb254578e09c80bbe2174e))

## 3.3.0 (2022-05-16)

* [bitnami/*] add ingress extraRules feature (#10253) ([0f6cbb9](https://github.com/bitnami/charts/commit/0f6cbb9099b0e56685cc1d36ba50340f3d7278a1)), closes [#10253](https://github.com/bitnami/charts/issues/10253)

## <small>3.2.4 (2022-05-13)</small>

* [bitnami/argo-cd] Release 3.2.4 updating components versions ([d5083c0](https://github.com/bitnami/charts/commit/d5083c0f3c88dd428e2a97d96b074d6f932c4fff))

## <small>3.2.3 (2022-05-13)</small>

* [bitnami/*] Unify k8s directives separators (#10185) ([2650214](https://github.com/bitnami/charts/commit/26502141d146ca3bdfb3bf744fcdec8ca5cece44)), closes [#10185](https://github.com/bitnami/charts/issues/10185)

## <small>3.2.2 (2022-05-12)</small>

* [bitnami/argo-cd] Ensure default's container entrypoint is executed (#9923) ([6796f22](https://github.com/bitnami/charts/commit/6796f22cb1477e98cfd3d6169d03d8f4656db4e2)), closes [#9923](https://github.com/bitnami/charts/issues/9923)

## <small>3.2.1 (2022-05-11)</small>

* [bitnami/argo-cd] Add missing namespace metadata (#10099) ([f3e3fe9](https://github.com/bitnami/charts/commit/f3e3fe93100e7b289326ea20a4aa98cad48933bd)), closes [#10099](https://github.com/bitnami/charts/issues/10099)

## 3.2.0 (2022-05-10)

* [bitnami/argo-cd] Change default for readOnly and runAsUser (#10094) ([e2f6ba9](https://github.com/bitnami/charts/commit/e2f6ba9b137791b5a762e0cb3fcb08203c7f6294)), closes [#10094](https://github.com/bitnami/charts/issues/10094)
* [bitnami/argo-cd] Fix SSH repo bug: No user exists for uid 1001 (#9986) ([165ed11](https://github.com/bitnami/charts/commit/165ed11a964e86abae75c65ac6efd50451cbe6ad)), closes [#9986](https://github.com/bitnami/charts/issues/9986)

## <small>3.1.16 (2022-04-30)</small>

* [bitnami/argo-cd] Release 3.1.16 updating components versions ([afade73](https://github.com/bitnami/charts/commit/afade732c2017838c91dbc778e8931e562e25de5))

## <small>3.1.15 (2022-04-28)</small>

* [bitnami/argo-cd] Fix Prometheus Operator integration (#9930) ([8644d63](https://github.com/bitnami/charts/commit/8644d63bb7ae7dd0d140d8d287f109f76f3d86e8)), closes [#9930](https://github.com/bitnami/charts/issues/9930)

## <small>3.1.14 (2022-04-22)</small>

* [bitnami/argo-cd] Release 3.1.14 updating components versions ([f9e139e](https://github.com/bitnami/charts/commit/f9e139e119172931ec7843de956fce3b546217fe))

## <small>3.1.13 (2022-04-19)</small>

* [bitnami/argo-cd] Release 3.1.13 updating components versions ([5588a4f](https://github.com/bitnami/charts/commit/5588a4fc504ea6878bf85c4e80b98d5e3cadbbaf))

## <small>3.1.12 (2022-04-12)</small>

* [bitnami/argo-cd] document clean, fix typos ([88a340d](https://github.com/bitnami/charts/commit/88a340d13ff52049d8f04db43b75f26a7ee51c65))

## <small>3.1.11 (2022-04-04)</small>

* [bitnami/argo-cd] Fix issue enabling repoServer.metrics (#9662) ([8aca892](https://github.com/bitnami/charts/commit/8aca892a558155f6b2820d08a38781abd34304cd)), closes [#9662](https://github.com/bitnami/charts/issues/9662)

## <small>3.1.10 (2022-04-02)</small>

* [bitnami/argo-cd] Release 3.1.10 updating components versions ([37d1e4a](https://github.com/bitnami/charts/commit/37d1e4a4fbaacc8e5ce1767f441d0945f4ce6dfc))

## <small>3.1.9 (2022-03-30)</small>

* [bitnami/argo-cd] Release 3.1.9 updating components versions ([bde5eab](https://github.com/bitnami/charts/commit/bde5eab8e9c9be147c06f100f3404d957bc2a158))

## <small>3.1.8 (2022-03-29)</small>

* [bitnami/argo-cd] Release 3.1.8 updating components versions ([8e88382](https://github.com/bitnami/charts/commit/8e883826e1f890dd7725a7dd3b5881a5451ff1a1))

## <small>3.1.7 (2022-03-28)</small>

* [bitnami/argo-cd] Release 3.1.7 updating components versions ([b7af39a](https://github.com/bitnami/charts/commit/b7af39ad3282a82e155bb302df69523d6f910d86))

## <small>3.1.6 (2022-03-27)</small>

* [bitnami/argo-cd] Release 3.1.6 updating components versions ([1d23202](https://github.com/bitnami/charts/commit/1d232025431cd0e66425950eb775913fdc532b0b))

## <small>3.1.5 (2022-03-24)</small>

* [bitnami/argo-cd] Release 3.1.5 updating components versions ([049d747](https://github.com/bitnami/charts/commit/049d74719b80b2a9e5dde8c9770edf018a1ba163))

## <small>3.1.4 (2022-03-21)</small>

* [bitnami/argo-cd] Fix nil pointer evaluating interface {}.server (#9487) ([30ca761](https://github.com/bitnami/charts/commit/30ca761d9bb2166bb078602bffb47f7cf6b4df1d)), closes [#9487](https://github.com/bitnami/charts/issues/9487)

## <small>3.1.3 (2022-03-18)</small>

* [bitnami/argo-cd] Release 3.1.3 updating components versions ([73d5800](https://github.com/bitnami/charts/commit/73d5800cb2ff0aeb9d1cf59d1c84908a84cfb327))

## <small>3.1.2 (2022-03-17)</small>

* [bitnami/argo-cd] Fix context for include inside range extraHosts (#9433) ([510ecd4](https://github.com/bitnami/charts/commit/510ecd4f343ac35292f42f04f6a7701ff60ab043)), closes [#9433](https://github.com/bitnami/charts/issues/9433)
* [bitnami/argo-cd] Release 3.1.2 updating components versions ([526b094](https://github.com/bitnami/charts/commit/526b094c497e9820af4d586822a3522afcbb8c07))

## <small>3.1.1 (2022-03-16)</small>

* [bitnami/argo-cd] Release 3.1.1 updating components versions ([71528de](https://github.com/bitnami/charts/commit/71528debcc0d7870918cff7549ab36e2db9092f9))

## 3.1.0 (2022-03-16)

* [bitnami/argo-cd] Update CRDs + Add ApplicationSet CRD (#9413) ([9c5a02c](https://github.com/bitnami/charts/commit/9c5a02c5dac5c1a8f4a96708964da0bbd442ba40)), closes [#9413](https://github.com/bitnami/charts/issues/9413)

## <small>3.0.13 (2022-03-11)</small>

* [bitnami/argo-cd] Release 3.0.13 updating components versions ([262f2c8](https://github.com/bitnami/charts/commit/262f2c81b4e576d07eaa503a6bd4f6f2332c439d))

## <small>3.0.12 (2022-03-07)</small>

* [bitnami/argo-cd] Release 3.0.12 updating components versions ([b9032a2](https://github.com/bitnami/charts/commit/b9032a28fc0be46a71a9301d69128719e4419040))

## <small>3.0.11 (2022-03-02)</small>

* [bitnami/argo-cd] Fix svc wrong indentation (#9249) ([831a7fe](https://github.com/bitnami/charts/commit/831a7fea37da22c7cc0f4b494696b8e20d3d9262)), closes [#9249](https://github.com/bitnami/charts/issues/9249)

## <small>3.0.10 (2022-03-01)</small>

* [bitnami/argo-cd] Release 3.0.10 updating components versions ([9317d29](https://github.com/bitnami/charts/commit/9317d290cd512979f67f8f3ec5823d25f5099e64))

## <small>3.0.9 (2022-02-27)</small>

* [bitnami/argo-cd] Release 3.0.9 updating components versions ([efe2297](https://github.com/bitnami/charts/commit/efe22975875f8cef1437c96535950353376af1f3))

## <small>3.0.8 (2022-02-25)</small>

* [bitnami/argo-cd] Release 3.0.8 updating components versions ([ddcd4e5](https://github.com/bitnami/charts/commit/ddcd4e5f8b9cec6d17094e97031269b1c36bd6b5))

## <small>3.0.7 (2022-02-23)</small>

* [bitnami/argo-cd] Release 3.0.7 updating components versions ([708215f](https://github.com/bitnami/charts/commit/708215f44fe8032cb61161b45bfcbfaf4fef4b42))

## <small>3.0.6 (2022-02-23)</small>

* [bitnami/argo-cd] Release 3.0.6 updating components versions ([326fccf](https://github.com/bitnami/charts/commit/326fccf5960ba148051632944c953b4b8f30b0b4))

## <small>3.0.5 (2022-02-13)</small>

* [bitnami/argo-cd] Release 3.0.5 updating components versions ([b02f13e](https://github.com/bitnami/charts/commit/b02f13ed9d44eccf023d434f58e24fef124c56b1))

## <small>3.0.4 (2022-02-05)</small>

* [bitnami/argo-cd] Release 3.0.4 updating components versions ([32e69af](https://github.com/bitnami/charts/commit/32e69af9f6ff17a7c92fdb884041299446260e3c))

## <small>3.0.3 (2022-02-03)</small>

* [bitnami/argo-cd] Release 3.0.3 updating components versions ([c451368](https://github.com/bitnami/charts/commit/c45136870b09ae68061dceba06e005753c32293e))

## <small>3.0.2 (2022-01-21)</small>

* [bitnami/argo-cd] Fix tls certs configmap (#8740) ([b2140fa](https://github.com/bitnami/charts/commit/b2140fac3380c4740136aaf0541d9e97631500a3)), closes [#8740](https://github.com/bitnami/charts/issues/8740)
* [bitnami/several] Change prerequisites (#8725) ([8d740c5](https://github.com/bitnami/charts/commit/8d740c566cfdb7e2d933c40128b4e919fce953a5)), closes [#8725](https://github.com/bitnami/charts/issues/8725)

## <small>3.0.1 (2022-01-20)</small>

* [bitnami/*] Update READMEs (#8716) ([b9a9533](https://github.com/bitnami/charts/commit/b9a953337590eb2979453385874a267bacf50936)), closes [#8716](https://github.com/bitnami/charts/issues/8716)
* [bitnami/argo-cd] Release 3.0.1 updating components versions ([87c46c6](https://github.com/bitnami/charts/commit/87c46c608c8ce51f7b903297ba3cacf2e1e25293))

## 3.0.0 (2022-01-19)

* [bitnami/argo-cd] Chart standardized (#7923) ([74849a7](https://github.com/bitnami/charts/commit/74849a7c2b60798510556d6dc6da8a6467b87804)), closes [#7923](https://github.com/bitnami/charts/issues/7923)

## <small>2.1.2 (2022-01-18)</small>

* [bitnami/*] Readme automation (#8579) ([78d1938](https://github.com/bitnami/charts/commit/78d193831c900d178198491ffd08fa2217a64ecd)), closes [#8579](https://github.com/bitnami/charts/issues/8579)
* [bitnami/argo-cd] Release 2.1.2 updating components versions ([48e695d](https://github.com/bitnami/charts/commit/48e695d8c243d6ebb07ae8fb5ef4bd072474c0b2))

## <small>2.1.1 (2022-01-12)</small>

* [bitnami/argo-cd] Release 2.1.1 updating components versions ([6fc25df](https://github.com/bitnami/charts/commit/6fc25dfecfb6c647b338275018e5a425399e0320))

## 2.1.0 (2022-01-05)

* [bitnami/several] Adapt templating format (#8562) ([8cad18a](https://github.com/bitnami/charts/commit/8cad18aed9966a6f0208e5ad6cee46cb217f47ab)), closes [#8562](https://github.com/bitnami/charts/issues/8562)
* [bitnami/several] Add license to the README ([05f7633](https://github.com/bitnami/charts/commit/05f763372501d596e57db713dd53ff4ff3027cc4))
* [bitnami/several] Add license to the README ([32fb238](https://github.com/bitnami/charts/commit/32fb238e60a0affc6debd3142eaa3c3d9089ec2a))
* [bitnami/several] Add license to the README ([b87c2f7](https://github.com/bitnami/charts/commit/b87c2f7899d48a8b02c506765e6ae82937e9ba3f))

## <small>2.0.20 (2022-01-01)</small>

* [bitnami/argo-cd] Disable passing redis password when there is none (#8440) ([82b3b20](https://github.com/bitnami/charts/commit/82b3b205e8afce5773c728dbc66fe64094fd5ac2)), closes [#8440](https://github.com/bitnami/charts/issues/8440)
* [bitnami/argo-cd] Release 2.0.20 updating components versions ([1c58322](https://github.com/bitnami/charts/commit/1c583226430b0a7686a997bc0a861552d87111ce))

## <small>2.0.19 (2021-12-17)</small>

* [bitnami/argo-cd] Release 2.0.19 updating components versions ([e6bba77](https://github.com/bitnami/charts/commit/e6bba77d6d5ce8ea9db2c9d55b9a6f1f245a90aa))

## <small>2.0.18 (2021-12-17)</small>

* [bitnami/argo-cd] Release 2.0.18 updating components versions ([dd78289](https://github.com/bitnami/charts/commit/dd7828931d18d23049687faff7bc0448687eaf8c))

## <small>2.0.17 (2021-12-16)</small>

* [bitnami/argo-cd] Release 2.0.17 updating components versions ([51cf4d6](https://github.com/bitnami/charts/commit/51cf4d68b1c5dd0695ef0060b725c52c50af7f3a))

## <small>2.0.16 (2021-12-15)</small>

* [bitnami/argo-cd] Release 2.0.16 updating components versions ([1a20e2f](https://github.com/bitnami/charts/commit/1a20e2fdaa158ab5a865a72e4fc65fa24354c1d2))

## <small>2.0.15 (2021-12-14)</small>

* [bitnami/argo-cd] Release 2.0.15 updating components versions ([758535d](https://github.com/bitnami/charts/commit/758535df1feb615a5de3d1d5c28aba2ff50b2851))

## <small>2.0.14 (2021-12-02)</small>

* Properly renders overridden readiness probes in argo-cd (#8286) ([98ab74d](https://github.com/bitnami/charts/commit/98ab74d8d18afb93d4ccb5543151611eadc49656)), closes [#8286](https://github.com/bitnami/charts/issues/8286)

## <small>2.0.13 (2021-11-29)</small>

* [bitnami/argo-cd] Fix issue with server.config (#8173) ([3da4311](https://github.com/bitnami/charts/commit/3da431157cb73a6c3d9298657ab307b55a13c306)), closes [#8173](https://github.com/bitnami/charts/issues/8173)
* [bitnami/several] Fix deadlinks in README.md (#8215) ([99e90d2](https://github.com/bitnami/charts/commit/99e90d244b3244e059a42f72dcbecd3cda2b66bb)), closes [#8215](https://github.com/bitnami/charts/issues/8215)
* [bitnami/several] Regenerate README tables ([7b091c0](https://github.com/bitnami/charts/commit/7b091c0808ef00425c404cb97fe73c0578ccf1a3))
* [bitnami/several] Replace HTTP by HTTPS when possible (#8259) ([eafb5bd](https://github.com/bitnami/charts/commit/eafb5bd5a2cc3aaf04fc1e8ebedd73f420d76864)), closes [#8259](https://github.com/bitnami/charts/issues/8259)

## <small>2.0.12 (2021-11-18)</small>

* [bitnami/argo-cd] Release 2.0.12 updating components versions ([f2cb51b](https://github.com/bitnami/charts/commit/f2cb51be960d4545ee00eb4e9025ca9160dd3a9a))

## <small>2.0.11 (2021-11-02)</small>

* [bitnami/argo-cd] Fix typo on repository-credentials-secret (#8003) ([50467ce](https://github.com/bitnami/charts/commit/50467ce2f3fcbe2c77a91368767e389964b42188)), closes [#8003](https://github.com/bitnami/charts/issues/8003)
* [bitnami/several] Regenerate README tables ([3cefed3](https://github.com/bitnami/charts/commit/3cefed3ef961fbd7596242b1165bcfa229a9cadb))

## <small>2.0.10 (2021-10-29)</small>

* [bitnami/argo-cd] Release 2.0.10 updating components versions ([8eefa8e](https://github.com/bitnami/charts/commit/8eefa8eae126e87c1254e6843e052b13e3d487a5))
* [bitnami/several] Regenerate README tables ([412cf6a](https://github.com/bitnami/charts/commit/412cf6a513cb0c03444a6e7811c6f27193239a10))

## <small>2.0.9 (2021-10-26)</small>

* [bitnami/argo-cd] Release 2.0.9 updating components versions ([92905e0](https://github.com/bitnami/charts/commit/92905e021eddfc041b0a8dba81b7e3159adbfad5))
* [bitnami/several] Regenerate README tables ([c82619f](https://github.com/bitnami/charts/commit/c82619f4141cd18e1b6079fdd84eb5b7bb47d819))

## <small>2.0.8 (2021-10-22)</small>

* [bitnami/several] Add chart info to NOTES.txt (#7889) ([a6751cd](https://github.com/bitnami/charts/commit/a6751cdd33c461fabbc459fbea6f219ec64ab6b2)), closes [#7889](https://github.com/bitnami/charts/issues/7889)

## <small>2.0.7 (2021-10-21)</small>

* [bitnami/argo-cd] Release 2.0.7 updating components versions ([0cc724c](https://github.com/bitnami/charts/commit/0cc724c6638e3ca0b22a69496508a2108846908c))
* [bitnami/several] Regenerate README tables ([6c31f25](https://github.com/bitnami/charts/commit/6c31f256389531fd334aedb0b99c82ee11803621))

## <small>2.0.6 (2021-10-21)</small>

* [bitnami/argo-cd] Release 2.0.6 updating components versions ([967e363](https://github.com/bitnami/charts/commit/967e363b6270dea7062f67d31ba328bdb785ba9b))

## <small>2.0.5 (2021-10-19)</small>

* [bitnami/several] Change pullPolicy for bitnami-shell image (#7852) ([9711a33](https://github.com/bitnami/charts/commit/9711a33c6eec72ea79143c4b7574dbe6a148d6b2)), closes [#7852](https://github.com/bitnami/charts/issues/7852)

## <small>2.0.4 (2021-10-04)</small>

* [bitnami/argo-cd] Calculate password Mtime using always UTC (#7547) ([4a33308](https://github.com/bitnami/charts/commit/4a33308057e454fb70425606897f1f8f75909db4)), closes [#7547](https://github.com/bitnami/charts/issues/7547)

## <small>2.0.3 (2021-10-01)</small>

* [bitnami/*] Drop support for deprecated cert-manager annotation (#7582) ([a081792](https://github.com/bitnami/charts/commit/a08179293543f063e5de966a9976ca967161de7b)), closes [#7582](https://github.com/bitnami/charts/issues/7582)
* [bitnami/several] Regenerate README tables ([17dd6c4](https://github.com/bitnami/charts/commit/17dd6c43f181ba1d44429db86f6b1100f9b4c636))

## <small>2.0.2 (2021-09-30)</small>

* [bitnami/argo-cd] Release 2.0.2 updating components versions ([eabbedd](https://github.com/bitnami/charts/commit/eabbedd08898d62dc410c305a8faedb204d6f125))

## <small>2.0.1 (2021-09-23)</small>

* [bitnami/wordpress] Use the dependency fullname template (#7472) ([ae7e0dd](https://github.com/bitnami/charts/commit/ae7e0dd6a687b283e9d57939143511f938bfe654)), closes [#7472](https://github.com/bitnami/charts/issues/7472)

## 2.0.0 (2021-09-14)

* [bitnami/ several charts] Redis dependency upgrade (#7481) ([bbed564](https://github.com/bitnami/charts/commit/bbed5645fc1e93bde1341f50ba47c614b53ba42a)), closes [#7481](https://github.com/bitnami/charts/issues/7481)
* [bitnami/several] Regenerate README tables ([b294dc2](https://github.com/bitnami/charts/commit/b294dc21d3b108bd49cf64fd1e3ddaa8a2bc8e4a))

## <small>1.0.5 (2021-09-13)</small>

* [bitnami/argo-cd] Release 1.0.5 updating components versions ([bf65df5](https://github.com/bitnami/charts/commit/bf65df5239dc3fe5c2b232aeaa4996acc4fea4ea))
* [bitnami/several] Regenerate README tables ([8c2dfde](https://github.com/bitnami/charts/commit/8c2dfde7724141adfb90f0fa6bb97bf9acd4d14e))

## <small>1.0.4 (2021-09-02)</small>

* [bitnami/argo-cd] Release 1.0.4 updating components versions ([428b154](https://github.com/bitnami/charts/commit/428b1546bae9b9d61dd59af56c711dd87901a282))
* [bitnami/several] Regenerate README tables ([da2513b](https://github.com/bitnami/charts/commit/da2513bf0a33819f3b1151d387c631a9ffdb03e2))

## <small>1.0.3 (2021-08-25)</small>

* [bitnami/argo-cd] Release 1.0.3 updating components versions ([86d374c](https://github.com/bitnami/charts/commit/86d374cbf3b08272dc90fc176f603425b97afc3d))

## <small>1.0.2 (2021-08-16)</small>

* [bitnami/argo-cd] Fix extraArgs nindent (#7207) ([59c3163](https://github.com/bitnami/charts/commit/59c31635baa48d67cd1a5b6cc32144e988058ac6)), closes [#7207](https://github.com/bitnami/charts/issues/7207)
* [bitnami/several] Regenerate README tables ([6c107e8](https://github.com/bitnami/charts/commit/6c107e835d6caf8db2e8b17dcd48c5971637e013))

## <small>1.0.1 (2021-08-11)</small>

* [bitnami/argo-cd] Fix application-controller repo-server (#7175) ([15a3d17](https://github.com/bitnami/charts/commit/15a3d17b46bf3e17017850410b8457bc23ff563b)), closes [#7175](https://github.com/bitnami/charts/issues/7175)

## 1.0.0 (2021-08-02)

* [bitnami/argo-cd] Simplify image definition logic removing duplications (#7113) ([758541f](https://github.com/bitnami/charts/commit/758541f9663089dc039734995289b055ee573559)), closes [#7113](https://github.com/bitnami/charts/issues/7113)

## <small>0.1.6 (2021-07-31)</small>

* [bitnami/argo-cd] Release 0.1.6 updating components versions ([5a9f09b](https://github.com/bitnami/charts/commit/5a9f09b2054081c3232b237d6e62ae5e282df9f3))

## <small>0.1.5 (2021-07-27)</small>

* [bitnami/several] Bump version and update READMEs (#7069) ([6340bff](https://github.com/bitnami/charts/commit/6340bff66f93c8c797bda3ca0842e4bf770059f1)), closes [#7069](https://github.com/bitnami/charts/issues/7069)

## <small>0.1.4 (2021-07-23)</small>

* [bitnami/argo-cd] Release 0.1.4 updating components versions ([c01068d](https://github.com/bitnami/charts/commit/c01068d75acdbc2e1a45447cb30c07ad3b9730f7))

## <small>0.1.3 (2021-07-22)</small>

* [bitnami/several] Fix default values and regenerate README (#7023) ([c443ded](https://github.com/bitnami/charts/commit/c443ded691a1184a72af7b812759fad54b240ae9)), closes [#7023](https://github.com/bitnami/charts/issues/7023)

## <small>0.1.2 (2021-07-20)</small>

* [bitnami/argo-cd] Release 0.1.2 updating components versions ([ab3bf6a](https://github.com/bitnami/charts/commit/ab3bf6a5a5cbcb5c4de0cd75ffdc9aa19a6345a5))

## <small>0.1.1 (2021-07-16)</small>

* [bitnami/argo-cd] Fix configmap (#6961) ([b470fb5](https://github.com/bitnami/charts/commit/b470fb5db0b6ca47753b112a3214fb7f5fc6c68d)), closes [#6961](https://github.com/bitnami/charts/issues/6961)
* [bitnami/argo-cd] Release 0.1.1 updating components versions ([0a67de0](https://github.com/bitnami/charts/commit/0a67de07e625206e9e63146007cb52e75af3c4b7))

## 0.1.0 (2021-07-15)

* [bitnami/argo-cd] Add new Argo CD Helm Chart (#6770) ([87c43a2](https://github.com/bitnami/charts/commit/87c43a2aa61f0e756f2f6be2092eb3e2c5997894)), closes [#6770](https://github.com/bitnami/charts/issues/6770)
