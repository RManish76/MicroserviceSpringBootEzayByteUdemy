# Changelog

## 13.0.6 (2025-08-13)

* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references ([#35824](https://github.com/bitnami/charts/pull/35824))

## <small>13.0.5 (2025-08-13)</small>

* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references (#35788) ([bdd8728](https://github.com/bitnami/charts/commit/bdd8728f0e40457dc96cdd62447fafc508c34a73)), closes [#35788](https://github.com/bitnami/charts/issues/35788)

## <small>13.0.4 (2025-08-12)</small>

* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references (#35755) ([b2d0ffc](https://github.com/bitnami/charts/commit/b2d0ffc22544d9bedb52253cb91607a1ff58a09c)), closes [#35755](https://github.com/bitnami/charts/issues/35755)

## <small>13.0.3 (2025-08-07)</small>

* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references (#35538) ([cd3484b](https://github.com/bitnami/charts/commit/cd3484b6bbb6480b1d984b4706c86aaef5cc6d65)), closes [#35538](https://github.com/bitnami/charts/issues/35538)

## <small>13.0.2 (2025-08-06)</small>

* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references (#35454) ([53fdd77](https://github.com/bitnami/charts/commit/53fdd774886e44b9c222b378d0b0cd1e850e3e80)), closes [#35454](https://github.com/bitnami/charts/issues/35454)

## <small>13.0.1 (2025-07-25)</small>

* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references (#35261) ([737af5f](https://github.com/bitnami/charts/commit/737af5f780ebc544781f9bf9bdcd615c885519d7)), closes [#35261](https://github.com/bitnami/charts/issues/35261)

## 13.0.0 (2025-07-23)

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/argo-workflows] Upgrade MySQL subchart to 14 (#35254) ([06cb090](https://github.com/bitnami/charts/commit/06cb0900f83b402447250875b832ce05b1dc73fd)), closes [#35254](https://github.com/bitnami/charts/issues/35254)

## <small>12.0.7 (2025-07-08)</small>

* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references (#34872) ([875728e](https://github.com/bitnami/charts/commit/875728e9a757fa1b50dcc6667342f54abcffc969)), closes [#34872](https://github.com/bitnami/charts/issues/34872)

## <small>12.0.6 (2025-06-13)</small>

* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references (#34402) ([f827d5f](https://github.com/bitnami/charts/commit/f827d5f3544d821c6a207ef729f98cc5a4216e78)), closes [#34402](https://github.com/bitnami/charts/issues/34402)

## <small>12.0.5 (2025-06-05)</small>

* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references (#34138) ([d434724](https://github.com/bitnami/charts/commit/d4347242b8ece4a7c54401c82684a34b24af0916)), closes [#34138](https://github.com/bitnami/charts/issues/34138)

## <small>12.0.4 (2025-06-04)</small>

* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references (#34102) ([9b072ec](https://github.com/bitnami/charts/commit/9b072ecbd5072d0b75db514e97fca89f8569603d)), closes [#34102](https://github.com/bitnami/charts/issues/34102)

## <small>12.0.3 (2025-06-03)</small>

* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references (#34079) ([4f28567](https://github.com/bitnami/charts/commit/4f285670473b876769e44b61d935a7f9d7f20371)), closes [#34079](https://github.com/bitnami/charts/issues/34079)

## <small>12.0.2 (2025-06-03)</small>

* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references (#34058) ([ea9bffc](https://github.com/bitnami/charts/commit/ea9bffcd43bf25f13c9eebbb3d76decbf73abbfb)), closes [#34058](https://github.com/bitnami/charts/issues/34058)

## <small>12.0.1 (2025-06-02)</small>

* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references (#34032) ([55f85c1](https://github.com/bitnami/charts/commit/55f85c1fdd9bd63403732288e2d62dd32b50fec0)), closes [#34032](https://github.com/bitnami/charts/issues/34032)

## 12.0.0 (2025-05-12)

* [bitnami/argo-workflows] Update MySQL subchart (#33612) ([1b26a9e](https://github.com/bitnami/charts/commit/1b26a9e0a9aae2c812fec428fa294c035c266d07)), closes [#33612](https://github.com/bitnami/charts/issues/33612)
* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)

## <small>11.1.16 (2025-05-08)</small>

* [bitnami/argo-workflows] :zap: :arrow_up: Update dependency references (#33555) ([8fbddc6](https://github.com/bitnami/charts/commit/8fbddc628df7162b278a5ce0cd185d52dd08825e)), closes [#33555](https://github.com/bitnami/charts/issues/33555)

## <small>11.1.15 (2025-05-07)</small>

* [bitnami/argo-workflows] Release 11.1.15 (#33540) ([45a7a53](https://github.com/bitnami/charts/commit/45a7a53a72757e0bc19b6aa7fb32dcf84c7385cb)), closes [#33540](https://github.com/bitnami/charts/issues/33540)

## <small>11.1.14 (2025-05-06)</small>

* [bitnami/argo-workflows] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references  ([ff43ddf](https://github.com/bitnami/charts/commit/ff43ddf1d8adca95518eeecc0562ff5663548810)), closes [#33338](https://github.com/bitnami/charts/issues/33338)

## <small>11.1.13 (2025-04-29)</small>

* [bitnami/argo-workflows] Release 11.1.13 (#33251) ([3486155](https://github.com/bitnami/charts/commit/348615503d4c72ad09bc8a1e0ba20db2df83823d)), closes [#33251](https://github.com/bitnami/charts/issues/33251)

## <small>11.1.12 (2025-04-28)</small>

* [bitnami/argo-workflows] Release 11.1.12 (#33230) ([c4f0308](https://github.com/bitnami/charts/commit/c4f03080b936f33da9874043c863ce3817d8df7d)), closes [#33230](https://github.com/bitnami/charts/issues/33230)

## <small>11.1.11 (2025-04-01)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/argo-workflows] Release 11.1.11 (#32718) ([c7a0b15](https://github.com/bitnami/charts/commit/c7a0b153bb32c5f5985cf70801b869be71a94d8d)), closes [#32718](https://github.com/bitnami/charts/issues/32718)

## <small>11.1.10 (2025-03-11)</small>

* [bitnami/argo-workflows] Release 11.1.10 (#32399) ([daca813](https://github.com/bitnami/charts/commit/daca813b2a0beaa4654d4202faff934572f16f3f)), closes [#32399](https://github.com/bitnami/charts/issues/32399)

## <small>11.1.9 (2025-03-04)</small>

* [bitnami/argo-workflows] Release 11.1.9 (#32277) ([fd874cc](https://github.com/bitnami/charts/commit/fd874ccdf91e737d41978d40a2a42dc245ca3980)), closes [#32277](https://github.com/bitnami/charts/issues/32277)

## <small>11.1.8 (2025-02-20)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/argo-workflows] Release 11.1.8 (#32087) ([db716bb](https://github.com/bitnami/charts/commit/db716bbde52b9b6a47732be5107edc04215505a1)), closes [#32087](https://github.com/bitnami/charts/issues/32087)

## <small>11.1.7 (2025-02-10)</small>

* [bitnami/argo-workflows] Release 11.1.7 (#31853) ([01abe92](https://github.com/bitnami/charts/commit/01abe92e2e1ca50450f2096b5492652b05c10227)), closes [#31853](https://github.com/bitnami/charts/issues/31853)

## <small>11.1.6 (2025-02-07)</small>

* [bitnami/argo-workflows] Release 11.1.6 (#31839) ([49dd6d4](https://github.com/bitnami/charts/commit/49dd6d4ec3586701659a6112083ff8618d8c67fe)), closes [#31839](https://github.com/bitnami/charts/issues/31839)

## <small>11.1.5 (2025-02-07)</small>

* [bitnami/argo-workflows] Release 11.1.5 (#31824) ([bd9a9a2](https://github.com/bitnami/charts/commit/bd9a9a26567b0c76c40ba9d1d5c09bf25c0611a0)), closes [#31824](https://github.com/bitnami/charts/issues/31824)

## <small>11.1.4 (2025-02-04)</small>

* [bitnami/argo-workflows] Release 11.1.4 (#31743) ([03714fc](https://github.com/bitnami/charts/commit/03714fc841dcf5199a8c841d9b3b5876fa80c821)), closes [#31743](https://github.com/bitnami/charts/issues/31743)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## <small>11.1.3 (2025-01-24)</small>

* [bitnami/argo-workflows] Release 11.1.3 (#31542) ([08db052](https://github.com/bitnami/charts/commit/08db052141e48c2f28d920d2ec923da8c7953f7e)), closes [#31542](https://github.com/bitnami/charts/issues/31542)

## <small>11.1.2 (2025-01-16)</small>

* [bitnami/argo-workflows] Release 11.1.2 (#31408) ([fc7398e](https://github.com/bitnami/charts/commit/fc7398e8b2d6b1e29fe2e2730b2af217dc307af3)), closes [#31408](https://github.com/bitnami/charts/issues/31408)

## <small>11.1.1 (2025-01-12)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/argo-workflows] Release 11.1.1 (#31309) ([bd97fdc](https://github.com/bitnami/charts/commit/bd97fdc65c501405bc15950b778ae954a3959bf7)), closes [#31309](https://github.com/bitnami/charts/issues/31309)

## 11.1.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/argo-workflows] Detect non-standard images (#30864) ([f47e86a](https://github.com/bitnami/charts/commit/f47e86a9b51dee8812bf752f2946fc6e5c24e3e0)), closes [#30864](https://github.com/bitnami/charts/issues/30864)

## <small>11.0.3 (2024-12-03)</small>

* [bitnami/argo-workflows] Release 11.0.3 (#30740) ([a3c6c77](https://github.com/bitnami/charts/commit/a3c6c77e3ed1f94056b2fc4212167b326c66bff6)), closes [#30740](https://github.com/bitnami/charts/issues/30740)

## <small>11.0.2 (2024-12-02)</small>

* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/*] docs: :memo: Add "Prometheus metrics" (batch 1) (#30660) ([7409ca4](https://github.com/bitnami/charts/commit/7409ca4c21869fabe1532dd4f3ff24895df71c6d)), closes [#30660](https://github.com/bitnami/charts/issues/30660)
* [bitnami/*] docs: :memo: Unify "Securing Traffic using TLS" section (#30707) ([b572333](https://github.com/bitnami/charts/commit/b57233336e4fe9af928ecb4f2a5f334011efb1bc)), closes [#30707](https://github.com/bitnami/charts/issues/30707)
* [bitnami/argo-workflows] Release 11.0.2 (#30715) ([c186498](https://github.com/bitnami/charts/commit/c18649871d5e3d7b757dffd00b3b9bf4a71dc95f)), closes [#30715](https://github.com/bitnami/charts/issues/30715)

## <small>11.0.1 (2024-11-15)</small>

* [bitnami/argo-workflows] Release 11.0.1 (#30474) ([1c7a861](https://github.com/bitnami/charts/commit/1c7a8616140ab171241f0e0896aa1e74ac31fcc0)), closes [#30474](https://github.com/bitnami/charts/issues/30474)

## 11.0.0 (2024-11-12)

* [bitnami/argo-workflows] chore!: :arrow_up: :boom: Bump MySQL subchart to 12 (#30430) ([2486b2b](https://github.com/bitnami/charts/commit/2486b2b6cdd82475b8b4ea9c4672092c7ec2eb9a)), closes [#30430](https://github.com/bitnami/charts/issues/30430)

## <small>10.0.2 (2024-11-07)</small>

* [bitnami/argo-workflows] Release 10.0.2 (#30254) ([cb88066](https://github.com/bitnami/charts/commit/cb88066e9a869f78b5f4cea63512ea700f1aa348)), closes [#30254](https://github.com/bitnami/charts/issues/30254)

## <small>10.0.1 (2024-10-31)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/argo-workflows] Release 10.0.1 (#30156) ([844a5df](https://github.com/bitnami/charts/commit/844a5df12aab12876d5822155d9c0c0f0dcb0aa5)), closes [#30156](https://github.com/bitnami/charts/issues/30156)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## 10.0.0 (2024-10-03)

* [bitnami/argo-workflows] feat!: :arrow_up: :boom: Bump PostgreSQL to 17.x (#29728) ([25732e6](https://github.com/bitnami/charts/commit/25732e6386f7b52adf8a444ba587790b97972622)), closes [#29728](https://github.com/bitnami/charts/issues/29728)

## <small>9.1.18 (2024-10-02)</small>

* [bitnami/argo-workflows] Release 9.1.18 (#29753) ([fad625d](https://github.com/bitnami/charts/commit/fad625d3fd348d62dd6abf2d20f5ac9f4deb23a3)), closes [#29753](https://github.com/bitnami/charts/issues/29753)

## <small>9.1.17 (2024-09-27)</small>

* [bitnami/argo-workflows] Update Workflow RBAC to Use Recommended `workflowtaskresults` CRD (#29620) ([76885b6](https://github.com/bitnami/charts/commit/76885b6c21ac601009c827dfc76ca94a40a25bc4)), closes [#29620](https://github.com/bitnami/charts/issues/29620)

## <small>9.1.16 (2024-09-23)</small>

* [bitnami/argo-workflows] Release 9.1.16 (#29576) ([c07a61e](https://github.com/bitnami/charts/commit/c07a61e36623a0bf4816790a65f376452a4bdc6d)), closes [#29576](https://github.com/bitnami/charts/issues/29576)

## <small>9.1.15 (2024-09-05)</small>

* [bitnami/argo-workflows] Release 9.1.15 (#29225) ([33115a7](https://github.com/bitnami/charts/commit/33115a72f0cf52c4bd31aa7f7f0bc7807a87c8f6)), closes [#29225](https://github.com/bitnami/charts/issues/29225)

## <small>9.1.14 (2024-08-27)</small>

* [bitnami/argo-workflows] Release 9.1.14 (#29072) ([4dd81da](https://github.com/bitnami/charts/commit/4dd81da6d33c2b08ee089d3f00a5a35d73f99d0a)), closes [#29072](https://github.com/bitnami/charts/issues/29072)

## <small>9.1.13 (2024-08-07)</small>

* [bitnami/argo-workflows] Release 9.1.13 (#28761) ([474a8b1](https://github.com/bitnami/charts/commit/474a8b139d486cc564a66499723231395ded621f)), closes [#28761](https://github.com/bitnami/charts/issues/28761)

## <small>9.1.12 (2024-08-07)</small>

* [bitnami/argo-workflows] Release 9.1.12 (#28619) ([85cd823](https://github.com/bitnami/charts/commit/85cd8233362289969013a69462cc8355fc6687de)), closes [#28619](https://github.com/bitnami/charts/issues/28619)

## <small>9.1.11 (2024-07-25)</small>

* [bitnami/argo-workflows] Release 9.1.11 (#28395) ([9caaa0a](https://github.com/bitnami/charts/commit/9caaa0ad21a82e2e66c574a4e48ef3e839396117)), closes [#28395](https://github.com/bitnami/charts/issues/28395)

## <small>9.1.10 (2024-07-24)</small>

* [bitnami/argo-workflows] Release 9.1.10 (#28274) ([54d7a18](https://github.com/bitnami/charts/commit/54d7a18ebd7406fc10c070949a2d774815f303b7)), closes [#28274](https://github.com/bitnami/charts/issues/28274)

## <small>9.1.9 (2024-07-23)</small>

* [bitnami/argo-workflows] Release 9.1.9 (#28229) ([cd68de2](https://github.com/bitnami/charts/commit/cd68de2cdbe260791b81051c441c2ea9c0342894)), closes [#28229](https://github.com/bitnami/charts/issues/28229)

## <small>9.1.8 (2024-07-23)</small>

* [bitnami/argo-workflows] Release 9.1.8 (#28210) ([2b3d53c](https://github.com/bitnami/charts/commit/2b3d53c81e0ac4c778bba41496c4bb347d910a60)), closes [#28210](https://github.com/bitnami/charts/issues/28210)

## <small>9.1.7 (2024-07-18)</small>

* [bitnami/argo-workflows] Global StorageClass as default value (#28000) ([19060c8](https://github.com/bitnami/charts/commit/19060c83fe5a16f1b3b7e9f705b178f25d4a2984)), closes [#28000](https://github.com/bitnami/charts/issues/28000)

## <small>9.1.6 (2024-07-04)</small>

* [bitnami/argo-workflows] Release 9.1.6 (#27755) ([b30c5f5](https://github.com/bitnami/charts/commit/b30c5f5f8affa1f3924e6248c7597ca365ca1c4c)), closes [#27755](https://github.com/bitnami/charts/issues/27755)

## <small>9.1.5 (2024-07-02)</small>

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/argo-workflows] Release 9.1.5 (#27640) ([5d1255c](https://github.com/bitnami/charts/commit/5d1255c62120ad579a12957c1dd0c60d9fa6a53e)), closes [#27640](https://github.com/bitnami/charts/issues/27640)

## <small>9.1.4 (2024-06-18)</small>

* [bitnami/argo-workflows] Release 9.1.4 (#27402) ([0c29858](https://github.com/bitnami/charts/commit/0c29858bdd7127b83fc98718d8b3105e32300289)), closes [#27402](https://github.com/bitnami/charts/issues/27402)

## <small>9.1.3 (2024-06-17)</small>

* [bitnami/argo-workflows] Release 9.1.3 (#27203) ([e06390e](https://github.com/bitnami/charts/commit/e06390ec12ae42973c812ee6654a21d6cfb9940c)), closes [#27203](https://github.com/bitnami/charts/issues/27203)

## <small>9.1.2 (2024-06-06)</small>

* [bitnami/argo-workflows] Release 9.1.2 (#26939) ([3ce67e5](https://github.com/bitnami/charts/commit/3ce67e58391b9cc30f25d871d9a8403d62153de4)), closes [#26939](https://github.com/bitnami/charts/issues/26939)

## <small>9.1.1 (2024-06-05)</small>

* [bitnami/argo-workflows] Bump chart version (#26822) ([6bfdc26](https://github.com/bitnami/charts/commit/6bfdc260bbf7b6a6442d567f909e6d1238012832)), closes [#26822](https://github.com/bitnami/charts/issues/26822)

## 9.1.0 (2024-06-05)

* [bitnami/argo-workflows] Enable PodDisruptionBudgets (#26595) ([4a87ecd](https://github.com/bitnami/charts/commit/4a87ecd4fc9fd817655426839843a65f8eda47e5)), closes [#26595](https://github.com/bitnami/charts/issues/26595)

## <small>9.0.3 (2024-06-05)</small>

* [bitnami/argo-workflows] Bump chart version (#26764) ([3ad8f3b](https://github.com/bitnami/charts/commit/3ad8f3bd66903b2f844698f8bdfd21d58c8a2385)), closes [#26764](https://github.com/bitnami/charts/issues/26764)

## <small>9.0.2 (2024-06-05)</small>

* [bitnami/argo-workflows] Release 9.0.2 (#26719) ([8935f8c](https://github.com/bitnami/charts/commit/8935f8c7f1736c2ec9134be621e5cfcaf10fe539)), closes [#26719](https://github.com/bitnami/charts/issues/26719)

## <small>9.0.1 (2024-05-27)</small>

* [bitnami/argo-workflows] Release 9.0.1 (#26456) ([8f899a8](https://github.com/bitnami/charts/commit/8f899a80be1f6462a77f27e01ee93e7f0cef529e)), closes [#26456](https://github.com/bitnami/charts/issues/26456)

## 9.0.0 (2024-05-27)

* [bitnami/argo-workflows] Update dependencies (#26449) ([0491305](https://github.com/bitnami/charts/commit/0491305081197889ebb5388901a154b03dcc5893)), closes [#26449](https://github.com/bitnami/charts/issues/26449)

## <small>8.1.1 (2024-05-23)</small>

* [bitnami/argo-workflows] Use different liveness/readiness probes (#26338) ([74c9d18](https://github.com/bitnami/charts/commit/74c9d1860077443f82d7140c2cdaf95a63fa1615)), closes [#26338](https://github.com/bitnami/charts/issues/26338)

## 8.1.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/argo-workflows] feat: :sparkles: :lock: Add warning when original images are replaced (#261 ([9130a5c](https://github.com/bitnami/charts/commit/9130a5c8d9ffff44d74b261e6d0b602b938db7e1)), closes [#26183](https://github.com/bitnami/charts/issues/26183)

## <small>8.0.10 (2024-05-17)</small>

* [bitnami/argo-workflows] Release 8.0.10 updating components versions (#26002) ([bf63313](https://github.com/bitnami/charts/commit/bf6331320f32bf264ef105bc470f1a4af467ae8f)), closes [#26002](https://github.com/bitnami/charts/issues/26002)

## <small>8.0.9 (2024-05-15)</small>

* [bitnami/argo-workflows] PDB review (#25864) ([9af10f4](https://github.com/bitnami/charts/commit/9af10f4dbfe888ebc948f8b012828eeb1dafedfd)), closes [#25864](https://github.com/bitnami/charts/issues/25864)

## <small>8.0.8 (2024-05-13)</small>

* [bitnami/argo-workflows] Release 8.0.8 updating components versions (#25739) ([7cac37a](https://github.com/bitnami/charts/commit/7cac37ac465462e12be8165948f645c51a9fa361)), closes [#25739](https://github.com/bitnami/charts/issues/25739)

## <small>8.0.7 (2024-05-08)</small>

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/argo-workflows] Release 8.0.7 updating components versions (#25633) ([9e1ec97](https://github.com/bitnami/charts/commit/9e1ec974747acdcc14d505b57506891cb5582ce3)), closes [#25633](https://github.com/bitnami/charts/issues/25633)
* [bitnami/multiple charts] Fix typo: "NetworkPolice" vs "NetworkPolicy" (#25348) ([6970c1b](https://github.com/bitnami/charts/commit/6970c1ba245873506e73d459c6eac1e4919b778f)), closes [#25348](https://github.com/bitnami/charts/issues/25348)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## <small>8.0.6 (2024-04-24)</small>

* [bitnami/argo-workflows] Release 8.0.6 (#25360) ([c88b670](https://github.com/bitnami/charts/commit/c88b67071349afc7266d906d02a1a5d66858e063)), closes [#25360](https://github.com/bitnami/charts/issues/25360)

## <small>8.0.5 (2024-04-09)</small>

* [bitnami/argo-workflows] Remove dup part of server deployment (#25053) ([65527e1](https://github.com/bitnami/charts/commit/65527e1f7f2d331a2e56d52133f437f5c05655be)), closes [#25053](https://github.com/bitnami/charts/issues/25053)

## <small>8.0.4 (2024-04-06)</small>

* [bitnami/argo-workflows] Release 8.0.4 updating components versions (#25016) ([5788c89](https://github.com/bitnami/charts/commit/5788c899f0bb8bc16938ff7001b0c07141b7b888)), closes [#25016](https://github.com/bitnami/charts/issues/25016)

## <small>8.0.3 (2024-04-04)</small>

* [bitnami/argo-workflows] Release 8.0.3 updating components versions (#24871) ([c51644a](https://github.com/bitnami/charts/commit/c51644ad5a47d764c90889d914343d0e3a585457)), closes [#24871](https://github.com/bitnami/charts/issues/24871)

## <small>8.0.2 (2024-04-03)</small>

* [bitnami/argo-workflows] Fix WordPress typo (#24854) ([d4d0301](https://github.com/bitnami/charts/commit/d4d0301c7956b3861216b6be0a3639b0bd72e7ef)), closes [#24854](https://github.com/bitnami/charts/issues/24854)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## <small>8.0.1 (2024-03-29)</small>

* Fix duplicate part-of key (#24745) ([08f6b14](https://github.com/bitnami/charts/commit/08f6b14b06124f5daa0a006792b1bd4ca78f7bc5)), closes [#24745](https://github.com/bitnami/charts/issues/24745)

## 8.0.0 (2024-03-26)

* [bitnami/argo-workflows] feat!: :lock: :boom: Improve security defaults (#24540) ([1942f8a](https://github.com/bitnami/charts/commit/1942f8a63967c1e77a201ebe2d20916e212e0f9c)), closes [#24540](https://github.com/bitnami/charts/issues/24540)

## <small>7.0.1 (2024-03-22)</small>

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* Fix #24534, Add part-of: argo-workflows label to controller and server pod (#24602) ([0eefc00](https://github.com/bitnami/charts/commit/0eefc0053673ab4960f8c4c10ddda1c79be1f377)), closes [#24534](https://github.com/bitnami/charts/issues/24534) [#24602](https://github.com/bitnami/charts/issues/24602)

## 7.0.0 (2024-03-08)

* [bitnami/argo-workflows] Update bundled PostgreSQL (#24280) ([59f07c0](https://github.com/bitnami/charts/commit/59f07c060b8e5244c8e330ce61bba6b46d12fd9c)), closes [#24280](https://github.com/bitnami/charts/issues/24280)

## <small>6.8.1 (2024-03-06)</small>

* [bitnami/argo-workflows] Release 6.8.1 updating components versions (#24185) ([690927b](https://github.com/bitnami/charts/commit/690927b8e59d3ac5d2b0f8335011e07f9df57375)), closes [#24185](https://github.com/bitnami/charts/issues/24185)

## 6.8.0 (2024-03-06)

* [bitnami/argo-workflows] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v ([4f8979b](https://github.com/bitnami/charts/commit/4f8979b9c513e2ad153f57e84cf42cae3606e5fe)), closes [#24065](https://github.com/bitnami/charts/issues/24065)

## <small>6.7.2 (2024-03-01)</small>

* [bitnami/argo-workflows] Release 6.7.2 (#24003) ([ddc1552](https://github.com/bitnami/charts/commit/ddc1552dbde79ee8dba3d6eb9f7c2fb0928cc7eb)), closes [#24003](https://github.com/bitnami/charts/issues/24003)

## <small>6.7.1 (2024-02-29)</small>

* [bitnami/argocd-workflows] Fix executor securitycontext (#23998) ([73daf48](https://github.com/bitnami/charts/commit/73daf48e498f92a930cc3a5fc3d05b3194e90e61)), closes [#23998](https://github.com/bitnami/charts/issues/23998)

## 6.7.0 (2024-02-27)

* [bitnami/argo-workflows] feat: :sparkles: :lock: Add readOnlyRootFilesystem support (#23876) ([71201e8](https://github.com/bitnami/charts/commit/71201e8b4026ba5109aa6cf31237aa360ee66ec7)), closes [#23876](https://github.com/bitnami/charts/issues/23876)

## <small>6.6.3 (2024-02-21)</small>

* [bitnami/argo-workflows] Release 6.6.3 updating components versions (#23740) ([0fb61c9](https://github.com/bitnami/charts/commit/0fb61c9c04bfa6ecfdee443b2bfe82bd6fb2ffb0)), closes [#23740](https://github.com/bitnami/charts/issues/23740)

## <small>6.6.2 (2024-02-21)</small>

* [bitnami/argo-workflows] Release 6.6.2 updating components versions (#23636) ([9b5a9d0](https://github.com/bitnami/charts/commit/9b5a9d08475b7222e4b95e31c359a4864f2ced54)), closes [#23636](https://github.com/bitnami/charts/issues/23636)

## <small>6.6.1 (2024-02-21)</small>

* [bitnami/argo-workflows] Release 6.4.1 (#23399) ([c6d0a8c](https://github.com/bitnami/charts/commit/c6d0a8cbaae78100911838a7e4a5a1fc671d283d)), closes [#23399](https://github.com/bitnami/charts/issues/23399)

## 6.6.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## 6.5.0 (2024-02-15)

* [bitnami/argo-workflows] feat: :sparkles: :lock: Add resource preset support (#23432) ([21167f1](https://github.com/bitnami/charts/commit/21167f1d8e6c2b4ff19f31b8f5a1308e2475eec6)), closes [#23432](https://github.com/bitnami/charts/issues/23432)

## 6.4.0 (2024-02-12)

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/argo-workflows] feat: :lock: Enable networkPolicy (#23343) ([8580945](https://github.com/bitnami/charts/commit/8580945a6ae4f8579b2b0c8d5f1092a68be8bab7)), closes [#23343](https://github.com/bitnami/charts/issues/23343)

## <small>6.3.2 (2024-01-24)</small>

* [bitnami/argo-workflows] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22570) ([be22302](https://github.com/bitnami/charts/commit/be223024dc33d9db39fcda569bc8b42e026092d1)), closes [#22570](https://github.com/bitnami/charts/issues/22570)

## <small>6.3.1 (2024-01-22)</small>

* [bitnami/argo-workflows] bugfix: Fix argo workflows namespaces roles and rolebindings (#22522) ([6884956](https://github.com/bitnami/charts/commit/68849560f473bb1c66c434b0cc72bd462cbf96d0)), closes [#22522](https://github.com/bitnami/charts/issues/22522)

## 6.3.0 (2024-01-19)

* [bitnami/argo-workflows] fix: :lock: Move service-account token auto-mount to pod declaration (#2238 ([f7d5b6f](https://github.com/bitnami/charts/commit/f7d5b6f2c4813d113f2b2853b0be3e3342c0f6a4)), closes [#22387](https://github.com/bitnami/charts/issues/22387)

## <small>6.2.1 (2024-01-18)</small>

* [bitnami/argo-workflows] Update CRDs and add source header (#22368) ([21952fd](https://github.com/bitnami/charts/commit/21952fd492c84bdbcb3c77f6b0fd0d18fc6d7b61)), closes [#22368](https://github.com/bitnami/charts/issues/22368)

## 6.2.0 (2024-01-16)

* [bitnami/argo-workflows] fix: :lock: Improve podSecurityContext and containerSecurityContext with es ([5f2079d](https://github.com/bitnami/charts/commit/5f2079d25bd2d95b0b7b16ca9675b8ff574f8526)), closes [#22101](https://github.com/bitnami/charts/issues/22101)

## <small>6.1.5 (2024-01-15)</small>

* [bitnami/*] Fix docs.bitnami.com broken links (#21901) ([f35506d](https://github.com/bitnami/charts/commit/f35506d2dadee4f097986e7792df1f53ab215b5d)), closes [#21901](https://github.com/bitnami/charts/issues/21901)
* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)
* [bitnami/argo-workflows] fix: :lock: Do not use the default service account (#21990) ([265631b](https://github.com/bitnami/charts/commit/265631b1d98040cd9ab47c6abb497c57ac66fe88)), closes [#21990](https://github.com/bitnami/charts/issues/21990)

## <small>6.1.4 (2023-11-21)</small>

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/argo-workflows] Release 6.1.4 updating components versions (#21095) ([a2f8a80](https://github.com/bitnami/charts/commit/a2f8a80d25539c06f306803d88d0da10ea73346e)), closes [#21095](https://github.com/bitnami/charts/issues/21095)
* Update readme-generator links (#21043) ([1581eba](https://github.com/bitnami/charts/commit/1581eba8044d730a763c266f279ac2ac782f764d)), closes [#21043](https://github.com/bitnami/charts/issues/21043)

## <small>6.1.3 (2023-11-08)</small>

* [bitnami/argo-workflows] Release 6.1.3 updating components versions (#20793) ([874de62](https://github.com/bitnami/charts/commit/874de6276ec67e365dd0b7d3f11b73c21c8d0ee4)), closes [#20793](https://github.com/bitnami/charts/issues/20793)

## <small>6.1.2 (2023-11-08)</small>

* [bitnami/argo-workflows] Release 6.1.2 updating components versions (#20730) ([283d1f2](https://github.com/bitnami/charts/commit/283d1f2bb4bf6f6a146639fac95a3cebd77bf230)), closes [#20730](https://github.com/bitnami/charts/issues/20730)

## <small>6.1.1 (2023-11-04)</small>

* [bitnami/argo-workflows] Release 6.1.1 updating components versions (#20618) ([549d0f2](https://github.com/bitnami/charts/commit/549d0f28b0e6bb9e3a50c235d5c8cd554b744b08)), closes [#20618](https://github.com/bitnami/charts/issues/20618)

## 6.1.0 (2023-10-31)

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [bitnami/argo-workflows] feat: :sparkles: Add support for PSA restricted policy (#20404) ([cacbf34](https://github.com/bitnami/charts/commit/cacbf349ceaf9e21c93d5f1ebb211c65299cc300)), closes [#20404](https://github.com/bitnami/charts/issues/20404)

## <small>6.0.5 (2023-10-17)</small>

* [bitnami/argo-workflows] Release 6.0.5 (#20265) ([d5af06d](https://github.com/bitnami/charts/commit/d5af06d732a6e560bb7bdc5ddd1a84a0f83ba71b)), closes [#20265](https://github.com/bitnami/charts/issues/20265)

## <small>6.0.4 (2023-10-11)</small>

* [bitnami/argo-workflows] Release 6.0.4 (#20034) ([01cc13b](https://github.com/bitnami/charts/commit/01cc13b56c6986dc926949226653059d9768856d)), closes [#20034](https://github.com/bitnami/charts/issues/20034)

## <small>6.0.3 (2023-10-11)</small>

* [bitnami/argo-workflows] Release 6.0.3 (#20033) ([9c42552](https://github.com/bitnami/charts/commit/9c42552cd8bd1aa4a4e4f5db96fdb0d6da5da937)), closes [#20033](https://github.com/bitnami/charts/issues/20033)

## <small>6.0.2 (2023-10-09)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/argo-workflows] Release 6.0.2 (#19814) ([1324dd2](https://github.com/bitnami/charts/commit/1324dd21bbdf9afcb56f136da6ee0a90fa1359ab)), closes [#19814](https://github.com/bitnami/charts/issues/19814)

## <small>6.0.1 (2023-10-04)</small>

* [bitnami/argo-workflows] Release 6.0.1 (#19696) ([7b3f2a7](https://github.com/bitnami/charts/commit/7b3f2a7a96e2be425930b77798b55e25e4960c72)), closes [#19696](https://github.com/bitnami/charts/issues/19696)

## 6.0.0 (2023-09-29)

* [bitnami/argo-workflows] Update dependencies (#19610) ([53d08c3](https://github.com/bitnami/charts/commit/53d08c377f988e62eeae2048fc8bada640f44e12)), closes [#19610](https://github.com/bitnami/charts/issues/19610)

## <small>5.4.5 (2023-09-26)</small>

* [bitnami/argo-workflows] Release 5.4.5 (#19542) ([39da3c1](https://github.com/bitnami/charts/commit/39da3c1bef27993568bc41bb97b65b4cb43c4fa5)), closes [#19542](https://github.com/bitnami/charts/issues/19542)

## <small>5.4.4 (2023-09-20)</small>

* [bitnami/argo-workflows] Use different app.kubernetes.io/version label on subcomponents (#19327) ([4666588](https://github.com/bitnami/charts/commit/4666588b9f28a33b8c7f4e8a112b4c0660b01c54)), closes [#19327](https://github.com/bitnami/charts/issues/19327)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>5.4.3 (2023-09-08)</small>

* [bitnami/argo-workflows] Release 5.4.3 (#19197) ([ff8121e](https://github.com/bitnami/charts/commit/ff8121ee686f7547142342f2b394fc97640080a8)), closes [#19197](https://github.com/bitnami/charts/issues/19197)

## <small>5.4.2 (2023-09-07)</small>

* [bitnami/argo-workflows: Use merge helper]: (#19023) ([c7cda66](https://github.com/bitnami/charts/commit/c7cda666b9b938b18ce202f8ebfbf348307899f6)), closes [#19023](https://github.com/bitnami/charts/issues/19023)

## <small>5.4.1 (2023-08-23)</small>

* [bitnami/argo-workflows] Release 5.4.1 (#18819) ([c757fe3](https://github.com/bitnami/charts/commit/c757fe31087fde137c0b14742db5b56d75330f3b)), closes [#18819](https://github.com/bitnami/charts/issues/18819)

## 5.4.0 (2023-08-23)

* [bitnami/argo-workflows] Support for customizing standard labels (#18459) ([7465c0c](https://github.com/bitnami/charts/commit/7465c0cde85935558e9ce11f893378a0346689e1)), closes [#18459](https://github.com/bitnami/charts/issues/18459)

## <small>5.3.12 (2023-08-19)</small>

* [bitnami/argo-workflows] Release 5.3.12 (#18645) ([5af3fe6](https://github.com/bitnami/charts/commit/5af3fe690704a1ba4b44beafd8677e61bbcc36dd)), closes [#18645](https://github.com/bitnami/charts/issues/18645)

## <small>5.3.11 (2023-08-17)</small>

* [bitnami/argo-workflows] Release 5.3.11 (#18492) ([58838e2](https://github.com/bitnami/charts/commit/58838e2f3b6a396a80d3d29aca53ab5c3a406a1e)), closes [#18492](https://github.com/bitnami/charts/issues/18492)

## <small>5.3.10 (2023-08-08)</small>

* [bitnami/argo-workflows] chore: :page_facing_up: Remove license in CRDs (#18259) ([d14eda9](https://github.com/bitnami/charts/commit/d14eda99bc888e254191f44f9afdb58a6de1ef7d)), closes [#18259](https://github.com/bitnami/charts/issues/18259)

## <small>5.3.9 (2023-07-28)</small>

* [bitnami/argo-workflows] Release 5.3.9 (#18022) ([5e099a5](https://github.com/bitnami/charts/commit/5e099a53f52af1df7d6ecb15f46019ca6ebffdea)), closes [#18022](https://github.com/bitnami/charts/issues/18022)

## <small>5.3.8 (2023-07-17)</small>

* [bitnami/argo-workflows] Release 5.3.8 (#17738) ([59df2b4](https://github.com/bitnami/charts/commit/59df2b4de36e25ecede0091c84d972e19748bd9a)), closes [#17738](https://github.com/bitnami/charts/issues/17738)

## <small>5.3.7 (2023-07-13)</small>

* [bitnami/argo-workflows] Release 5.3.7 (#17688) ([41bb1dd](https://github.com/bitnami/charts/commit/41bb1ddcba5fc4e498c70b218174d70b9f00d82b)), closes [#17688](https://github.com/bitnami/charts/issues/17688)

## <small>5.3.6 (2023-06-29)</small>

* [bitnami/argo-workflows] Release 5.3.6 (#17403) ([f78272f](https://github.com/bitnami/charts/commit/f78272f79e4ca05f171682e52960b5fcb836759e)), closes [#17403](https://github.com/bitnami/charts/issues/17403)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## <small>5.3.5 (2023-06-21)</small>

* Fix errors (#17258) ([b6ec0cf](https://github.com/bitnami/charts/commit/b6ec0cf9a8202ed875a68bfab7da7a58619700d3)), closes [#17258](https://github.com/bitnami/charts/issues/17258)

## <small>5.3.4 (2023-06-06)</small>

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/argo-workflows] Fix liveness probe and templating of externalDatabase (#16596) ([496c371](https://github.com/bitnami/charts/commit/496c37105663a2cfcac262cbd989a9f1363f19db)), closes [#16596](https://github.com/bitnami/charts/issues/16596)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)

## <small>5.3.3 (2023-05-29)</small>

* [bitnami/argo-workflows] Release 5.3.3 (#16943) ([dd441bd](https://github.com/bitnami/charts/commit/dd441bd62a652a27cf0d9b1addf68b6c4b2bfc71)), closes [#16943](https://github.com/bitnami/charts/issues/16943)

## <small>5.3.2 (2023-05-21)</small>

* [bitnami/argo-workflows] Release 5.3.2 (#16754) ([3ee8631](https://github.com/bitnami/charts/commit/3ee86316caad69c6a3413f10f5164f4205bd8ace)), closes [#16754](https://github.com/bitnami/charts/issues/16754)

## <small>5.3.1 (2023-05-17)</small>

* [bitnami/argo-workflows] Release 5.3.1 (#16683) ([c199dd4](https://github.com/bitnami/charts/commit/c199dd402c39db14cc3631276964a100cbce6221)), closes [#16683](https://github.com/bitnami/charts/issues/16683)
* Add wording for enterprise page (#16560) ([8f22774](https://github.com/bitnami/charts/commit/8f2277440b976d52785ba9149762ad8620a73d1f)), closes [#16560](https://github.com/bitnami/charts/issues/16560)

## 5.3.0 (2023-05-09)

* [bitnami/several] Adapt Chart.yaml to set desired OCI annotations (#16546) ([fc9b18f](https://github.com/bitnami/charts/commit/fc9b18f2e98805d4df629acbcde696f44f973344)), closes [#16546](https://github.com/bitnami/charts/issues/16546)

## <small>5.2.1 (2023-05-09)</small>

* [bitnami/argo-workflows] Release 5.2.1 (#16531) ([0baf366](https://github.com/bitnami/charts/commit/0baf366b4bd79b8dbe93cfb694d592f575fb37e9)), closes [#16531](https://github.com/bitnami/charts/issues/16531)

## 5.2.0 (2023-04-20)

* [bitnami/*] Make Helm charts 100% OCI (#15998) ([8841510](https://github.com/bitnami/charts/commit/884151035efcbf2e1b3206e7def85511073fb57d)), closes [#15998](https://github.com/bitnami/charts/issues/15998)

## <small>5.1.14 (2023-04-14)</small>

* [bitnami/argo-workflows] Release 5.1.14 (#16066) ([51ec829](https://github.com/bitnami/charts/commit/51ec8297d8031f63ae9cd90d2b2583758ce9d2a9)), closes [#16066](https://github.com/bitnami/charts/issues/16066)

## <small>5.1.13 (2023-04-01)</small>

* [bitnami/argo-workflows] Release 5.1.13 (#15839) ([2ea07df](https://github.com/bitnami/charts/commit/2ea07dfb349699c413e678deabb7ba22e82913f3)), closes [#15839](https://github.com/bitnami/charts/issues/15839)

## <small>5.1.12 (2023-03-18)</small>

* [bitnami/argo-workflows] Release 5.1.12 (#15555) ([1d9d698](https://github.com/bitnami/charts/commit/1d9d69847afde21ca7f4d601d968fee56e8c6d6e)), closes [#15555](https://github.com/bitnami/charts/issues/15555)
* [bitnami/charts] Apply linter to README files (#15357) ([0e29e60](https://github.com/bitnami/charts/commit/0e29e600d3adc8b1b46e506eccb3decfab3b4e63)), closes [#15357](https://github.com/bitnami/charts/issues/15357)

## <small>5.1.11 (2023-03-03)</small>

* [bitnami/argo-workflows] Add missing verb on workflow-controller cluster role for using HTTP templat ([21ad7f4](https://github.com/bitnami/charts/commit/21ad7f41ce78431d41d39fdf58ee5fdcbb16b6d9)), closes [#15301](https://github.com/bitnami/charts/issues/15301)

## <small>5.1.10 (2023-03-01)</small>

* [bitnami/argo-workflows] Release 5.1.10 (#15192) ([8129cba](https://github.com/bitnami/charts/commit/8129cba3c8f1313045501634ed29a9424da8a2a8)), closes [#15192](https://github.com/bitnami/charts/issues/15192)

## <small>5.1.9 (2023-02-17)</small>

* [bitnami/argo-workflows] Release 5.1.9 (#14947) ([04ca14a](https://github.com/bitnami/charts/commit/04ca14a21e1e5847f7ec8eaec3c2b4e42b89a174)), closes [#14947](https://github.com/bitnami/charts/issues/14947)

## <small>5.1.8 (2023-02-16)</small>

* [bitnami/argo-workflows] Force new version publishing (#14921) ([2a63fd3](https://github.com/bitnami/charts/commit/2a63fd39d7316aaa145c211248d12c0489d3468e)), closes [#14921](https://github.com/bitnami/charts/issues/14921)
* [bitnami/argo-workflows] Update pullPolicy to not to always pull the images (#14907) ([089a7db](https://github.com/bitnami/charts/commit/089a7db7069ddfa69b68f7dff67b5e7e2acec338)), closes [#14907](https://github.com/bitnami/charts/issues/14907)

## <small>5.1.7 (2023-02-16)</small>

* [bitnami/*] Fix markdown linter issues (#14874) ([a51e0e8](https://github.com/bitnami/charts/commit/a51e0e8d35495b907f3e70dd2f8e7c3bcbf4166a)), closes [#14874](https://github.com/bitnami/charts/issues/14874)
* [bitnami/*] Fix markdown linter issues 2 (#14890) ([aa96572](https://github.com/bitnami/charts/commit/aa9657237ee8df4a46db0d7fdf8a23230dd6902a)), closes [#14890](https://github.com/bitnami/charts/issues/14890)
* [bitnami/*] Remove unexpected extra spaces (#14873) ([c97c714](https://github.com/bitnami/charts/commit/c97c714887380d47eae7bfeff316bf01595ecd1d)), closes [#14873](https://github.com/bitnami/charts/issues/14873)
* [bitnami/argo-workflows]feat: update CRDs (#14901) ([8d458ff](https://github.com/bitnami/charts/commit/8d458ffd7d5f55188b541c386ead6ed1604713d2)), closes [#14901](https://github.com/bitnami/charts/issues/14901)

## <small>5.1.6 (2023-02-09)</small>

* [bitnami/argo-workflows] Release 5.1.6 (#14808) ([7001fd5](https://github.com/bitnami/charts/commit/7001fd54cd728cfccfbc23072fb56eced7e4ac78)), closes [#14808](https://github.com/bitnami/charts/issues/14808)

## <small>5.1.5 (2023-02-07)</small>

* [bitnami/*] Change copyright date (#14682) ([add4ec7](https://github.com/bitnami/charts/commit/add4ec701108ac36ed4de2dffbdf407a0d091067)), closes [#14682](https://github.com/bitnami/charts/issues/14682)
* [bitnami/argo-workflows] Release 5.1.5 (#14788) ([c8dc871](https://github.com/bitnami/charts/commit/c8dc871043b4661002abcf29d54d5b90c070b546)), closes [#14788](https://github.com/bitnami/charts/issues/14788)

## <small>5.1.4 (2023-01-31)</small>

* [bitnami/argo-workflows] Don't regenerate self-signed certs on upgrade (#14609) ([717732e](https://github.com/bitnami/charts/commit/717732e4cc73fb343176f7718a6f9dc3f972f021)), closes [#14609](https://github.com/bitnami/charts/issues/14609)

## <small>5.1.3 (2023-01-29)</small>

* [bitnami/*] Add license annotation and remove obsolete engine parameter (#14293) ([da2a794](https://github.com/bitnami/charts/commit/da2a7943bae95b6e9b5b4ed972c15e990b69fdb0)), closes [#14293](https://github.com/bitnami/charts/issues/14293)
* [bitnami/*] Change licenses annotation format (#14377) ([0ab7608](https://github.com/bitnami/charts/commit/0ab760862c660fcc78cffadf8e1d8cdd70881473)), closes [#14377](https://github.com/bitnami/charts/issues/14377)
* [bitnami/*] Unify READMEs (#14472) ([2064fb8](https://github.com/bitnami/charts/commit/2064fb8dcc78a845cdede8211af8c3cc52551161)), closes [#14472](https://github.com/bitnami/charts/issues/14472)
* [bitnami/argo-workflows] Release 5.1.3 (#14585) ([9eba02f](https://github.com/bitnami/charts/commit/9eba02f6b1d87272ea36098972002baff100ee73)), closes [#14585](https://github.com/bitnami/charts/issues/14585)

## <small>5.1.2 (2023-01-11)</small>

* [bitnami/argo-workflows] fix config map generation for external database enablement (#14126) ([c8eeba3](https://github.com/bitnami/charts/commit/c8eeba37b4851f546bcec15016870e53382f7229)), closes [#14126](https://github.com/bitnami/charts/issues/14126)

## <small>5.1.1 (2022-12-30)</small>

* [bitnami/argo-workflows] Release 5.1.1 (#14139) ([be0e682](https://github.com/bitnami/charts/commit/be0e682261280610faa9620d63532650487ec485)), closes [#14139](https://github.com/bitnami/charts/issues/14139)
* Fix typo (#13834) ([9626798](https://github.com/bitnami/charts/commit/9626798958d580197b1d666ea620d16937830f29)), closes [#13834](https://github.com/bitnami/charts/issues/13834)

## 5.1.0 (2022-12-07)

* [bitnami/argo-workflows] Fix persistence archive configMap rendering (#13812) ([2e86826](https://github.com/bitnami/charts/commit/2e86826cf1e8ba72eff1be0e3fba770959160b99)), closes [#13812](https://github.com/bitnami/charts/issues/13812) [#13798](https://github.com/bitnami/charts/issues/13798)

## <small>5.0.2 (2022-11-29)</small>

* [bitnami/argo-workflows] Release 5.0.2 (#13752) ([1a36b15](https://github.com/bitnami/charts/commit/1a36b154ab62977105dd9fb3728d09c886693fcd)), closes [#13752](https://github.com/bitnami/charts/issues/13752)

## <small>5.0.1 (2022-11-22)</small>

* [bitnami/argo-workflows] fix apiversion hardcode ClusterRoleBinding (#13616) ([bdf10ec](https://github.com/bitnami/charts/commit/bdf10ecfddf1639f3b13acdda557785e9b5b0bd7)), closes [#13616](https://github.com/bitnami/charts/issues/13616)

## 5.0.0 (2022-11-18)

* [bitnami/argo-workflows] Fixes sso parameters rendering (#13577) ([db8b425](https://github.com/bitnami/charts/commit/db8b4257b6e792d1c28f5525adb621c35e0842d0)), closes [#13577](https://github.com/bitnami/charts/issues/13577)

## 4.1.0 (2022-11-16)

* [bitnami/argo-workflows] Add tests and publishing using VIB (#13329) ([8c1c5a3](https://github.com/bitnami/charts/commit/8c1c5a35ed91eb1fe2f9678aabef52d70be2f1c2)), closes [#13329](https://github.com/bitnami/charts/issues/13329)

## <small>4.0.1 (2022-10-31)</small>

* [bitnami/argo-workflows] Release 4.0.1 updating components versions ([301de61](https://github.com/bitnami/charts/commit/301de612ad2d6b65419ff3b830826accfa5e721a))

## 4.0.0 (2022-10-28)

* [bitnami/argo-workflows] Update dependencies (#13215) ([7325a2a](https://github.com/bitnami/charts/commit/7325a2a9df9969b9fce0df70c3493cd10f3bbd22)), closes [#13215](https://github.com/bitnami/charts/issues/13215)
* Fix typo in README.md (#13192) ([f0383fd](https://github.com/bitnami/charts/commit/f0383fdb7735f6054d1dbf3828eb19565d461b46)), closes [#13192](https://github.com/bitnami/charts/issues/13192)

## <small>3.0.5 (2022-10-23)</small>

* [bitnami/*] Use new default branch name in links (#12943) ([a529e02](https://github.com/bitnami/charts/commit/a529e02597d49d944eba1eb0f190713293247176)), closes [#12943](https://github.com/bitnami/charts/issues/12943)
* [bitnami/argo-workflows] Release 3.0.5 updating components versions ([e57a0e5](https://github.com/bitnami/charts/commit/e57a0e5e72936f6532783e4abe40e99d233859d3))
* Generic README instructions related to the repo (#12792) ([3cf6b10](https://github.com/bitnami/charts/commit/3cf6b10e10e60df4b3e191d6b99aa99a9f597755)), closes [#12792](https://github.com/bitnami/charts/issues/12792)

## <small>3.0.4 (2022-10-01)</small>

* [bitnami/argo-workflows] Release 3.0.4 updating components versions ([5cd2d15](https://github.com/bitnami/charts/commit/5cd2d15e9782e84f5af207fed969b98707fc6e60))

## <small>3.0.3 (2022-09-28)</small>

* [bitnami/argo-workflows] Release 3.0.3 updating components versions ([2eeedf1](https://github.com/bitnami/charts/commit/2eeedf1853dc345376fdbe6f3c52236dc0becf04))

## <small>3.0.2 (2022-09-28)</small>

* [bitnami/argo-workflows]add the CustomResourceDefinition to the role (#12716) ([2dc6291](https://github.com/bitnami/charts/commit/2dc62911f46e1f0822fb88b1d220abcb18d20905)), closes [#12716](https://github.com/bitnami/charts/issues/12716)

## <small>3.0.1 (2022-09-27)</small>

* [bitnami/argo-workflows] add workflowartifactgctasks (#12704) ([590b622](https://github.com/bitnami/charts/commit/590b622271ca6cf91a72eff47167ad68786af0f2)), closes [#12704](https://github.com/bitnami/charts/issues/12704)

## 3.0.0 (2022-09-23)

* [bitnami/argo-workflows] delete executors  (#12651) ([15545bf](https://github.com/bitnami/charts/commit/15545bf90c754dc06a0476f8c509fcb9cec365eb)), closes [#12651](https://github.com/bitnami/charts/issues/12651)

## <small>2.4.4 (2022-09-21)</small>

* [bitnami/argo-workflows] Use custom probes if given (#12481) ([dfa8cd4](https://github.com/bitnami/charts/commit/dfa8cd40702d00d38fc313ff68408ceecba68dd3)), closes [#12481](https://github.com/bitnami/charts/issues/12481) [#12354](https://github.com/bitnami/charts/issues/12354)

## <small>2.4.3 (2022-09-09)</small>

* [bitnami/argo-workflows] Release 2.4.3 updating components versions ([90314d8](https://github.com/bitnami/charts/commit/90314d8f80e0b37921fe4ec6b09062cd1cc0d4b6))

## <small>2.4.2 (2022-08-23)</small>

* [bitnami/argo-workflows] Update Chart.lock (#12103) ([fc60f23](https://github.com/bitnami/charts/commit/fc60f23a2490a43bb42c978039d2beb58339d787)), closes [#12103](https://github.com/bitnami/charts/issues/12103)
* fix(argo-workflow): server cluster role add to watch secrets, serviceaccounts (#11975) ([18d2171](https://github.com/bitnami/charts/commit/18d2171d665f10becb12c4f8a5a85026b41bce17)), closes [#11975](https://github.com/bitnami/charts/issues/11975)

## <small>2.4.1 (2022-08-22)</small>

* [bitnami/argo-workflows] Update Chart.lock (#11994) ([8aa2637](https://github.com/bitnami/charts/commit/8aa2637007de4a19acf68073161fb3062ab82b09)), closes [#11994](https://github.com/bitnami/charts/issues/11994)

## 2.4.0 (2022-08-22)

* [bitnami/argo-workflows] Add support for image digest apart from tag (#11877) ([ce71e97](https://github.com/bitnami/charts/commit/ce71e9747c9459b54f6256853e9d0c5401f03c96)), closes [#11877](https://github.com/bitnami/charts/issues/11877)

## <small>2.3.10 (2022-08-10)</small>

* [bitnami/argo-workflows] Release 2.3.10 updating components versions ([e6104a4](https://github.com/bitnami/charts/commit/e6104a453ac6c9d31b0e3f8a5eaa8214b4a7e707))

## <small>2.3.9 (2022-08-09)</small>

* [bitnami/argo-workflows] Release 2.3.9 updating components versions ([f9b9aa7](https://github.com/bitnami/charts/commit/f9b9aa7e8fb362af9b11248cece2f5fc1d3d685c))

## <small>2.3.8 (2022-08-04)</small>

* [bitnami/argo-workflows] Release 2.3.8 updating components versions ([4a4467d](https://github.com/bitnami/charts/commit/4a4467da73d8a59fb819798f3c8f49edd642abfa))

## <small>2.3.7 (2022-07-29)</small>

* [bitnami/*] Update URLs to point to the new bitnami/containers monorepo (#11352) ([d665af0](https://github.com/bitnami/charts/commit/d665af0c708846192d8d5fb2f5f9ea65dd464ab0)), closes [#11352](https://github.com/bitnami/charts/issues/11352)
* [bitnami/argo-workflows] Release 2.3.7 updating components versions ([cdc421c](https://github.com/bitnami/charts/commit/cdc421cc0b33e65351bc8b3879c49d1935987de9))

## <small>2.3.6 (2022-07-12)</small>

* Fix argo-workflows icon url (#11149) ([720cec9](https://github.com/bitnami/charts/commit/720cec9687e63f1a5ee2ece69a31eae9211a2f7e)), closes [#11149](https://github.com/bitnami/charts/issues/11149)

## <small>2.3.5 (2022-06-29)</small>

* [bitnami/argo-workflows] Release 2.3.5 updating components versions ([6de3ad0](https://github.com/bitnami/charts/commit/6de3ad0aa41a771a97cc26be567506987d3f5ce4))

## <small>2.3.4 (2022-06-24)</small>

* [bitnami/argo-workflows] Release 2.3.4 updating components versions ([1c06373](https://github.com/bitnami/charts/commit/1c06373a14d234c7240f6a6d4d7f3beca15e4aa3))

## <small>2.3.3 (2022-06-21)</small>

* [bitnami/argo-workflows] Release 2.3.3 updating components versions ([01a1c86](https://github.com/bitnami/charts/commit/01a1c8662fe256c8fbad6eb7d5c9ff146ba867be))

## <small>2.3.2 (2022-06-14)</small>

* [bitnami/argo-workflows] fix: :bug: Use proper type for sidecars and init containers (#10753) ([73d85b4](https://github.com/bitnami/charts/commit/73d85b4e0352b7abc593fab49eeac7fcccc7ae4d)), closes [#10753](https://github.com/bitnami/charts/issues/10753)

## <small>2.3.1 (2022-06-09)</small>

* [bitnami/*] Replace Kubeapps URL in READMEs (and kubeapps Chart.yaml) and remove BKPR references (#1 ([c6a7914](https://github.com/bitnami/charts/commit/c6a7914361e5aea6016fb45bf4d621edfd111d32)), closes [#10600](https://github.com/bitnami/charts/issues/10600)
* [bitnami/argo-workflows] Release 2.3.1 updating components versions ([6bde87a](https://github.com/bitnami/charts/commit/6bde87a9ddf107f610038916dbfebfe676110134))

## 2.3.0 (2022-06-02)

* [bitnami/argo-workflows] Easier configuration for workflowDefaults in Controller configMap (#10257) ([fbe8605](https://github.com/bitnami/charts/commit/fbe86055b5cc2ed6836a3b4465ea7a6bc142d31c)), closes [#10257](https://github.com/bitnami/charts/issues/10257)

## <small>2.2.4 (2022-06-01)</small>

* [bitnami/several] Replace maintainers email by url (#10523) ([ff3cf61](https://github.com/bitnami/charts/commit/ff3cf617a1680509b0f3855d17c4ccff7b29a0ff)), closes [#10523](https://github.com/bitnami/charts/issues/10523)

## <small>2.2.3 (2022-05-30)</small>

* [bitnami/several] Replace base64 --decode with base64 -d (#10495) ([099286a](https://github.com/bitnami/charts/commit/099286ae7a87784cf809df0b64ab24f7ff0144c8)), closes [#10495](https://github.com/bitnami/charts/issues/10495)

## <small>2.2.2 (2022-05-26)</small>

* [bitnami/argo-workflows] Release 2.2.2 updating components versions ([9432da6](https://github.com/bitnami/charts/commit/9432da6e50d0effb28160042ca49beca8e7486b0))

## <small>2.2.1 (2022-05-25)</small>

* [bitnami/argo-workflows] Release 2.2.1 updating components versions ([4130ba7](https://github.com/bitnami/charts/commit/4130ba7574b8208275b8ede9748fe9a88320f643))

## 2.2.0 (2022-05-23)

* [bitnami/argo-workflows] Add missing serviceAccount.* parameters (#10340) ([492cf0b](https://github.com/bitnami/charts/commit/492cf0b00919ef1ff851ed63dc6e593b6d0601a8)), closes [#10340](https://github.com/bitnami/charts/issues/10340)

## <small>2.1.1 (2022-05-18)</small>

* [bitnami/argo-workflows] Release 2.1.1 updating components versions ([2e440e5](https://github.com/bitnami/charts/commit/2e440e57a23866a1f24b801eb4bc1c160d5357e0))

## 2.1.0 (2022-05-16)

* [bitnami/*] add ingress extraRules feature (#10253) ([0f6cbb9](https://github.com/bitnami/charts/commit/0f6cbb9099b0e56685cc1d36ba50340f3d7278a1)), closes [#10253](https://github.com/bitnami/charts/issues/10253)

## <small>2.0.2 (2022-05-16)</small>

* [bitnami/argo-workflows] Fix the ability to list secrets in server clusterrole (#10184) ([cac805f](https://github.com/bitnami/charts/commit/cac805f6ee6ef1286ee26e7b477a9cff613ba819)), closes [#10184](https://github.com/bitnami/charts/issues/10184)

## <small>2.0.1 (2022-05-13)</small>

* [bitnami/*] Unify k8s directives separators (#10185) ([2650214](https://github.com/bitnami/charts/commit/26502141d146ca3bdfb3bf744fcdec8ca5cece44)), closes [#10185](https://github.com/bitnami/charts/issues/10185)

## 2.0.0 (2022-05-12)

* [bitnami/argo-workflows] Bump mysql subchart version (#10178) ([d55b9ef](https://github.com/bitnami/charts/commit/d55b9ef792528e8e2396ba773feb6e3e90420c69)), closes [#10178](https://github.com/bitnami/charts/issues/10178)

## <small>1.1.14 (2022-05-11)</small>

* [bitnami/*] Fix typo in comments (relay -> rely) (#10151) ([9cfe4a4](https://github.com/bitnami/charts/commit/9cfe4a48cc35851faea6be7ffb2a978d223befa0)), closes [#10151](https://github.com/bitnami/charts/issues/10151)

## <small>1.1.13 (2022-05-04)</small>

* [bitnami/argo-workflows] Release 1.1.13 updating components versions ([ad6a41d](https://github.com/bitnami/charts/commit/ad6a41df9de2204da957f54b9309a0a4f8e04fd5))

## <small>1.1.12 (2022-04-30)</small>

* [bitnami/argo-workflows] Release 1.1.12 updating components versions ([3360861](https://github.com/bitnami/charts/commit/33608615eddff5bbbf35b517a8cb772ffe641e5f))

## <small>1.1.11 (2022-04-29)</small>

* [bitnami/argo-workflows] Release 1.1.11 updating components versions ([b68a033](https://github.com/bitnami/charts/commit/b68a0330a68ea44635aa142cb8ef8d8ad65d0807))

## <small>1.1.10 (2022-04-26)</small>

* [bitnami/argo-workflows] Release 1.1.10 updating components versions ([a2f516c](https://github.com/bitnami/charts/commit/a2f516c7c30b3de722f81ba4faaa76759fd06a9d))

## <small>1.1.9 (2022-04-25)</small>

* [bitnami/argo-workflows]: fix argo-workflow ServiceMonitor port name error (#9896) ([18f4b92](https://github.com/bitnami/charts/commit/18f4b927bb683a9114cbe14835f7d3571935a0e8)), closes [#9896](https://github.com/bitnami/charts/issues/9896)

## <small>1.1.8 (2022-04-21)</small>

* [bitnami/argo-workflows] Release 1.1.8 updating components versions ([b58dbb9](https://github.com/bitnami/charts/commit/b58dbb9f7fa54e23e912fbd066bead9c4a3a09f9))

## <small>1.1.7 (2022-04-21)</small>

* [bitnami/argo-workflows] Release 1.1.7 updating components versions ([7d1f16c](https://github.com/bitnami/charts/commit/7d1f16cf08573a77d5d2ee1b1a401e6ca04dd36c))

## <small>1.1.6 (2022-04-06)</small>

* [bitnami/argo-workflows] Update CRDs (#9699) ([1e0082f](https://github.com/bitnami/charts/commit/1e0082f585351a87c2952de5648df1dd3ceae73b)), closes [#9699](https://github.com/bitnami/charts/issues/9699)

## <small>1.1.5 (2022-04-06)</small>

* Add missing crd (#9700) ([cd2326f](https://github.com/bitnami/charts/commit/cd2326ff12d10ea137ada8d3a833c2a3053249a7)), closes [#9700](https://github.com/bitnami/charts/issues/9700)

## <small>1.1.4 (2022-04-06)</small>

* [bitnami/argo-workflows] Release 1.1.4 updating components versions ([1fa37d1](https://github.com/bitnami/charts/commit/1fa37d1844693e394c4bf611a14788f102184305))

## <small>1.1.3 (2022-03-29)</small>

* [bitnami/argo-workflows] Release 1.1.3 updating components versions ([91ff1bd](https://github.com/bitnami/charts/commit/91ff1bd75774e347aadc0d3a6197664a2cdf9df9))

## <small>1.1.2 (2022-03-24)</small>

* [bitnami/argo-workflows] Release 1.1.2 updating components versions ([ca9a3ca](https://github.com/bitnami/charts/commit/ca9a3ca4597e3d4d1f199bf0aef05b92bd2c78fd))

## <small>1.1.1 (2022-03-21)</small>

* [bitnami/argo-workflows] Remove podWorkers flag (#9438) ([09507ee](https://github.com/bitnami/charts/commit/09507eebdf914458ce99de82ef385c204a690d2a)), closes [#9438](https://github.com/bitnami/charts/issues/9438)

## 1.1.0 (2022-03-18)

* [bitnami/argo-workflows] Set rootOnlyrootFileSystem by default (#9357) ([290069c](https://github.com/bitnami/charts/commit/290069c529a75110f0e1d31ffdb2c837eaadea61)), closes [#9357](https://github.com/bitnami/charts/issues/9357)

## <small>1.0.2 (2022-03-07)</small>

* [bitnami/*] Take 'global.postgresql' values into account (#9314) ([dd428a0](https://github.com/bitnami/charts/commit/dd428a06614551c92500afa84ce9750c4d8b90c9)), closes [#9314](https://github.com/bitnami/charts/issues/9314)

## <small>1.0.1 (2022-03-03)</small>

* [bitnami/argo-workflows] Release 1.0.1 updating components versions ([0aa3380](https://github.com/bitnami/charts/commit/0aa3380b2ff71372fe4c4854b5b660f1c4e70944))

## 1.0.0 (2022-03-02)

* [bitnami/argo-workflows]: feat!: ⬆️ Bump PostgreSQL subchart (#9257) ([e1029cd](https://github.com/bitnami/charts/commit/e1029cdee5001cd66052ba0fa5ee67496c5f56a2)), closes [#9257](https://github.com/bitnami/charts/issues/9257)

## <small>0.2.6 (2022-02-21)</small>

* [bitnami/argo-workflows] Do not hardcode PDB apiVersion (#9089) ([49c04cb](https://github.com/bitnami/charts/commit/49c04cb845892134fb991ab7c608cf23b37a1eee)), closes [#9089](https://github.com/bitnami/charts/issues/9089)

## <small>0.2.5 (2022-02-04)</small>

* [bitnami/argo-workflows] Release 0.2.5 updating components versions ([23e3179](https://github.com/bitnami/charts/commit/23e317952f02b973720b387cd04edc888d8d7751))

## <small>0.2.4 (2022-02-02)</small>

* [bitnami/*] Make use of new "common.ingress.certManagerRequest" helper (#8862) ([12e4c37](https://github.com/bitnami/charts/commit/12e4c3733eaeaa9a5579fdf917fa098a0f2aae23)), closes [#8862](https://github.com/bitnami/charts/issues/8862)

## <small>0.2.3 (2022-01-28)</small>

* [bitnami/argo-workflows] Release 0.2.3 updating components versions ([a51671d](https://github.com/bitnami/charts/commit/a51671d614ed2746aa174bea1d0d9c04b42af35a))

## <small>0.2.2 (2022-01-20)</small>

* [bitnami/*] Update READMEs (#8716) ([b9a9533](https://github.com/bitnami/charts/commit/b9a953337590eb2979453385874a267bacf50936)), closes [#8716](https://github.com/bitnami/charts/issues/8716)
* [bitnami/several] Change prerequisites (#8725) ([8d740c5](https://github.com/bitnami/charts/commit/8d740c566cfdb7e2d933c40128b4e919fce953a5)), closes [#8725](https://github.com/bitnami/charts/issues/8725)

## <small>0.2.1 (2022-01-18)</small>

* [bitnami/*] Readme automation (#8579) ([78d1938](https://github.com/bitnami/charts/commit/78d193831c900d178198491ffd08fa2217a64ecd)), closes [#8579](https://github.com/bitnami/charts/issues/8579)
* [bitnami/argo-workflows] Release 0.2.1 updating components versions ([dd050ed](https://github.com/bitnami/charts/commit/dd050edbb1bfbe98da9b8ffd8b667e1461f0e70d))

## 0.2.0 (2022-01-05)

* [bitnami/several] Adapt templating format (#8562) ([8cad18a](https://github.com/bitnami/charts/commit/8cad18aed9966a6f0208e5ad6cee46cb217f47ab)), closes [#8562](https://github.com/bitnami/charts/issues/8562)
* [bitnami/several] Add license to the README ([05f7633](https://github.com/bitnami/charts/commit/05f763372501d596e57db713dd53ff4ff3027cc4))
* [bitnami/several] Add license to the README ([32fb238](https://github.com/bitnami/charts/commit/32fb238e60a0affc6debd3142eaa3c3d9089ec2a))
* [bitnami/several] Add license to the README ([b87c2f7](https://github.com/bitnami/charts/commit/b87c2f7899d48a8b02c506765e6ae82937e9ba3f))

## <small>0.1.13 (2021-12-18)</small>

* [bitnami/argo-workflows] Release 0.1.13 updating components versions ([7972343](https://github.com/bitnami/charts/commit/797234359a705e5f2c6ddcb6c5b1773d706ebf02))

## <small>0.1.12 (2021-12-17)</small>

* [bitnami/argo-workflows] Release 0.1.12 updating components versions ([f949260](https://github.com/bitnami/charts/commit/f9492609e733f4239dd19ccdfaabb9570c3faf55))

## <small>0.1.11 (2021-12-16)</small>

* [bitnami/argo-workflows] Release 0.1.11 updating components versions ([d11c14a](https://github.com/bitnami/charts/commit/d11c14a6248375853285394e16f90b20c4764331))

## <small>0.1.10 (2021-12-16)</small>

* [bitnami/argo-workflows] Release 0.1.10 updating components versions ([d4eca52](https://github.com/bitnami/charts/commit/d4eca5237c16df0c97e6de7be8168573b53bfb07))

## <small>0.1.9 (2021-11-29)</small>

* [bitnami/several] Fix deadlinks in README.md (#8215) ([99e90d2](https://github.com/bitnami/charts/commit/99e90d244b3244e059a42f72dcbecd3cda2b66bb)), closes [#8215](https://github.com/bitnami/charts/issues/8215)
* [bitnami/several] Regenerate README tables ([7b091c0](https://github.com/bitnami/charts/commit/7b091c0808ef00425c404cb97fe73c0578ccf1a3))
* [bitnami/several] Replace HTTP by HTTPS when possible (#8259) ([eafb5bd](https://github.com/bitnami/charts/commit/eafb5bd5a2cc3aaf04fc1e8ebedd73f420d76864)), closes [#8259](https://github.com/bitnami/charts/issues/8259)

## <small>0.1.8 (2021-11-18)</small>

* [bitnami/argo-workflows] Release 0.1.8 updating components versions ([6404774](https://github.com/bitnami/charts/commit/6404774f23d793f4ffb593e2b572c183cd6b879b))
* [bitnami/several] Regenerate README tables ([bb0eee1](https://github.com/bitnami/charts/commit/bb0eee13ee8394ec2cae7ef078a06502267d1891))

## <small>0.1.7 (2021-10-27)</small>

* [bitnami/argo-workflows] Release 0.1.7 updating components versions ([2b08fab](https://github.com/bitnami/charts/commit/2b08fab88a4e07968ace0275a634d25bf411c25c))
* [bitnami/several] Regenerate README tables ([c82619f](https://github.com/bitnami/charts/commit/c82619f4141cd18e1b6079fdd84eb5b7bb47d819))

## <small>0.1.6 (2021-10-22)</small>

* [bitnami/several] Add chart info to NOTES.txt (#7889) ([a6751cd](https://github.com/bitnami/charts/commit/a6751cdd33c461fabbc459fbea6f219ec64ab6b2)), closes [#7889](https://github.com/bitnami/charts/issues/7889)

## <small>0.1.5 (2021-10-22)</small>

* [bitnami/*] Drop support for deprecated cert-manager annotation (#7892) ([c88379c](https://github.com/bitnami/charts/commit/c88379cffb604a8c18aac5858f8f148043513042)), closes [#7892](https://github.com/bitnami/charts/issues/7892)

## <small>0.1.4 (2021-10-21)</small>

* [bitnami/argo-workflows] Release 0.1.4 updating components versions ([05f85a4](https://github.com/bitnami/charts/commit/05f85a4069076788d8f85970e1c02781732f5bc9))
* [bitnami/several] Regenerate README tables ([73cabea](https://github.com/bitnami/charts/commit/73cabea54a941d2239accd98e8df6cbfc9fa8d3c))

## <small>0.1.3 (2021-10-20)</small>

* [bitnami/argo-workflows] Check passwords in upgrade (#7828) ([795b01c](https://github.com/bitnami/charts/commit/795b01c59a66ae5105b22e0a381620c67c56c84e)), closes [#7828](https://github.com/bitnami/charts/issues/7828)
* [bitnami/argo-workflows] Release 0.1.3 updating components versions ([0c09d0c](https://github.com/bitnami/charts/commit/0c09d0cb0c69f262cd6bd1331da07ecd9f7adc36))
* [bitnami/several] Regenerate README tables ([681f9fa](https://github.com/bitnami/charts/commit/681f9fa6cdbbb742d383db2d9fc6da1251f3d3e5))

## <small>0.1.2 (2021-10-18)</small>

* [bitnami/argo-workflows] Release 0.1.2 updating components versions ([ee24e4f](https://github.com/bitnami/charts/commit/ee24e4f90a45a44e41d5d3820884d95e533208bb))
* [bitnami/several] Regenerate README tables ([a678bc7](https://github.com/bitnami/charts/commit/a678bc7ba8f35e8e9735b23d136aeeff7c4db1d2))

## <small>0.1.1 (2021-10-06)</small>

* [bitnami/argo-workflows] Release 0.1.1 updating components versions ([778c6c9](https://github.com/bitnami/charts/commit/778c6c99d310125219a139f839b996f9e54e46e1))

## 0.1.0 (2021-10-06)

* [bitnami/argo-workflows] Add new Argo Workflows Helm Chart (#7554) ([155b46f](https://github.com/bitnami/charts/commit/155b46f952980b48cb90cb63cfad358bb1d32e09)), closes [#7554](https://github.com/bitnami/charts/issues/7554)
