# Changelog

## 5.1.47 (2025-09-11)

* [bitnami/concourse] Add in SSL Mode for external databases. ([#36249](https://github.com/bitnami/charts/pull/36249))

## <small>5.1.45 (2025-08-07)</small>

* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#35598) ([5d1e20b](https://github.com/bitnami/charts/commit/5d1e20bb8b79825dc7f189fd2cfe21e8b2770fa4)), closes [#35598](https://github.com/bitnami/charts/issues/35598)

## <small>5.1.44 (2025-08-07)</small>

* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#35463) ([fb561e0](https://github.com/bitnami/charts/commit/fb561e0f6d28f13b3f0d00a7688e4c14d3a20da5)), closes [#35463](https://github.com/bitnami/charts/issues/35463)

## <small>5.1.43 (2025-08-01)</small>

* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#35384) ([af55f1f](https://github.com/bitnami/charts/commit/af55f1f7c658d2c8845ec6e00e3983e3554df6d6)), closes [#35384](https://github.com/bitnami/charts/issues/35384)

## <small>5.1.42 (2025-07-26)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#35304) ([d3b6151](https://github.com/bitnami/charts/commit/d3b615191c9b8dd35ccd5c9e4914bf81a8feb4a2)), closes [#35304](https://github.com/bitnami/charts/issues/35304)

## <small>5.1.41 (2025-07-15)</small>

* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#35085) ([941ab45](https://github.com/bitnami/charts/commit/941ab45b6b46918a554510dbe6d39dcab0f426bd)), closes [#35085](https://github.com/bitnami/charts/issues/35085)

## <small>5.1.40 (2025-07-09)</small>

* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#34912) ([d2581eb](https://github.com/bitnami/charts/commit/d2581eb2d597e363d2c47c67c022d3a66516a9fd)), closes [#34912](https://github.com/bitnami/charts/issues/34912)

## <small>5.1.39 (2025-06-28)</small>

* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#34644) ([d632023](https://github.com/bitnami/charts/commit/d632023ce16a6c94f474e5baa129962ce8262395)), closes [#34644](https://github.com/bitnami/charts/issues/34644)

## <small>5.1.38 (2025-06-27)</small>

* [bitnami/concourse] Update deps and test (#34688) ([c4e66cd](https://github.com/bitnami/charts/commit/c4e66cdd2a3f75b76bb832593e2f2d8c5881a6e0)), closes [#34688](https://github.com/bitnami/charts/issues/34688)

## <small>5.1.37 (2025-06-13)</small>

* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#34425) ([47d3adc](https://github.com/bitnami/charts/commit/47d3adc0ac52ab5d0ae74f9603a70ebeb05f2459)), closes [#34425](https://github.com/bitnami/charts/issues/34425)

## <small>5.1.36 (2025-06-11)</small>

* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#34358) ([e17ed03](https://github.com/bitnami/charts/commit/e17ed03ce7e83d450aa25c9d0bd2909cbba615e9)), closes [#34358](https://github.com/bitnami/charts/issues/34358)

## <small>5.1.35 (2025-06-11)</small>

* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#34325) ([3c57bc6](https://github.com/bitnami/charts/commit/3c57bc663bfca7c88c09f0d76731575e8a38bb35)), closes [#34325](https://github.com/bitnami/charts/issues/34325)

## <small>5.1.34 (2025-06-05)</small>

* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#34145) ([ae49739](https://github.com/bitnami/charts/commit/ae4973970e1509c98983467f2729465df5dfb6ba)), closes [#34145](https://github.com/bitnami/charts/issues/34145)

## <small>5.1.33 (2025-06-03)</small>

* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#34073) ([ad7c9f9](https://github.com/bitnami/charts/commit/ad7c9f96248e5b7a9530b37bdc371c87b9c9d2b4)), closes [#34073](https://github.com/bitnami/charts/issues/34073)

## <small>5.1.32 (2025-05-23)</small>

* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#33868) ([3001192](https://github.com/bitnami/charts/commit/3001192942b19d81cf20dd051c8998e489ba2c59)), closes [#33868](https://github.com/bitnami/charts/issues/33868)

## <small>5.1.31 (2025-05-16)</small>

* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#33754) ([efe9468](https://github.com/bitnami/charts/commit/efe94689d045c518a84580da4653a2e7607b272d)), closes [#33754](https://github.com/bitnami/charts/issues/33754)
* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)

## <small>5.1.30 (2025-05-08)</small>

* [bitnami/concourse] :zap: :arrow_up: Update dependency references (#33560) ([0c0c895](https://github.com/bitnami/charts/commit/0c0c895389674cbb26f604b2e46fe545bc175f50)), closes [#33560](https://github.com/bitnami/charts/issues/33560)

## <small>5.1.29 (2025-05-07)</small>

* [bitnami/concourse] Release 5.1.29 (#33510) ([eb6f982](https://github.com/bitnami/charts/commit/eb6f9826cd4e472ea98a705d3f2ed2e870a01972)), closes [#33510](https://github.com/bitnami/charts/issues/33510)

## <small>5.1.28 (2025-05-06)</small>

* [bitnami/concourse] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#333 ([20e8c18](https://github.com/bitnami/charts/commit/20e8c18fa51f6435d4768e712a73e4447ecaf3ff)), closes [#33348](https://github.com/bitnami/charts/issues/33348)

## <small>5.1.27 (2025-05-05)</small>

* [bitnami/concourse] Release 5.1.27 (#33328) ([32a1154](https://github.com/bitnami/charts/commit/32a11548d42e2faa90ca978552d0831c17da3b53)), closes [#33328](https://github.com/bitnami/charts/issues/33328)

## <small>5.1.26 (2025-04-29)</small>

* [bitnami/concourse] Release 5.1.26 (#33252) ([2b044e8](https://github.com/bitnami/charts/commit/2b044e855625a0047c1ebe713bceebb872bffb68)), closes [#33252](https://github.com/bitnami/charts/issues/33252)

## <small>5.1.25 (2025-04-25)</small>

* [bitnami/concourse] Release 5.1.25 (#33183) ([18dd2c0](https://github.com/bitnami/charts/commit/18dd2c0062b99799ec5ebacf10552078ce2ad988)), closes [#33183](https://github.com/bitnami/charts/issues/33183)

## <small>5.1.24 (2025-04-10)</small>

* [bitnami/concourse] Release 5.1.24 (#32946) ([d8ed62a](https://github.com/bitnami/charts/commit/d8ed62a36d73ee04d631da044fe2966c7945c8a5)), closes [#32946](https://github.com/bitnami/charts/issues/32946)

## <small>5.1.23 (2025-04-09)</small>

* [bitnami/concourse] Release 5.1.23 (#32941) ([58aee8b](https://github.com/bitnami/charts/commit/58aee8b6cbd12e046221e74816f0be298081cc49)), closes [#32941](https://github.com/bitnami/charts/issues/32941)

## <small>5.1.22 (2025-04-09)</small>

* [bitnami/concourse] Release 5.1.22 (#32940) ([5b16416](https://github.com/bitnami/charts/commit/5b16416c03542e1fd9f7219526b2ddb65ccfde6c)), closes [#32940](https://github.com/bitnami/charts/issues/32940)

## <small>5.1.21 (2025-04-09)</small>

* [bitnami/concourse] Release 5.1.21 (#32936) ([489697a](https://github.com/bitnami/charts/commit/489697ae5d554cc551b5b866eefa904b9e6dc9d0)), closes [#32936](https://github.com/bitnami/charts/issues/32936)

## <small>5.1.20 (2025-04-09)</small>

* [bitnami/concourse] Release 5.1.20 (#32931) ([66f1bf3](https://github.com/bitnami/charts/commit/66f1bf3a27e8702df9fe17b66ff086ad6c626891)), closes [#32931](https://github.com/bitnami/charts/issues/32931)

## <small>5.1.19 (2025-04-01)</small>

* [bitnami/concourse] Release 5.1.19 (#32724) ([f6c9831](https://github.com/bitnami/charts/commit/f6c9831e6e56f3c07b0b14aa38e62849ef3fe20e)), closes [#32724](https://github.com/bitnami/charts/issues/32724)

## <small>5.1.18 (2025-03-17)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/concourse] Release 5.1.18 (#32491) ([27841fb](https://github.com/bitnami/charts/commit/27841fb4e7c2ce55e22041e4a9a4d0a2f6a14e53)), closes [#32491](https://github.com/bitnami/charts/issues/32491)

## <small>5.1.17 (2025-03-04)</small>

* [bitnami/concourse] Release 5.1.17 (#32283) ([b1ed30c](https://github.com/bitnami/charts/commit/b1ed30c4bf7d8bacfd27b5fd84646cc44077f594)), closes [#32283](https://github.com/bitnami/charts/issues/32283)

## <small>5.1.16 (2025-03-04)</small>

* [bitnami/concourse] Release 5.1.16 (#32269) ([224ca88](https://github.com/bitnami/charts/commit/224ca88e7e935d3eccb01137476936a2d9063f69)), closes [#32269](https://github.com/bitnami/charts/issues/32269)

## <small>5.1.15 (2025-02-27)</small>

* [bitnami/concourse] Release 5.1.15 (#32197) ([637796b](https://github.com/bitnami/charts/commit/637796b7e078f96b7375a721a7456e29a2d6b211)), closes [#32197](https://github.com/bitnami/charts/issues/32197)

## <small>5.1.14 (2025-02-19)</small>

* [bitnami/concourse] Release 5.1.14 (#31979) ([cfa5547](https://github.com/bitnami/charts/commit/cfa554753fb3840fd7a29d53e90f2c09fb839757)), closes [#31979](https://github.com/bitnami/charts/issues/31979)

## <small>5.1.13 (2025-02-14)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/concourse] Release 5.1.13 (#31923) ([0f72679](https://github.com/bitnami/charts/commit/0f726790be67f367a5828f335c86ce12dc354e76)), closes [#31923](https://github.com/bitnami/charts/issues/31923)

## <small>5.1.12 (2025-02-05)</small>

* [bitnami/concourse] Release 5.1.12 (#31796) ([67d7ab2](https://github.com/bitnami/charts/commit/67d7ab24868dd35ecc34c2177d3e46e149f6ea80)), closes [#31796](https://github.com/bitnami/charts/issues/31796)

## <small>5.1.11 (2025-02-04)</small>

* [bitnami/concourse] Release 5.1.11 (#31747) ([7fb2fc5](https://github.com/bitnami/charts/commit/7fb2fc52e50ba82efe9959d5607511e4be618377)), closes [#31747](https://github.com/bitnami/charts/issues/31747)

## <small>5.1.10 (2025-02-04)</small>

* [bitnami/concourse] Release 5.1.10 (#31723) ([52eb3d0](https://github.com/bitnami/charts/commit/52eb3d0ec4414068111b37500ca096fc77d672e8)), closes [#31723](https://github.com/bitnami/charts/issues/31723)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## <small>5.1.9 (2025-01-24)</small>

* [bitnami/concourse] Release 5.1.9 (#31546) ([211f0e9](https://github.com/bitnami/charts/commit/211f0e96531c13be6d077d601902272145f80ad1)), closes [#31546](https://github.com/bitnami/charts/issues/31546)

## <small>5.1.8 (2025-01-22)</small>

* [bitnami/concourse] Release 5.1.8 (#31519) ([aed29d3](https://github.com/bitnami/charts/commit/aed29d3709ec249595de424a7d6fe3a3a8fdaf27)), closes [#31519](https://github.com/bitnami/charts/issues/31519)

## <small>5.1.7 (2025-01-17)</small>

* [bitnami/concourse] Release 5.1.7 (#31462) ([590f617](https://github.com/bitnami/charts/commit/590f617f65a5ba1ad4600e492e849233437e30fd)), closes [#31462](https://github.com/bitnami/charts/issues/31462)

## <small>5.1.6 (2025-01-17)</small>

* [bitnami/concourse] Release 5.1.6 (#31414) ([beffcf4](https://github.com/bitnami/charts/commit/beffcf486baeb7bb52b710c13ccc00f49cb75bff)), closes [#31414](https://github.com/bitnami/charts/issues/31414)

## <small>5.1.5 (2025-01-10)</small>

* [bitnami/concourse] Release 5.1.5 (#31282) ([fd3fc4b](https://github.com/bitnami/charts/commit/fd3fc4b09ae5873c4f3a83aeebf5abedc3328c28)), closes [#31282](https://github.com/bitnami/charts/issues/31282)

## <small>5.1.4 (2025-01-07)</small>

* [bitnami/concourse] Release 5.1.4 (#31245) ([17527c5](https://github.com/bitnami/charts/commit/17527c53d4651a78710b4c5165c90170045557f0)), closes [#31245](https://github.com/bitnami/charts/issues/31245)

## <small>5.1.3 (2025-01-04)</small>

* [bitnami/concourse] Release 5.1.3 (#31214) ([3c19446](https://github.com/bitnami/charts/commit/3c19446fba280bab739179dd962fcbd8688336cc)), closes [#31214](https://github.com/bitnami/charts/issues/31214)

## <small>5.1.2 (2024-12-20)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/concourse] Release 5.1.2 (#31130) ([a16f095](https://github.com/bitnami/charts/commit/a16f0953ab89087823fed9afab3fecf1430d9638)), closes [#31130](https://github.com/bitnami/charts/issues/31130)

## <small>5.1.1 (2024-12-11)</small>

* [bitnami/concourse] Release 5.1.1 (#30977) ([9e2c209](https://github.com/bitnami/charts/commit/9e2c20934cb7848b042aed0c8f87a2d4ed627006)), closes [#30977](https://github.com/bitnami/charts/issues/30977)

## 5.1.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/concourse] Detect non-standard images (#30872) ([62a2bd4](https://github.com/bitnami/charts/commit/62a2bd4c512a859b75d765c846d5cb2a9fe694b2)), closes [#30872](https://github.com/bitnami/charts/issues/30872)

## <small>5.0.15 (2024-12-05)</small>

* [bitnami/concourse] Release 5.0.15 (#30792) ([51f0d05](https://github.com/bitnami/charts/commit/51f0d051baad14130026737253d1184cbddf43c7)), closes [#30792](https://github.com/bitnami/charts/issues/30792)

## <small>5.0.14 (2024-12-03)</small>

* [bitnami/concourse] Release 5.0.14 (#30748) ([fa06b8c](https://github.com/bitnami/charts/commit/fa06b8c9d3b3d9844a2b31ffa0190066e48985b8)), closes [#30748](https://github.com/bitnami/charts/issues/30748)

## <small>5.0.13 (2024-12-03)</small>

* [bitnami/concourse] Release 5.0.13 (#30719) ([a4108f5](https://github.com/bitnami/charts/commit/a4108f51cad86eb0df6e433123cac7cb9e611140)), closes [#30719](https://github.com/bitnami/charts/issues/30719)

## <small>5.0.12 (2024-12-02)</small>

* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/*] docs: :memo: Add "Update Credentials" (batch 1) (#30685) ([be6aa1d](https://github.com/bitnami/charts/commit/be6aa1df0bd4479173a78400fef7295de15b408d)), closes [#30685](https://github.com/bitnami/charts/issues/30685)
* [bitnami/concourse] Release 5.0.12 (#30716) ([dd849ee](https://github.com/bitnami/charts/commit/dd849eee5251131ce0be3f5837a15ce42952151d)), closes [#30716](https://github.com/bitnami/charts/issues/30716)

## <small>5.0.11 (2024-11-21)</small>

* [bitnami/concourse] Release 5.0.11 (#30569) ([864c4bb](https://github.com/bitnami/charts/commit/864c4bbda79fd01bf68b4e9e21f9447075a77bf0)), closes [#30569](https://github.com/bitnami/charts/issues/30569)

## <small>5.0.10 (2024-11-18)</small>

* [bitnami/concourse] Release 5.0.10 (#30507) ([23c55b6](https://github.com/bitnami/charts/commit/23c55b6d4f2e3b588e5b6b87dcdf45c0f9f5e54a)), closes [#30507](https://github.com/bitnami/charts/issues/30507)

## <small>5.0.9 (2024-11-16)</small>

* [bitnami/concourse] Release 5.0.9 (#30484) ([4f797cd](https://github.com/bitnami/charts/commit/4f797cdfbd250a7343de2c245365789fac515885)), closes [#30484](https://github.com/bitnami/charts/issues/30484)

## <small>5.0.8 (2024-11-14)</small>

* [bitnami/concourse] Release 5.0.8 (#30468) ([1bacd1a](https://github.com/bitnami/charts/commit/1bacd1a01f6b799e0dd908ebe86f3fcbcb5084a6)), closes [#30468](https://github.com/bitnami/charts/issues/30468)

## <small>5.0.7 (2024-11-08)</small>

* [bitnami/concourse] Unify seLinuxOptions default value (#30348) ([47c0557](https://github.com/bitnami/charts/commit/47c055711a53cc7287cda6c17de6cb38de56da4f)), closes [#30348](https://github.com/bitnami/charts/issues/30348)

## <small>5.0.6 (2024-11-08)</small>

* [bitnami/concourse] Release 5.0.6 (#30311) ([f324d80](https://github.com/bitnami/charts/commit/f324d806010b0abc2154d1dca23b1bf76f4a523a)), closes [#30311](https://github.com/bitnami/charts/issues/30311)

## <small>5.0.5 (2024-11-07)</small>

* [bitnami/concourse] Release 5.0.5 (#30258) ([cd032b9](https://github.com/bitnami/charts/commit/cd032b9252556a477e3ff5d55d0b0460156bb593)), closes [#30258](https://github.com/bitnami/charts/issues/30258)

## <small>5.0.4 (2024-11-02)</small>

* [bitnami/concourse] Release 5.0.4 (#30175) ([69e0319](https://github.com/bitnami/charts/commit/69e03191ca3ead2a3915bbaf022fc9ea81ca1df6)), closes [#30175](https://github.com/bitnami/charts/issues/30175)

## <small>5.0.3 (2024-10-31)</small>

* [bitnami/concourse] Release 5.0.3 (#30144) ([446f4b5](https://github.com/bitnami/charts/commit/446f4b570014f85d7a3904a2ce2a1cdff2ef2936)), closes [#30144](https://github.com/bitnami/charts/issues/30144)

## <small>5.0.2 (2024-10-29)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/concourse] Release 5.0.2 (#30130) ([4fb2295](https://github.com/bitnami/charts/commit/4fb2295fc9638907b1b58498c9776b74b7f722d3)), closes [#30130](https://github.com/bitnami/charts/issues/30130)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## <small>5.0.1 (2024-10-09)</small>

* [bitnami/concourse] Release 5.0.1 (#29848) ([82bba13](https://github.com/bitnami/charts/commit/82bba13bec3bf461f54e2ceda875c1c796244685)), closes [#29848](https://github.com/bitnami/charts/issues/29848)

## 5.0.0 (2024-10-03)

* [bitnami/concourse] feat!: :arrow_up: :boom: Bump PostgreSQL to 17.x (#29730) ([3d11c36](https://github.com/bitnami/charts/commit/3d11c365c9bd8b197a58d306a8c52dfb5fbb5d2d)), closes [#29730](https://github.com/bitnami/charts/issues/29730)

## <small>4.2.12 (2024-08-30)</small>

* [bitnami/concourse] Release 4.2.12 (#29133) ([2482a2a](https://github.com/bitnami/charts/commit/2482a2ae001a54721f167d57979ee88ea9fed749)), closes [#29133](https://github.com/bitnami/charts/issues/29133)

## <small>4.2.11 (2024-07-25)</small>

* [bitnami/concourse] Release 4.2.11 (#28503) ([eaab8b0](https://github.com/bitnami/charts/commit/eaab8b0a3ad6bc1d0a1e0354b7a66bd79ea38efa)), closes [#28503](https://github.com/bitnami/charts/issues/28503)

## <small>4.2.10 (2024-07-24)</small>

* [bitnami/concourse] Release 4.2.10 (#28385) ([39f4fe2](https://github.com/bitnami/charts/commit/39f4fe20c02e73c49c068b3a0b3f2a0647371507)), closes [#28385](https://github.com/bitnami/charts/issues/28385)

## <small>4.2.9 (2024-07-16)</small>

* [bitnami/concourse] Global StorageClass as default value (#28006) ([841a853](https://github.com/bitnami/charts/commit/841a853202dc4f7eef67cd5b26990eecaa3c781e)), closes [#28006](https://github.com/bitnami/charts/issues/28006)

## <small>4.2.8 (2024-07-03)</small>

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/concourse] Release 4.2.8 (#27727) ([620335f](https://github.com/bitnami/charts/commit/620335fb27cad38074d5ce6b3bb18e9f1c8f16b2)), closes [#27727](https://github.com/bitnami/charts/issues/27727)

## <small>4.2.7 (2024-06-18)</small>

* [bitnami/concourse] Release 4.2.7 (#27432) ([0214bf9](https://github.com/bitnami/charts/commit/0214bf977798a91fe3110960463ababebdaf99d2)), closes [#27432](https://github.com/bitnami/charts/issues/27432)

## <small>4.2.6 (2024-06-17)</small>

* [bitnami/concourse] Release 4.2.6 (#27301) ([7309c98](https://github.com/bitnami/charts/commit/7309c98e8bcb7d6a87c4fc1d79144ded24ae39a7)), closes [#27301](https://github.com/bitnami/charts/issues/27301)

## <small>4.2.5 (2024-06-06)</small>

* [bitnami/concourse] Release 4.2.5 (#26931) ([9c29ca0](https://github.com/bitnami/charts/commit/9c29ca041a09726337cd6e75e191ca6ba5290e52)), closes [#26931](https://github.com/bitnami/charts/issues/26931)

## <small>4.2.4 (2024-06-06)</small>

* [bitnami/concourse] Align PodDisruptionBudgets with templates (#26688) ([5fb555f](https://github.com/bitnami/charts/commit/5fb555f85c804d48e3cbf0ccf5f0d8dd278dbdcc)), closes [#26688](https://github.com/bitnami/charts/issues/26688)

## <small>4.2.3 (2024-06-05)</small>

* [bitnami/concourse] Bump chart version (#26824) ([2ab9b50](https://github.com/bitnami/charts/commit/2ab9b509e77e27dc5af7537da764f7c1612e8015)), closes [#26824](https://github.com/bitnami/charts/issues/26824)

## <small>4.2.2 (2024-06-05)</small>

* [bitnami/concourse] Bump chart version (#26766) ([5413c17](https://github.com/bitnami/charts/commit/5413c1784a303f46c590b14cb9ad3663e1618747)), closes [#26766](https://github.com/bitnami/charts/issues/26766)

## <small>4.2.1 (2024-05-23)</small>

* [bitnami/concourse] Use different liveness/readiness probes (#26340) ([04467b6](https://github.com/bitnami/charts/commit/04467b6969709579e43317c63ade2d3a96f79bfc)), closes [#26340](https://github.com/bitnami/charts/issues/26340)

## 4.2.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/concourse] feat: :sparkles: :lock: Add warning when original images are replaced (#26189) ([2c3742a](https://github.com/bitnami/charts/commit/2c3742ac0105f0ec3955b8443d8b07dbe109fd05)), closes [#26189](https://github.com/bitnami/charts/issues/26189)

## 4.1.0 (2024-05-20)

* [bitnami/concourse] PDB review (#25869) ([d8a78da](https://github.com/bitnami/charts/commit/d8a78daca1557e14278d8aebe109d58692b710f2)), closes [#25869](https://github.com/bitnami/charts/issues/25869)

## <small>4.0.2 (2024-05-18)</small>

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/concourse] Release 4.0.2 updating components versions (#26091) ([61ac7dd](https://github.com/bitnami/charts/commit/61ac7dd0375e0f6525feeab317e1b65aa9e0f41f)), closes [#26091](https://github.com/bitnami/charts/issues/26091)
* [bitnami/multiple charts] Fix typo: "NetworkPolice" vs "NetworkPolicy" (#25348) ([6970c1b](https://github.com/bitnami/charts/commit/6970c1ba245873506e73d459c6eac1e4919b778f)), closes [#25348](https://github.com/bitnami/charts/issues/25348)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## <small>4.0.1 (2024-04-21)</small>

* [bitnami/concourse] Release 4.0.1 (#25293) ([0ce4fbb](https://github.com/bitnami/charts/commit/0ce4fbbc4a185226929c796039d50201c2741637)), closes [#25293](https://github.com/bitnami/charts/issues/25293)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## 4.0.0 (2024-04-01)

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* [bitnami/concourse] feat!: :lock: :boom: Improve security defaults (#24541) ([00e0013](https://github.com/bitnami/charts/commit/00e0013229a6bcba7a9571c163c62b3272d5f2a4)), closes [#24541](https://github.com/bitnami/charts/issues/24541)

## <small>3.7.3 (2024-03-12)</small>

* [bitnami/concourse] Release 3.7.3 updating components versions (#24366) ([2b79469](https://github.com/bitnami/charts/commit/2b7946956919ab70f77914d4295263c5f12815ed)), closes [#24366](https://github.com/bitnami/charts/issues/24366)

## <small>3.7.2 (2024-03-11)</small>

* [bitnami/concourse] Release 3.7.2 updating components versions (#24356) ([3dff7b1](https://github.com/bitnami/charts/commit/3dff7b14bce7eb08adb0f69c99f04b88d84ab728)), closes [#24356](https://github.com/bitnami/charts/issues/24356)

## <small>3.7.1 (2024-03-06)</small>

* [bitnami/concourse] Release 3.7.1 updating components versions (#24189) ([5bab2ae](https://github.com/bitnami/charts/commit/5bab2ae0db06f82fa447e9a70cc08012b3691228)), closes [#24189](https://github.com/bitnami/charts/issues/24189)

## 3.7.0 (2024-03-06)

* [bitnami/concourse] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v2 SCC ([57f00a7](https://github.com/bitnami/charts/commit/57f00a74c8ef438a9db4bc36430906bdaac89722)), closes [#24070](https://github.com/bitnami/charts/issues/24070)

## 3.6.0 (2024-02-27)

* [bitnami/concourse] feat: :sparkles: :lock: Add readOnlyRootFilesystem support (#23878) ([e2a4425](https://github.com/bitnami/charts/commit/e2a4425b31cd799879b2f87c0259696a9327918c)), closes [#23878](https://github.com/bitnami/charts/issues/23878)

## <small>3.5.3 (2024-02-27)</small>

* [bitnami/concourse] Release 3.5.3 updating components versions (#23934) ([e71e2a9](https://github.com/bitnami/charts/commit/e71e2a9218b51b765c558082a2b4ff0bc9427db6)), closes [#23934](https://github.com/bitnami/charts/issues/23934)

## <small>3.5.2 (2024-02-21)</small>

* [bitnami/concourse] Release 3.5.2 updating components versions (#23741) ([ec0ec17](https://github.com/bitnami/charts/commit/ec0ec17b1c5ce6df0d02a68005afe2814061cdbb)), closes [#23741](https://github.com/bitnami/charts/issues/23741)

## <small>3.5.1 (2024-02-21)</small>

* [bitnami/concourse] feat: :sparkles: :lock: Add resource preset support (#23437) ([0829956](https://github.com/bitnami/charts/commit/08299565064ded952d543c5abda9a0359cdf7d39)), closes [#23437](https://github.com/bitnami/charts/issues/23437)
* [bitnami/concourse] Release 3.5.1 updating components versions (#23638) ([23a6493](https://github.com/bitnami/charts/commit/23a649387194cbc681602d5538f3d26961f8e163)), closes [#23638](https://github.com/bitnami/charts/issues/23638)

## 3.5.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## 3.4.0 (2024-02-08)

* [bitnami/concourse] feat: :lock: Enable networkPolicy (#23334) ([0e35bb2](https://github.com/bitnami/charts/commit/0e35bb2fcf820012b5f9a4d2cc8773da00de881b)), closes [#23334](https://github.com/bitnami/charts/issues/23334)

## <small>3.3.9 (2024-02-08)</small>

* [bitnami/concourse] Release 3.3.9 updating components versions (#23326) ([e5a1f5f](https://github.com/bitnami/charts/commit/e5a1f5f706a957a4a990ca68ee0a25d261aafcb3)), closes [#23326](https://github.com/bitnami/charts/issues/23326)

## <small>3.3.8 (2024-02-07)</small>

* [bitnami/concourse] Release 3.3.8 updating components versions (#23268) ([4d04bac](https://github.com/bitnami/charts/commit/4d04bac229d35de8f69619868ec24978a940e3ce)), closes [#23268](https://github.com/bitnami/charts/issues/23268)

## <small>3.3.7 (2024-02-07)</small>

* [bitnami/concourse] Release 3.3.7 updating components versions (#23223) ([9d747fc](https://github.com/bitnami/charts/commit/9d747fc4035ab571af09d2ed57a1c43e46212625)), closes [#23223](https://github.com/bitnami/charts/issues/23223)

## <small>3.3.6 (2024-02-03)</small>

* [bitnami/concourse] Release 3.3.6 updating components versions (#23091) ([984c80b](https://github.com/bitnami/charts/commit/984c80b7d78b2eaca3d63e5c90e4d25bb5d6833e)), closes [#23091](https://github.com/bitnami/charts/issues/23091)

## <small>3.3.5 (2024-02-02)</small>

* [bitnami/concourse] Release 3.3.5 updating components versions (#23039) ([b8b6d2e](https://github.com/bitnami/charts/commit/b8b6d2e378225243f6ded5565ee04aae77074f74)), closes [#23039](https://github.com/bitnami/charts/issues/23039)

## <small>3.3.4 (2024-01-30)</small>

* [bitnami/concourse] Release 3.3.4 updating components versions (#22865) ([bd6978e](https://github.com/bitnami/charts/commit/bd6978e52e364b492560ddc0e739e0d0c270574d)), closes [#22865](https://github.com/bitnami/charts/issues/22865)

## <small>3.3.3 (2024-01-27)</small>

* [bitnami/concourse] Release 3.3.3 updating components versions (#22791) ([2909547](https://github.com/bitnami/charts/commit/2909547bdea42846f2d0104f023ff39c121d6409)), closes [#22791](https://github.com/bitnami/charts/issues/22791)

## <small>3.3.2 (2024-01-26)</small>

* [bitnami/concourse] Release 3.3.2 updating components versions (#22768) ([fc36e80](https://github.com/bitnami/charts/commit/fc36e80c9ae42fd6a423a567c7fa1f6dab44ffd3)), closes [#22768](https://github.com/bitnami/charts/issues/22768)

## <small>3.3.1 (2024-01-24)</small>

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/concourse] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22575) ([c4c2353](https://github.com/bitnami/charts/commit/c4c2353878f11422976954890bb36035532cd024)), closes [#22575](https://github.com/bitnami/charts/issues/22575)

## 3.3.0 (2024-01-22)

* [bitnami/concourse] fix: :lock: Move service-account token auto-mount to pod declaration (#22391) ([1f86167](https://github.com/bitnami/charts/commit/1f86167ee10a3abdac0357232ec2f99ec3c526d7)), closes [#22391](https://github.com/bitnami/charts/issues/22391)

## <small>3.2.1 (2024-01-18)</small>

* [bitnami/concourse] Release 3.2.1 updating components versions (#22262) ([be1a7ca](https://github.com/bitnami/charts/commit/be1a7ca8c4397ebcefc86210426e7ddd6bb703ee)), closes [#22262](https://github.com/bitnami/charts/issues/22262)

## 3.2.0 (2024-01-16)

* [bitnami/concourse] fix: :lock: Improve podSecurityContext and containerSecurityContext with essenti ([d27cd90](https://github.com/bitnami/charts/commit/d27cd906f8a8a16c8e5d1706be79b12e183a7b61)), closes [#22106](https://github.com/bitnami/charts/issues/22106)

## <small>3.1.1 (2024-01-13)</small>

* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/concourse] Release 3.1.1 updating components versions (#22077) ([352eace](https://github.com/bitnami/charts/commit/352eace3adb7c2c3d3056ef22593a16c94a1ab90)), closes [#22077](https://github.com/bitnami/charts/issues/22077)

## 3.1.0 (2024-01-10)

* [bitnami/concourse] feat: :sparkles: Add seccompProfile to containerSecurityContext (#21907) ([a505657](https://github.com/bitnami/charts/commit/a50565719ec0d2ed87e2bab6c99585bd579e4549)), closes [#21907](https://github.com/bitnami/charts/issues/21907)

## <small>3.0.16 (2024-01-10)</small>

* [bitnami/*] Fix docs.bitnami.com broken links (#21901) ([f35506d](https://github.com/bitnami/charts/commit/f35506d2dadee4f097986e7792df1f53ab215b5d)), closes [#21901](https://github.com/bitnami/charts/issues/21901)
* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)
* [bitnami/concourse] Release 3.0.16 updating components versions (#21930) ([f9d922d](https://github.com/bitnami/charts/commit/f9d922deb7471fe96fcf59d0d64e932a419db4d2)), closes [#21930](https://github.com/bitnami/charts/issues/21930)

## <small>3.0.15 (2024-01-02)</small>

* [bitnami/concourse] Release 3.0.15 updating components versions (#21811) ([2c1085b](https://github.com/bitnami/charts/commit/2c1085b278bdd648d011ad88a2483c2f26af41ee)), closes [#21811](https://github.com/bitnami/charts/issues/21811)

## <small>3.0.14 (2023-12-15)</small>

* [bitnami/concourse] Release 3.0.14 updating components versions (#21599) ([96f74ea](https://github.com/bitnami/charts/commit/96f74ea81c10e83e6856199dbcafcb244c280dc4)), closes [#21599](https://github.com/bitnami/charts/issues/21599)

## <small>3.0.13 (2023-12-12)</small>

* [bitnami/concourse] Release 3.0.13 updating components versions (#21535) ([4184a64](https://github.com/bitnami/charts/commit/4184a643d0f39a63f892e84c5328870a5d1d91f0)), closes [#21535](https://github.com/bitnami/charts/issues/21535)

## <small>3.0.12 (2023-11-30)</small>

* [bitnami/concourse] Release 3.0.12 updating components versions (#21317) ([b708df9](https://github.com/bitnami/charts/commit/b708df9c4c048c66f23eb0b3535119ebef1e7afc)), closes [#21317](https://github.com/bitnami/charts/issues/21317)

## <small>3.0.11 (2023-11-27)</small>

* [bitnami/concourse] Release 3.0.11 updating components versions (#21277) ([3a73978](https://github.com/bitnami/charts/commit/3a739784bb0eaa63715ff6a275154ecd4a0f672e)), closes [#21277](https://github.com/bitnami/charts/issues/21277)

## <small>3.0.10 (2023-11-21)</small>

* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/concourse] Release 3.0.10 updating components versions (#21104) ([9fb0a4f](https://github.com/bitnami/charts/commit/9fb0a4fd4ae6c7328000cdee882052ffa239fc79)), closes [#21104](https://github.com/bitnami/charts/issues/21104)
* Update readme-generator links (#21043) ([1581eba](https://github.com/bitnami/charts/commit/1581eba8044d730a763c266f279ac2ac782f764d)), closes [#21043](https://github.com/bitnami/charts/issues/21043)

## <small>3.0.9 (2023-11-16)</small>

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/concourse] Release 3.0.9 updating components versions (#21008) ([032ef80](https://github.com/bitnami/charts/commit/032ef80f750dda1208e11f5d10ec7ab19813438b)), closes [#21008](https://github.com/bitnami/charts/issues/21008)

## <small>3.0.8 (2023-11-09)</small>

* [bitnami/concourse] Release 3.0.8 updating components versions (#20839) ([64b33ef](https://github.com/bitnami/charts/commit/64b33efd67aac08de04b6c2ba9d6b8ed5ba64439)), closes [#20839](https://github.com/bitnami/charts/issues/20839)

## <small>3.0.7 (2023-11-09)</small>

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [bitnami/concourse] Release 3.0.7 updating components versions (#20726) ([96d291a](https://github.com/bitnami/charts/commit/96d291aecc0faab94b193692b29a9a71150e1fba)), closes [#20726](https://github.com/bitnami/charts/issues/20726)

## <small>3.0.6 (2023-10-15)</small>

* [bitnami/concourse] Release 3.0.6 updating components versions (#20176) ([6d86049](https://github.com/bitnami/charts/commit/6d86049d61a324510c7ca67ebf423a473ef818eb)), closes [#20176](https://github.com/bitnami/charts/issues/20176)

## <small>3.0.5 (2023-10-09)</small>

* [bitnami/concourse] Release 3.0.5 (#19896) ([b471d92](https://github.com/bitnami/charts/commit/b471d92d15335f2b00de288c776a63b7562f0184)), closes [#19896](https://github.com/bitnami/charts/issues/19896)

## <small>3.0.4 (2023-10-09)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/concourse] Release 3.0.4 (#19816) ([170087f](https://github.com/bitnami/charts/commit/170087ff29c3140391265def0b5a0f47dce7f1a5)), closes [#19816](https://github.com/bitnami/charts/issues/19816)

## <small>3.0.3 (2023-10-03)</small>

* [bitnami/concourse] Release 3.0.3 (#19698) ([23451fa](https://github.com/bitnami/charts/commit/23451fa9a8c2ba3bbb1797a684fb3aae626d7499)), closes [#19698](https://github.com/bitnami/charts/issues/19698)

## <small>3.0.2 (2023-10-03)</small>

* [bitnami/concourse] Use common capabilities for PSP (#19625) ([0a714c2](https://github.com/bitnami/charts/commit/0a714c2fe347e0adadb930db161d7cec07420ee0)), closes [#19625](https://github.com/bitnami/charts/issues/19625)

## <small>3.0.1 (2023-09-29)</small>

* [bitnami/concourse] Release 3.0.1 (#19651) ([09de562](https://github.com/bitnami/charts/commit/09de562f520717519b71ba9de729e366f7937d95)), closes [#19651](https://github.com/bitnami/charts/issues/19651)

## 3.0.0 (2023-09-29)

* [bitnami/concourse] Update dependencies (#19611) ([a82dcb8](https://github.com/bitnami/charts/commit/a82dcb880823733880fddb3de0d3ca92d5254deb)), closes [#19611](https://github.com/bitnami/charts/issues/19611)

## <small>2.3.8 (2023-09-26)</small>

* [bitnami/concourse] Release 2.3.8 (#19539) ([7186a8c](https://github.com/bitnami/charts/commit/7186a8c26eac2caa38e6dd0f2cd5f32f54db064a)), closes [#19539](https://github.com/bitnami/charts/issues/19539)

## <small>2.3.7 (2023-09-19)</small>

* [bitnami/*] Update readme files (#19277) ([e56aeb2](https://github.com/bitnami/charts/commit/e56aeb2fbfbf5b6e42375db48cc7ae1ef1c3a823)), closes [#19277](https://github.com/bitnami/charts/issues/19277)
* [bitnami/concourse] Release 2.3.7 (#19383) ([ba38d75](https://github.com/bitnami/charts/commit/ba38d75ce1c1cb43cc929c0e1436c36d374b0552)), closes [#19383](https://github.com/bitnami/charts/issues/19383)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>2.3.6 (2023-09-17)</small>

* [bitnami/concourse] Release 2.3.6 (#19315) ([fd6cbb1](https://github.com/bitnami/charts/commit/fd6cbb19f8321fe38c6578b332cb4facd1db958a)), closes [#19315](https://github.com/bitnami/charts/issues/19315)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)

## <small>2.3.5 (2023-09-08)</small>

* [bitnami/concourse] Release 2.3.5 (#19201) ([a743866](https://github.com/bitnami/charts/commit/a7438662366466c17e61c9ff9c57823bdc2e0226)), closes [#19201](https://github.com/bitnami/charts/issues/19201)

## <small>2.3.4 (2023-09-06)</small>

* [bitnami/concourse: Use merge helper]: (#19027) ([a6a132a](https://github.com/bitnami/charts/commit/a6a132a00bd959ad2860e29599303ed4ec74ad94)), closes [#19027](https://github.com/bitnami/charts/issues/19027)

## <small>2.3.3 (2023-08-28)</small>

* [bitnami/concourse] Release 2.3.3 (#18920) ([66a27da](https://github.com/bitnami/charts/commit/66a27daa728f1fd9347ffcfa8426baf6077e9d51)), closes [#18920](https://github.com/bitnami/charts/issues/18920)

## <small>2.3.2 (2023-08-26)</small>

* [bitnami/concourse] Release 2.3.2 (#18877) ([8409921](https://github.com/bitnami/charts/commit/8409921923a933e7283a068518f068858b6b451f)), closes [#18877](https://github.com/bitnami/charts/issues/18877)

## <small>2.3.1 (2023-08-24)</small>

* [bitnami/concourse] Release 2.3.1 (#18844) ([51bfc5c](https://github.com/bitnami/charts/commit/51bfc5c1785ec0045e70cd1111fbf0b2ee31d19d)), closes [#18844](https://github.com/bitnami/charts/issues/18844)

## 2.3.0 (2023-08-23)

* [bitnami/concourse] Support for customizing standard labels (#18460) ([7434f7e](https://github.com/bitnami/charts/commit/7434f7e31ee64a16787e0a81d18d413de1384cd4)), closes [#18460](https://github.com/bitnami/charts/issues/18460)

## <small>2.2.12 (2023-08-19)</small>

* [bitnami/concourse] Release 2.2.12 (#18650) ([5837141](https://github.com/bitnami/charts/commit/583714197d91bec9956fb4a6576362f096f7f315)), closes [#18650](https://github.com/bitnami/charts/issues/18650)

## <small>2.2.11 (2023-08-17)</small>

* [bitnami/concourse] Release 2.2.11 (#18505) ([02354ab](https://github.com/bitnami/charts/commit/02354ab3504bed91d0c703107dd182e9361314ba)), closes [#18505](https://github.com/bitnami/charts/issues/18505)

## <small>2.2.10 (2023-08-11)</small>

* [bitnami/concourse] Release 2.2.10 (#18370) ([d4eff8d](https://github.com/bitnami/charts/commit/d4eff8d78be50bac3b9d21921d1606266fc8e60e)), closes [#18370](https://github.com/bitnami/charts/issues/18370)

## <small>2.2.9 (2023-08-11)</small>

* [bitnami/concourse] Release 2.2.9 (#18368) ([be9445f](https://github.com/bitnami/charts/commit/be9445f6fdc50787cf3a248ea749defca22d9ca2)), closes [#18368](https://github.com/bitnami/charts/issues/18368)

## <small>2.2.8 (2023-08-10)</small>

* [bitnami/concourse] Release 2.2.8 (#18342) ([7322516](https://github.com/bitnami/charts/commit/73225165582bb1869d4aff05e4fc273d8948f1cc)), closes [#18342](https://github.com/bitnami/charts/issues/18342)

## <small>2.2.7 (2023-07-28)</small>

* [bitnami/concourse] Release 2.2.7 (#18006) ([ae07e78](https://github.com/bitnami/charts/commit/ae07e78ea802d085aba5ebe46bb6673733d102f7)), closes [#18006](https://github.com/bitnami/charts/issues/18006)

## <small>2.2.6 (2023-07-26)</small>

* [bitnami/concourse] Release 2.2.6 (#17967) ([1d363b4](https://github.com/bitnami/charts/commit/1d363b44acf0f0d74065065ab83d66354a9a7aba)), closes [#17967](https://github.com/bitnami/charts/issues/17967)

## <small>2.2.5 (2023-07-26)</small>

* [bitnami/concourse] Release 2.2.5 (#17815) ([d53dd8a](https://github.com/bitnami/charts/commit/d53dd8a551423d764689c95bbfb6cdb78ec14172)), closes [#17815](https://github.com/bitnami/charts/issues/17815)

## <small>2.2.4 (2023-07-15)</small>

* [bitnami/concourse] Release 2.2.4 (#17633) ([9f4d1af](https://github.com/bitnami/charts/commit/9f4d1afc546df7b2ed34856ef4417d38c81d0794)), closes [#17633](https://github.com/bitnami/charts/issues/17633)
* Use os-shell in tempate and Jaeger runtime params (#17557) ([91a49eb](https://github.com/bitnami/charts/commit/91a49eb1e3c81c7b7c6c28d1bc5d6d6ae698c1e2)), closes [#17557](https://github.com/bitnami/charts/issues/17557)

## <small>2.2.3 (2023-07-06)</small>

* [bitnami/concourse] Release 2.2.3 (#17500) ([6e275fa](https://github.com/bitnami/charts/commit/6e275fa3aca2e0df33ffc00514c5f5e89c26a36e)), closes [#17500](https://github.com/bitnami/charts/issues/17500)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## <small>2.2.2 (2023-06-21)</small>

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/concourse] Remove namespace field for cluster wide resources #17256 ([009e8ec](https://github.com/bitnami/charts/commit/009e8eccc8ef5d6c53d2a9c28f71080959a24bd7)), closes [#17256](https://github.com/bitnami/charts/issues/17256)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)

## <small>2.2.1 (2023-05-21)</small>

* [bitnami/concourse] Release 2.2.1 (#16846) ([9fc58ce](https://github.com/bitnami/charts/commit/9fc58ceb5659234afb2daec48bdbd84526144c6f)), closes [#16846](https://github.com/bitnami/charts/issues/16846)
* Add wording for enterprise page (#16560) ([8f22774](https://github.com/bitnami/charts/commit/8f2277440b976d52785ba9149762ad8620a73d1f)), closes [#16560](https://github.com/bitnami/charts/issues/16560)

## 2.2.0 (2023-05-09)

* [bitnami/several] Adapt Chart.yaml to set desired OCI annotations (#16546) ([fc9b18f](https://github.com/bitnami/charts/commit/fc9b18f2e98805d4df629acbcde696f44f973344)), closes [#16546](https://github.com/bitnami/charts/issues/16546)

## <small>2.1.2 (2023-05-09)</small>

* [bitnami/concourse] Release 2.1.2 (#16448) ([0bad76f](https://github.com/bitnami/charts/commit/0bad76feb0c3d79b0da5c9045043c433a061ac1c)), closes [#16448](https://github.com/bitnami/charts/issues/16448)

## <small>2.1.1 (2023-04-29)</small>

* [bitnami/concourse] Release 2.1.1 (#16278) ([46e045f](https://github.com/bitnami/charts/commit/46e045fd1ab612d354f90383f66706ee57730562)), closes [#16278](https://github.com/bitnami/charts/issues/16278)

## 2.1.0 (2023-04-20)

* [bitnami/*] Make Helm charts 100% OCI (#15998) ([8841510](https://github.com/bitnami/charts/commit/884151035efcbf2e1b3206e7def85511073fb57d)), closes [#15998](https://github.com/bitnami/charts/issues/15998)

## <small>2.0.7 (2023-04-01)</small>

* [bitnami/concourse] Release 2.0.7 (#15851) ([7b79f04](https://github.com/bitnami/charts/commit/7b79f042a9ef59a6d592f0242f1c88b86628bdd8)), closes [#15851](https://github.com/bitnami/charts/issues/15851)

## <small>2.0.6 (2023-03-18)</small>

* [bitnami/charts] Apply linter to README files (#15357) ([0e29e60](https://github.com/bitnami/charts/commit/0e29e600d3adc8b1b46e506eccb3decfab3b4e63)), closes [#15357](https://github.com/bitnami/charts/issues/15357)
* [bitnami/concourse] Release 2.0.6 (#15574) ([78a8777](https://github.com/bitnami/charts/commit/78a8777807a05ed1ca2fb2b07a9ebbc046667f05)), closes [#15574](https://github.com/bitnami/charts/issues/15574)

## <small>2.0.5 (2023-03-01)</small>

* [bitnami/concourse] Release 2.0.5 (#15197) ([442a900](https://github.com/bitnami/charts/commit/442a900b5b9cad76aa038206e9d41bb122154253)), closes [#15197](https://github.com/bitnami/charts/issues/15197)
* Fixes dead links (#15065) ([9e99fd9](https://github.com/bitnami/charts/commit/9e99fd94d89605c2aa47417ae80eecb86719d904)), closes [#15065](https://github.com/bitnami/charts/issues/15065)

## <small>2.0.4 (2023-02-18)</small>

* [bitnami/*] Fix markdown linter issues (#14874) ([a51e0e8](https://github.com/bitnami/charts/commit/a51e0e8d35495b907f3e70dd2f8e7c3bcbf4166a)), closes [#14874](https://github.com/bitnami/charts/issues/14874)
* [bitnami/*] Fix markdown linter issues 2 (#14890) ([aa96572](https://github.com/bitnami/charts/commit/aa9657237ee8df4a46db0d7fdf8a23230dd6902a)), closes [#14890](https://github.com/bitnami/charts/issues/14890)
* [bitnami/*] Remove unexpected extra spaces (#14873) ([c97c714](https://github.com/bitnami/charts/commit/c97c714887380d47eae7bfeff316bf01595ecd1d)), closes [#14873](https://github.com/bitnami/charts/issues/14873)
* [bitnami/concourse] Release 2.0.4 (#15054) ([08e0f42](https://github.com/bitnami/charts/commit/08e0f4207adbe191e16e26a7cb43cfb609443e54)), closes [#15054](https://github.com/bitnami/charts/issues/15054)

## <small>2.0.3 (2023-02-09)</small>

* [bitnami/concourse] Release 2.0.3 (#14699) ([ec066e6](https://github.com/bitnami/charts/commit/ec066e6d03f355667671b0000177d2b8090d28d8)), closes [#14699](https://github.com/bitnami/charts/issues/14699)

## <small>2.0.2 (2023-01-31)</small>

* [bitnami/*] Add license annotation and remove obsolete engine parameter (#14293) ([da2a794](https://github.com/bitnami/charts/commit/da2a7943bae95b6e9b5b4ed972c15e990b69fdb0)), closes [#14293](https://github.com/bitnami/charts/issues/14293)
* [bitnami/*] Change copyright date (#14682) ([add4ec7](https://github.com/bitnami/charts/commit/add4ec701108ac36ed4de2dffbdf407a0d091067)), closes [#14682](https://github.com/bitnami/charts/issues/14682)
* [bitnami/*] Change licenses annotation format (#14377) ([0ab7608](https://github.com/bitnami/charts/commit/0ab760862c660fcc78cffadf8e1d8cdd70881473)), closes [#14377](https://github.com/bitnami/charts/issues/14377)
* [bitnami/*] Unify READMEs (#14472) ([2064fb8](https://github.com/bitnami/charts/commit/2064fb8dcc78a845cdede8211af8c3cc52551161)), closes [#14472](https://github.com/bitnami/charts/issues/14472)
* [bitnami/concourse] Don't regenerate self-signed certs on upgrade (#14613) ([32cac87](https://github.com/bitnami/charts/commit/32cac8713b75c8a93b8008d6fb334e36632e4b51)), closes [#14613](https://github.com/bitnami/charts/issues/14613)

## <small>2.0.1 (2022-11-12)</small>

* [bitnami/concourse] Release 2.0.1 (#13491) ([53f274f](https://github.com/bitnami/charts/commit/53f274ff5b060a0e782232ca1681fa0c62ba7d9e)), closes [#13491](https://github.com/bitnami/charts/issues/13491)

## 2.0.0 (2022-10-28)

* [bitnami/*] Use new default branch name in links (#12943) ([a529e02](https://github.com/bitnami/charts/commit/a529e02597d49d944eba1eb0f190713293247176)), closes [#12943](https://github.com/bitnami/charts/issues/12943)
* [bitnami/concourse] Update dependencies (#13213) ([6922a1b](https://github.com/bitnami/charts/commit/6922a1b797c9f03ba67592e91584cfabd3f25b67)), closes [#13213](https://github.com/bitnami/charts/issues/13213)

## <small>1.5.3 (2022-10-13)</small>

* [bitnami/concourse] Release 1.5.3 (#12939) ([1f3b8e2](https://github.com/bitnami/charts/commit/1f3b8e251f2269f2a6fb87a6370597b177be7b82)), closes [#12939](https://github.com/bitnami/charts/issues/12939)
* Generic README instructions related to the repo (#12792) ([3cf6b10](https://github.com/bitnami/charts/commit/3cf6b10e10e60df4b3e191d6b99aa99a9f597755)), closes [#12792](https://github.com/bitnami/charts/issues/12792)

## <small>1.5.2 (2022-09-30)</small>

* [bitnami/concourse] Force new version publishing (#12758) ([2d125bc](https://github.com/bitnami/charts/commit/2d125bca771aa5db59e2bd557beac8e81f5fac9e)), closes [#12758](https://github.com/bitnami/charts/issues/12758)

## <small>1.5.1 (2022-09-29)</small>

* [bitnami/concourse] Release 1.5.1 (#12723) ([8768541](https://github.com/bitnami/charts/commit/876854198ad92bcb60b4524c2660e4ba803a2733)), closes [#12723](https://github.com/bitnami/charts/issues/12723)

## 1.5.0 (2022-09-23)

* [bitnami/concourse] Add tests and publishing using VIB (#12578) ([05e85dc](https://github.com/bitnami/charts/commit/05e85dcad0456a49744d41b42f4b004769160b75)), closes [#12578](https://github.com/bitnami/charts/issues/12578)

## <small>1.4.3 (2022-09-21)</small>

* [bitnami/concourse] Use custom probes if given (#12485) ([6fa3731](https://github.com/bitnami/charts/commit/6fa3731cbcf21eb1714246906c579c6d816d3292)), closes [#12485](https://github.com/bitnami/charts/issues/12485) [#12354](https://github.com/bitnami/charts/issues/12354)

## <small>1.4.2 (2022-08-30)</small>

* [bitnami/concourse] Release 1.4.2 updating components versions ([50fe9cc](https://github.com/bitnami/charts/commit/50fe9cc0caeea5bbdecb538a73b98520fdc46258))

## <small>1.4.1 (2022-08-23)</small>

* [bitnami/concourse] Update Chart.lock (#12102) ([c8baa56](https://github.com/bitnami/charts/commit/c8baa561098654ff2aa1348cbf44241213f387ca)), closes [#12102](https://github.com/bitnami/charts/issues/12102)

## 1.4.0 (2022-08-22)

* [bitnami/concourse] Add support for image digest apart from tag (#11870) ([e678e9b](https://github.com/bitnami/charts/commit/e678e9b39c896fbdd5ea5bc5bc4966d7a647f18f)), closes [#11870](https://github.com/bitnami/charts/issues/11870)

## <small>1.3.12 (2022-08-08)</small>

* [bitnami/concourse] Release 1.3.12 updating components versions ([789e1b0](https://github.com/bitnami/charts/commit/789e1b096ee116e8d96bcaa900529031063caed3))

## <small>1.3.11 (2022-08-04)</small>

* [bitnami/concourse] Release 1.3.11 updating components versions ([9da7d2f](https://github.com/bitnami/charts/commit/9da7d2ffe23bdb9760e70487e3ce6c4b07520d27))

## <small>1.3.10 (2022-08-04)</small>

* [bitnami/concourse] Release 1.3.10 updating components versions ([755e0e2](https://github.com/bitnami/charts/commit/755e0e21b1aebd0cca670996f47b64fb382e20ae))

## <small>1.3.9 (2022-08-02)</small>

* [bitnami/*] Update URLs to point to the new bitnami/containers monorepo (#11352) ([d665af0](https://github.com/bitnami/charts/commit/d665af0c708846192d8d5fb2f5f9ea65dd464ab0)), closes [#11352](https://github.com/bitnami/charts/issues/11352)
* [bitnami/concourse] Release 1.3.9 updating components versions ([824d752](https://github.com/bitnami/charts/commit/824d75274927f7c4893792c80580ac95e1fcafde))

## <small>1.3.8 (2022-07-16)</small>

* [bitnami/concourse] Release 1.3.8 updating components versions ([fbdbc9f](https://github.com/bitnami/charts/commit/fbdbc9f12e48f9ed16f5947b9dddd32379797e92))

## <small>1.3.7 (2022-06-30)</small>

* [bitnami/concourse] Release 1.3.7 updating components versions ([ac41a26](https://github.com/bitnami/charts/commit/ac41a26b4fbfbbac3323e297a166c0393a773b52))

## <small>1.3.6 (2022-06-14)</small>

* [bitnami/concourse] Release 1.3.6 updating components versions ([859be7a](https://github.com/bitnami/charts/commit/859be7a85181badcd9fc47b0294a601e70619c80))

## <small>1.3.5 (2022-06-10)</small>

* [bitnami/concourse] Release 1.3.5 updating components versions ([cb8ce35](https://github.com/bitnami/charts/commit/cb8ce35b5a78b582834050e5fefff0b9a74b574d))

## <small>1.3.4 (2022-06-07)</small>

* [bitnami/*] Replace Kubeapps URL in READMEs (and kubeapps Chart.yaml) and remove BKPR references (#1 ([c6a7914](https://github.com/bitnami/charts/commit/c6a7914361e5aea6016fb45bf4d621edfd111d32)), closes [#10600](https://github.com/bitnami/charts/issues/10600)
* Fix tolerations and topologySpreadConstraints default values (#10623) ([5b22c66](https://github.com/bitnami/charts/commit/5b22c6677afa2e3c60eeb4150ff04440dfd1c292)), closes [#10623](https://github.com/bitnami/charts/issues/10623)

## <small>1.3.3 (2022-06-07)</small>

* [bitnami/concourse] Release 1.3.3 updating components versions ([4e7e25d](https://github.com/bitnami/charts/commit/4e7e25d018ea7a3dc93b82d1f431c8b495aa3c78))

## <small>1.3.2 (2022-06-01)</small>

* [bitnami/several] Replace maintainers email by url (#10523) ([ff3cf61](https://github.com/bitnami/charts/commit/ff3cf617a1680509b0f3855d17c4ccff7b29a0ff)), closes [#10523](https://github.com/bitnami/charts/issues/10523)

## <small>1.3.1 (2022-05-30)</small>

* [bitnami/several] Replace base64 --decode with base64 -d (#10495) ([099286a](https://github.com/bitnami/charts/commit/099286ae7a87784cf809df0b64ab24f7ff0144c8)), closes [#10495](https://github.com/bitnami/charts/issues/10495)

## 1.3.0 (2022-05-26)

* [bitnami/concourse] Add missing service parameter (#10404) ([a02c257](https://github.com/bitnami/charts/commit/a02c25739b2f28fa36bdc477df96ee74195eee78)), closes [#10404](https://github.com/bitnami/charts/issues/10404)

## <small>1.2.6 (2022-05-25)</small>

* [bitnami/concourse] Release 1.2.6 updating components versions ([813a1bc](https://github.com/bitnami/charts/commit/813a1bc9dc1cf4de0bbd9469f91fc5c6aeb0f912))

## <small>1.2.5 (2022-05-24)</small>

* [bitnami/concourse] Use the new helper for HPA API version (#10195) ([3933bdf](https://github.com/bitnami/charts/commit/3933bdf52912697278af153e42f6acdc72da0977)), closes [#10195](https://github.com/bitnami/charts/issues/10195)

## <small>1.2.4 (2022-05-21)</small>

* [bitnami/concourse] Release 1.2.4 updating components versions ([39243af](https://github.com/bitnami/charts/commit/39243af460f5fd84b129dc6d62ea902f09daec76))

## <small>1.2.3 (2022-05-20)</small>

* [bitnami/concourse] Release 1.2.3 updating components versions ([0f3ec87](https://github.com/bitnami/charts/commit/0f3ec8799e351ca6762ef8cb186cc1d41eb370e0))

## <small>1.2.2 (2022-05-19)</small>

* [bitnami/concourse] Release 1.2.2 updating components versions ([320481c](https://github.com/bitnami/charts/commit/320481c1e6d4afa3e6d2affafcd109848eaff35b))

## <small>1.2.1 (2022-05-18)</small>

* [bitnami/concourse] Release 1.2.1 updating components versions ([91f4cdf](https://github.com/bitnami/charts/commit/91f4cdf057a6a347a8cf82520d8a963776c06fd7))

## 1.2.0 (2022-05-16)

* [bitnami/*] add ingress extraRules feature (#10253) ([0f6cbb9](https://github.com/bitnami/charts/commit/0f6cbb9099b0e56685cc1d36ba50340f3d7278a1)), closes [#10253](https://github.com/bitnami/charts/issues/10253)

## 1.1.0 (2022-05-13)

* [bitnami/concourse] Add conjur integration to concourse (#10167) ([d21d31d](https://github.com/bitnami/charts/commit/d21d31deba6f5310b9e6e9b08e868b694a065a2f)), closes [#10167](https://github.com/bitnami/charts/issues/10167)

## <small>1.0.20 (2022-05-13)</small>

* [bitnami/*] Fix typo in comments (relay -> rely) (#10151) ([9cfe4a4](https://github.com/bitnami/charts/commit/9cfe4a48cc35851faea6be7ffb2a978d223befa0)), closes [#10151](https://github.com/bitnami/charts/issues/10151)
* [bitnami/*] Remove old 'ci' files (#10171) ([5df30c4](https://github.com/bitnami/charts/commit/5df30c44dbd1812da8786579ce4a94917d46a6ad)), closes [#10171](https://github.com/bitnami/charts/issues/10171)
* [bitnami/*] Unify k8s directives separators (#10185) ([2650214](https://github.com/bitnami/charts/commit/26502141d146ca3bdfb3bf744fcdec8ca5cece44)), closes [#10185](https://github.com/bitnami/charts/issues/10185)

## <small>1.0.19 (2022-05-11)</small>

* [bitnami/concourse] Add missing namespace metadata (#10111) ([17337c6](https://github.com/bitnami/charts/commit/17337c6ad796d2dc5a8b18aa8eae9f703b787d7a)), closes [#10111](https://github.com/bitnami/charts/issues/10111)

## <small>1.0.18 (2022-04-21)</small>

* [bitnami/concourse] Release 1.0.18 updating components versions ([328b360](https://github.com/bitnami/charts/commit/328b360683aa6719940d22aba3607bb419410f76))

## <small>1.0.17 (2022-04-20)</small>

* [bitnami/concourse] Release 1.0.17 updating components versions ([294b4fc](https://github.com/bitnami/charts/commit/294b4fc55ff244251bad1a5646888a92ce866470))

## <small>1.0.16 (2022-04-19)</small>

* [bitnami/concourse] Release 1.0.16 updating components versions ([36dff4c](https://github.com/bitnami/charts/commit/36dff4caad7da62c2cd30ddbfb9ec277773e64b6))

## <small>1.0.15 (2022-04-06)</small>

* [bitnami/concourse] Release 1.0.15 updating components versions ([a996fb1](https://github.com/bitnami/charts/commit/a996fb1490523d77936cc71c98c57068fc267217))

## <small>1.0.14 (2022-04-02)</small>

* [bitnami/concourse] Release 1.0.14 updating components versions ([337e995](https://github.com/bitnami/charts/commit/337e9958f7499b6055d4744ced27325e2696ef84))

## <small>1.0.13 (2022-03-29)</small>

* [bitnami/concourse] Release 1.0.13 updating components versions ([765898c](https://github.com/bitnami/charts/commit/765898cdd1a3f468dde75d6d3e97d20ec5c5222a))

## <small>1.0.12 (2022-03-28)</small>

* [bitnami/concourse] Release 1.0.12 updating components versions ([d758134](https://github.com/bitnami/charts/commit/d758134008477156c12194fc6d2b7864fc250704))

## <small>1.0.11 (2022-03-28)</small>

* [bitnami/concourse] Release 1.0.11 updating components versions ([eda9df5](https://github.com/bitnami/charts/commit/eda9df509e60e8d78f4164c02c2153dd6f9f8b4b))

## <small>1.0.10 (2022-03-27)</small>

* [bitnami/concourse] Release 1.0.10 updating components versions ([00cffac](https://github.com/bitnami/charts/commit/00cffac2f2b51443144da9571274ea73fe89bf8c))

## <small>1.0.9 (2022-03-18)</small>

* [bitnami/concourse] Release 1.0.9 updating components versions ([5145c34](https://github.com/bitnami/charts/commit/5145c3498926062f8fd0639184e373c4ba155f98))

## <small>1.0.8 (2022-03-18)</small>

* [bitnami/concourse] Release 1.0.8 updating components versions ([451f852](https://github.com/bitnami/charts/commit/451f85217e78d76ebf9389fbd683b7821cdd56f4))

## <small>1.0.7 (2022-03-16)</small>

* [bitnami/concourse] Release 1.0.7 updating components versions ([8a8093d](https://github.com/bitnami/charts/commit/8a8093d3796bd6c33dcb7c1b35f1e71efec8776c))

## <small>1.0.6 (2022-03-10)</small>

* [bitnami/concourse] Release 1.0.6 updating components versions ([fcf61bf](https://github.com/bitnami/charts/commit/fcf61bfda4107e33b4a3d6081f9cec07c1a32daa))

## <small>1.0.5 (2022-03-01)</small>

* [bitnami/concourse] Release 1.0.5 updating components versions ([e9126fb](https://github.com/bitnami/charts/commit/e9126fbaa8d5c5f8d3fa75fdecc478af9ab7c338))

## <small>1.0.4 (2022-02-28)</small>

* [bitnami/concourse] Release 1.0.4 updating components versions ([19f7c8e](https://github.com/bitnami/charts/commit/19f7c8eb8b8ed87efcda32c5761d8f6c86b99180))

## <small>1.0.3 (2022-02-21)</small>

* [bitnami/concourse] Add flag '-r' to xargs in volumePermissions init-container (#9129) ([265d124](https://github.com/bitnami/charts/commit/265d124a785eb233a808730b6e190df321f9fe69)), closes [#9129](https://github.com/bitnami/charts/issues/9129)

## <small>1.0.2 (2022-02-15)</small>

* [bitnami/concourse] Release 1.0.2 updating components versions ([41abb9a](https://github.com/bitnami/charts/commit/41abb9a7e89bc3db0df7064348fda7eff0c408a4))

## <small>1.0.1 (2022-02-11)</small>

* [bitnami/concourse] Add support to PostgreSQL globals (#8988) ([39e7c8c](https://github.com/bitnami/charts/commit/39e7c8c4752cc06862ae30ad714d499149e8a1b9)), closes [#8988](https://github.com/bitnami/charts/issues/8988)

## 1.0.0 (2022-02-09)

* [bitnami/concourse] Chart standardization (#8926) ([4539cb3](https://github.com/bitnami/charts/commit/4539cb3ac0395cad93cd3f523cc798c47e9b3c4b)), closes [#8926](https://github.com/bitnami/charts/issues/8926)

## <small>0.2.2 (2022-01-20)</small>

* [bitnami/*] Readme automation (#8579) ([78d1938](https://github.com/bitnami/charts/commit/78d193831c900d178198491ffd08fa2217a64ecd)), closes [#8579](https://github.com/bitnami/charts/issues/8579)
* [bitnami/*] Update READMEs (#8716) ([b9a9533](https://github.com/bitnami/charts/commit/b9a953337590eb2979453385874a267bacf50936)), closes [#8716](https://github.com/bitnami/charts/issues/8716)
* [bitnami/several] Change prerequisites (#8725) ([8d740c5](https://github.com/bitnami/charts/commit/8d740c566cfdb7e2d933c40128b4e919fce953a5)), closes [#8725](https://github.com/bitnami/charts/issues/8725)

## <small>0.2.1 (2022-01-11)</small>

* [bitnami/concourse] Release 0.2.1 updating components versions ([0659238](https://github.com/bitnami/charts/commit/065923842f8653ff981d6ac4892bceb6575bd3d8))

## 0.2.0 (2022-01-05)

* [bitnami/several] Adapt templating format (#8562) ([8cad18a](https://github.com/bitnami/charts/commit/8cad18aed9966a6f0208e5ad6cee46cb217f47ab)), closes [#8562](https://github.com/bitnami/charts/issues/8562)

## <small>0.1.18 (2022-01-04)</small>

* [bitnami/several] Add license to the README ([05f7633](https://github.com/bitnami/charts/commit/05f763372501d596e57db713dd53ff4ff3027cc4))
* [bitnami/several] Add license to the README ([32fb238](https://github.com/bitnami/charts/commit/32fb238e60a0affc6debd3142eaa3c3d9089ec2a))
* [bitnami/several] Add license to the README ([b87c2f7](https://github.com/bitnami/charts/commit/b87c2f7899d48a8b02c506765e6ae82937e9ba3f))
* [bitnami/several] Fix issue with quote when followed by }} (#8561) ([58077af](https://github.com/bitnami/charts/commit/58077af58f40e74e7af41485bcca493e38523537)), closes [#8561](https://github.com/bitnami/charts/issues/8561)

## <small>0.1.17 (2021-12-17)</small>

* [bitnami/concourse] Release 0.1.17 updating components versions ([e2bfe5a](https://github.com/bitnami/charts/commit/e2bfe5a78299862c73a503b46831acdb80ce1d06))

## <small>0.1.16 (2021-12-16)</small>

* [bitnami/concourse] Release 0.1.16 updating components versions ([96ad836](https://github.com/bitnami/charts/commit/96ad836e1e37fad8f73936a9fd25431d26c5a20c))
* [bitnami/several] Regenerate README tables ([8150149](https://github.com/bitnami/charts/commit/8150149f0bb746e86ff0029fc375d43775bdf15a))

## <small>0.1.15 (2021-11-29)</small>

* [bitnami/several] Replace HTTP by HTTPS when possible (#8259) ([eafb5bd](https://github.com/bitnami/charts/commit/eafb5bd5a2cc3aaf04fc1e8ebedd73f420d76864)), closes [#8259](https://github.com/bitnami/charts/issues/8259)

## <small>0.1.14 (2021-11-28)</small>

* [bitnami/concourse] Release 0.1.14 updating components versions ([f5dd520](https://github.com/bitnami/charts/commit/f5dd520d105be51bc5f10d006520df6ce3fcdd42))
* [bitnami/concourse] Updated README (#7964) ([ffaaa3c](https://github.com/bitnami/charts/commit/ffaaa3c4514420e9a007d0652e7f82b3ab57bda1)), closes [#7964](https://github.com/bitnami/charts/issues/7964)
* [bitnami/several] Regenerate README tables ([3cefed3](https://github.com/bitnami/charts/commit/3cefed3ef961fbd7596242b1165bcfa229a9cadb))

## <small>0.1.13 (2021-10-29)</small>

* [bitnami/concourse] Release 0.1.13 updating components versions ([f12eae9](https://github.com/bitnami/charts/commit/f12eae99be6c0bc0716ae88d8a562a3c0d040ed6))

## <small>0.1.12 (2021-10-27)</small>

* [bitnami/*] Mark PodSecurityPolicy resources as deprecated (#7948) ([5cac753](https://github.com/bitnami/charts/commit/5cac7539dcb6c3baef06ed6676bfa99c16fdb5fe)), closes [#7948](https://github.com/bitnami/charts/issues/7948)
* [bitnami/several] Regenerate README tables ([412cf6a](https://github.com/bitnami/charts/commit/412cf6a513cb0c03444a6e7811c6f27193239a10))

## <small>0.1.11 (2021-10-26)</small>

* [bitnami/concourse] Release 0.1.11 updating components versions ([c94bbbb](https://github.com/bitnami/charts/commit/c94bbbb6c46582a48d2e72c5ce40b91256a9c16e))

## <small>0.1.10 (2021-10-22)</small>

* [bitnami/several] Add chart info to NOTES.txt (#7889) ([a6751cd](https://github.com/bitnami/charts/commit/a6751cdd33c461fabbc459fbea6f219ec64ab6b2)), closes [#7889](https://github.com/bitnami/charts/issues/7889)

## <small>0.1.9 (2021-10-19)</small>

* [bitnami/several] Change pullPolicy for bitnami-shell image (#7852) ([9711a33](https://github.com/bitnami/charts/commit/9711a33c6eec72ea79143c4b7574dbe6a148d6b2)), closes [#7852](https://github.com/bitnami/charts/issues/7852)
* [bitnami/several] Regenerate README tables ([0a26eaa](https://github.com/bitnami/charts/commit/0a26eaafd6ad234046aa91c79a44a1d45f55724e))

## <small>0.1.8 (2021-10-17)</small>

* [bitnami/concourse] Release 0.1.8 updating components versions ([e2f9916](https://github.com/bitnami/charts/commit/e2f99160ddaacb74c3ec6baa889832d71e13bc6f))

## <small>0.1.7 (2021-10-01)</small>

* [bitnami/*] Drop support for deprecated cert-manager annotation (#7582) ([a081792](https://github.com/bitnami/charts/commit/a08179293543f063e5de966a9976ca967161de7b)), closes [#7582](https://github.com/bitnami/charts/issues/7582)
* [bitnami/several] Regenerate README tables ([003a0fb](https://github.com/bitnami/charts/commit/003a0fbaedeb775c546b8d8452b7a5ab0a63af52))

## <small>0.1.6 (2021-09-17)</small>

* [bitnami/concourse] Release 0.1.6 updating components versions ([d09ed9f](https://github.com/bitnami/charts/commit/d09ed9fa48550343ccfb146ac3cc9878e3b8e1c0))
* [bitnami/several] Regenerate README tables ([a94b593](https://github.com/bitnami/charts/commit/a94b5937a8665743457afc158202ebc33405c8e1))

## <small>0.1.5 (2021-09-10)</small>

* [bitnami/concourse] Release 0.1.5 updating components versions ([b4c77d4](https://github.com/bitnami/charts/commit/b4c77d48967ae423d2ddca002078e840f341bb19))
* [bitnami/several] Regenerate README tables ([da2513b](https://github.com/bitnami/charts/commit/da2513bf0a33819f3b1151d387c631a9ffdb03e2))

## <small>0.1.4 (2021-08-25)</small>

* [bitnami/concourse] Release 0.1.4 updating components versions ([a5602a0](https://github.com/bitnami/charts/commit/a5602a0ca3c9f6d6088553e6c456d4701d21f1b4))
* [bitnami/several] Fix default values when using `foo: |` (#7092) ([fe91297](https://github.com/bitnami/charts/commit/fe91297fdf3f6c74aee31c423912e4ac19b55c94)), closes [#7092](https://github.com/bitnami/charts/issues/7092)
* [bitnami/several] Update READMEs (#7108) ([44961d9](https://github.com/bitnami/charts/commit/44961d9cdfae1b0d06808124c4b47e8adc3de146)), closes [#7108](https://github.com/bitnami/charts/issues/7108)

## <small>0.1.3 (2021-07-29)</small>

* [bitnami/concourse] Release 0.1.3 updating components versions ([47b60e2](https://github.com/bitnami/charts/commit/47b60e228bf43dc107a0f689ab3d543eabff86a6))

## <small>0.1.2 (2021-07-29)</small>

* [bitnami/concourse] Fix nil value (#7093) ([f394e1a](https://github.com/bitnami/charts/commit/f394e1a5e24e720505141fcc47d9e9ccf5c38319)), closes [#7093](https://github.com/bitnami/charts/issues/7093)

## <small>0.1.1 (2021-07-22)</small>

* [bitnami/several] Fix default values and regenerate README (#7023) ([c443ded](https://github.com/bitnami/charts/commit/c443ded691a1184a72af7b812759fad54b240ae9)), closes [#7023](https://github.com/bitnami/charts/issues/7023)

## 0.1.0 (2021-07-17)

* [bitnami/concourse] Add new Concourse Helm chart (#6799) ([4a31699](https://github.com/bitnami/charts/commit/4a31699234add1268ed2438966a5dc87e1def739)), closes [#6799](https://github.com/bitnami/charts/issues/6799)
