# Changelog

## 2.0.7 (2025-08-07)

* [bitnami/flink] :zap: :arrow_up: Update dependency references ([#35554](https://github.com/bitnami/charts/pull/35554))

## <small>2.0.6 (2025-07-29)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/flink] :zap: :arrow_up: Update dependency references (#35326) ([1769a5d](https://github.com/bitnami/charts/commit/1769a5d837051a27c1852ab03b52800f26c26550)), closes [#35326](https://github.com/bitnami/charts/issues/35326)

## <small>2.0.5 (2025-07-07)</small>

* [bitnami/flink] :zap: :arrow_up: Update dependency references (#34830) ([d9e4505](https://github.com/bitnami/charts/commit/d9e4505f106f3aa83fa61ac70560be36757428f8)), closes [#34830](https://github.com/bitnami/charts/issues/34830)

## <small>2.0.4 (2025-06-07)</small>

* [bitnami/flink] :zap: :arrow_up: Update dependency references (#34246) ([8cfde38](https://github.com/bitnami/charts/commit/8cfde3859edbd220bc30ec07168b344ca210057b)), closes [#34246](https://github.com/bitnami/charts/issues/34246)
* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)

## <small>2.0.3 (2025-05-08)</small>

* [bitnami/flink] :zap: :arrow_up: Update dependency references (#33562) ([06629ce](https://github.com/bitnami/charts/commit/06629ced21f3fdd860a8a2bb48823027925d5f19)), closes [#33562](https://github.com/bitnami/charts/issues/33562)

## <small>2.0.2 (2025-05-06)</small>

* [bitnami/flink] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#33360) ([3522956](https://github.com/bitnami/charts/commit/3522956e60ae89f100e093f8fbe22e81503cf3df)), closes [#33360](https://github.com/bitnami/charts/issues/33360)

## <small>2.0.1 (2025-04-24)</small>

* [bitnami/flink] Release 2.0.1 (#33172) ([8e878d7](https://github.com/bitnami/charts/commit/8e878d711fe5a2b616a2e7cc7cfdf86e3ee0e04b)), closes [#33172](https://github.com/bitnami/charts/issues/33172)

## 2.0.0 (2025-03-28)

* [bitnami/flink] Release 2.0.0 (#32603) ([086de00](https://github.com/bitnami/charts/commit/086de005636344e119bd3ad636dc12f2333f38ef)), closes [#32603](https://github.com/bitnami/charts/issues/32603)

## <small>1.4.5 (2025-03-21)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/flink] Release 1.4.5 (#32547) ([ff4abfc](https://github.com/bitnami/charts/commit/ff4abfc3109f98fe88a26b2e451a7e8dd087a4cc)), closes [#32547](https://github.com/bitnami/charts/issues/32547)

## <small>1.4.4 (2025-02-21)</small>

* [bitnami/flink] Release 1.4.4 (#31995) ([1312886](https://github.com/bitnami/charts/commit/1312886050b597105af3f2ae07fac701213dbcab)), closes [#31995](https://github.com/bitnami/charts/issues/31995)

## <small>1.4.3 (2025-02-12)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/flink] Release 1.4.3 (#31905) ([cc6d993](https://github.com/bitnami/charts/commit/cc6d99384d62416d9b7265539d99f047833d6966)), closes [#31905](https://github.com/bitnami/charts/issues/31905)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## <small>1.4.2 (2025-01-28)</small>

* [bitnami/flink] Release 1.4.2 (#31636) ([420ed14](https://github.com/bitnami/charts/commit/420ed144c8967af027f6c11a8e64800f394005ad)), closes [#31636](https://github.com/bitnami/charts/issues/31636)

## <small>1.4.1 (2024-12-26)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/flink] Release 1.4.1 (#31170) ([f07b771](https://github.com/bitnami/charts/commit/f07b771b405429185de6fdb6d631e87040cf6425)), closes [#31170](https://github.com/bitnami/charts/issues/31170)

## 1.4.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/flink] Detect non-standard images (#30893) ([9bbfbf7](https://github.com/bitnami/charts/commit/9bbfbf7e1b99916edcb4a4fbe2feae45c46742d1)), closes [#30893](https://github.com/bitnami/charts/issues/30893)

## <small>1.3.16 (2024-11-16)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/flink] Release 1.3.16 (#30486) ([1794591](https://github.com/bitnami/charts/commit/1794591109bfa996ede6717411d1737b277b63dc)), closes [#30486](https://github.com/bitnami/charts/issues/30486)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## <small>1.3.15 (2024-10-07)</small>

* [bitnami/flink] Release 1.3.15 (#29803) ([6926d7e](https://github.com/bitnami/charts/commit/6926d7e3cb8376a8c0a71643cb9b249922ef0901)), closes [#29803](https://github.com/bitnami/charts/issues/29803)

## <small>1.3.14 (2024-09-02)</small>

* [bitnami/flink] Release 1.3.14 (#29155) ([33446f2](https://github.com/bitnami/charts/commit/33446f233c518c6df94cdf1ed63164c1a3dba2ff)), closes [#29155](https://github.com/bitnami/charts/issues/29155)

## <small>1.3.13 (2024-09-02)</small>

* [bitnami/flink] Release 1.3.13 (#29152) ([2424812](https://github.com/bitnami/charts/commit/242481260cb5f7467a46ee2f4ed44b65446ed76b)), closes [#29152](https://github.com/bitnami/charts/issues/29152)

## <small>1.3.12 (2024-08-01)</small>

* [bitnami/flink] Release 1.3.12 (#28625) ([18810c2](https://github.com/bitnami/charts/commit/18810c2e600761d58950c97e509191b7630a19bc)), closes [#28625](https://github.com/bitnami/charts/issues/28625)

## <small>1.3.11 (2024-07-25)</small>

* [bitnami/flink] Release 1.3.11 (#28435) ([77ddf10](https://github.com/bitnami/charts/commit/77ddf10ac9a4c6b5ba9c20284158d257858557f6)), closes [#28435](https://github.com/bitnami/charts/issues/28435)

## <small>1.3.10 (2024-07-24)</small>

* [bitnami/flink] Release 1.3.10 (#28302) ([725a84c](https://github.com/bitnami/charts/commit/725a84c9e47c4531f337b41289aaba75f076794a)), closes [#28302](https://github.com/bitnami/charts/issues/28302)

## <small>1.3.9 (2024-07-23)</small>

* [bitnami/flink] Release 1.3.9 (#28242) ([49846ce](https://github.com/bitnami/charts/commit/49846ce3fb792db7a24ac5126481f67ec5d795ad)), closes [#28242](https://github.com/bitnami/charts/issues/28242)

## <small>1.3.8 (2024-07-16)</small>

* [bitnami/flink] Global StorageClass as default value (#28018) ([39fa01e](https://github.com/bitnami/charts/commit/39fa01e344c574edcea71c3f0d9f38f571fc7fdb)), closes [#28018](https://github.com/bitnami/charts/issues/28018)

## <small>1.3.7 (2024-07-03)</small>

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/flink] Release 1.3.7 (#27683) ([48d2c43](https://github.com/bitnami/charts/commit/48d2c436a7367ac68abac6fd09114b49541371b3)), closes [#27683](https://github.com/bitnami/charts/issues/27683)

## <small>1.3.6 (2024-06-18)</small>

* [bitnami/flink] Release 1.3.6 (#27343) ([b6743d3](https://github.com/bitnami/charts/commit/b6743d3b1e17cdeb12e3a4f6ee25ef8c564318fa)), closes [#27343](https://github.com/bitnami/charts/issues/27343)

## <small>1.3.5 (2024-06-17)</small>

* [bitnami/flink] Release 1.3.5 (#27217) ([72a8672](https://github.com/bitnami/charts/commit/72a867263269a9cec5d61411b1c294d3a75a1c10)), closes [#27217](https://github.com/bitnami/charts/issues/27217)

## <small>1.3.4 (2024-06-14)</small>

* [bitnami/flink] Release 1.3.4 (#27182) ([19a8dae](https://github.com/bitnami/charts/commit/19a8daeacb51e6d60051d55e81ab20afc19b11e3)), closes [#27182](https://github.com/bitnami/charts/issues/27182)

## <small>1.3.3 (2024-06-06)</small>

* [bitnami/flink] Release 1.3.3 (#26950) ([af5fc61](https://github.com/bitnami/charts/commit/af5fc61847eac8aef7c9a59ea99de77614daf3b9)), closes [#26950](https://github.com/bitnami/charts/issues/26950)

## <small>1.3.2 (2024-06-06)</small>

* [bitnami/flink] Release 1.3.2 (#26898) ([63273f2](https://github.com/bitnami/charts/commit/63273f25a3329be9f570ba31327dc7d6f3bc29b6)), closes [#26898](https://github.com/bitnami/charts/issues/26898)

## <small>1.3.1 (2024-06-04)</small>

* [bitnami/flink] Bump chart version (#26630) ([ae25bb7](https://github.com/bitnami/charts/commit/ae25bb7fad5896ff76afbf00f94c89a1fdcbefed)), closes [#26630](https://github.com/bitnami/charts/issues/26630)

## 1.3.0 (2024-06-03)

* [bitnami/flink] Enable PodDisruptionBudgets (#26429) ([a0514ba](https://github.com/bitnami/charts/commit/a0514ba575c8fbe7cd0f730deb976c1788464e40)), closes [#26429](https://github.com/bitnami/charts/issues/26429)

## <small>1.2.1 (2024-05-23)</small>

* [bitnami/flink] Use different liveness/readiness probes (#26316) ([bb44040](https://github.com/bitnami/charts/commit/bb44040e2fb9a1da7317bf4af97e2bb6c5e0162e)), closes [#26316](https://github.com/bitnami/charts/issues/26316)

## 1.2.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/flink] feat: :sparkles: :lock: Add warning when original images are replaced (#26203) ([85acf85](https://github.com/bitnami/charts/commit/85acf8586edbd2ddbad591a8d550fd3066662b01)), closes [#26203](https://github.com/bitnami/charts/issues/26203)

## <small>1.1.3 (2024-05-18)</small>

* [bitnami/flink] Release 1.1.3 updating components versions (#26013) ([e9d6acf](https://github.com/bitnami/charts/commit/e9d6acfe436493e13afeb4657a02e0d2e57ac22c)), closes [#26013](https://github.com/bitnami/charts/issues/26013)

## <small>1.1.2 (2024-05-13)</small>

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/flink] Release 1.1.2 updating components versions (#25753) ([360dda8](https://github.com/bitnami/charts/commit/360dda87888a47755f352a45437c1b59d817b35c)), closes [#25753](https://github.com/bitnami/charts/issues/25753)

## <small>1.1.1 (2024-04-29)</small>

* [bitnami/flink] Release 1.1.1 updating components versions (#25448) ([ec7d04e](https://github.com/bitnami/charts/commit/ec7d04e1398076e0ec2dedd2d8a695d8e8a728f6)), closes [#25448](https://github.com/bitnami/charts/issues/25448)

## 1.1.0 (2024-04-25)

* [bitnami/flink] Improve service ports & network policies (#25350) ([4237bb6](https://github.com/bitnami/charts/commit/4237bb61d9c249880d759934caff6e845a175345)), closes [#25350](https://github.com/bitnami/charts/issues/25350)
* [bitnami/multiple charts] Fix typo: "NetworkPolice" vs "NetworkPolicy" (#25348) ([6970c1b](https://github.com/bitnami/charts/commit/6970c1ba245873506e73d459c6eac1e4919b778f)), closes [#25348](https://github.com/bitnami/charts/issues/25348)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## <small>1.0.2 (2024-04-22)</small>

* [bitnami/flink] Ensure data port is set in configuration (#25169) ([fa9eda1](https://github.com/bitnami/charts/commit/fa9eda14602a666824f6204cf5a398a21a04953d)), closes [#25169](https://github.com/bitnami/charts/issues/25169)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## <small>1.0.1 (2024-03-20)</small>

* [bitnami/flink] Release 1.0.1 updating components versions (#24571) ([3a09c26](https://github.com/bitnami/charts/commit/3a09c26856a8b1771eb59de496e3ff35d94466b7)), closes [#24571](https://github.com/bitnami/charts/issues/24571)

## 1.0.0 (2024-03-18)

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* [bitnami/flink] feat!: :lock: :boom: Improve security defaults (#24326) ([d7cf5f7](https://github.com/bitnami/charts/commit/d7cf5f7b18d961b0e5fd2197011f8dbdffd11194)), closes [#24326](https://github.com/bitnami/charts/issues/24326)

## 0.13.0 (2024-03-08)

* [bitnami/flink] feat: :sparkles: :lock: Add support for readOnlyRootFilesystem (#24198) ([74ab25e](https://github.com/bitnami/charts/commit/74ab25e80b579ca9dff116ea0f7281b2c6fd72df)), closes [#24198](https://github.com/bitnami/charts/issues/24198)

## 0.12.0 (2024-03-06)

* [bitnami/flink] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v2 SCC (#2 ([dce33d9](https://github.com/bitnami/charts/commit/dce33d9c59d19574be0d4f84f55ce6ca966c9e32)), closes [#24081](https://github.com/bitnami/charts/issues/24081)

## 0.11.0 (2024-03-05)

* [bitnami/flink] Taskmanager to use a statefulset (#23904) ([50e8c6d](https://github.com/bitnami/charts/commit/50e8c6dacf8ddf43db1919427a17f7ba074c6aaa)), closes [#23904](https://github.com/bitnami/charts/issues/23904)

## <small>0.10.2 (2024-02-21)</small>

* [bitnami/flink] Release 0.10.2 updating components versions (#23768) ([045b1d8](https://github.com/bitnami/charts/commit/045b1d8385697feaa24d4020481b8dd1b2ad3ef8)), closes [#23768](https://github.com/bitnami/charts/issues/23768)

## <small>0.10.1 (2024-02-21)</small>

* [bitnami/flink] Release 0.10.1 updating components versions (#23704) ([838cf89](https://github.com/bitnami/charts/commit/838cf89e4956b8f661c9bb7791fdbcd8484be121)), closes [#23704](https://github.com/bitnami/charts/issues/23704)

## 0.10.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## 0.9.0 (2024-02-16)

* [bitnami/flink] feat: :sparkles: :lock: Add resource preset support (#23448) ([23fbdaf](https://github.com/bitnami/charts/commit/23fbdaf9dd6641de91aa198ec707828cc2428df2)), closes [#23448](https://github.com/bitnami/charts/issues/23448)

## 0.8.0 (2024-02-07)

* [bitnami/flink] feat: :lock: Enable networkPolicy (#23284) ([9c4b59f](https://github.com/bitnami/charts/commit/9c4b59f02a2a07b44f2a18372a26913a2dd9b16b)), closes [#23284](https://github.com/bitnami/charts/issues/23284)

## <small>0.7.4 (2024-02-05)</small>

* [bitnami/flink] Release 0.7.4 (#22927) ([d3cfa5b](https://github.com/bitnami/charts/commit/d3cfa5bc89d09347c8c7faab3da055a96b885b6e)), closes [#22927](https://github.com/bitnami/charts/issues/22927)

## <small>0.7.3 (2024-01-30)</small>

* [bitnami/flink] Release 0.7.3 updating components versions (#22841) ([0eff7ba](https://github.com/bitnami/charts/commit/0eff7ba1969ffe5d475a11ae64337189074c70bc)), closes [#22841](https://github.com/bitnami/charts/issues/22841)

## <small>0.7.2 (2024-01-27)</small>

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/flink] Release 0.7.2 updating components versions (#22775) ([c98f119](https://github.com/bitnami/charts/commit/c98f1195195689c75abf7b9176a55d55500af958)), closes [#22775](https://github.com/bitnami/charts/issues/22775)

## <small>0.7.1 (2024-01-24)</small>

* [bitnami/flink] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22586) ([ac47595](https://github.com/bitnami/charts/commit/ac47595c78051430ea37ff7206620a3803ac6b0e)), closes [#22586](https://github.com/bitnami/charts/issues/22586)

## 0.7.0 (2024-01-22)

* [bitnami/flink] fix: :lock: Move service-account token auto-mount to pod declaration (#22483) ([af53d3c](https://github.com/bitnami/charts/commit/af53d3c48cd13d58f6e3d14de82ab19bba4d1adb)), closes [#22483](https://github.com/bitnami/charts/issues/22483)

## <small>0.6.1 (2024-01-18)</small>

* [bitnami/flink] Release 0.6.1 updating components versions (#22347) ([291134b](https://github.com/bitnami/charts/commit/291134b3868ab1694a7f2b093ea71d5174e51ef5)), closes [#22347](https://github.com/bitnami/charts/issues/22347)

## 0.6.0 (2024-01-16)

* [bitnami/flink] fix: :lock: Improve podSecurityContext and containerSecurityContext with essential s ([39f0e8a](https://github.com/bitnami/charts/commit/39f0e8a10eadd21ab2c05fceea4a0e4045569ea3)), closes [#22117](https://github.com/bitnami/charts/issues/22117)

## <small>0.5.4 (2024-01-15)</small>

* [bitnami/*] Fix docs.bitnami.com broken links (#21901) ([f35506d](https://github.com/bitnami/charts/commit/f35506d2dadee4f097986e7792df1f53ab215b5d)), closes [#21901](https://github.com/bitnami/charts/issues/21901)
* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)
* [bitnami/flink] fix: :lock: Do not automount the service account token unless necessary (#22039) ([8577e38](https://github.com/bitnami/charts/commit/8577e389e4f01dc3a537f299ddda660886af13a2)), closes [#22039](https://github.com/bitnami/charts/issues/22039)

## <small>0.5.3 (2023-12-31)</small>

* [bitnami/flink] Release 0.5.3 updating components versions (#21802) ([ac4be37](https://github.com/bitnami/charts/commit/ac4be3731363fe52a098ac5bdd7a79e7be819dc7)), closes [#21802](https://github.com/bitnami/charts/issues/21802)

## <small>0.5.2 (2023-11-21)</small>

* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/flink] Release 0.5.2 updating components versions (#21114) ([1c57b8e](https://github.com/bitnami/charts/commit/1c57b8e88d3b0ef36a11c3349ba68e6f3bceefa7)), closes [#21114](https://github.com/bitnami/charts/issues/21114)

## <small>0.5.1 (2023-11-20)</small>

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/flink] Release 0.5.1 (#21011) ([268b61c](https://github.com/bitnami/charts/commit/268b61c41a16bf22e17c935bdf043ebb678daefb)), closes [#21011](https://github.com/bitnami/charts/issues/21011)

## 0.5.0 (2023-10-31)

* [bitnami/flink] feat: :sparkles: Add support for PSA restricted policy (#20427) ([dd6a83c](https://github.com/bitnami/charts/commit/dd6a83c37cf63aaf9c81f0df0b480c1e619768dd)), closes [#20427](https://github.com/bitnami/charts/issues/20427)

## <small>0.4.6 (2023-10-24)</small>

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [bitnami/flink] Release 0.4.6 updating components versions (#20392) ([8e79ebd](https://github.com/bitnami/charts/commit/8e79ebd7e1b61ad55f677bbfdd38448f5c562cf2)), closes [#20392](https://github.com/bitnami/charts/issues/20392)

## <small>0.4.5 (2023-10-12)</small>

* [bitnami/flink] Release 0.4.5 updating components versions (#20129) ([a29934a](https://github.com/bitnami/charts/commit/a29934a6779b24860e1c2acc27271de5b1c28a96)), closes [#20129](https://github.com/bitnami/charts/issues/20129)

## <small>0.4.4 (2023-10-12)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/flink] Release 0.4.4 (#20115) ([5a652d7](https://github.com/bitnami/charts/commit/5a652d73ae198a0a0459e11845a369a99781ffd1)), closes [#20115](https://github.com/bitnami/charts/issues/20115)

## <small>0.4.3 (2023-10-02)</small>

* [bitnami/flink] Fix pullSecrets and extraVolumeMounts (#19675) ([575e1b9](https://github.com/bitnami/charts/commit/575e1b9322a85613fe57c6370426e8bdf8c8c268)), closes [#19675](https://github.com/bitnami/charts/issues/19675)

## <small>0.4.2 (2023-09-18)</small>

* [bitnami/flink] Release 0.4.2 (#19357) ([d0cb50e](https://github.com/bitnami/charts/commit/d0cb50e308d24f6661e6a6b9b868678bde5fa6ce)), closes [#19357](https://github.com/bitnami/charts/issues/19357)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>0.4.1 (2023-09-06)</small>

* [bitnami/flink: Use merge helper]: (#19037) ([a8c93e5](https://github.com/bitnami/charts/commit/a8c93e588d93aa7161fa5474126a13b26692da56)), closes [#19037](https://github.com/bitnami/charts/issues/19037)

## 0.4.0 (2023-08-22)

* [bitnami/flink] Support for customizing standard labels (#18299) ([ad24bd1](https://github.com/bitnami/charts/commit/ad24bd128b25cc3c153def7e7db61c489447451f)), closes [#18299](https://github.com/bitnami/charts/issues/18299)

## <small>0.3.8 (2023-08-19)</small>

* [bitnami/flink] Release 0.3.8 (#18658) ([034aefd](https://github.com/bitnami/charts/commit/034aefd426e2017bd45b5a1a150cfe22013ac967)), closes [#18658](https://github.com/bitnami/charts/issues/18658)

## <small>0.3.7 (2023-08-17)</small>

* [bitnami/flink] Release 0.3.7 (#18515) ([9785d4a](https://github.com/bitnami/charts/commit/9785d4ad4ecdd97f1af06e1170533b1d616e8149)), closes [#18515](https://github.com/bitnami/charts/issues/18515)

## <small>0.3.6 (2023-07-26)</small>

* [bitnami/flink] Release 0.3.6 (#17983) ([eb2886c](https://github.com/bitnami/charts/commit/eb2886c65857aac9e18b356f59e00d92a918e98a)), closes [#17983](https://github.com/bitnami/charts/issues/17983)

## <small>0.3.5 (2023-07-19)</small>

* [bitnami/flink] Release 0.3.5 (#17777) ([4f2dffb](https://github.com/bitnami/charts/commit/4f2dffbe1e5bbe5a60c9b7ecf5358c1c7a796354)), closes [#17777](https://github.com/bitnami/charts/issues/17777)

## <small>0.3.4 (2023-07-13)</small>

* [bitnami/flink] Release 0 (#17595) ([3edfc0b](https://github.com/bitnami/charts/commit/3edfc0b007e2ba3abd952f5f4a1c8038e8d23870)), closes [#17595](https://github.com/bitnami/charts/issues/17595)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)

## <small>0.3.3 (2023-06-25)</small>

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/flink] Release 0.3.3 (#17342) ([97cc438](https://github.com/bitnami/charts/commit/97cc438d91fd0ae8c059c28a50d5399c2c89d649)), closes [#17342](https://github.com/bitnami/charts/issues/17342)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## <small>0.3.2 (2023-05-26)</small>

* [bitnami/flink] Release 0.3.2 updating components versions (#16926) ([4dc7a1c](https://github.com/bitnami/charts/commit/4dc7a1c70798070e6b1ba10a8cec6f28178dc62c)), closes [#16926](https://github.com/bitnami/charts/issues/16926)

## <small>0.3.1 (2023-05-26)</small>

* [bitnami/flink] Release 0.3.1 updating components versions (#16924) ([dee7f0a](https://github.com/bitnami/charts/commit/dee7f0a1d064f3fedcc9f78e3757de400c61dfde)), closes [#16924](https://github.com/bitnami/charts/issues/16924)
* Add wording for enterprise page (#16560) ([8f22774](https://github.com/bitnami/charts/commit/8f2277440b976d52785ba9149762ad8620a73d1f)), closes [#16560](https://github.com/bitnami/charts/issues/16560)

## 0.3.0 (2023-05-09)

* [bitnami/several] Adapt Chart.yaml to set desired OCI annotations (#16546) ([fc9b18f](https://github.com/bitnami/charts/commit/fc9b18f2e98805d4df629acbcde696f44f973344)), closes [#16546](https://github.com/bitnami/charts/issues/16546)

## <small>0.2.1 (2023-05-09)</small>

* [bitnami/flink] Release 0.2.1 (#16506) ([7c6b674](https://github.com/bitnami/charts/commit/7c6b6741cad164cb9a7b619b51d9143680210a97)), closes [#16506](https://github.com/bitnami/charts/issues/16506)

## 0.2.0 (2023-04-20)

* [bitnami/*] Make Helm charts 100% OCI (#15998) ([8841510](https://github.com/bitnami/charts/commit/884151035efcbf2e1b3206e7def85511073fb57d)), closes [#15998](https://github.com/bitnami/charts/issues/15998)

## <small>0.1.2 (2023-04-12)</small>

* [bitnami/flink] Release 0.1.2 updating components versions ([231c884](https://github.com/bitnami/charts/commit/231c884a54cb71678956f2d8b9a68c9872bd3c26))

## <small>0.1.1 (2023-04-05)</small>

* [bitnami/flink] Release 0.1.1 updating components versions ([ff1bd0f](https://github.com/bitnami/charts/commit/ff1bd0fd1ef405418a1ed5711512072c099d6bcd))

## 0.1.0 (2023-04-05)

* [bitnami/flink] Add Apache Flink chart (#14879) ([f05c7a6](https://github.com/bitnami/charts/commit/f05c7a6045576b506cf57533cfde8b386c7a97ad)), closes [#14879](https://github.com/bitnami/charts/issues/14879) [#15510](https://github.com/bitnami/charts/issues/15510)
