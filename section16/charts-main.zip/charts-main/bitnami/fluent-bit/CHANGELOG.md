# Changelog

## 3.1.13 (2025-08-15)

* [bitnami/fluent-bit] :zap: :arrow_up: Update dependency references ([#36031](https://github.com/bitnami/charts/pull/36031))

## <small>3.1.12 (2025-08-14)</small>

* [bitnami/fluent-bit] fix: add extraContainerPorts value(s) to container configuration for fluent-bit ([c445c14](https://github.com/bitnami/charts/commit/c445c14826478cd9bb27b4569e3da3ffe608ca9f)), closes [#35806](https://github.com/bitnami/charts/issues/35806)

## <small>3.1.11 (2025-08-07)</small>

* [bitnami/fluent-bit] :zap: :arrow_up: Update dependency references (#35534) ([06c5301](https://github.com/bitnami/charts/commit/06c5301163a515c698b45a6a26adeaeacbba4ab8)), closes [#35534](https://github.com/bitnami/charts/issues/35534)

## <small>3.1.10 (2025-08-04)</small>

* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/fluent-bit] :zap: :arrow_up: Update dependency references (#35393) ([e9c0b8d](https://github.com/bitnami/charts/commit/e9c0b8dfa35c66f03290ba97265b12efeb7c226b)), closes [#35393](https://github.com/bitnami/charts/issues/35393)

## <small>3.1.9 (2025-07-23)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/fluent-bit] :zap: :arrow_up: Update dependency references (#35250) ([da8a832](https://github.com/bitnami/charts/commit/da8a8322cdbbdb12c5cdf573d4833f57069aee3b)), closes [#35250](https://github.com/bitnami/charts/issues/35250)

## <small>3.1.8 (2025-07-09)</small>

* [bitnami/fluent-bit] :zap: :arrow_up: Update dependency references (#34976) ([15a4e75](https://github.com/bitnami/charts/commit/15a4e755979a53e4a447110b513caf0dbc9e4ef4)), closes [#34976](https://github.com/bitnami/charts/issues/34976)

## <small>3.1.7 (2025-07-07)</small>

* [bitnami/fluent-bit] Remove healthcheck VIB test (#34829) ([86395d4](https://github.com/bitnami/charts/commit/86395d4011a3b031f5f37f867b0a4ccba3d676e1)), closes [#34829](https://github.com/bitnami/charts/issues/34829)

## <small>3.1.6 (2025-06-29)</small>

* [bitnami/fluent-bit] :zap: :arrow_up: Update dependency references (#34704) ([4a29a32](https://github.com/bitnami/charts/commit/4a29a322d558718ff9e3a582e38faef1c5c49026)), closes [#34704](https://github.com/bitnami/charts/issues/34704)

## <small>3.1.5 (2025-06-03)</small>

* [bitnami/fluent-bit] Fix HPA  target type (#34052) ([b38ed91](https://github.com/bitnami/charts/commit/b38ed9161d728c576666940106b27a669abf3e7d)), closes [#34052](https://github.com/bitnami/charts/issues/34052)

## <small>3.1.4 (2025-05-30)</small>

* [bitnami/fluent-bit] :zap: :arrow_up: Update dependency references (#34019) ([3c8dd6f](https://github.com/bitnami/charts/commit/3c8dd6ff2c92ee698869434becb5331dca4b8fa9)), closes [#34019](https://github.com/bitnami/charts/issues/34019)

## <small>3.1.3 (2025-05-13)</small>

* [bitnami/fluent-bit] :zap: :arrow_up: Update dependency references (#33674) ([7d4b3e4](https://github.com/bitnami/charts/commit/7d4b3e4c7bbacfc703daf2da91b8443702f1817e)), closes [#33674](https://github.com/bitnami/charts/issues/33674)
* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)

## <small>3.1.2 (2025-05-06)</small>

* [bitnami/fluent-bit] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#33 ([412517d](https://github.com/bitnami/charts/commit/412517d16ac16572752b4f142991d26693da4d55)), closes [#33361](https://github.com/bitnami/charts/issues/33361)

## <small>3.1.1 (2025-04-23)</small>

* [bitnami/fluent-bit] Release 3.1.1 (#33151) ([79e0e18](https://github.com/bitnami/charts/commit/79e0e185755f4b4b058ac3697761025df6c03532)), closes [#33151](https://github.com/bitnami/charts/issues/33151)

## 3.1.0 (2025-04-21)

* [bitnami/fluent-bit] Added support for extraContainerPorts (#33083) ([d1089a0](https://github.com/bitnami/charts/commit/d1089a0eab6f5a0c3a451806b1f58287fe727d1e)), closes [#33083](https://github.com/bitnami/charts/issues/33083)

## 3.0.0 (2025-04-02)

* [bitnami/fluent-bit] Release 3.0.0 (#32779) ([1c82162](https://github.com/bitnami/charts/commit/1c821623a0a03ad80ff88c64fe6bb54347a09772)), closes [#32779](https://github.com/bitnami/charts/issues/32779)

## <small>2.5.7 (2025-03-25)</small>

* [bitnami/fluent-bit] Release 2.5.7 (#32602) ([4a96af6](https://github.com/bitnami/charts/commit/4a96af6ec5c150b3306866d381466fb6c0c6d667)), closes [#32602](https://github.com/bitnami/charts/issues/32602)

## <small>2.5.6 (2025-03-17)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/fluent-bit] Release 2.5.6 (#32489) ([47dca7d](https://github.com/bitnami/charts/commit/47dca7dc7527ee9fd39a88e76f14e2594f9bf410)), closes [#32489](https://github.com/bitnami/charts/issues/32489)

## <small>2.5.5 (2025-03-04)</small>

* [bitnami/fluent-bit] Release 2.5.5 (#32255) ([64c11bc](https://github.com/bitnami/charts/commit/64c11bc51e9a921a70bf06fed57c44013bc57db1)), closes [#32255](https://github.com/bitnami/charts/issues/32255)

## <small>2.5.4 (2025-03-03)</small>

* [bitnami/fluent-bit] Release 2.5.4 (#32247) ([74b219d](https://github.com/bitnami/charts/commit/74b219dcca1cbcb6aa59ecc91f5dd3a38b4286a6)), closes [#32247](https://github.com/bitnami/charts/issues/32247)

## <small>2.5.3 (2025-03-03)</small>

* [bitnami/fluent-bit] Release 2.5.3 (#32245) ([f9cba71](https://github.com/bitnami/charts/commit/f9cba711df3ae367c26a34bea5344a4622da0f64)), closes [#32245](https://github.com/bitnami/charts/issues/32245)

## <small>2.5.2 (2025-03-03)</small>

* [bitnami/fluent-bit] Release 2.5.2 (#32242) ([af34835](https://github.com/bitnami/charts/commit/af348355f1917e339120f0de74ba6c5fb417f32a)), closes [#32242](https://github.com/bitnami/charts/issues/32242)

## <small>2.5.1 (2025-02-20)</small>

* [bitnami/fluent-bit] Release 2.5.1 (#32090) ([5e1ff1f](https://github.com/bitnami/charts/commit/5e1ff1f9c34224f8053af5051f28b56155d720ea)), closes [#32090](https://github.com/bitnami/charts/issues/32090)

## 2.5.0 (2025-02-20)

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/fluent-bit] feat: use new helper for checking API versions (#32049) ([d098ed1](https://github.com/bitnami/charts/commit/d098ed13754597c257fd32a09228b09f31b09b0b)), closes [#32049](https://github.com/bitnami/charts/issues/32049)

## <small>2.4.5 (2025-02-07)</small>

* [bitnami/fluent-bit] Release 2.4.5 (#31835) ([ade7a48](https://github.com/bitnami/charts/commit/ade7a48bd37b52a6d70cecb1fa2670eb25480c72)), closes [#31835](https://github.com/bitnami/charts/issues/31835)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## <small>2.4.4 (2025-01-24)</small>

* [bitnami/fluent-bit] Release 2.4.4 (#31551) ([67f7f3b](https://github.com/bitnami/charts/commit/67f7f3b8fe90c9edf097e323e9b530fe55887155)), closes [#31551](https://github.com/bitnami/charts/issues/31551)

## <small>2.4.3 (2024-12-30)</small>

* [bitnami/fluent-bit] Release 2.4.3 (#31186) ([343ce6d](https://github.com/bitnami/charts/commit/343ce6df75c858132b0a42cb7691441da56768df)), closes [#31186](https://github.com/bitnami/charts/issues/31186)

## <small>2.4.2 (2024-12-20)</small>

* [bitnami/fluent-bit] Fix typo daemonset.enable (#31088) ([2efe620](https://github.com/bitnami/charts/commit/2efe620ac591850d89f62243a3aac9806d37c9fa)), closes [#31088](https://github.com/bitnami/charts/issues/31088)

## <small>2.4.1 (2024-12-19)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/fluent-bit] Release 2.4.1 (#31123) ([1cb1993](https://github.com/bitnami/charts/commit/1cb199349264a9210d3424829416471760411021)), closes [#31123](https://github.com/bitnami/charts/issues/31123)

## 2.4.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/*] docs: :memo: Add "Prometheus metrics" (batch 2) (#30662) ([50e0570](https://github.com/bitnami/charts/commit/50e0570f98ab15308af7910b405baa4480e5fe3f)), closes [#30662](https://github.com/bitnami/charts/issues/30662)
* [bitnami/fluent-bit] Detect non-standard images (#30891) ([f27be3c](https://github.com/bitnami/charts/commit/f27be3c8f1943001278a5769876ca0699be5e342)), closes [#30891](https://github.com/bitnami/charts/issues/30891)

## <small>2.3.25 (2024-11-28)</small>

* [bitnami/fluent-bit] Release 2.3.25 (#30667) ([4ae0f96](https://github.com/bitnami/charts/commit/4ae0f9678d68f7cf1215ef7700b54eabbd8cf188)), closes [#30667](https://github.com/bitnami/charts/issues/30667)

## <small>2.3.24 (2024-11-17)</small>

* [bitnami/fluent-bit] Release 2.3.24 (#30487) ([e9951e3](https://github.com/bitnami/charts/commit/e9951e3c9022560eaea85da02882441811e9017f)), closes [#30487](https://github.com/bitnami/charts/issues/30487)

## <small>2.3.23 (2024-11-15)</small>

* [bitnami/fluent-bit] Release 2.3.23 (#30475) ([0d5b4b8](https://github.com/bitnami/charts/commit/0d5b4b8dac85dca9031cbbc35e4ea400c9eb5b75)), closes [#30475](https://github.com/bitnami/charts/issues/30475)

## <small>2.3.22 (2024-11-05)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/fluent-bit] Release 2.3.22 (#30209) ([ed02c36](https://github.com/bitnami/charts/commit/ed02c36c58d089da94873026bea10f81fecea69b)), closes [#30209](https://github.com/bitnami/charts/issues/30209)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## <small>2.3.21 (2024-09-27)</small>

* [bitnami/fluent-bit] Release 2.3.21 (#29647) ([973a279](https://github.com/bitnami/charts/commit/973a2792e0bc5967e3180c6d44eebf223b9f1d83)), closes [#29647](https://github.com/bitnami/charts/issues/29647)

## <small>2.3.20 (2024-09-27)</small>

* [bitnami/fluent-bit] Release 2.3.20 (#29643) ([0a14a7c](https://github.com/bitnami/charts/commit/0a14a7c4bf815bd4e5a829a8de93c1b94fda7a43)), closes [#29643](https://github.com/bitnami/charts/issues/29643)

## <small>2.3.19 (2024-09-16)</small>

* [bitnami/fluent-bit] Release 2.3.19 (#29460) ([33dd6a6](https://github.com/bitnami/charts/commit/33dd6a6786fd234cf3d5b643b3db7f7b278a0105)), closes [#29460](https://github.com/bitnami/charts/issues/29460)

## <small>2.3.18 (2024-09-02)</small>

* [bitnami/fluent-bit] Release 2.3.18 (#29147) ([39609d1](https://github.com/bitnami/charts/commit/39609d1d483127e836fcad9dc4c35103762f1fea)), closes [#29147](https://github.com/bitnami/charts/issues/29147)

## <small>2.3.17 (2024-08-14)</small>

* [bitnami/fluent-bit] Release 2.3.17 (#28888) ([ddf160a](https://github.com/bitnami/charts/commit/ddf160a6c4b23599b3e023b9703c08f7e582a7d7)), closes [#28888](https://github.com/bitnami/charts/issues/28888)

## <small>2.3.16 (2024-08-10)</small>

* [bitnami/fluent-bit] Release 2.3.16 (#28818) ([b11e97f](https://github.com/bitnami/charts/commit/b11e97f9b3a4c12a86db9c22762062be62428382)), closes [#28818](https://github.com/bitnami/charts/issues/28818)

## <small>2.3.15 (2024-07-25)</small>

* [bitnami/fluent-bit] Release 2.3.15 (#28449) ([3dfaa01](https://github.com/bitnami/charts/commit/3dfaa01043acdfcec57677058d26048653a04226)), closes [#28449](https://github.com/bitnami/charts/issues/28449)

## <small>2.3.14 (2024-07-25)</small>

* [bitnami/fluent-bit] Release 2.3.14 (#28405) ([c64cb6d](https://github.com/bitnami/charts/commit/c64cb6dd36f82816534880050bd03c87f30a0e2b)), closes [#28405](https://github.com/bitnami/charts/issues/28405)

## <small>2.3.13 (2024-07-24)</small>

* [bitnami/fluent-bit] Release 2.3.13 (#28307) ([c611beb](https://github.com/bitnami/charts/commit/c611beb6563a3634261c49cbeec3d3831520424d)), closes [#28307](https://github.com/bitnami/charts/issues/28307)

## <small>2.3.12 (2024-07-24)</small>

* [bitnami/fluent-bit] Release 2.3.12 (#28241) ([240482b](https://github.com/bitnami/charts/commit/240482b3ad70ea5876c36995036ef8ebcd722991)), closes [#28241](https://github.com/bitnami/charts/issues/28241)

## <small>2.3.11 (2024-07-17)</small>

* [bitnami/fluent-bit] Release 2.3.11 (#28130) ([1dcfe94](https://github.com/bitnami/charts/commit/1dcfe94b0c14f04c9b96a0171dbc7fa36b189080)), closes [#28130](https://github.com/bitnami/charts/issues/28130)

## <small>2.3.10 (2024-07-16)</small>

* [bitnami/fluent-bit] Global StorageClass as default value (#28019) ([f4718c2](https://github.com/bitnami/charts/commit/f4718c2bbc9babe8051c912ea8bd0feaaf868a5e)), closes [#28019](https://github.com/bitnami/charts/issues/28019)

## <small>2.3.9 (2024-07-12)</small>

* [bitnami/fluent-bit] Release 2.3.9 (#27923) ([a435aaa](https://github.com/bitnami/charts/commit/a435aaa3769fb1c91d1a7317c531c3056bc9539c)), closes [#27923](https://github.com/bitnami/charts/issues/27923)

## <small>2.3.8 (2024-07-10)</small>

* [bitnami/fluent-bit] Release 2.3.8 (#27883) ([bc8e1bd](https://github.com/bitnami/charts/commit/bc8e1bd604da1ca6466dc0e978e38afbd83c25f8)), closes [#27883](https://github.com/bitnami/charts/issues/27883)

## <small>2.3.7 (2024-07-08)</small>

* [bitnami/fluent-bit] Release 2.3.7 (#27848) ([5e56666](https://github.com/bitnami/charts/commit/5e566665993c48c79a8e284da8adb6e150bea0a1)), closes [#27848](https://github.com/bitnami/charts/issues/27848)

## <small>2.3.6 (2024-07-03)</small>

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/fluent-bit] Release 2.3.6 (#27692) ([6543416](https://github.com/bitnami/charts/commit/6543416ae8d32281921cedfb73306e8122adc2a0)), closes [#27692](https://github.com/bitnami/charts/issues/27692)

## <small>2.3.5 (2024-06-18)</small>

* [bitnami/fluent-bit] Release 2.3.5 (#27344) ([1032ea6](https://github.com/bitnami/charts/commit/1032ea62180360dc0a289e2c606473f8a0abad4c)), closes [#27344](https://github.com/bitnami/charts/issues/27344)

## <small>2.3.4 (2024-06-17)</small>

* [bitnami/fluent-bit] Release 2.3.4 (#27218) ([2189ddb](https://github.com/bitnami/charts/commit/2189ddbbd6d5808ae1b8bd82ff58075418340f5f)), closes [#27218](https://github.com/bitnami/charts/issues/27218)

## <small>2.3.3 (2024-06-12)</small>

* [bitnami/fluent-bit] Release 2.3.3 (#27125) ([6544466](https://github.com/bitnami/charts/commit/6544466a73d9ce96986a2829a6c245e1363d0e79)), closes [#27125](https://github.com/bitnami/charts/issues/27125)

## <small>2.3.2 (2024-06-08)</small>

* [bitnami/fluent-bit] Release 2.3.2 (#27061) ([1a5338d](https://github.com/bitnami/charts/commit/1a5338daf534b712823a407b409f7b71b9ddb294)), closes [#27061](https://github.com/bitnami/charts/issues/27061)

## <small>2.3.1 (2024-06-07)</small>

* [bitnami/fluent-bit] Release 2.3.1 (#26949) ([62fdaac](https://github.com/bitnami/charts/commit/62fdaacb7d41f4ce8ec98688374eb8eeef31f099)), closes [#26949](https://github.com/bitnami/charts/issues/26949)

## 2.3.0 (2024-06-06)

* [bitnami/fluent-bit] Enable PodDisruptionBudgets (#26693) ([a746ed1](https://github.com/bitnami/charts/commit/a746ed1b65609c31ca517a6851c4b13668df016d)), closes [#26693](https://github.com/bitnami/charts/issues/26693)

## <small>2.2.3 (2024-06-04)</small>

* [bitnami/fluent-bit] Bump chart version (#26631) ([3119749](https://github.com/bitnami/charts/commit/311974914d758451d8ed6a7754b3bff61e1633f0)), closes [#26631](https://github.com/bitnami/charts/issues/26631)

## <small>2.2.2 (2024-05-27)</small>

* [bitnami/fluent-bit] Release 2.2.2 (#26442) ([d966419](https://github.com/bitnami/charts/commit/d9664199abc3f0b025546b05686b1e1daff07341)), closes [#26442](https://github.com/bitnami/charts/issues/26442)

## <small>2.2.1 (2024-05-24)</small>

* [bitnami/fluent-bit] Release 2.2.1 (#26418) ([a77aee2](https://github.com/bitnami/charts/commit/a77aee26883a604a8e5fe8d81ffe05a1142d9857)), closes [#26418](https://github.com/bitnami/charts/issues/26418)

## 2.2.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/fluent-bit] feat: :sparkles: :lock: Add warning when original images are replaced (#26204) ([08a9122](https://github.com/bitnami/charts/commit/08a912234a5128d3e1e26cba150a6a011d82329a)), closes [#26204](https://github.com/bitnami/charts/issues/26204)

## <small>2.1.5 (2024-05-21)</small>

* [bitnami/fluent-bit] Release 2.1.5 updating components versions (#26148) ([3a925c2](https://github.com/bitnami/charts/commit/3a925c288d4872d2734169fedf3b4f2d820fd20e)), closes [#26148](https://github.com/bitnami/charts/issues/26148)

## <small>2.1.4 (2024-05-20)</small>

* [bitnami/fluent-bit] Use different liveness/readiness probes (#25990) ([6f01d22](https://github.com/bitnami/charts/commit/6f01d228607c0263887c9b7bc68538408dc3d549)), closes [#25990](https://github.com/bitnami/charts/issues/25990)

## <small>2.1.3 (2024-05-18)</small>

* [bitnami/fluent-bit] Release 2.1.3 updating components versions (#26015) ([b8bfb1e](https://github.com/bitnami/charts/commit/b8bfb1ee355db86ccd7dfb3c21dae3491b00bd3b)), closes [#26015](https://github.com/bitnami/charts/issues/26015)

## <small>2.1.2 (2024-05-13)</small>

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/fluent-bit] Release 2.1.2 updating components versions (#25754) ([f85c9cd](https://github.com/bitnami/charts/commit/f85c9cda0197e2c04de2f238433d325d3f1c6334)), closes [#25754](https://github.com/bitnami/charts/issues/25754)

## <small>2.1.1 (2024-04-27)</small>

* [bitnami/fluent-bit] Release 2.1.1 updating components versions (#25435) ([70ec58c](https://github.com/bitnami/charts/commit/70ec58c63467a6707e8723ed0e40c69bb3ef2332)), closes [#25435](https://github.com/bitnami/charts/issues/25435)
* [bitnami/multiple charts] Fix typo: "NetworkPolice" vs "NetworkPolicy" (#25348) ([6970c1b](https://github.com/bitnami/charts/commit/6970c1ba245873506e73d459c6eac1e4919b778f)), closes [#25348](https://github.com/bitnami/charts/issues/25348)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## 2.1.0 (2024-04-23)

* [bitnami/fluent-bit] add checksum/config (#24836) ([c64bb0e](https://github.com/bitnami/charts/commit/c64bb0ecca9d870e997c252573369218320717d1)), closes [#24836](https://github.com/bitnami/charts/issues/24836)

## <small>2.0.1 (2024-04-12)</small>

* [bitnami/fluent-bit] Release 2.0.1 updating components versions (#25151) ([503e1a7](https://github.com/bitnami/charts/commit/503e1a7456505ddf9b1bba67c76626928a00adb4)), closes [#25151](https://github.com/bitnami/charts/issues/25151)

## 2.0.0 (2024-04-09)

* [bitnami/fluent-bit] Release 2.0.0 (#25080) ([1e6f097](https://github.com/bitnami/charts/commit/1e6f09757d91cb2150c8d413f516401ad3815818)), closes [#25080](https://github.com/bitnami/charts/issues/25080)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## <small>1.0.1 (2024-04-01)</small>

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* [bitnami/fluent-bit] Release 1.0.1 updating components versions (#24778) ([1148d78](https://github.com/bitnami/charts/commit/1148d78a8e5d042dbb46df2c05627c2b9cc2f837)), closes [#24778](https://github.com/bitnami/charts/issues/24778)

## 1.0.0 (2024-03-12)

* [bitnami/fluent-bit] feat!: :lock: :boom: Improve security defaults (#24327) ([af1588e](https://github.com/bitnami/charts/commit/af1588ed530ac7700b80250f431b73a7c37e5672)), closes [#24327](https://github.com/bitnami/charts/issues/24327)

## 0.12.0 (2024-03-06)

* [bitnami/fluent-bit] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v2 SC ([5020743](https://github.com/bitnami/charts/commit/5020743b4beb0ebd93155c75c3b94c5792037dd8)), closes [#24082](https://github.com/bitnami/charts/issues/24082)

## <small>0.11.1 (2024-03-04)</small>

* [bitnami/fluent-bit] feat: add missing parser files definitions (#23986) ([5278e6a](https://github.com/bitnami/charts/commit/5278e6ab6e76cd21f6d27d9fd9002e22865a7e39)), closes [#23986](https://github.com/bitnami/charts/issues/23986)

## 0.11.0 (2024-02-27)

* [bitnami/fluent-bit] feat: :sparkles: :lock: Add readOnlyRootFilesystem support (#23891) ([09c0f95](https://github.com/bitnami/charts/commit/09c0f95888a731cc1d63e7b03297a10a76adf52b)), closes [#23891](https://github.com/bitnami/charts/issues/23891)

## <small>0.10.2 (2024-02-21)</small>

* [bitnami/fluent-bit] Release 0.10.2 updating components versions (#23755) ([07a9c7a](https://github.com/bitnami/charts/commit/07a9c7a571794a200ff4e1d10d53e4400f308d6b)), closes [#23755](https://github.com/bitnami/charts/issues/23755)

## <small>0.10.1 (2024-02-21)</small>

* [bitnami/fluent-bit] feat: :sparkles: :lock: Add resource preset support (#23449) ([b08b25f](https://github.com/bitnami/charts/commit/b08b25fa04be7b661dc86041719c5120824716a7)), closes [#23449](https://github.com/bitnami/charts/issues/23449)
* [bitnami/fluent-bit] Release 0.10.1 updating components versions (#23648) ([734d266](https://github.com/bitnami/charts/commit/734d2660e971a426dc486c1c1f51bc202ea4f5f2)), closes [#23648](https://github.com/bitnami/charts/issues/23648)

## 0.10.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## 0.9.0 (2024-02-09)

* [bitnami/fluent-bit] feat: :lock: Enable networkPolicy (#23282) ([2fa2b11](https://github.com/bitnami/charts/commit/2fa2b1175561e4dd1306a8a27fde241e8ffb93c6)), closes [#23282](https://github.com/bitnami/charts/issues/23282)

## <small>0.8.4 (2024-02-02)</small>

* [bitnami/fluent-bit] Release 0.8.4 updating components versions (#23061) ([02b6877](https://github.com/bitnami/charts/commit/02b687728492976afa7f2d7c4dc2ceec3728cd77)), closes [#23061](https://github.com/bitnami/charts/issues/23061)

## <small>0.8.3 (2024-01-30)</small>

* [bitnami/fluent-bit] Release 0.8.3 updating components versions (#22915) ([b886993](https://github.com/bitnami/charts/commit/b886993e4a01b96a586a93e0d80f15d2d2bd8613)), closes [#22915](https://github.com/bitnami/charts/issues/22915)

## <small>0.8.2 (2024-01-30)</small>

* [bitnami/fluent-bit] Release 0.8.2 updating components versions (#22853) ([4672ab1](https://github.com/bitnami/charts/commit/4672ab127f535942877cbe97be2ab45a6854b90b)), closes [#22853](https://github.com/bitnami/charts/issues/22853)

## <small>0.8.1 (2024-01-26)</small>

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/fluent-bit] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22587) ([f7f3e41](https://github.com/bitnami/charts/commit/f7f3e41c0e8468c27054c1cdca8bddfa58b79a61)), closes [#22587](https://github.com/bitnami/charts/issues/22587)

## 0.8.0 (2024-01-19)

* [bitnami/fluent-bit] fix: :lock: Move service-account token auto-mount to pod declaration (#22399) ([cae0687](https://github.com/bitnami/charts/commit/cae06879a5b4e764f1ce9a67d216176cb33b741b)), closes [#22399](https://github.com/bitnami/charts/issues/22399)

## <small>0.7.1 (2024-01-18)</small>

* [bitnami/fluent-bit] Release 0.7.1 updating components versions (#22270) ([1471311](https://github.com/bitnami/charts/commit/1471311c1f927c20af683a69dcea2336b677d3c0)), closes [#22270](https://github.com/bitnami/charts/issues/22270)

## 0.7.0 (2024-01-16)

* [bitnami/fluent-bit] Fix HPA API version template usage (#21953) ([d17a292](https://github.com/bitnami/charts/commit/d17a29280b2fbd31545123388ee1eaa16a6ecba2)), closes [#21953](https://github.com/bitnami/charts/issues/21953)
* [bitnami/fluent-bit] fix: :lock: Improve podSecurityContext and containerSecurityContext with essent ([a3b6dac](https://github.com/bitnami/charts/commit/a3b6dac2280324004458ad3687b170aec93dfc83)), closes [#22118](https://github.com/bitnami/charts/issues/22118)

## <small>0.6.6 (2024-01-14)</small>

* [bitnami/*] Fix docs.bitnami.com broken links (#21901) ([f35506d](https://github.com/bitnami/charts/commit/f35506d2dadee4f097986e7792df1f53ab215b5d)), closes [#21901](https://github.com/bitnami/charts/issues/21901)
* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)
* [bitnami/fluent-bit] Release 0.6.6 updating components versions (#22083) ([fcd8fc0](https://github.com/bitnami/charts/commit/fcd8fc0440ae070c57cea827c5ee27797db6f3cb)), closes [#22083](https://github.com/bitnami/charts/issues/22083)

## <small>0.6.5 (2023-12-22)</small>

* [bitnami/fluent-bit] Release 0.6.5 updating components versions (#21724) ([0d319cf](https://github.com/bitnami/charts/commit/0d319cf899caf94735279dfb60ac6398ebf56271)), closes [#21724](https://github.com/bitnami/charts/issues/21724)

## <small>0.6.4 (2023-12-05)</small>

* [bitnami/fluent-bit] Replace deprecated pull secret partial (#21371) ([79c094b](https://github.com/bitnami/charts/commit/79c094b3604decad85c68f772e9fee67f4ffd45d)), closes [#21371](https://github.com/bitnami/charts/issues/21371)

## <small>0.6.3 (2023-11-21)</small>

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/fluent-bit] Release 0.6.3 updating components versions (#21116) ([54ce713](https://github.com/bitnami/charts/commit/54ce713f7227277d4621c2d3b237891612ab36ea)), closes [#21116](https://github.com/bitnami/charts/issues/21116)

## <small>0.6.2 (2023-11-09)</small>

* [bitnami/fluent-bit] Release 0.6.2 updating components versions (#20819) ([3c27b88](https://github.com/bitnami/charts/commit/3c27b889b319fcf7f17ea3a028018fca641c5306)), closes [#20819](https://github.com/bitnami/charts/issues/20819)

## <small>0.6.1 (2023-11-08)</small>

* [bitnami/fluent-bit] Release 0.6.1 updating components versions (#20688) ([7486396](https://github.com/bitnami/charts/commit/74863962f0e50515302bea7a3666d28256f1b274)), closes [#20688](https://github.com/bitnami/charts/issues/20688)

## 0.6.0 (2023-10-31)

* [bitnami/fluent-bit] feat: :sparkles: Add support for PSA restricted policy (#20438) ([477f4ae](https://github.com/bitnami/charts/commit/477f4ae3dbb1fa6f5f21169db41d5360e476aa9c)), closes [#20438](https://github.com/bitnami/charts/issues/20438)

## <small>0.5.5 (2023-10-24)</small>

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [bitnami/fluent-bit] Release 0.5.5 updating components versions (#20370) ([0d397c8](https://github.com/bitnami/charts/commit/0d397c80c94e0fa5e2fc4e73889095aaff629e11)), closes [#20370](https://github.com/bitnami/charts/issues/20370)

## <small>0.5.4 (2023-10-15)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/fluent-bit] bump bitnami/common (#20079) ([91e6b28](https://github.com/bitnami/charts/commit/91e6b284960ff78cb10594ee8d00add9c8485dd9)), closes [#20079](https://github.com/bitnami/charts/issues/20079)

## <small>0.5.3 (2023-09-24)</small>

* [bitnami/fluent-bit] Release 0.5.3 (#19490) ([4887fdf](https://github.com/bitnami/charts/commit/4887fdf240537341d7451d5807ff3015d498d2ea)), closes [#19490](https://github.com/bitnami/charts/issues/19490)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>0.5.2 (2023-09-07)</small>

* [bitnami/fluent-bit: Use merge helper]: (#19038) ([335cb27](https://github.com/bitnami/charts/commit/335cb272ef2af6fb0c562f202dd3cd984dc1292b)), closes [#19038](https://github.com/bitnami/charts/issues/19038)

## <small>0.5.1 (2023-09-05)</small>

* [bitnami/fluent-bit] Release 0.5.1 (#19009) ([66ced97](https://github.com/bitnami/charts/commit/66ced97b3c6236c17cb76d2072d613af379fd49b)), closes [#19009](https://github.com/bitnami/charts/issues/19009)

## 0.5.0 (2023-08-23)

* [bitnami/fluent-bit] Support for customizing standard labels (#18301) ([dab806b](https://github.com/bitnami/charts/commit/dab806b246c3beaa3753bff398a37b00385f0b16)), closes [#18301](https://github.com/bitnami/charts/issues/18301)

## <small>0.4.11 (2023-08-19)</small>

* [bitnami/fluent-bit] Release 0.4.11 (#18661) ([e53a890](https://github.com/bitnami/charts/commit/e53a890734bfab510479e8607d309fc59a487f33)), closes [#18661](https://github.com/bitnami/charts/issues/18661)

## <small>0.4.10 (2023-08-17)</small>

* [bitnami/fluent-bit] Release 0.4.10 (#18516) ([411281d](https://github.com/bitnami/charts/commit/411281db2cc5c08aca56eb5fd793257bde16550f)), closes [#18516](https://github.com/bitnami/charts/issues/18516)

## <small>0.4.9 (2023-07-25)</small>

* [bitnami/fluent-bit] Release 0.4.9 (#17869) ([e2d44cd](https://github.com/bitnami/charts/commit/e2d44cdf1edee929deb9b67509cf46a99102500f)), closes [#17869](https://github.com/bitnami/charts/issues/17869)

## <small>0.4.8 (2023-07-13)</small>

* [bitnami/fluent-bit] Release 0 updating components versions (#17597) ([7e235cc](https://github.com/bitnami/charts/commit/7e235ccd4635cd8e63c0b3f3eeaf2418a31f727b)), closes [#17597](https://github.com/bitnami/charts/issues/17597)

## <small>0.4.7 (2023-07-13)</small>

* [bitnami/fluent-bit] Release 0.4.7 (#17585) ([7372a41](https://github.com/bitnami/charts/commit/7372a41226d3c162fa513d33d5c19de23f429ae6)), closes [#17585](https://github.com/bitnami/charts/issues/17585)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)

## <small>0.4.6 (2023-06-23)</small>

* [bitnami/fluent-bit] Release 0.4.6 (#17324) ([08b5f46](https://github.com/bitnami/charts/commit/08b5f46f592f2c348bdc26432ee959da5cf40025)), closes [#17324](https://github.com/bitnami/charts/issues/17324)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## <small>0.4.5 (2023-06-21)</small>

* [bitnami/fluent-bit] Remove namespace field for cluster wide resources (#17275) ([30dd293](https://github.com/bitnami/charts/commit/30dd293c9516667587c5401873f904cb3f04373f)), closes [#17275](https://github.com/bitnami/charts/issues/17275)

## <small>0.4.4 (2023-06-15)</small>

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/fluent-bit] Release 0.4.4 (#17132) ([d136533](https://github.com/bitnami/charts/commit/d13653316bb06edad148e66f312bbf5e7b7716b7)), closes [#17132](https://github.com/bitnami/charts/issues/17132)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)

## <small>0.4.3 (2023-05-26)</small>

* [bitnami/fluent-bit] Release 0.4.3 updating components versions (#16928) ([b85db15](https://github.com/bitnami/charts/commit/b85db15b7f0641bd5e9a17e0a9d6992ffe7cd356)), closes [#16928](https://github.com/bitnami/charts/issues/16928)

## <small>0.4.2 (2023-05-21)</small>

* [bitnami/fluent-bit] Release 0.4.2 (#16772) ([15f5495](https://github.com/bitnami/charts/commit/15f5495a5fcdcf7480d0b1c4bfccbe69e7348d02)), closes [#16772](https://github.com/bitnami/charts/issues/16772)
* [bitnami/fluent-bit] Update README.md (#16728) ([249165c](https://github.com/bitnami/charts/commit/249165cfef487ae1f34ecc25ea22e6ffacd9d1bd)), closes [#16728](https://github.com/bitnami/charts/issues/16728)

## <small>0.4.1 (2023-05-16)</small>

* [bitnami/fluent-bit] Release 0.4.1 (#16662) ([2447669](https://github.com/bitnami/charts/commit/244766913031039eecfc1cff6c4e9fa99cb1ea50)), closes [#16662](https://github.com/bitnami/charts/issues/16662)

## 0.4.0 (2023-05-15)

* [bitnami/fluent-bit] Remove default systemd input (#16641) ([2247af1](https://github.com/bitnami/charts/commit/2247af178771e12135b910db81d3ca45b637e9e2)), closes [#16641](https://github.com/bitnami/charts/issues/16641)
* Add wording for enterprise page (#16560) ([8f22774](https://github.com/bitnami/charts/commit/8f2277440b976d52785ba9149762ad8620a73d1f)), closes [#16560](https://github.com/bitnami/charts/issues/16560)

## 0.3.0 (2023-05-09)

* [bitnami/several] Adapt Chart.yaml to set desired OCI annotations (#16546) ([fc9b18f](https://github.com/bitnami/charts/commit/fc9b18f2e98805d4df629acbcde696f44f973344)), closes [#16546](https://github.com/bitnami/charts/issues/16546)

## <small>0.2.1 (2023-05-09)</small>

* [bitnami/fluent-bit] Release 0.2.1 (#16457) ([442c092](https://github.com/bitnami/charts/commit/442c092e6d48ce49bd59df677580adc9a448487e)), closes [#16457](https://github.com/bitnami/charts/issues/16457)

## 0.2.0 (2023-05-04)

* [bitnami/fluent-bit] Include imagePullSecrets on deployment (#16381) ([51a2d30](https://github.com/bitnami/charts/commit/51a2d30f7261b8cbfd1841624a333b4c57e972ed)), closes [#16381](https://github.com/bitnami/charts/issues/16381)

## <small>0.1.2 (2023-05-03)</small>

* [bitnami/fluent-bit] Add Fluent Bit OCI links (#16352) ([2320ed7](https://github.com/bitnami/charts/commit/2320ed7eb487f0bc037044a590d86b223d8bc003)), closes [#16352](https://github.com/bitnami/charts/issues/16352)

## <small>0.1.1 (2023-04-29)</small>

* [bitnami/fluent-bit] Release 0.1.1 updating components versions ([df18134](https://github.com/bitnami/charts/commit/df18134d979edbc038f032352df3497450209a28))

## 0.1.0 (2023-04-25)

* [bitnami/fluent-bit] Add Fluent Bit Chart (#15453) ([5bbec69](https://github.com/bitnami/charts/commit/5bbec695303d576b300c1e74a7fe22df930e2215)), closes [#15453](https://github.com/bitnami/charts/issues/15453) [#15510](https://github.com/bitnami/charts/issues/15510)
