# Changelog

## 2.4.35 (2025-08-07)

* [bitnami/flux] :zap: :arrow_up: Update dependency references ([#35606](https://github.com/bitnami/charts/pull/35606))

## <small>2.4.34 (2025-08-07)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#35470) ([6195f63](https://github.com/bitnami/charts/commit/6195f631e48f4e896433dedf6db56054b2fb4b84)), closes [#35470](https://github.com/bitnami/charts/issues/35470)

## <small>2.4.33 (2025-08-01)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/flux] :zap: :arrow_up: Update dependency references (#35376) ([7bc2221](https://github.com/bitnami/charts/commit/7bc2221ad2c65ba5268257bb5c0cf1746e400a02)), closes [#35376](https://github.com/bitnami/charts/issues/35376)

## <small>2.4.32 (2025-07-15)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#35088) ([f9e9ec3](https://github.com/bitnami/charts/commit/f9e9ec30545673e97762c20066c75e8e4d53561a)), closes [#35088](https://github.com/bitnami/charts/issues/35088)

## <small>2.4.31 (2025-07-08)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#34889) ([697f9c9](https://github.com/bitnami/charts/commit/697f9c9551f53bf8d2a19ddeb4cbf898b4152237)), closes [#34889](https://github.com/bitnami/charts/issues/34889)

## <small>2.4.30 (2025-07-08)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#34884) ([cf42d00](https://github.com/bitnami/charts/commit/cf42d0055bc5b779db6cbc8ffc0b590b4f2de95d)), closes [#34884](https://github.com/bitnami/charts/issues/34884)

## <small>2.4.29 (2025-07-08)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#34846) ([75e9998](https://github.com/bitnami/charts/commit/75e999858006e751c58253aeb026df3e8ff05090)), closes [#34846](https://github.com/bitnami/charts/issues/34846)

## <small>2.4.28 (2025-07-08)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#34841) ([226daba](https://github.com/bitnami/charts/commit/226dabaaa4376f42127485ca08e805cc2275d5fd)), closes [#34841](https://github.com/bitnami/charts/issues/34841)

## <small>2.4.27 (2025-06-27)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#34690) ([75abdc7](https://github.com/bitnami/charts/commit/75abdc7d7316c65fdadfa848ff8ab09c0d3612db)), closes [#34690](https://github.com/bitnami/charts/issues/34690)

## <small>2.4.26 (2025-06-13)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#34428) ([567a03f](https://github.com/bitnami/charts/commit/567a03feffb557f8a0268636bb37070e7cd630aa)), closes [#34428](https://github.com/bitnami/charts/issues/34428)

## <small>2.4.25 (2025-06-13)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#34423) ([e9619cb](https://github.com/bitnami/charts/commit/e9619cb90042a57c781bf20b8a25c9469f310486)), closes [#34423](https://github.com/bitnami/charts/issues/34423)

## <small>2.4.24 (2025-06-13)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#34404) ([d672eb9](https://github.com/bitnami/charts/commit/d672eb9780bb67710e2fbf26b8f1291380c87b15)), closes [#34404](https://github.com/bitnami/charts/issues/34404)

## <small>2.4.23 (2025-06-13)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#34399) ([651a589](https://github.com/bitnami/charts/commit/651a589a1fcc28d4b1c01b093f6189b36c2c92c9)), closes [#34399](https://github.com/bitnami/charts/issues/34399)

## <small>2.4.22 (2025-06-10)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#34329) ([b8e4901](https://github.com/bitnami/charts/commit/b8e4901c8f81fb96c5118003dc9522339f9b7522)), closes [#34329](https://github.com/bitnami/charts/issues/34329)

## <small>2.4.21 (2025-06-06)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#34157) ([be07065](https://github.com/bitnami/charts/commit/be0706572bfde3ba0ddfa82c53463e9ce5415beb)), closes [#34157](https://github.com/bitnami/charts/issues/34157)

## <small>2.4.20 (2025-06-05)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#34154) ([30d17a9](https://github.com/bitnami/charts/commit/30d17a957717e16c0b5094c6c0755d5f605f3880)), closes [#34154](https://github.com/bitnami/charts/issues/34154)

## <small>2.4.19 (2025-06-01)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#34027) ([eb57020](https://github.com/bitnami/charts/commit/eb57020cda6719e2f8e6a29714e5fe7e34f5ad32)), closes [#34027](https://github.com/bitnami/charts/issues/34027)

## <small>2.4.18 (2025-05-29)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#33948) ([1d9e828](https://github.com/bitnami/charts/commit/1d9e828accbe0139f0862f8f526387e775f9a5f4)), closes [#33948](https://github.com/bitnami/charts/issues/33948)

## <small>2.4.17 (2025-05-28)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#33942) ([d09dfac](https://github.com/bitnami/charts/commit/d09dfac6fddf6c2b70b3977f673983f9a6489ad2)), closes [#33942](https://github.com/bitnami/charts/issues/33942)

## <small>2.4.16 (2025-05-27)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#33911) ([30d9d20](https://github.com/bitnami/charts/commit/30d9d201387be171336b825c524de987d95dab94)), closes [#33911](https://github.com/bitnami/charts/issues/33911)

## <small>2.4.15 (2025-05-27)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#33909) ([4de3432](https://github.com/bitnami/charts/commit/4de3432337ab872f171de85951b439a1ec854a59)), closes [#33909](https://github.com/bitnami/charts/issues/33909)

## <small>2.4.14 (2025-05-27)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#33908) ([44325de](https://github.com/bitnami/charts/commit/44325deb7580b6c44b97bb5fd3da4bc7daba7b23)), closes [#33908](https://github.com/bitnami/charts/issues/33908)

## <small>2.4.13 (2025-05-13)</small>

* [bitnami/flux] :zap: :arrow_up: Update dependency references (#33683) ([072b13e](https://github.com/bitnami/charts/commit/072b13efddd2a3f790a34dcf97ebedf776156045)), closes [#33683](https://github.com/bitnami/charts/issues/33683)
* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)

## <small>2.4.12 (2025-05-07)</small>

* [bitnami/flux] Release 2.4.12 (#33473) ([c1db9da](https://github.com/bitnami/charts/commit/c1db9da7567881f995727d6dc8402ea9d647f56a)), closes [#33473](https://github.com/bitnami/charts/issues/33473)

## <small>2.4.11 (2025-05-06)</small>

* [bitnami/flux] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#33363) ([1834a52](https://github.com/bitnami/charts/commit/1834a52444d2b297a643b68ccdb9b59288fe110e)), closes [#33363](https://github.com/bitnami/charts/issues/33363)

## <small>2.4.10 (2025-05-01)</small>

* [bitnami/flux] Release 2.4.10 (#33290) ([a3e199c](https://github.com/bitnami/charts/commit/a3e199cd22b6fd081c7bc1b79ed38a8e6d89d7e9)), closes [#33290](https://github.com/bitnami/charts/issues/33290)

## <small>2.4.9 (2025-04-01)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/flux] Release 2.4.9 (#32729) ([08e35a8](https://github.com/bitnami/charts/commit/08e35a800d2d34719aa5368c7a43668d48252357)), closes [#32729](https://github.com/bitnami/charts/issues/32729)

## <small>2.4.8 (2025-03-05)</small>

* [bitnami/flux] Release 2.4.8 (#32288) ([1ea7d91](https://github.com/bitnami/charts/commit/1ea7d9169f72cdddf5b2e0b68f4d262c69b72b10)), closes [#32288](https://github.com/bitnami/charts/issues/32288)

## <small>2.4.7 (2025-02-19)</small>

* [bitnami/flux] Release 2.4.7 (#31997) ([aba94f9](https://github.com/bitnami/charts/commit/aba94f9c81568678315d0c7a0915f39064199acd)), closes [#31997](https://github.com/bitnami/charts/issues/31997)

## <small>2.4.6 (2025-02-14)</small>

* [bitnami/flux] Release 2.4.6 (#31932) ([53dd799](https://github.com/bitnami/charts/commit/53dd7992f23da58019c9036ec5c784e0160c082e)), closes [#31932](https://github.com/bitnami/charts/issues/31932)

## <small>2.4.5 (2025-02-12)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/flux] Release 2.4.5 (#31887) ([a2e0596](https://github.com/bitnami/charts/commit/a2e0596f08bb4213f1c8973536fb6d310483c85a)), closes [#31887](https://github.com/bitnami/charts/issues/31887)

## <small>2.4.4 (2025-02-04)</small>

* [bitnami/flux] Release 2.4.4 (#31752) ([f67fea0](https://github.com/bitnami/charts/commit/f67fea02ec9dce765009b91189af28ceab524819)), closes [#31752](https://github.com/bitnami/charts/issues/31752)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## <small>2.4.3 (2025-01-24)</small>

* [bitnami/flux] Release 2.4.3 (#31552) ([c04c1dc](https://github.com/bitnami/charts/commit/c04c1dce4009eb066fb20e4704bfa0b0fa45c51d)), closes [#31552](https://github.com/bitnami/charts/issues/31552)

## <small>2.4.2 (2025-01-17)</small>

* [bitnami/flux] Release 2.4.2 (#31416) ([640bfd8](https://github.com/bitnami/charts/commit/640bfd8b53078ebca0b9a87aa576931253c84196)), closes [#31416](https://github.com/bitnami/charts/issues/31416)

## <small>2.4.1 (2025-01-13)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/flux] Release 2.4.1 (#31313) ([0ed2580](https://github.com/bitnami/charts/commit/0ed2580d9f39676cb6b12ab5c9f5df680fca7efc)), closes [#31313](https://github.com/bitnami/charts/issues/31313)

## 2.4.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/flux] Detect non-standard images (#30892) ([a4f4a9c](https://github.com/bitnami/charts/commit/a4f4a9c2bdc0bd2f5b91a307ddded6c22f9b4f03)), closes [#30892](https://github.com/bitnami/charts/issues/30892)

## <small>2.3.22 (2024-12-03)</small>

* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/*] docs: :memo: Add "Prometheus metrics" (batch 2) (#30662) ([50e0570](https://github.com/bitnami/charts/commit/50e0570f98ab15308af7910b405baa4480e5fe3f)), closes [#30662](https://github.com/bitnami/charts/issues/30662)
* [bitnami/flux] Release 2.3.22 (#30749) ([1ecb342](https://github.com/bitnami/charts/commit/1ecb342be439ce78a2bddb4cf433a9384505c09b)), closes [#30749](https://github.com/bitnami/charts/issues/30749)

## <small>2.3.21 (2024-11-07)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/flux] Release 2.3.21 (#30263) ([0a49b81](https://github.com/bitnami/charts/commit/0a49b81709b631dcd2e3f4c71d2c33deb52fdd91)), closes [#30263](https://github.com/bitnami/charts/issues/30263)

## <small>2.3.20 (2024-10-02)</small>

* [bitnami/flux] Release 2.3.20 (#29691) ([ab05b82](https://github.com/bitnami/charts/commit/ab05b82e2d7f572995086c0935b6fbfaad70d184)), closes [#29691](https://github.com/bitnami/charts/issues/29691)

## <small>2.3.19 (2024-09-26)</small>

* [bitnami/flux] Release 2.3.19 (#29638) ([6b93649](https://github.com/bitnami/charts/commit/6b93649fd91b138cc40a73a928242627f019386d)), closes [#29638](https://github.com/bitnami/charts/issues/29638)

## <small>2.3.18 (2024-09-25)</small>

* [bitnami/flux] Release 2.3.18 (#29606) ([b02b54f](https://github.com/bitnami/charts/commit/b02b54f7f0a04992f3d0034f4ebe8b4e4a4e2b8a)), closes [#29606](https://github.com/bitnami/charts/issues/29606)

## <small>2.3.17 (2024-09-19)</small>

* [bitnami/flux] Release 2.3.17 (#29513) ([81ff21a](https://github.com/bitnami/charts/commit/81ff21aca7ab4d05009f871ef15a90cae8c3843b)), closes [#29513](https://github.com/bitnami/charts/issues/29513)

## <small>2.3.16 (2024-09-16)</small>

* [bitnami/flux] Release 2.3.16 (#29447) ([9acdd0f](https://github.com/bitnami/charts/commit/9acdd0fa523280c667733d7d5ec3fcec6aad12ad)), closes [#29447](https://github.com/bitnami/charts/issues/29447)

## <small>2.3.15 (2024-09-05)</small>

* [bitnami/flux] Release 2.3.15 (#29230) ([2b0fab8](https://github.com/bitnami/charts/commit/2b0fab8b91de19475f8626acb5b770a080246a64)), closes [#29230](https://github.com/bitnami/charts/issues/29230)

## <small>2.3.14 (2024-08-07)</small>

* [bitnami/flux] Release 2.3.14 (#28710) ([7f19247](https://github.com/bitnami/charts/commit/7f19247a14d737594ddbd21f7af603cbf7f6f71a)), closes [#28710](https://github.com/bitnami/charts/issues/28710)

## <small>2.3.13 (2024-08-06)</small>

* [bitnami/flux] Use nginx instead of dokuwiki for testing (#28671) ([fd31545](https://github.com/bitnami/charts/commit/fd31545aa00292995aeceb7e8d1338852e8a4514)), closes [#28671](https://github.com/bitnami/charts/issues/28671)

## <small>2.3.12 (2024-07-25)</small>

* [bitnami/flux] Release 2.3.12 (#28429) ([d37fda0](https://github.com/bitnami/charts/commit/d37fda0b2b83f0f961b3cbb2d8dc985cf5ce3de2)), closes [#28429](https://github.com/bitnami/charts/issues/28429)

## <small>2.3.11 (2024-07-24)</small>

* [bitnami/flux] Release 2.3.11 (#28275) ([b23d1cd](https://github.com/bitnami/charts/commit/b23d1cdc6a01cf2f9374174f022ec98a1da79f28)), closes [#28275](https://github.com/bitnami/charts/issues/28275)

## <small>2.3.10 (2024-07-24)</small>

* [bitnami/flux] Release 2.3.10 (#28266) ([dced3e4](https://github.com/bitnami/charts/commit/dced3e4856e1bcd7cc710c49443e17748638249c)), closes [#28266](https://github.com/bitnami/charts/issues/28266)

## <small>2.3.9 (2024-07-18)</small>

* [bitnami/flux] Global StorageClass as default value (#28021) ([d16095e](https://github.com/bitnami/charts/commit/d16095eb4fba118281fe9248d4cc22db31985043)), closes [#28021](https://github.com/bitnami/charts/issues/28021)

## <small>2.3.8 (2024-07-04)</small>

* [bitnami/flux] Release 2.3.8 (#27782) ([de06d71](https://github.com/bitnami/charts/commit/de06d71002305f8ec3f52a245ec4e25aeed084d1)), closes [#27782](https://github.com/bitnami/charts/issues/27782)

## <small>2.3.7 (2024-07-03)</small>

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/flux] Release 2.3.7 (#27648) ([488d70c](https://github.com/bitnami/charts/commit/488d70c8412155c2a3288a30bf0ea3eb5aa368cb)), closes [#27648](https://github.com/bitnami/charts/issues/27648)

## <small>2.3.6 (2024-06-18)</small>

* [bitnami/flux] Release 2.3.6 (#27347) ([93f9bd3](https://github.com/bitnami/charts/commit/93f9bd311895f086dca1ad03b6edf3cfc9684873)), closes [#27347](https://github.com/bitnami/charts/issues/27347)

## <small>2.3.5 (2024-06-17)</small>

* [bitnami/flux] Release 2.3.5 (#27220) ([d6a55e1](https://github.com/bitnami/charts/commit/d6a55e1f60c24b69ba980c0e4b1fbe98ddd1ddb6)), closes [#27220](https://github.com/bitnami/charts/issues/27220)

## <small>2.3.4 (2024-06-06)</small>

* [bitnami/flux] Release 2.3.4 (#26956) ([4e1e169](https://github.com/bitnami/charts/commit/4e1e1691fffeb8dde61ed07978876af2b8e187f6)), closes [#26956](https://github.com/bitnami/charts/issues/26956)

## <small>2.3.3 (2024-06-05)</small>

* [bitnami/flux] Align PodDisruptionBudgets with templates (#26694) ([328d102](https://github.com/bitnami/charts/commit/328d102cf4a18663989cf3b56c90c85319b30844)), closes [#26694](https://github.com/bitnami/charts/issues/26694)

## <small>2.3.2 (2024-06-05)</small>

* [bitnami/flux] Release 2.3.2 (#26725) ([53a66af](https://github.com/bitnami/charts/commit/53a66af5a59dbbd365c4d458f1ad5a95a62e5266)), closes [#26725](https://github.com/bitnami/charts/issues/26725)

## <small>2.3.1 (2024-06-04)</small>

* [bitnami/flux] Bump chart version (#26632) ([1b8fd97](https://github.com/bitnami/charts/commit/1b8fd97a13c1017a896191b930041ce8d0659b9d)), closes [#26632](https://github.com/bitnami/charts/issues/26632)

## 2.3.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/flux] feat: :sparkles: :lock: Add warning when original images are replaced (#26206) ([3320237](https://github.com/bitnami/charts/commit/3320237e6a5e478c8878175a81932fa5c511c3ad)), closes [#26206](https://github.com/bitnami/charts/issues/26206)

## 2.2.0 (2024-05-21)

* [bitnami/flux] PDB review (#25934) ([2f053f3](https://github.com/bitnami/charts/commit/2f053f3c1868ff44bd8b756bc409e0d31b3c4a79)), closes [#25934](https://github.com/bitnami/charts/issues/25934)

## <small>2.1.4 (2024-05-18)</small>

* [bitnami/flux] Release 2.1.4 updating components versions (#26016) ([8d80373](https://github.com/bitnami/charts/commit/8d80373f7d5f11afdb116fae14cb0d30820adc5d)), closes [#26016](https://github.com/bitnami/charts/issues/26016)

## <small>2.1.3 (2024-05-14)</small>

* [bitnami/flux] Release 2.1.3 (#25769) ([9dc5bdf](https://github.com/bitnami/charts/commit/9dc5bdf8fd99ba587280a468d4c0a401dcc42525)), closes [#25769](https://github.com/bitnami/charts/issues/25769)

## <small>2.1.2 (2024-05-08)</small>

* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/flux] Release 2.1.2 (#25632) ([778b4f8](https://github.com/bitnami/charts/commit/778b4f8f41ddd24aba84aae82f8fbb7d320f5e36)), closes [#25632](https://github.com/bitnami/charts/issues/25632)
* [bitnami/multiple charts] Fix typo: "NetworkPolice" vs "NetworkPolicy" (#25348) ([6970c1b](https://github.com/bitnami/charts/commit/6970c1ba245873506e73d459c6eac1e4919b778f)), closes [#25348](https://github.com/bitnami/charts/issues/25348)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## <small>2.1.1 (2024-04-24)</small>

* [bitnami/flux] Release 2.1.1 updating components versions (#25353) ([0198bd1](https://github.com/bitnami/charts/commit/0198bd1975ed6467abedcab6aae113287071b923)), closes [#25353](https://github.com/bitnami/charts/issues/25353)

## 2.1.0 (2024-04-12)

* [bitnami/flux] fix: :bug: :lock: Add missing notification controller ports (#25075) ([ce6cbee](https://github.com/bitnami/charts/commit/ce6cbee0bb4cd7a2039cc031fee295eb03a310d5)), closes [#25075](https://github.com/bitnami/charts/issues/25075)

## <small>2.0.4 (2024-04-05)</small>

* [bitnami/flux] Release 2.0.4 updating components versions (#24957) ([f590283](https://github.com/bitnami/charts/commit/f590283676cba8e6b51909913e587338295f1704)), closes [#24957](https://github.com/bitnami/charts/issues/24957)

## <small>2.0.3 (2024-04-04)</small>

* [bitnami/flux] Release 2.0.3 (#24899) ([03ed6c3](https://github.com/bitnami/charts/commit/03ed6c39d94f7e14505f86fa5852d4d08d3341e3)), closes [#24899](https://github.com/bitnami/charts/issues/24899)

## <small>2.0.2 (2024-04-04)</small>

* [bitnami/flux] Release 2.0.2 (#24880) ([655626b](https://github.com/bitnami/charts/commit/655626b267ed5a0a5a386517a0b4391656e4df1e)), closes [#24880](https://github.com/bitnami/charts/issues/24880)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## <small>2.0.1 (2024-03-18)</small>

* [bitnami/flux] Release 2.0.1 updating components versions (#24521) ([5baf6b3](https://github.com/bitnami/charts/commit/5baf6b34debe485a6646c6c9beb48abf2c9ac3ab)), closes [#24521](https://github.com/bitnami/charts/issues/24521)

## 2.0.0 (2024-03-18)

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* [bitnami/flux] feat!: :lock: :boom: Improve security defaults (#24332) ([cb80ecb](https://github.com/bitnami/charts/commit/cb80ecbc3adc8c991fff21a284eb3df27d0d16ef)), closes [#24332](https://github.com/bitnami/charts/issues/24332)

## <small>1.10.1 (2024-03-06)</small>

* [bitnami/flux] Release 1.10.1 updating components versions (#24197) ([e5e52f1](https://github.com/bitnami/charts/commit/e5e52f1bea5ec2b1e3dc15b00ed58eb3d21cf6f4)), closes [#24197](https://github.com/bitnami/charts/issues/24197)

## 1.10.0 (2024-03-06)

* [bitnami/flux] feat: :sparkles: :lock: Add runAsGroup (#24170) ([ac57e9d](https://github.com/bitnami/charts/commit/ac57e9dbfb225332778de27dab40cdcd8a9ed3b3)), closes [#24170](https://github.com/bitnami/charts/issues/24170)

## 1.9.0 (2024-03-05)

* [bitnami/flux] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v2 SCC (#24 ([8d96934](https://github.com/bitnami/charts/commit/8d96934cc884fe0a500629451a7c14fd69a9302b)), closes [#24084](https://github.com/bitnami/charts/issues/24084)

## <small>1.8.2 (2024-02-21)</small>

* [bitnami/flux] Release 1.8.2 updating components versions (#23770) ([6c132e2](https://github.com/bitnami/charts/commit/6c132e2e3c45bd60f83982e146e080aba46af5e5)), closes [#23770](https://github.com/bitnami/charts/issues/23770)

## <small>1.8.1 (2024-02-21)</small>

* [bitnami/flux] Release 1.8.1 updating components versions (#23706) ([c2b8c51](https://github.com/bitnami/charts/commit/c2b8c51ae857f19a2f24230931df6381c761e6fb)), closes [#23706](https://github.com/bitnami/charts/issues/23706)

## 1.8.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## 1.7.0 (2024-02-19)

* [bitnami/flux] feat: :sparkles: :lock: Add resource preset support (#23451) ([1f4d89d](https://github.com/bitnami/charts/commit/1f4d89d2bf97dd2b2f7128e0e2866098500c99ad)), closes [#23451](https://github.com/bitnami/charts/issues/23451)

## <small>1.6.1 (2024-02-09)</small>

* [bitnami/flux] Release 1.5.9 (#23253) ([9e398e9](https://github.com/bitnami/charts/commit/9e398e913fbeface13dbc809e045dd05003df583)), closes [#23253](https://github.com/bitnami/charts/issues/23253)

## 1.6.0 (2024-02-07)

* [bitnami/flux] feat: :lock: Enable networkPolicy (#23264) ([cf5a284](https://github.com/bitnami/charts/commit/cf5a284682b6b0cc397b26d6ac958835681473c5)), closes [#23264](https://github.com/bitnami/charts/issues/23264)

## <small>1.5.8 (2024-02-03)</small>

* [bitnami/flux] Release 1.5.8 (#23092) ([282e05e](https://github.com/bitnami/charts/commit/282e05ed083b830ca749f9340a33d05f5fc347de)), closes [#23092](https://github.com/bitnami/charts/issues/23092)

## <small>1.5.7 (2024-02-02)</small>

* [bitnami/flux] Release 1.5.7 (#23040) ([4323ff0](https://github.com/bitnami/charts/commit/4323ff040d03cdbaa61a1069d4e33c389111ec9c)), closes [#23040](https://github.com/bitnami/charts/issues/23040)

## <small>1.5.6 (2024-01-31)</small>

* [bitnami/flux] Update CRDs and add headers for automatic update (#22888) ([cdb5a9a](https://github.com/bitnami/charts/commit/cdb5a9a797b557d0590292c87aefb9c56a3db7ef)), closes [#22888](https://github.com/bitnami/charts/issues/22888)

## <small>1.5.5 (2024-01-30)</small>

* [bitnami/flux] Release 1.5.5 updating components versions (#22908) ([9ad222e](https://github.com/bitnami/charts/commit/9ad222efe7b6f83133c14467f3330fe2c1bec950)), closes [#22908](https://github.com/bitnami/charts/issues/22908)

## <small>1.5.4 (2024-01-30)</small>

* [bitnami/flux] Release 1.5.4 updating components versions (#22856) ([cf0958e](https://github.com/bitnami/charts/commit/cf0958eb69611941bad3f604fc6aae8d824551e4)), closes [#22856](https://github.com/bitnami/charts/issues/22856)

## <small>1.5.3 (2024-01-30)</small>

* [bitnami/flux] Release 1.5.3 updating components versions (#22843) ([3d9c025](https://github.com/bitnami/charts/commit/3d9c0258245dc6a036f0f6fa75555b82a8c0f56c)), closes [#22843](https://github.com/bitnami/charts/issues/22843)

## <small>1.5.2 (2024-01-27)</small>

* [bitnami/flux] Release 1.5.2 updating components versions (#22792) ([c5ee2e3](https://github.com/bitnami/charts/commit/c5ee2e3d6292fbdb7129e788fd80d1cc373d63d4)), closes [#22792](https://github.com/bitnami/charts/issues/22792)

## <small>1.5.1 (2024-01-24)</small>

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/flux] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22589) ([e5afe3a](https://github.com/bitnami/charts/commit/e5afe3acfcbeba74482c9ac6c1b2c576b0262623)), closes [#22589](https://github.com/bitnami/charts/issues/22589)

## 1.5.0 (2024-01-22)

* [bitnami/flux] fix: :lock: Move service-account token auto-mount to pod declaration (#22401) ([cd2b5ad](https://github.com/bitnami/charts/commit/cd2b5adafb2318d90cb13d413b3ab4f4f080d8b8)), closes [#22401](https://github.com/bitnami/charts/issues/22401)

## 1.4.0 (2024-01-19)

* [bitnami/flux] feat: :lock: Allow limiting the scope to the deployed namespace (#22254) ([5d838d3](https://github.com/bitnami/charts/commit/5d838d32b977cadcb74b1f27566b4d5a0e592c7d)), closes [#22254](https://github.com/bitnami/charts/issues/22254)

## <small>1.3.3 (2024-01-18)</small>

* [bitnami/flux] Update CRDs and add source header (#22372) ([bc11a8f](https://github.com/bitnami/charts/commit/bc11a8f32182f909121b7ea010febdbba2da74eb)), closes [#22372](https://github.com/bitnami/charts/issues/22372)

## <small>1.3.2 (2024-01-18)</small>

* [bitnami/flux] Release 1.3.2 updating components versions (#22282) ([8d159ad](https://github.com/bitnami/charts/commit/8d159adccbf5ae258f254871eda9cd508a40b1bd)), closes [#22282](https://github.com/bitnami/charts/issues/22282)

## <small>1.3.1 (2024-01-17)</small>

* [bitnami/flux] Update Flux notification api version (#22232) ([b836cb9](https://github.com/bitnami/charts/commit/b836cb9bfb63c6d15e9dbe50b89588fc4302e17b)), closes [#22232](https://github.com/bitnami/charts/issues/22232)

## 1.3.0 (2024-01-16)

* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/flux] fix: :lock: Improve podSecurityContext and containerSecurityContext with essential se ([08538a2](https://github.com/bitnami/charts/commit/08538a2a4e7f75945c3e0cdb9c6427926e2526c0)), closes [#22120](https://github.com/bitnami/charts/issues/22120)

## <small>1.2.2 (2024-01-10)</small>

* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)
* [bitnami/flux] Release 1.2.2 updating components versions (#21936) ([a643374](https://github.com/bitnami/charts/commit/a643374746bc7bf155c40158efb936f94c355fd5)), closes [#21936](https://github.com/bitnami/charts/issues/21936)

## <small>1.2.1 (2023-12-27)</small>

* [bitnami/flux] Release 1.2.1 (#21589) ([0344e28](https://github.com/bitnami/charts/commit/0344e28d82a354526bcc778465e8341cbd96f5ce)), closes [#21589](https://github.com/bitnami/charts/issues/21589)

## 1.2.0 (2023-12-05)

* Move Flux CRDs (#21350) ([f6f8556](https://github.com/bitnami/charts/commit/f6f855635de467ae4600b80427f435ae3a6e391a)), closes [#21350](https://github.com/bitnami/charts/issues/21350)

## <small>1.1.3 (2023-11-21)</small>

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/flux] Release 1.1.3 updating components versions (#21147) ([d7599b5](https://github.com/bitnami/charts/commit/d7599b58142b2742a7a9f6b399ddd358f9db2703)), closes [#21147](https://github.com/bitnami/charts/issues/21147)

## <small>1.1.2 (2023-11-15)</small>

* [bitnami/flux] Release 1.1.2 updating components versions (#20976) ([90129c0](https://github.com/bitnami/charts/commit/90129c0a014c500b67b4ed376670795e017c2e61)), closes [#20976](https://github.com/bitnami/charts/issues/20976)

## <small>1.1.1 (2023-11-08)</small>

* [bitnami/flux] Release 1.1.1 updating components versions (#20739) ([b3e7be3](https://github.com/bitnami/charts/commit/b3e7be3120bb515582b9cbc7061d3e64f1cb281e)), closes [#20739](https://github.com/bitnami/charts/issues/20739)

## 1.1.0 (2023-10-31)

* [bitnami/flux] feat: :sparkles: Add support for PSA restricted policy (#20440) ([c91aebb](https://github.com/bitnami/charts/commit/c91aebb2d00b44837531ed8f6679394337fe3d9f)), closes [#20440](https://github.com/bitnami/charts/issues/20440)

## <small>1.0.7 (2023-10-25)</small>

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [Bitnami/flux] Fix templating error in the source controller servicemonitor (#20289) ([99177df](https://github.com/bitnami/charts/commit/99177df009734686ddc551c3de1ae0144f368657)), closes [#20289](https://github.com/bitnami/charts/issues/20289)

## <small>1.0.6 (2023-10-17)</small>

* [bitnami/flux] Release 1.0.6 (#20283) ([a2dfa33](https://github.com/bitnami/charts/commit/a2dfa33deecad0f5fbcd6ba70475be82708eb672)), closes [#20283](https://github.com/bitnami/charts/issues/20283)

## <small>1.0.5 (2023-10-15)</small>

* [bitnami/flux] Release 1.0.5 updating components versions (#20192) ([96d41d9](https://github.com/bitnami/charts/commit/96d41d92a72b21c3793952d483e65a7afcc1ac35)), closes [#20192](https://github.com/bitnami/charts/issues/20192)

## <small>1.0.4 (2023-10-09)</small>

* [bitnami/flux] Release 1.0.4 (#19910) ([8563b32](https://github.com/bitnami/charts/commit/8563b328de19470ced1341b222ff6b4c65fe0697)), closes [#19910](https://github.com/bitnami/charts/issues/19910)

## <small>1.0.3 (2023-10-09)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/flux] Release 1.0.3 (#19822) ([0002adf](https://github.com/bitnami/charts/commit/0002adf67a9feccea8dbc6ac599ecd52b9dbcd4c)), closes [#19822](https://github.com/bitnami/charts/issues/19822)

## <small>1.0.2 (2023-10-03)</small>

* [bitnami/flux] Release 1.0.2 (#19707) ([39884c4](https://github.com/bitnami/charts/commit/39884c4bf6f0ff6eb2d149d3b515bb25e6c2f5ac)), closes [#19707](https://github.com/bitnami/charts/issues/19707)

## <small>1.0.1 (2023-09-20)</small>

* [bitnami/flux] Use different app.kubernetes.io/version label on subcomponents (#19330) ([f3f73a5](https://github.com/bitnami/charts/commit/f3f73a513945c445bbc77ddffbb2f30fbf3d1866)), closes [#19330](https://github.com/bitnami/charts/issues/19330)

## 1.0.0 (2023-09-19)

* [bitnami/*] Update readme files (#19277) ([e56aeb2](https://github.com/bitnami/charts/commit/e56aeb2fbfbf5b6e42375db48cc7ae1ef1c3a823)), closes [#19277](https://github.com/bitnami/charts/issues/19277)
* [bitnami/flux] Update containers versions (#19387) ([2181732](https://github.com/bitnami/charts/commit/21817328e2f1dd3a03fb973367858640ac088704)), closes [#19387](https://github.com/bitnami/charts/issues/19387)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>0.4.1 (2023-09-08)</small>

* [bitnami/flux: Use merge helper]: (#19040) ([8d4cc38](https://github.com/bitnami/charts/commit/8d4cc38db0402e67e8108c1ed3ad0001a2a3d74f)), closes [#19040](https://github.com/bitnami/charts/issues/19040)

## 0.4.0 (2023-08-23)

* [bitnami/flux] Support for customizing standard labels (#18303) ([bdf65f5](https://github.com/bitnami/charts/commit/bdf65f53702898740588ce6119d7ebc426174ebb)), closes [#18303](https://github.com/bitnami/charts/issues/18303)

## <small>0.3.11 (2023-08-19)</small>

* [bitnami/flux] Release 0.3.11 (#18662) ([dbfdbda](https://github.com/bitnami/charts/commit/dbfdbda0dde66a6e3b1954d728a19b36b80a16c4)), closes [#18662](https://github.com/bitnami/charts/issues/18662)

## <small>0.3.10 (2023-08-17)</small>

* [bitnami/flux] Release 0.3.10 (#18518) ([7fb48c2](https://github.com/bitnami/charts/commit/7fb48c235c611ecdecd609d768bb67db56faf8c0)), closes [#18518](https://github.com/bitnami/charts/issues/18518)

## <small>0.3.9 (2023-08-08)</small>

* [bitnami/flux] chore: :page_facing_up: Remove license in CRDs (#18261) ([99a6f0a](https://github.com/bitnami/charts/commit/99a6f0a1921b22954d5623c496a091deab2abdf7)), closes [#18261](https://github.com/bitnami/charts/issues/18261)

## <small>0.3.8 (2023-07-25)</small>

* [bitnami/flux] Release 0.3.8 (#17885) ([18e2578](https://github.com/bitnami/charts/commit/18e2578f2ebe0f5853923ead4f084ed2c55cef61)), closes [#17885](https://github.com/bitnami/charts/issues/17885)

## <small>0.3.7 (2023-07-19)</small>

* [bitnami/flux] Release 0.3.7 (#17783) ([2b71181](https://github.com/bitnami/charts/commit/2b711810925e9c922c8bbb44082a53ef61d427d2)), closes [#17783](https://github.com/bitnami/charts/issues/17783)

## <small>0.3.6 (2023-07-15)</small>

* [bitnami/flux] Release 0 (#17609) ([742bfff](https://github.com/bitnami/charts/commit/742bfff83119d63f1b00a8e4e4fd6aecb4d32181)), closes [#17609](https://github.com/bitnami/charts/issues/17609)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)
* Use os-shell in tempate and Jaeger runtime params (#17557) ([91a49eb](https://github.com/bitnami/charts/commit/91a49eb1e3c81c7b7c6c28d1bc5d6d6ae698c1e2)), closes [#17557](https://github.com/bitnami/charts/issues/17557)

## <small>0.3.5 (2023-06-22)</small>

* [bitnami/flux] Release 0.3.5 (#17310) ([3a7655a](https://github.com/bitnami/charts/commit/3a7655a32d2ae3389cb7e1e100997a445c31861f)), closes [#17310](https://github.com/bitnami/charts/issues/17310)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## <small>0.3.4 (2023-06-21)</small>

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/flux] Remove namespace field for cluster wide resources (#17273) ([e31a1b6](https://github.com/bitnami/charts/commit/e31a1b656b6bd4ebdfb66b39bbe900b6023d364b)), closes [#17273](https://github.com/bitnami/charts/issues/17273)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)

## <small>0.3.3 (2023-06-01)</small>

* [bitnami/flux] Release 0.3.3 (#16985) ([f7a7fbe](https://github.com/bitnami/charts/commit/f7a7fbe416a8bffaa622aed655e39f5c5193e120)), closes [#16985](https://github.com/bitnami/charts/issues/16985)

## <small>0.3.2 (2023-05-24)</small>

* Update flux with valid CRDs (#16879) ([ed00c2d](https://github.com/bitnami/charts/commit/ed00c2d1573bcabd0fdde084b6ebcb9901149da5)), closes [#16879](https://github.com/bitnami/charts/issues/16879)

## <small>0.3.1 (2023-05-22)</small>

* [bitnami/flux] Release 0.2.2 (#16459) ([7ef50c8](https://github.com/bitnami/charts/commit/7ef50c8cc76657cf2cdc26bc0f69d098bd7d5c6c)), closes [#16459](https://github.com/bitnami/charts/issues/16459)
* Add wording for enterprise page (#16560) ([8f22774](https://github.com/bitnami/charts/commit/8f2277440b976d52785ba9149762ad8620a73d1f)), closes [#16560](https://github.com/bitnami/charts/issues/16560)

## 0.3.0 (2023-05-09)

* [bitnami/several] Adapt Chart.yaml to set desired OCI annotations (#16546) ([fc9b18f](https://github.com/bitnami/charts/commit/fc9b18f2e98805d4df629acbcde696f44f973344)), closes [#16546](https://github.com/bitnami/charts/issues/16546)

## <small>0.2.1 (2023-05-01)</small>

* [bitnami/flux] Release 0.2.1 updating components versions ([7602cb5](https://github.com/bitnami/charts/commit/7602cb5927844ac35ca2cd73922aa797659b12b9))

## 0.2.0 (2023-04-20)

* [bitnami/*] Make Helm charts 100% OCI (#15998) ([8841510](https://github.com/bitnami/charts/commit/884151035efcbf2e1b3206e7def85511073fb57d)), closes [#15998](https://github.com/bitnami/charts/issues/15998)

## <small>0.1.2 (2023-04-01)</small>

* [bitnami/flux] Release 0.1.2 updating components versions ([75e2c0c](https://github.com/bitnami/charts/commit/75e2c0c24c656b801dd65897459bdb7936bdc5cd))

## <small>0.1.1 (2023-03-29)</small>

* [bitnami/flux] Release 0.1.1 updating components versions ([357cdb7](https://github.com/bitnami/charts/commit/357cdb7a02a0af00d28ffff32fb5cfa1e9639f68))

## 0.1.0 (2023-03-28)

* [bitnami/flux] feat: :tada: Add chart (#15750) ([7b41196](https://github.com/bitnami/charts/commit/7b41196013c99310dea0c4b8fb471a831c2224e7)), closes [#15750](https://github.com/bitnami/charts/issues/15750)
