# Changelog

## 3.2.22 (2025-08-13)

* [bitnami/gitea] :zap: :arrow_up: Update dependency references ([#35846](https://github.com/bitnami/charts/pull/35846))

## <small>3.2.21 (2025-08-07)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#35605) ([7c2b42d](https://github.com/bitnami/charts/commit/7c2b42db0682fecb2bc51e6c77ba7635344d5b88)), closes [#35605](https://github.com/bitnami/charts/issues/35605)

## <small>3.2.20 (2025-08-07)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#35562) ([8cbacb0](https://github.com/bitnami/charts/commit/8cbacb009582b449b2384bd8c5b31f7fb5759cc3)), closes [#35562](https://github.com/bitnami/charts/issues/35562)

## <small>3.2.19 (2025-08-07)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#35474) ([fe0ba8f](https://github.com/bitnami/charts/commit/fe0ba8f263a0373a90a050e05dd0932c9e4e7f00)), closes [#35474](https://github.com/bitnami/charts/issues/35474)

## <small>3.2.18 (2025-08-04)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#35402) ([9493f30](https://github.com/bitnami/charts/commit/9493f30c02727dfe7f0931738d4c173b02e1a41e)), closes [#35402](https://github.com/bitnami/charts/issues/35402)

## <small>3.2.17 (2025-07-15)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#35091) ([a4651e1](https://github.com/bitnami/charts/commit/a4651e181d60473947db38e5d391b1bc99c069ec)), closes [#35091](https://github.com/bitnami/charts/issues/35091)

## <small>3.2.16 (2025-07-15)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#35054) ([5e81d2a](https://github.com/bitnami/charts/commit/5e81d2a7c665780c8f5147d6e9e56236a32bd9e5)), closes [#35054](https://github.com/bitnami/charts/issues/35054)

## <small>3.2.15 (2025-07-11)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#35014) ([2f60133](https://github.com/bitnami/charts/commit/2f6013303813b98083d8297ec98e1ebfc5656009)), closes [#35014](https://github.com/bitnami/charts/issues/35014)

## <small>3.2.14 (2025-07-11)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#35006) ([9f0bc3d](https://github.com/bitnami/charts/commit/9f0bc3d82b790f5bb4dd337b226314aa0cfb9041)), closes [#35006](https://github.com/bitnami/charts/issues/35006)

## <small>3.2.13 (2025-07-08)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#34890) ([acc77e5](https://github.com/bitnami/charts/commit/acc77e5b63e3e593f01f2c266ae0b38ec016c9b4)), closes [#34890](https://github.com/bitnami/charts/issues/34890)

## <small>3.2.12 (2025-06-20)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#34576) ([c6775b5](https://github.com/bitnami/charts/commit/c6775b5d9f599e09b708c53e5466cd76e83be16a)), closes [#34576](https://github.com/bitnami/charts/issues/34576)

## <small>3.2.11 (2025-06-20)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#34568) ([1d1c24a](https://github.com/bitnami/charts/commit/1d1c24af817dafe81e8efd00adf76d03e83966e0)), closes [#34568](https://github.com/bitnami/charts/issues/34568)

## <small>3.2.10 (2025-06-13)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#34432) ([f104400](https://github.com/bitnami/charts/commit/f104400df985eccad8cccc535751b6b0952ca72a)), closes [#34432](https://github.com/bitnami/charts/issues/34432)

## <small>3.2.9 (2025-06-10)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#34288) ([b6c97f6](https://github.com/bitnami/charts/commit/b6c97f6716b8ee0223d32efee6e1fd72b8993151)), closes [#34288](https://github.com/bitnami/charts/issues/34288)

## <small>3.2.8 (2025-06-06)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#34162) ([674aa77](https://github.com/bitnami/charts/commit/674aa77b463b119e3049d98beae4889b410a5e4f)), closes [#34162](https://github.com/bitnami/charts/issues/34162)

## <small>3.2.7 (2025-05-13)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#33622) ([9b09ecd](https://github.com/bitnami/charts/commit/9b09ecd3fe077dfc550daceacc25101e3b1ea2b5)), closes [#33622](https://github.com/bitnami/charts/issues/33622)
* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)

## <small>3.2.6 (2025-05-08)</small>

* [bitnami/gitea] :zap: :arrow_up: Update dependency references (#33558) ([cf1e13b](https://github.com/bitnami/charts/commit/cf1e13bcd7c791faedb003185ab2c50c0f5dd487)), closes [#33558](https://github.com/bitnami/charts/issues/33558)

## <small>3.2.5 (2025-05-07)</small>

* [bitnami/gitea] Release 3.2.5 (#33479) ([a1595ee](https://github.com/bitnami/charts/commit/a1595eee53e221b0b22cbdef0db922dc72ef825d)), closes [#33479](https://github.com/bitnami/charts/issues/33479)

## <small>3.2.4 (2025-05-06)</small>

* [bitnami/gitea] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#33365) ([6850abe](https://github.com/bitnami/charts/commit/6850abe386dcae0781ee5b1f4e61b548784a292b)), closes [#33365](https://github.com/bitnami/charts/issues/33365)

## <small>3.2.3 (2025-04-09)</small>

* [bitnami/gitea] Release 3.2.3 (#32905) ([cf465ce](https://github.com/bitnami/charts/commit/cf465ce64050d29fdd2ead91540bfa185b836bb3)), closes [#32905](https://github.com/bitnami/charts/issues/32905)

## <small>3.2.2 (2025-04-08)</small>

* [bitnami/gitea] Release 3.2.2 (#32856) ([8a6e278](https://github.com/bitnami/charts/commit/8a6e2781db8ba84cfc81a654daac1fcee3de9eda)), closes [#32856](https://github.com/bitnami/charts/issues/32856)

## <small>3.2.1 (2025-04-01)</small>

* [bitnami/gitea] Release 3.2.1 (#32730) ([bad3639](https://github.com/bitnami/charts/commit/bad3639d7d8dc68ecc2ff9ae0fad8f189f1cfa21)), closes [#32730](https://github.com/bitnami/charts/issues/32730)

## 3.2.0 (2025-03-27)

* [bitnami/gitea] Set `usePasswordFiles=true` by default (#32347) ([f82ce08](https://github.com/bitnami/charts/commit/f82ce081fed5aaddc123caae618776df141bf691)), closes [#32347](https://github.com/bitnami/charts/issues/32347)

## <small>3.1.14 (2025-03-24)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/gitea] Release 3.1.14 (#32586) ([bdb0cd7](https://github.com/bitnami/charts/commit/bdb0cd798e223e1603551f5000c63c733d6d5966)), closes [#32586](https://github.com/bitnami/charts/issues/32586)

## <small>3.1.13 (2025-03-05)</small>

* [bitnami/gitea] Release 3.1.13 (#32299) ([f435581](https://github.com/bitnami/charts/commit/f435581f5edee10b0eb96962d4c1e42e0e7231c3)), closes [#32299](https://github.com/bitnami/charts/issues/32299)

## <small>3.1.12 (2025-03-05)</small>

* [bitnami/gitea] Release 3.1.12 (#32289) ([7e1b8f8](https://github.com/bitnami/charts/commit/7e1b8f8163da5e9724da1c0f76ec5e3b94262fb8)), closes [#32289](https://github.com/bitnami/charts/issues/32289)

## <small>3.1.11 (2025-02-21)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/gitea] Release 3.1.11 (#32040) ([158c59f](https://github.com/bitnami/charts/commit/158c59fef6c9af660e63e983b10476c366919834)), closes [#32040](https://github.com/bitnami/charts/issues/32040)

## <small>3.1.10 (2025-02-06)</small>

* [bitnami/gitea] Release 3.1.10 (#31806) ([b32c026](https://github.com/bitnami/charts/commit/b32c0264329e5914869a5ab25e22f0c53037b782)), closes [#31806](https://github.com/bitnami/charts/issues/31806)

## <small>3.1.9 (2025-02-05)</small>

* [bitnami/gitea] Release 3.1.9 (#31799) ([1f04ad3](https://github.com/bitnami/charts/commit/1f04ad3e970269382ff2586e244c9b202e26fb08)), closes [#31799](https://github.com/bitnami/charts/issues/31799)

## <small>3.1.8 (2025-02-04)</small>

* [bitnami/gitea] Release 3.1.8 (#31753) ([987ba6c](https://github.com/bitnami/charts/commit/987ba6c0cd5f5c157a7cd314a4aecd50bbfe47ff)), closes [#31753](https://github.com/bitnami/charts/issues/31753)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## <small>3.1.7 (2025-01-24)</small>

* [bitnami/gitea] Release 3.1.7 (#31553) ([bca599d](https://github.com/bitnami/charts/commit/bca599dce849e43865249c76024417786a3fb5b5)), closes [#31553](https://github.com/bitnami/charts/issues/31553)

## <small>3.1.6 (2025-01-23)</small>

* [bitnami/gitea] Release 3.1.6 (#31530) ([85b96e6](https://github.com/bitnami/charts/commit/85b96e69b4087501b590240f2ad0a7840af544d5)), closes [#31530](https://github.com/bitnami/charts/issues/31530)

## <small>3.1.5 (2025-01-17)</small>

* [bitnami/gitea] Release 3.1.5 (#31417) ([c941f2d](https://github.com/bitnami/charts/commit/c941f2d742e004a5b13163187c5b77a6a1be3ecc)), closes [#31417](https://github.com/bitnami/charts/issues/31417)

## <small>3.1.4 (2025-01-10)</small>

* [bitnami/gitea] Release 3.1.4 (#31285) ([6afa662](https://github.com/bitnami/charts/commit/6afa662c1cb7c25a9e165b607ffa404364ebf8d4)), closes [#31285](https://github.com/bitnami/charts/issues/31285)

## <small>3.1.3 (2025-01-09)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/gitea] Release 3.1.3 (#31276) ([50dc1bd](https://github.com/bitnami/charts/commit/50dc1bd4f77cc356862d39c919d31cba2d671b58)), closes [#31276](https://github.com/bitnami/charts/issues/31276)

## <small>3.1.2 (2024-12-13)</small>

* [bitnami/gitea] Release 3.1.2 (#31031) ([f137d21](https://github.com/bitnami/charts/commit/f137d2178d93c2c257339ca6fd8688cbb5a74034)), closes [#31031](https://github.com/bitnami/charts/issues/31031)

## <small>3.1.1 (2024-12-11)</small>

* [bitnami/gitea] Release 3.1.1 (#31000) ([893a7e0](https://github.com/bitnami/charts/commit/893a7e0b2ea7cddd98553f14d290849c0e5d0d07)), closes [#31000](https://github.com/bitnami/charts/issues/31000)

## 3.1.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/gitea] Detect non-standard images (#30889) ([00a7a4e](https://github.com/bitnami/charts/commit/00a7a4e5ed1d81a90cf5f5c9f1b816eb1b0becac)), closes [#30889](https://github.com/bitnami/charts/issues/30889)

## <small>3.0.4 (2024-12-03)</small>

* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/*] docs: :memo: Add "Update Credentials" (batch 2) (#30687) ([c457848](https://github.com/bitnami/charts/commit/c457848b2a111aad59830b98f85ffa1e29918e10)), closes [#30687](https://github.com/bitnami/charts/issues/30687)
* [bitnami/gitea] Release 3.0.4 (#30750) ([61e17d8](https://github.com/bitnami/charts/commit/61e17d8e5b627d9bd2174a28708edfb2b611ca53)), closes [#30750](https://github.com/bitnami/charts/issues/30750)

## <small>3.0.3 (2024-11-27)</small>

* [bitnami/gitea] Release 3.0.3 (#30642) ([6278bcc](https://github.com/bitnami/charts/commit/6278bcc27deabce0d3bf6c9f475974c78d4441a1)), closes [#30642](https://github.com/bitnami/charts/issues/30642)

## <small>3.0.2 (2024-11-07)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/gitea] Release 3.0.2 (#30265) ([a65be9e](https://github.com/bitnami/charts/commit/a65be9e30f7a4906a97afbf56c8df31ab46c0eb1)), closes [#30265](https://github.com/bitnami/charts/issues/30265)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## <small>3.0.1 (2024-10-09)</small>

* [bitnami/gitea] Release 3.0.1 (#29853) ([06bc529](https://github.com/bitnami/charts/commit/06bc529e30553869e3414c900eee6c8cf9dbd300)), closes [#29853](https://github.com/bitnami/charts/issues/29853)

## 3.0.0 (2024-10-03)

* [bitnami/gitea] feat!: :arrow_up: :boom: Bump PostgreSQL to 17.x (#29732) ([d7f95fe](https://github.com/bitnami/charts/commit/d7f95fe48347c4cdb0a63f19752db52b5d7f9612)), closes [#29732](https://github.com/bitnami/charts/issues/29732)

## <small>2.3.23 (2024-10-02)</small>

* [bitnami/gitea] Release 2.3.23 (#29692) ([b9087cc](https://github.com/bitnami/charts/commit/b9087cc758df039fd5a47f74271d608f577e8697)), closes [#29692](https://github.com/bitnami/charts/issues/29692)

## <small>2.3.22 (2024-09-19)</small>

* [bitnami/gitea] Release 2.3.22 (#29512) ([5b8e97d](https://github.com/bitnami/charts/commit/5b8e97dae372b47f3ff2df5f9826373f3cc778e0)), closes [#29512](https://github.com/bitnami/charts/issues/29512)

## <small>2.3.21 (2024-09-15)</small>

* [bitnami/gitea] Release 2.3.21 (#29427) ([fc69df6](https://github.com/bitnami/charts/commit/fc69df6f756458aa4f2b769460fd43f2249654d8)), closes [#29427](https://github.com/bitnami/charts/issues/29427)

## <small>2.3.20 (2024-09-11)</small>

* [bitnami/gitea] Update externaldb-secret logic (#27596) ([c247305](https://github.com/bitnami/charts/commit/c2473057525a51f5177c3da0fc9ae03c0e4577dc)), closes [#27596](https://github.com/bitnami/charts/issues/27596)

## <small>2.3.19 (2024-09-06)</small>

* [bitnami/gitea] Release 2.3.19 (#29244) ([c08607d](https://github.com/bitnami/charts/commit/c08607d3a426e0a41881160baa650147b3b36451)), closes [#29244](https://github.com/bitnami/charts/issues/29244)

## <small>2.3.18 (2024-08-07)</small>

* [bitnami/gitea] Release 2.3.18 (#28713) ([1c3acc8](https://github.com/bitnami/charts/commit/1c3acc86db823eccafcd80454dfd0596128ed655)), closes [#28713](https://github.com/bitnami/charts/issues/28713)

## <small>2.3.17 (2024-07-25)</small>

* [bitnami/gitea] Release 2.3.17 (#28406) ([7e7d160](https://github.com/bitnami/charts/commit/7e7d16055a07b89fc6270a63eabf7f5629a33edf)), closes [#28406](https://github.com/bitnami/charts/issues/28406)

## <small>2.3.16 (2024-07-24)</small>

* [bitnami/gitea] Release 2.3.16 (#28278) ([ec73679](https://github.com/bitnami/charts/commit/ec7367976ea372796d7825cd7854e2ef125501ae)), closes [#28278](https://github.com/bitnami/charts/issues/28278)

## <small>2.3.15 (2024-07-24)</small>

* [bitnami/gitea] Release 2.3.15 (#28250) ([b3b4a50](https://github.com/bitnami/charts/commit/b3b4a5093a599091e18955b29bdff33fdcf88298)), closes [#28250](https://github.com/bitnami/charts/issues/28250)

## <small>2.3.14 (2024-07-18)</small>

* [bitnami/gitea] Global StorageClass as default value (#28023) ([36100a3](https://github.com/bitnami/charts/commit/36100a3f4471aabfeb2d4179fea56d153157e525)), closes [#28023](https://github.com/bitnami/charts/issues/28023)

## <small>2.3.13 (2024-07-15)</small>

* [bitnami/gitea] Include goss-wait test to improve test results (#27980) ([c690b0d](https://github.com/bitnami/charts/commit/c690b0d818d06feb79ad473ae1447d5b3b345518)), closes [#27980](https://github.com/bitnami/charts/issues/27980)

## <small>2.3.12 (2024-07-15)</small>

* [bitnami/gitea] Release 2.3.12 (#27964) ([48112ab](https://github.com/bitnami/charts/commit/48112ab4823167fd68daa82cda933f4f896acf7e)), closes [#27964](https://github.com/bitnami/charts/issues/27964)

## <small>2.3.11 (2024-07-05)</small>

* [bitnami/gitea] Release 2.3.11 (#27810) ([f792844](https://github.com/bitnami/charts/commit/f7928444d215f77f582b06dd8b0cce317d538992)), closes [#27810](https://github.com/bitnami/charts/issues/27810)

## <small>2.3.10 (2024-07-04)</small>

* [bitnami/gitea] Release 2.3.10 (#27803) ([0dd2cf0](https://github.com/bitnami/charts/commit/0dd2cf0499d348260f7b967a9d739a8e57d451c4)), closes [#27803](https://github.com/bitnami/charts/issues/27803)

## <small>2.3.9 (2024-07-04)</small>

* [bitnami/gitea] Release 2.3.9 (#27752) ([b37b9ef](https://github.com/bitnami/charts/commit/b37b9ef02ef34e15e576544ff94ce3c98c1ac159)), closes [#27752](https://github.com/bitnami/charts/issues/27752)

## <small>2.3.8 (2024-07-03)</small>

* [bitnami/gitea] Release 2.3.8 (#27647) ([53e54e7](https://github.com/bitnami/charts/commit/53e54e79995cd75fb1356302f22b8f16160928e8)), closes [#27647](https://github.com/bitnami/charts/issues/27647)

## <small>2.3.7 (2024-07-02)</small>

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/gitea] Release 2.3.7 (#27630) ([e0208e5](https://github.com/bitnami/charts/commit/e0208e5b734d3c5c3e9475894222ce4b5bb653da)), closes [#27630](https://github.com/bitnami/charts/issues/27630)

## <small>2.3.6 (2024-06-18)</small>

* [bitnami/gitea] Release 2.3.6 (#27348) ([b74347f](https://github.com/bitnami/charts/commit/b74347fad60d2643e60d6a6a572ec7d436b0d447)), closes [#27348](https://github.com/bitnami/charts/issues/27348)

## <small>2.3.5 (2024-06-17)</small>

* [bitnami/gitea] Release 2.3.5 (#27223) ([8933668](https://github.com/bitnami/charts/commit/893366838219b710030bd39c047cf64bdd7cdf6b)), closes [#27223](https://github.com/bitnami/charts/issues/27223)

## <small>2.3.4 (2024-06-06)</small>

* [bitnami/gitea] Release 2.3.4 (#26952) ([02b29d7](https://github.com/bitnami/charts/commit/02b29d737ef4e5aca0386b21f0084f13ce7bfd7b)), closes [#26952](https://github.com/bitnami/charts/issues/26952)

## <small>2.3.3 (2024-06-05)</small>

* [bitnami/gitea] Bump chart version (#26830) ([8412b82](https://github.com/bitnami/charts/commit/8412b824b39039281dfd0680cc81e87568fb5411)), closes [#26830](https://github.com/bitnami/charts/issues/26830)

## <small>2.3.2 (2024-06-05)</small>

* [bitnami/gitea] Bump chart version (#26772) ([9cf1e1c](https://github.com/bitnami/charts/commit/9cf1e1cebc78b6a7ed5e304ca0bacb5c01f0a40c)), closes [#26772](https://github.com/bitnami/charts/issues/26772)

## <small>2.3.1 (2024-06-05)</small>

* [bitnami/gitea] Release 2.3.1 (#26727) ([05a43bd](https://github.com/bitnami/charts/commit/05a43bd2116fefd64e7796ea9036bfb99ba0983c)), closes [#26727](https://github.com/bitnami/charts/issues/26727)

## 2.3.0 (2024-06-03)

* [bitnami/gitea] Enable PodDisruptionBudgets (#26433) ([4b3877b](https://github.com/bitnami/charts/commit/4b3877b03c181c7b77386f4f327568fc93093a55)), closes [#26433](https://github.com/bitnami/charts/issues/26433)

## <small>2.2.1 (2024-05-27)</small>

* [bitnami/gitea] Release 2.2.1 (#26460) ([906fd77](https://github.com/bitnami/charts/commit/906fd77e7701577bed88a0dd5dea35e07163fafc)), closes [#26460](https://github.com/bitnami/charts/issues/26460)

## 2.2.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/gitea] feat: :sparkles: :lock: Add warning when original images are replaced (#26208) ([fcc0ff9](https://github.com/bitnami/charts/commit/fcc0ff90bb25d1e59bf0a314223b0f4c9da8e723)), closes [#26208](https://github.com/bitnami/charts/issues/26208)

## <small>2.1.2 (2024-05-20)</small>

* [bitnami/gitea] Use different liveness/readiness probes (#25987) ([9efee88](https://github.com/bitnami/charts/commit/9efee882f14cd1f9f97643c80f0293fe4069ed2d)), closes [#25987](https://github.com/bitnami/charts/issues/25987)

## <small>2.1.1 (2024-05-18)</small>

* [bitnami/gitea] Release 2.1.1 updating components versions (#26017) ([d707ebd](https://github.com/bitnami/charts/commit/d707ebde3f28cb7c28a6daf2388419992e6a8e0a)), closes [#26017](https://github.com/bitnami/charts/issues/26017)

## 2.1.0 (2024-05-14)

* [bitnami/gitea] Add new customizable environment variables - ENABLE OPENID SIGNIN/SIGNUP (#25684) ([9cca25b](https://github.com/bitnami/charts/commit/9cca25b5884e936b74d2d4cf7a46a96b91c1309a)), closes [#25684](https://github.com/bitnami/charts/issues/25684)

## <small>2.0.6 (2024-05-13)</small>

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/gitea] Release 2.0.6 updating components versions (#25758) ([2ea38a3](https://github.com/bitnami/charts/commit/2ea38a3fc3df8f4509469c904b419c2d6eaf96fc)), closes [#25758](https://github.com/bitnami/charts/issues/25758)

## <small>2.0.5 (2024-05-07)</small>

* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/gitea] Release 2.0.5 updating components versions (#25592) ([c66f3cd](https://github.com/bitnami/charts/commit/c66f3cd241259c6bbb0cd5b8fc59ac3cf1e0e40e)), closes [#25592](https://github.com/bitnami/charts/issues/25592)
* [bitnami/multiple charts] Fix typo: "NetworkPolice" vs "NetworkPolicy" (#25348) ([6970c1b](https://github.com/bitnami/charts/commit/6970c1ba245873506e73d459c6eac1e4919b778f)), closes [#25348](https://github.com/bitnami/charts/issues/25348)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## <small>2.0.4 (2024-04-16)</small>

* [bitnami/gitea] Release 2.0.4 updating components versions (#25186) ([a42b0d3](https://github.com/bitnami/charts/commit/a42b0d333ea7743be596135f4f86db6d1379a6ca)), closes [#25186](https://github.com/bitnami/charts/issues/25186)

## <small>2.0.3 (2024-04-06)</small>

* [bitnami/gitea] Release 2.0.3 updating components versions (#25006) ([7f6eb12](https://github.com/bitnami/charts/commit/7f6eb12526cfb0519abe3c8ac4f68d02c19fd36e)), closes [#25006](https://github.com/bitnami/charts/issues/25006)

## <small>2.0.2 (2024-04-05)</small>

* [bitnami/gitea] Release 2.0.2 updating components versions (#24950) ([be5714d](https://github.com/bitnami/charts/commit/be5714de2ab4b6c66b19b41d6dcbcc23b1f7dcc4)), closes [#24950](https://github.com/bitnami/charts/issues/24950)

## <small>2.0.1 (2024-04-04)</small>

* [bitnami/gitea] Release 2.0.1 (#24881) ([ac10211](https://github.com/bitnami/charts/commit/ac10211abd3190186afadad9d18daa4c5c9c5e60)), closes [#24881](https://github.com/bitnami/charts/issues/24881)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## 2.0.0 (2024-04-02)

* [bitnami/gitea] feat!: :lock: :boom: Improve security defaults (#24646) ([433b920](https://github.com/bitnami/charts/commit/433b920ca3d3f06981bcf8232ab53cd3a684adde)), closes [#24646](https://github.com/bitnami/charts/issues/24646)

## <small>1.6.4 (2024-03-26)</small>

* [bitnami/gitea] Release 1.6.4 updating components versions (#24663) ([61a37b9](https://github.com/bitnami/charts/commit/61a37b93a2baeaaae9d85b57bf481d82913e4370)), closes [#24663](https://github.com/bitnami/charts/issues/24663)

## <small>1.6.3 (2024-03-22)</small>

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* [bitnami/gitea] Release 1.6.3 updating components versions (#24615) ([a1402f2](https://github.com/bitnami/charts/commit/a1402f2bf88edb882a639fd1c7116b41e409a5bb)), closes [#24615](https://github.com/bitnami/charts/issues/24615)

## <small>1.6.2 (2024-03-13)</small>

* [bitnami/gitea] Release 1.6.2 updating components versions (#24383) ([deb36bc](https://github.com/bitnami/charts/commit/deb36bc166bff0ba3b53add75d0526086d75120a)), closes [#24383](https://github.com/bitnami/charts/issues/24383)

## <small>1.6.1 (2024-03-06)</small>

* [bitnami/gitea] Release 1.6.1 updating components versions (#24195) ([7a4761b](https://github.com/bitnami/charts/commit/7a4761b7950b2527674c0431be19616aa38223ff)), closes [#24195](https://github.com/bitnami/charts/issues/24195)

## 1.6.0 (2024-03-06)

* [bitnami/gitea] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v2 SCC (#2 ([134c85b](https://github.com/bitnami/charts/commit/134c85bd90f25d008f3d46c6f24edad8b36ca758)), closes [#24086](https://github.com/bitnami/charts/issues/24086)

## <small>1.5.4 (2024-02-26)</small>

* [bitnami/gitea] Release 1.5.4 updating components versions (#23916) ([23e5132](https://github.com/bitnami/charts/commit/23e51328688dfd7a46557cdf9210d2e9854a73e9)), closes [#23916](https://github.com/bitnami/charts/issues/23916)

## <small>1.5.3 (2024-02-23)</small>

* [bitnami/gitea] Release 1.5.3 updating components versions (#23868) ([a5308b8](https://github.com/bitnami/charts/commit/a5308b8f4cab618db996832adcdc1dc201b6ff0c)), closes [#23868](https://github.com/bitnami/charts/issues/23868)

## <small>1.5.2 (2024-02-21)</small>

* [bitnami/gitea] Release 1.5.2 updating components versions (#23754) ([c5615e2](https://github.com/bitnami/charts/commit/c5615e23ea1d07d721eba4c376209ef205776c0a)), closes [#23754](https://github.com/bitnami/charts/issues/23754)

## <small>1.5.1 (2024-02-21)</small>

* [bitnami/gitea] feat: :sparkles: :lock: Add resource preset support (#23453) ([018d8ab](https://github.com/bitnami/charts/commit/018d8abb412a546b478b94630c6dbbfcc05997e7)), closes [#23453](https://github.com/bitnami/charts/issues/23453)
* [bitnami/gitea] Release 1.5.1 updating components versions (#23650) ([9e9d449](https://github.com/bitnami/charts/commit/9e9d449cf1a7088905489cf34c7ae9f10fd39064)), closes [#23650](https://github.com/bitnami/charts/issues/23650)

## 1.5.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## <small>1.4.9 (2024-02-07)</small>

* [bitnami/gitea] Release 1.4.9 updating components versions (#23271) ([0158b2c](https://github.com/bitnami/charts/commit/0158b2c6682196db2d954e7e12cd283f2dbaa1cf)), closes [#23271](https://github.com/bitnami/charts/issues/23271)

## <small>1.4.8 (2024-02-07)</small>

* [bitnami/gitea] Release 1.4.8 updating components versions (#23228) ([221bae0](https://github.com/bitnami/charts/commit/221bae067be53a812f8f644b55c8ac93988c4cd3)), closes [#23228](https://github.com/bitnami/charts/issues/23228)

## <small>1.4.7 (2024-02-02)</small>

* [bitnami/gitea] Release 1.4.7 updating components versions (#23093) ([10194a8](https://github.com/bitnami/charts/commit/10194a8f2e0f275434e36c2800b06b839b91a237)), closes [#23093](https://github.com/bitnami/charts/issues/23093)

## <small>1.4.6 (2024-02-02)</small>

* [bitnami/gitea] Release 1.4.6 updating components versions (#23041) ([97376fb](https://github.com/bitnami/charts/commit/97376fbfdb2eeb344a712dff327a0cb4ecc032e1)), closes [#23041](https://github.com/bitnami/charts/issues/23041)

## <small>1.4.5 (2024-01-30)</small>

* [bitnami/gitea] Release 1.4.5 updating components versions (#22921) ([7f596e4](https://github.com/bitnami/charts/commit/7f596e456e7bd0e31a0875ee350048974929d298)), closes [#22921](https://github.com/bitnami/charts/issues/22921)

## <small>1.4.4 (2024-01-30)</small>

* [bitnami/gitea] Release 1.4.4 updating components versions (#22910) ([f460675](https://github.com/bitnami/charts/commit/f460675b57ae6e4fed2b4a2c81f3a0564e8eb964)), closes [#22910](https://github.com/bitnami/charts/issues/22910)

## <small>1.4.3 (2024-01-30)</small>

* [bitnami/gitea] Release 1.4.3 updating components versions (#22847) ([41a758d](https://github.com/bitnami/charts/commit/41a758d0973cbf91229f60f597221f180c08baf0)), closes [#22847](https://github.com/bitnami/charts/issues/22847)

## <small>1.4.2 (2024-01-27)</small>

* [bitnami/gitea] Release 1.4.2 updating components versions (#22776) ([fcaeae9](https://github.com/bitnami/charts/commit/fcaeae9dce7bb08136d2e532b77787a0a7d2c85c)), closes [#22776](https://github.com/bitnami/charts/issues/22776)

## <small>1.4.1 (2024-01-25)</small>

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/gitea] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22591) ([dee04a0](https://github.com/bitnami/charts/commit/dee04a0df2eb4510bda6b0a3bb8c4392de41e16e)), closes [#22591](https://github.com/bitnami/charts/issues/22591)

## 1.4.0 (2024-01-22)

* [bitnami/gitea] fix: :lock: Move service-account token auto-mount to pod declaration (#22403) ([a6d22fe](https://github.com/bitnami/charts/commit/a6d22febb182f28f532e62bbe98b57d643ce1650)), closes [#22403](https://github.com/bitnami/charts/issues/22403)

## <small>1.3.2 (2024-01-18)</small>

* [bitnami/gitea] Release 1.3.2 updating components versions (#22274) ([72aff85](https://github.com/bitnami/charts/commit/72aff85c8e6f308efdb8769f7e1f84d06b46dd57)), closes [#22274](https://github.com/bitnami/charts/issues/22274)

## <small>1.3.1 (2024-01-17)</small>

* [bitnami/gitea] Release 1.3.1 updating components versions (#22241) ([5a49422](https://github.com/bitnami/charts/commit/5a49422c05c4504053365d4a0849e8254d758001)), closes [#22241](https://github.com/bitnami/charts/issues/22241)

## 1.3.0 (2024-01-16)

* [bitnami/gitea] fix: :lock: Improve podSecurityContext and containerSecurityContext with essential s ([8e622af](https://github.com/bitnami/charts/commit/8e622af5f8323487c1be2488ec1d937142674ca5)), closes [#22122](https://github.com/bitnami/charts/issues/22122)

## <small>1.2.11 (2024-01-12)</small>

* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/gitea] fix: :lock: Do not automount the service account token unless necessary (#22041) ([72985fc](https://github.com/bitnami/charts/commit/72985fc695d979575a9212c53e836d97b0242856)), closes [#22041](https://github.com/bitnami/charts/issues/22041)

## <small>1.2.10 (2024-01-10)</small>

* [bitnami/*] Fix docs.bitnami.com broken links (#21901) ([f35506d](https://github.com/bitnami/charts/commit/f35506d2dadee4f097986e7792df1f53ab215b5d)), closes [#21901](https://github.com/bitnami/charts/issues/21901)
* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)
* [bitnami/gitea] Release 1.2.10 updating components versions (#21941) ([0ace7f4](https://github.com/bitnami/charts/commit/0ace7f4a7fd2cc82042e8c0e978d0a5e14128b17)), closes [#21941](https://github.com/bitnami/charts/issues/21941)

## <small>1.2.9 (2023-12-21)</small>

* [bitnami/gitea] Release 1.2.9 updating components versions (#21715) ([245cc37](https://github.com/bitnami/charts/commit/245cc37f8e89b54df838e7c106cf17185d589b4e)), closes [#21715](https://github.com/bitnami/charts/issues/21715)

## <small>1.2.8 (2023-12-12)</small>

* [bitnami/gitea] Release 1.2.8 updating components versions (#21536) ([93feee7](https://github.com/bitnami/charts/commit/93feee74fcef9afac4d99108cc3c0ac9b68d3da5)), closes [#21536](https://github.com/bitnami/charts/issues/21536)

## <small>1.2.7 (2023-12-07)</small>

* [bitnami/gitea] Release 1.2.7 updating components versions (#21446) ([f030fea](https://github.com/bitnami/charts/commit/f030fea9a0747a2b0e1ba880fa6970bdeda65031)), closes [#21446](https://github.com/bitnami/charts/issues/21446)

## <small>1.2.6 (2023-11-26)</small>

* [bitnami/gitea] Release 1.2.6 updating components versions (#21259) ([dc420cd](https://github.com/bitnami/charts/commit/dc420cdfacd467864c0a23b17fee6d91315aad38)), closes [#21259](https://github.com/bitnami/charts/issues/21259)

## <small>1.2.5 (2023-11-23)</small>

* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/gitea] Release 1.2.5 (#21220) ([c242f29](https://github.com/bitnami/charts/commit/c242f29f5a19d869ce0378395915b465ff6170db)), closes [#21220](https://github.com/bitnami/charts/issues/21220)

## <small>1.2.4 (2023-11-18)</small>

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/gitea] Release 1.2.4 updating components versions (#21048) ([8adc26c](https://github.com/bitnami/charts/commit/8adc26c7e034fbd5fc564f48f6a8ecb7d3a8fee2)), closes [#21048](https://github.com/bitnami/charts/issues/21048)

## <small>1.2.3 (2023-11-09)</small>

* [bitnami/gitea] Release 1.2.3 updating components versions (#20859) ([79dc246](https://github.com/bitnami/charts/commit/79dc246a8da5cec23b2d09b91205276385949eef)), closes [#20859](https://github.com/bitnami/charts/issues/20859)

## <small>1.2.2 (2023-11-09)</small>

* [bitnami/gitea] Release 1.2.2 updating components versions (#20833) ([de57cec](https://github.com/bitnami/charts/commit/de57cecee80681ddf1afb86a699174a0d0babb6e)), closes [#20833](https://github.com/bitnami/charts/issues/20833)

## <small>1.2.1 (2023-11-08)</small>

* [bitnami/gitea] Release 1.2.1 updating components versions (#20729) ([7b504d6](https://github.com/bitnami/charts/commit/7b504d65d8e3833a441f35030a168b441737ce38)), closes [#20729](https://github.com/bitnami/charts/issues/20729)

## 1.2.0 (2023-11-07)

* [bitnami/gitea] Remove HA support (#20526) ([21469f5](https://github.com/bitnami/charts/commit/21469f5fe69c6a5c5718434c544e8acb46772b6b)), closes [#20526](https://github.com/bitnami/charts/issues/20526)

## 1.1.0 (2023-10-31)

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [bitnami/gitea] feat: :sparkles: Add support for PSA restricted policy (#20442) ([5fd7a29](https://github.com/bitnami/charts/commit/5fd7a2961230a5ddaa8a3f27319ecd7402496d6b)), closes [#20442](https://github.com/bitnami/charts/issues/20442)

## <small>1.0.6 (2023-10-12)</small>

* [bitnami/gitea] Release 1.0.6 (#20131) ([2a46c21](https://github.com/bitnami/charts/commit/2a46c212219d238520f87ab4f9f2753b69031c4b)), closes [#20131](https://github.com/bitnami/charts/issues/20131)

## <small>1.0.5 (2023-10-11)</small>

* [bitnami/gitea] Release 1.0.5 (#20039) ([9f02182](https://github.com/bitnami/charts/commit/9f0218230912f24a9ab1395d304942bd683665bb)), closes [#20039](https://github.com/bitnami/charts/issues/20039)

## <small>1.0.4 (2023-10-09)</small>

* [bitnami/gitea] Release 1.0.4 (#19908) ([4a2e661](https://github.com/bitnami/charts/commit/4a2e6612bd36298c9181477e8c7bca1fdf937763)), closes [#19908](https://github.com/bitnami/charts/issues/19908)

## <small>1.0.3 (2023-10-09)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/gitea] Release 1.0.3 (#19823) ([5229cef](https://github.com/bitnami/charts/commit/5229cef0e8901b4edb23296b6bab21bafedb3731)), closes [#19823](https://github.com/bitnami/charts/issues/19823)

## <small>1.0.2 (2023-10-05)</small>

* [bitnami/gitea] Release 1.0.2 (#19764) ([5b7faaf](https://github.com/bitnami/charts/commit/5b7faaf16e311d88c9bfaf2a4737cbfc977afdf8)), closes [#19764](https://github.com/bitnami/charts/issues/19764)

## <small>1.0.1 (2023-10-03)</small>

* [bitnami/gitea] Release 1.0.1 (#19709) ([ff957f7](https://github.com/bitnami/charts/commit/ff957f716a29aa59563fcd6627e5a5a3fa13cc7d)), closes [#19709](https://github.com/bitnami/charts/issues/19709)

## 1.0.0 (2023-09-29)

* [bitnami/gitea] Update dependencies (#19613) ([1bb3840](https://github.com/bitnami/charts/commit/1bb3840f49b4a511e790b95a1946072f9777f95a)), closes [#19613](https://github.com/bitnami/charts/issues/19613)

## <small>0.4.3 (2023-09-26)</small>

* [bitnami/*] Update readme files (#19277) ([e56aeb2](https://github.com/bitnami/charts/commit/e56aeb2fbfbf5b6e42375db48cc7ae1ef1c3a823)), closes [#19277](https://github.com/bitnami/charts/issues/19277)
* [bitnami/gitea] Release 0.4.3 (#19544) ([59e9d48](https://github.com/bitnami/charts/commit/59e9d487e8ca9609b58cc1f447b0440251eebfbd)), closes [#19544](https://github.com/bitnami/charts/issues/19544)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>0.4.2 (2023-09-08)</small>

* [bitnami/gitea] Release 0.4.2 (#19198) ([b20e40f](https://github.com/bitnami/charts/commit/b20e40f55f1c43458c1675d9772c6cb4778e3d2c)), closes [#19198](https://github.com/bitnami/charts/issues/19198)

## <small>0.4.1 (2023-09-07)</small>

* [bitnami/gitea: Use merge helper]: (#19042) ([6be3273](https://github.com/bitnami/charts/commit/6be3273e1288c6f88c84b444f9d23415616994c0)), closes [#19042](https://github.com/bitnami/charts/issues/19042)

## 0.4.0 (2023-08-24)

* [bitnami/gitea] Support for customizing standard labels (#18486) ([91b2b09](https://github.com/bitnami/charts/commit/91b2b0981c65b4a708e044ebb2cdd660473d3605)), closes [#18486](https://github.com/bitnami/charts/issues/18486)

## <small>0.3.9 (2023-08-21)</small>

* [bitnami/gitea] Release 0.3.9 (#18763) ([de2acba](https://github.com/bitnami/charts/commit/de2acbaab8a340993d1eff39b7c8628458f4ae46)), closes [#18763](https://github.com/bitnami/charts/issues/18763)

## <small>0.3.8 (2023-08-17)</small>

* [bitnami/gitea] Release 0.3.8 (#18520) ([f429486](https://github.com/bitnami/charts/commit/f4294866b78693b02f4fa30c30f61258ed66c90e)), closes [#18520](https://github.com/bitnami/charts/issues/18520)

## <small>0.3.7 (2023-07-30)</small>

* [bitnami/gitea] Release 0.3.7 (#18032) ([b0fb130](https://github.com/bitnami/charts/commit/b0fb1301b8b273e2181867b6c21d30784ad0528e)), closes [#18032](https://github.com/bitnami/charts/issues/18032)

## <small>0.3.6 (2023-07-15)</small>

* [bitnami/gitea] Release 0 (#17607) ([e4ea569](https://github.com/bitnami/charts/commit/e4ea569fbad3e4f13cbaaff331c996e6f8c8ca4a)), closes [#17607](https://github.com/bitnami/charts/issues/17607)

## <small>0.3.5 (2023-07-04)</small>

* [bitnami/gitea] Release 0.3.5 (#17480) ([14ab5f6](https://github.com/bitnami/charts/commit/14ab5f6a7c66f9d2e17e9da1aaed9049bf72c30b)), closes [#17480](https://github.com/bitnami/charts/issues/17480)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)

## <small>0.3.4 (2023-06-22)</small>

* [bitnami/gitea] Release 0.3.4 (#17312) ([84915f5](https://github.com/bitnami/charts/commit/84915f503a65a1e405b6ea71fc5d9c4573fd43fd)), closes [#17312](https://github.com/bitnami/charts/issues/17312)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## <small>0.3.3 (2023-06-20)</small>

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/gitea] Release 0.3.3 (#17206) ([6d8fe4b](https://github.com/bitnami/charts/commit/6d8fe4b7a083ac12003dff2ed2e2b9ba3b8f4806)), closes [#17206](https://github.com/bitnami/charts/issues/17206)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)

## <small>0.3.2 (2023-05-21)</small>

* [bitnami/gitea] Release 0.3.2 (#16765) ([76bfbaa](https://github.com/bitnami/charts/commit/76bfbaa32d7d198f84ec0bbb9c23996722d1bea3)), closes [#16765](https://github.com/bitnami/charts/issues/16765)

## <small>0.3.1 (2023-05-16)</small>

* [bitnami/gitea] Release 0.3.1 (#16685) ([ec2453f](https://github.com/bitnami/charts/commit/ec2453f64953c298a20af7ccf9734b1ebb5b0838)), closes [#16685](https://github.com/bitnami/charts/issues/16685)
* Add wording for enterprise page (#16560) ([8f22774](https://github.com/bitnami/charts/commit/8f2277440b976d52785ba9149762ad8620a73d1f)), closes [#16560](https://github.com/bitnami/charts/issues/16560)

## 0.3.0 (2023-05-09)

* [bitnami/several] Adapt Chart.yaml to set desired OCI annotations (#16546) ([fc9b18f](https://github.com/bitnami/charts/commit/fc9b18f2e98805d4df629acbcde696f44f973344)), closes [#16546](https://github.com/bitnami/charts/issues/16546)

## <small>0.2.3 (2023-05-09)</small>

* [bitnami/gitea] Release 0.2.3 (#16451) ([22a2fc7](https://github.com/bitnami/charts/commit/22a2fc7863dd5c8ba30c1cc0fcd1605f293ef0af)), closes [#16451](https://github.com/bitnami/charts/issues/16451)

## <small>0.2.2 (2023-05-03)</small>

* [bitnami/gitea] Release 0.2.2 (#16368) ([cff0400](https://github.com/bitnami/charts/commit/cff040072ed216a1ac2918890c756ed991defe4f)), closes [#16368](https://github.com/bitnami/charts/issues/16368)

## <small>0.2.1 (2023-04-29)</small>

* [bitnami/gitea] Release 0.2.1 (#16270) ([eb5f298](https://github.com/bitnami/charts/commit/eb5f2987646cb994ba5236c5b7a452c261b9f641)), closes [#16270](https://github.com/bitnami/charts/issues/16270)

## 0.2.0 (2023-04-20)

* [bitnami/*] Make Helm charts 100% OCI (#15998) ([8841510](https://github.com/bitnami/charts/commit/884151035efcbf2e1b3206e7def85511073fb57d)), closes [#15998](https://github.com/bitnami/charts/issues/15998)

## <small>0.1.19 (2023-04-13)</small>

* [bitnami/gitea] Release 0.1.19 (#16039) ([bef8495](https://github.com/bitnami/charts/commit/bef8495d4f840078bc772536c3b663139d6a387d)), closes [#16039](https://github.com/bitnami/charts/issues/16039)

## <small>0.1.18 (2023-04-01)</small>

* [bitnami/gitea] Release 0.1.18 (#15849) ([471df7f](https://github.com/bitnami/charts/commit/471df7fbd1bb6c91c72cb0b30d0e3153d148a3ba)), closes [#15849](https://github.com/bitnami/charts/issues/15849)

## <small>0.1.17 (2023-03-30)</small>

* [bitnami/gitea] Release 0.1.17 (#15815) ([c2334c8](https://github.com/bitnami/charts/commit/c2334c8104e87c1f642c6a26537331a0b1576454)), closes [#15815](https://github.com/bitnami/charts/issues/15815)

## <small>0.1.16 (2023-03-29)</small>

* [bitnami/gitea] Release 0.1.16 (#15789) ([1ccec51](https://github.com/bitnami/charts/commit/1ccec51b06f6ea4dff63eaa148878582f08684a1)), closes [#15789](https://github.com/bitnami/charts/issues/15789)

## <small>0.1.15 (2023-03-18)</small>

* [bitnami/gitea] Release 0.1.15 (#15579) ([72c25df](https://github.com/bitnami/charts/commit/72c25df183b7d79f8186338b56176769cf97c11b)), closes [#15579](https://github.com/bitnami/charts/issues/15579)

## <small>0.1.14 (2023-03-08)</small>

* [bitnami/charts] Apply linter to README files (#15357) ([0e29e60](https://github.com/bitnami/charts/commit/0e29e600d3adc8b1b46e506eccb3decfab3b4e63)), closes [#15357](https://github.com/bitnami/charts/issues/15357)
* [bitnami/gitea] Release 0.1.14 (#15367) ([0323e25](https://github.com/bitnami/charts/commit/0323e25b36170a944a8f8a2b13ad0f307deeb025)), closes [#15367](https://github.com/bitnami/charts/issues/15367)

## <small>0.1.13 (2023-03-01)</small>

* [bitnami/gitea] Release 0.1.13 (#15236) ([af18f38](https://github.com/bitnami/charts/commit/af18f380ed83ba269392c5310c37b437b68f870b)), closes [#15236](https://github.com/bitnami/charts/issues/15236)

## <small>0.1.12 (2023-02-23)</small>

* [bitnami/gitea] Release 0.1.12 (#15113) ([eec101c](https://github.com/bitnami/charts/commit/eec101c8e73667162c524ad959519d5bd07bb059)), closes [#15113](https://github.com/bitnami/charts/issues/15113)

## <small>0.1.11 (2023-02-20)</small>

* [bitnami/gitea] Release 0.1.11 (#15059) ([fb797bc](https://github.com/bitnami/charts/commit/fb797bcbd95a4b95e9de2269887b34cd711153dc)), closes [#15059](https://github.com/bitnami/charts/issues/15059)

## <small>0.1.10 (2023-02-17)</small>

* [bitnami/*] Fix markdown linter issues (#14874) ([a51e0e8](https://github.com/bitnami/charts/commit/a51e0e8d35495b907f3e70dd2f8e7c3bcbf4166a)), closes [#14874](https://github.com/bitnami/charts/issues/14874)
* [bitnami/*] Fix markdown linter issues 2 (#14890) ([aa96572](https://github.com/bitnami/charts/commit/aa9657237ee8df4a46db0d7fdf8a23230dd6902a)), closes [#14890](https://github.com/bitnami/charts/issues/14890)
* [bitnami/*] Remove unexpected extra spaces (#14873) ([c97c714](https://github.com/bitnami/charts/commit/c97c714887380d47eae7bfeff316bf01595ecd1d)), closes [#14873](https://github.com/bitnami/charts/issues/14873)
* [bitnami/gitea] Release 0.1.10 (#14955) ([40a7fe8](https://github.com/bitnami/charts/commit/40a7fe8a19ce8c657ceb4ded0e916cad7c5c3c67)), closes [#14955](https://github.com/bitnami/charts/issues/14955)

## <small>0.1.9 (2023-02-02)</small>

* [bitnami/*] Change copyright date (#14682) ([add4ec7](https://github.com/bitnami/charts/commit/add4ec701108ac36ed4de2dffbdf407a0d091067)), closes [#14682](https://github.com/bitnami/charts/issues/14682)
* [bitnami/gitea] Don't regenerate self-signed certs on upgrade (#14622) ([858e766](https://github.com/bitnami/charts/commit/858e766b1e69fbf0b3b50463c292f8ccb5caecea)), closes [#14622](https://github.com/bitnami/charts/issues/14622)

## <small>0.1.8 (2023-01-24)</small>

* [bitnami/gitea] Release 0.1.8 (#14506) ([dd230b3](https://github.com/bitnami/charts/commit/dd230b354fb853f7a7fdb00e1df3e4956d934a42)), closes [#14506](https://github.com/bitnami/charts/issues/14506)

## <small>0.1.7 (2023-01-23)</small>

* [bitnami/*] Unify READMEs (#14472) ([2064fb8](https://github.com/bitnami/charts/commit/2064fb8dcc78a845cdede8211af8c3cc52551161)), closes [#14472](https://github.com/bitnami/charts/issues/14472)
* [bitnami/gitea] Release 0.1.7 (#14458) ([b043d8e](https://github.com/bitnami/charts/commit/b043d8ef4d51e44cc303ee72de6981b5bf8d4ff0)), closes [#14458](https://github.com/bitnami/charts/issues/14458)

## <small>0.1.6 (2023-01-18)</small>

* [bitnami/*] Add license annotation and remove obsolete engine parameter (#14293) ([da2a794](https://github.com/bitnami/charts/commit/da2a7943bae95b6e9b5b4ed972c15e990b69fdb0)), closes [#14293](https://github.com/bitnami/charts/issues/14293)
* [bitnami/*] Change licenses annotation format (#14377) ([0ab7608](https://github.com/bitnami/charts/commit/0ab760862c660fcc78cffadf8e1d8cdd70881473)), closes [#14377](https://github.com/bitnami/charts/issues/14377)
* [bitnami/gitea] Release 0.1.6 (#14413) ([01ed0f5](https://github.com/bitnami/charts/commit/01ed0f590e9eb3ee435f979447fdaf48c94c4b5d)), closes [#14413](https://github.com/bitnami/charts/issues/14413)

## <small>0.1.5 (2023-01-11)</small>

* [bitnami/gitea] Bump version chart to force new publish (#14288) ([c34b2c9](https://github.com/bitnami/charts/commit/c34b2c941a4ea029e8ceeb44b2d027c27549ce0a)), closes [#14288](https://github.com/bitnami/charts/issues/14288)

## <small>0.1.4 (2023-01-11)</small>

* [bitnami/gitea] Release 0.1.4 (#14284) ([126c1ea](https://github.com/bitnami/charts/commit/126c1ea339577f2db4035a6b7de55e89ea950611)), closes [#14284](https://github.com/bitnami/charts/issues/14284)

## <small>0.1.3 (2022-12-30)</small>

* [bitnami/gitea] Release 0.1.3 (#14136) ([8c78326](https://github.com/bitnami/charts/commit/8c783264c6e635a5ac8fb75caf331babf5b7f9e0)), closes [#14136](https://github.com/bitnami/charts/issues/14136)

## <small>0.1.2 (2022-12-22)</small>

* [bitnami/gitea] Release 0.1.2 (#14066) ([1e92a49](https://github.com/bitnami/charts/commit/1e92a496bfecd923624ecf481e7e6cc0857e52f4)), closes [#14066](https://github.com/bitnami/charts/issues/14066)

## <small>0.1.1 (2022-11-28)</small>

* [bitnami/gitea] Release 0.1.1 (#13721) ([f098e2b](https://github.com/bitnami/charts/commit/f098e2ba71aa824f267fb32509b123aa7961a118)), closes [#13721](https://github.com/bitnami/charts/issues/13721)

## 0.1.0 (2022-11-27)

* [bitnami/gitea] feat: :tada: Add chart (#13690) ([4803114](https://github.com/bitnami/charts/commit/4803114ff9cfa38ca4d5b7ca3a238b4ccda34b5b)), closes [#13690](https://github.com/bitnami/charts/issues/13690) [#13683](https://github.com/bitnami/charts/issues/13683) [#13685](https://github.com/bitnami/charts/issues/13685) [#13679](https://github.com/bitnami/charts/issues/13679) [#13684](https://github.com/bitnami/charts/issues/13684) [#13689](https://github.com/bitnami/charts/issues/13689) [#13691](https://github.com/bitnami/charts/issues/13691) [#13692](https://github.com/bitnami/charts/issues/13692) [#13593](https://github.com/bitnami/charts/issues/13593) [#13646](https://github.com/bitnami/charts/issues/13646) [#13695](https://github.com/bitnami/charts/issues/13695) [#13636](https://github.com/bitnami/charts/issues/13636)
