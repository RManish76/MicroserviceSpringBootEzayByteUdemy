# Changelog

## 3.0.18 (2025-08-14)

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references ([#35954](https://github.com/bitnami/charts/pull/35954))

## <small>3.0.17 (2025-08-13)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#35848) ([72247de](https://github.com/bitnami/charts/commit/72247de2a2973fe9e9bc73994b6e0f7f8726052e)), closes [#35848](https://github.com/bitnami/charts/issues/35848)

## <small>3.0.16 (2025-08-13)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#35801) ([614bee8](https://github.com/bitnami/charts/commit/614bee8946c1cd2a0e07573adc3ca16100769402)), closes [#35801](https://github.com/bitnami/charts/issues/35801)

## <small>3.0.15 (2025-08-07)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#35608) ([a609c88](https://github.com/bitnami/charts/commit/a609c880beb1a190175c9cc1f1d2506af81f2e87)), closes [#35608](https://github.com/bitnami/charts/issues/35608)

## <small>3.0.14 (2025-08-07)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#35482) ([bacdd8a](https://github.com/bitnami/charts/commit/bacdd8a19662b795925fd51e71537d5519478930)), closes [#35482](https://github.com/bitnami/charts/issues/35482)

## <small>3.0.13 (2025-07-31)</small>

* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#35359) ([86ee261](https://github.com/bitnami/charts/commit/86ee26146c0bf8db8b3311ad5f8e7281f33da6a5)), closes [#35359](https://github.com/bitnami/charts/issues/35359)

## <small>3.0.12 (2025-07-29)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#35322) ([7fef3a3](https://github.com/bitnami/charts/commit/7fef3a331ef1a241b95c771d04ed063c043fc9ff)), closes [#35322](https://github.com/bitnami/charts/issues/35322)

## <small>3.0.11 (2025-07-17)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#35180) ([ce3edd4](https://github.com/bitnami/charts/commit/ce3edd43c6daf304ca1bedc4c8d6bf6fcc96ba38)), closes [#35180](https://github.com/bitnami/charts/issues/35180)

## <small>3.0.10 (2025-07-15)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#35094) ([ad26dd6](https://github.com/bitnami/charts/commit/ad26dd6a7ac88070f982c1ea7aa697d3e00f23b7)), closes [#35094](https://github.com/bitnami/charts/issues/35094)

## <small>3.0.9 (2025-07-09)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#34900) ([03d90ee](https://github.com/bitnami/charts/commit/03d90ee1c5ff477cf71f78870ec1579e647a4000)), closes [#34900](https://github.com/bitnami/charts/issues/34900)

## <small>3.0.8 (2025-06-30)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#34712) ([76c1bbb](https://github.com/bitnami/charts/commit/76c1bbbda80d9c135300217dbc0cb4820de5e1d6)), closes [#34712](https://github.com/bitnami/charts/issues/34712)

## <small>3.0.7 (2025-06-26)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#34658) ([1d807af](https://github.com/bitnami/charts/commit/1d807af0e1fa0ceb6add82c619e1f7cd806332df)), closes [#34658](https://github.com/bitnami/charts/issues/34658)

## <small>3.0.6 (2025-06-24)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#34607) ([fb2df44](https://github.com/bitnami/charts/commit/fb2df44f9108572883a30844f3a2c73cd8ecd732)), closes [#34607](https://github.com/bitnami/charts/issues/34607)

## <small>3.0.5 (2025-06-19)</small>

* [bitnami/grafana-mimir] Typo in grafana-mimir's querier deployment (#34531) ([5c480e5](https://github.com/bitnami/charts/commit/5c480e5015e2c3d4d75d22bccf94ef59595d68f7)), closes [#34531](https://github.com/bitnami/charts/issues/34531)

## <small>3.0.4 (2025-06-13)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#34443) ([005bea0](https://github.com/bitnami/charts/commit/005bea081d2ba1e85b614fd8781cc38df6b831b0)), closes [#34443](https://github.com/bitnami/charts/issues/34443)

## <small>3.0.3 (2025-06-10)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#34313) ([ae17ab8](https://github.com/bitnami/charts/commit/ae17ab842eab4f77068336672021f2e59c551137)), closes [#34313](https://github.com/bitnami/charts/issues/34313)

## <small>3.0.2 (2025-06-09)</small>

* [bitnami/grafana-mimir] Disable MinIO Console (#34271) ([ed1abbb](https://github.com/bitnami/charts/commit/ed1abbbe1270c5a1a951659fa9926aafb2b98cf4)), closes [#34271](https://github.com/bitnami/charts/issues/34271)

## <small>3.0.1 (2025-06-06)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#34163) ([9c81957](https://github.com/bitnami/charts/commit/9c819579e8288e9f1f2f16f1fae8acf19fda6a40)), closes [#34163](https://github.com/bitnami/charts/issues/34163)

## 3.0.0 (2025-06-04)

* [bitnami/grafana-mimir] feat: major version due to Minio major bump (#34087) ([c5306dd](https://github.com/bitnami/charts/commit/c5306dd791e341c5a116d95fba3f166aeb8c1465)), closes [#34087](https://github.com/bitnami/charts/issues/34087)

## <small>2.0.7 (2025-05-30)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#33997) ([dcc9889](https://github.com/bitnami/charts/commit/dcc98897c81cd170887867554a89ba4187f39791)), closes [#33997](https://github.com/bitnami/charts/issues/33997)

## <small>2.0.6 (2025-05-29)</small>

* [bitnami/grafana-mimir] :zap: :arrow_up: Update dependency references (#33964) ([156851c](https://github.com/bitnami/charts/commit/156851ca47d393009874ddc2d4e75f5ab69092f3)), closes [#33964](https://github.com/bitnami/charts/issues/33964)
* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)

## <small>2.0.5 (2025-05-07)</small>

* [bitnami/grafana-mimir] Release 2.0.5 (#33514) ([200a738](https://github.com/bitnami/charts/commit/200a7389e257d1a3868071128884a10c53e48cfb)), closes [#33514](https://github.com/bitnami/charts/issues/33514)

## <small>2.0.4 (2025-05-06)</small>

* [bitnami/grafana-mimir] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references ( ([0790fef](https://github.com/bitnami/charts/commit/0790fef042b5b787723602e74ca213b7a2b51155)), closes [#33369](https://github.com/bitnami/charts/issues/33369)

## <small>2.0.3 (2025-04-28)</small>

* [bitnami/grafana-mimir] Release 2.0.3 (#33210) ([9b60c4b](https://github.com/bitnami/charts/commit/9b60c4b1690678d834c671139c90cdd69d891d31)), closes [#33210](https://github.com/bitnami/charts/issues/33210)

## <small>2.0.2 (2025-04-22)</small>

* [bitnami/grafana-mimir] Release 2.0.2 (#33115) ([0212aaf](https://github.com/bitnami/charts/commit/0212aaf9416d15596021b994171853e03da65922)), closes [#33115](https://github.com/bitnami/charts/issues/33115)

## <small>2.0.1 (2025-04-01)</small>

* [bitnami/grafana-mimir] Release 2.0.1 (#32732) ([1138fee](https://github.com/bitnami/charts/commit/1138feec6afe8ec7ad763c29f0798f8a2bdf01b8)), closes [#32732](https://github.com/bitnami/charts/issues/32732)

## 2.0.0 (2025-04-01)

* [bitnami/grafana-mimir] Bump MinIO major version 16.x.x (#32699) ([03e195b](https://github.com/bitnami/charts/commit/03e195bff6757cc3f7ceef76e6179d51d0be8a4e)), closes [#32699](https://github.com/bitnami/charts/issues/32699)

## <small>1.4.6 (2025-03-31)</small>

* [bitnami/grafana-mimir] Release 1.4.6 (#32689) ([2bae692](https://github.com/bitnami/charts/commit/2bae6925d2c4b85b604e60258b6e78db7d4f8826)), closes [#32689](https://github.com/bitnami/charts/issues/32689)

## <small>1.4.5 (2025-03-13)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/grafana-mimir] Release 1.4.5 (#32448) ([8739ad6](https://github.com/bitnami/charts/commit/8739ad6fa4024109b5014dd86af88dc0d968d63b)), closes [#32448](https://github.com/bitnami/charts/issues/32448)

## <small>1.4.4 (2025-03-05)</small>

* [bitnami/grafana-mimir] Release 1.4.4 (#32291) ([90dd2f1](https://github.com/bitnami/charts/commit/90dd2f1c5b0c9a8fc43b281545ca3936c0a3b310)), closes [#32291](https://github.com/bitnami/charts/issues/32291)

## <small>1.4.3 (2025-02-19)</small>

* [bitnami/grafana-mimir] Release 1.4.3 (#31999) ([b3ca92d](https://github.com/bitnami/charts/commit/b3ca92d8ce4143b3fdb25f2d7a6909d002d7271c)), closes [#31999](https://github.com/bitnami/charts/issues/31999)

## <small>1.4.2 (2025-02-12)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/grafana-mimir] Release 1.4.2 (#31889) ([7a5eb92](https://github.com/bitnami/charts/commit/7a5eb922f54c3eac0387838a282077d464abcd70)), closes [#31889](https://github.com/bitnami/charts/issues/31889)

## <small>1.4.1 (2025-02-04)</small>

* [bitnami/grafana-mimir] Release 1.4.1 (#31754) ([f074715](https://github.com/bitnami/charts/commit/f074715115f99341605d19b2b132ca15e66a61f7)), closes [#31754](https://github.com/bitnami/charts/issues/31754)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## 1.4.0 (2025-01-29)

* [bitnami/grafana-mimir] feature(minio): Bump MinIO subchart (#31659) ([423f680](https://github.com/bitnami/charts/commit/423f68052a6aeb6a2f389b560515f74570143b3c)), closes [#31659](https://github.com/bitnami/charts/issues/31659)

## <small>1.3.3 (2025-01-24)</small>

* [bitnami/grafana-mimir] Release 1.3.3 (#31554) ([576476f](https://github.com/bitnami/charts/commit/576476fb99dd6f2e7b57ee913d06967320750066)), closes [#31554](https://github.com/bitnami/charts/issues/31554)

## <small>1.3.2 (2025-01-17)</small>

* [bitnami/grafana-mimir] Release 1.3.2 (#31421) ([a6aa537](https://github.com/bitnami/charts/commit/a6aa537eb1bd157e41a3805b2dd3b1a09d613ae2)), closes [#31421](https://github.com/bitnami/charts/issues/31421)

## <small>1.3.1 (2025-01-03)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/grafana-mimir] Release 1.3.1 (#31205) ([9e53dc4](https://github.com/bitnami/charts/commit/9e53dc4f22e3d226d08ec3dec07cbfcbe04029ef)), closes [#31205](https://github.com/bitnami/charts/issues/31205)

## 1.3.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/grafana-mimir] Detect non-standard images (#30887) ([b56f760](https://github.com/bitnami/charts/commit/b56f7600bebb18d442055540590355888463d60f)), closes [#30887](https://github.com/bitnami/charts/issues/30887)

## <small>1.2.23 (2024-12-03)</small>

* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/*] docs: :memo: Add "Prometheus metrics" (batch 2) (#30662) ([50e0570](https://github.com/bitnami/charts/commit/50e0570f98ab15308af7910b405baa4480e5fe3f)), closes [#30662](https://github.com/bitnami/charts/issues/30662)
* [bitnami/grafana-mimir] Release 1.2.23 (#30753) ([e68da81](https://github.com/bitnami/charts/commit/e68da81a7fd7ae43414ca2e4ed9f7d8e169acd6e)), closes [#30753](https://github.com/bitnami/charts/issues/30753)

## <small>1.2.22 (2024-11-14)</small>

* [bitnami/grafana-mimir] Release 1.2.22 (#30450) ([d9d2d92](https://github.com/bitnami/charts/commit/d9d2d921e046f4ad56e35f7739856e4c3f9819c5)), closes [#30450](https://github.com/bitnami/charts/issues/30450)

## <small>1.2.21 (2024-11-07)</small>

* [bitnami/grafana-mimir] Release 1.2.21 (#30266) ([10d9b5f](https://github.com/bitnami/charts/commit/10d9b5f579258a6cf54f8660b3f6adbb26430ed6)), closes [#30266](https://github.com/bitnami/charts/issues/30266)

## <small>1.2.20 (2024-11-01)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/grafana-mimir] Release 1.2.20 (#30174) ([393e256](https://github.com/bitnami/charts/commit/393e256348e094d46c2efd1e3bbe85feb98dfc1d)), closes [#30174](https://github.com/bitnami/charts/issues/30174)

## <small>1.2.19 (2024-10-21)</small>

* [bitnami/grafana-mimir] Release 1.2.19 (#30018) ([79e1e9b](https://github.com/bitnami/charts/commit/79e1e9bb690850d0a40e151a89e74b564969fd50)), closes [#30018](https://github.com/bitnami/charts/issues/30018)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## <small>1.2.18 (2024-10-02)</small>

* [bitnami/grafana-mimir] Release 1.2.18 (#29693) ([08f450e](https://github.com/bitnami/charts/commit/08f450e911970099b7b64bc3d0525cab3733c0ab)), closes [#29693](https://github.com/bitnami/charts/issues/29693)

## <small>1.2.17 (2024-09-17)</small>

* [bitnami/grafana-mimir] Release 1.2.17 (#29483) ([d6bfc60](https://github.com/bitnami/charts/commit/d6bfc608021629d77051ca62af0cd7180277dd09)), closes [#29483](https://github.com/bitnami/charts/issues/29483)

## <small>1.2.16 (2024-09-16)</small>

* [bitnami/grafana-mimir] chore: :construction_worker: :wrench: Use serial verification ([089d15f](https://github.com/bitnami/charts/commit/089d15f59f6345ab24ee2f17cf6f740a5c8ca808))

## <small>1.2.15 (2024-09-09)</small>

*  [bitnami/grafana-mimir] removing quotes from gw secrets #29214 (#29267) ([3fe94e9](https://github.com/bitnami/charts/commit/3fe94e977c51d8d3ed08a9e9eb7f80092a66a3ed)), closes [#29214](https://github.com/bitnami/charts/issues/29214) [#29267](https://github.com/bitnami/charts/issues/29267)

## <small>1.2.14 (2024-09-05)</small>

* [bitnami/grafana-mimir] Release 1.2.14 (#29236) ([bb0dc36](https://github.com/bitnami/charts/commit/bb0dc36af90dde2443429e8eecf09419b1006e2d)), closes [#29236](https://github.com/bitnami/charts/issues/29236)

## <small>1.2.13 (2024-08-27)</small>

* [bitnami/grafana-mimir] Release 1.2.13 (#29050) ([d14c588](https://github.com/bitnami/charts/commit/d14c5885d15c70cc86b150af3c475c482777fb71)), closes [#29050](https://github.com/bitnami/charts/issues/29050)

## <small>1.2.12 (2024-08-23)</small>

* [bitnami/grafana-mimir] Release 1.2.12 (#29001) ([149903d](https://github.com/bitnami/charts/commit/149903d981e84bced8de667e8440daa2a3e9473f)), closes [#29001](https://github.com/bitnami/charts/issues/29001)

## <small>1.2.11 (2024-08-07)</small>

* [bitnami/grafana-mimir] Release 1.2.11 (#28715) ([c027550](https://github.com/bitnami/charts/commit/c0275505296803d800b8c66003b0c4d673ee7fbb)), closes [#28715](https://github.com/bitnami/charts/issues/28715)

## <small>1.2.10 (2024-07-25)</small>

* [bitnami/grafana-mimir] Release 1.2.10 (#28415) ([ab58d00](https://github.com/bitnami/charts/commit/ab58d00e2c0cc6489184b6de2ac8687311160293)), closes [#28415](https://github.com/bitnami/charts/issues/28415)

## <small>1.2.9 (2024-07-24)</small>

* [bitnami/grafana-mimir] Release 1.2.9 (#28312) ([7b1b3bc](https://github.com/bitnami/charts/commit/7b1b3bc73e04c57a69400851ff47ef110fbf24a9)), closes [#28312](https://github.com/bitnami/charts/issues/28312)

## <small>1.2.8 (2024-07-24)</small>

* [bitnami/grafana-mimir] Release 1.2.8 (#28247) ([923cd57](https://github.com/bitnami/charts/commit/923cd57a07cae06635b7bbc82816f1d802e58532)), closes [#28247](https://github.com/bitnami/charts/issues/28247)

## <small>1.2.7 (2024-07-22)</small>

* [bitnami/grafana-mimir] Global StorageClass as default value (#28026) ([ca1fab7](https://github.com/bitnami/charts/commit/ca1fab7ceca035dc4f1a34bf14afc758cbf0cee8)), closes [#28026](https://github.com/bitnami/charts/issues/28026)

## <small>1.2.6 (2024-07-05)</small>

* [bitnami/grafana-mimir] Release 1.2.6 (#27826) ([f905b88](https://github.com/bitnami/charts/commit/f905b887f60db45761cb1b7034f7451297062a97)), closes [#27826](https://github.com/bitnami/charts/issues/27826)

## <small>1.2.5 (2024-07-04)</small>

* [bitnami/grafana-mimir] Release 1.2.5 (#27767) ([4ecd808](https://github.com/bitnami/charts/commit/4ecd808615065f34f6ea97fcd68a393761d42dad)), closes [#27767](https://github.com/bitnami/charts/issues/27767)

## <small>1.2.4 (2024-07-03)</small>

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/grafana-mimir] Release 1.2.4 (#27651) ([c3ca8c3](https://github.com/bitnami/charts/commit/c3ca8c35942f39a665475451f7063995c354f89c)), closes [#27651](https://github.com/bitnami/charts/issues/27651)

## <small>1.2.3 (2024-06-18)</small>

* [bitnami/grafana-mimir] Release 1.2.3 (#27351) ([bea97ef](https://github.com/bitnami/charts/commit/bea97ef105d07a94cd50fd9eb894195cbd21f1d9)), closes [#27351](https://github.com/bitnami/charts/issues/27351)

## <small>1.2.2 (2024-06-17)</small>

* [bitnami/grafana-mimir] Release 1.2.2 (#27224) ([8657fec](https://github.com/bitnami/charts/commit/8657fecf03fc5d7f96671399038ec17bc7d7aad3)), closes [#27224](https://github.com/bitnami/charts/issues/27224)

## <small>1.2.1 (2024-06-06)</small>

* [bitnami/grafana-mimir] Release 1.2.1 (#26954) ([06d3971](https://github.com/bitnami/charts/commit/06d3971e5f34d6ab755080fde8a10fffd6766e75)), closes [#26954](https://github.com/bitnami/charts/issues/26954)

## 1.2.0 (2024-06-06)

* [bitnami/grafana-mimir] Enable PodDisruptionBudgets (#26695) ([bae36af](https://github.com/bitnami/charts/commit/bae36afa871eb80138dcbcc12ebbc663038108b3)), closes [#26695](https://github.com/bitnami/charts/issues/26695)

## <small>1.1.5 (2024-06-06)</small>

* [bitnami/grafana-mimir] Release 1.1.5 (#26903) ([f95bb0a](https://github.com/bitnami/charts/commit/f95bb0a5db396db1e896923a9a20a409504ef167)), closes [#26903](https://github.com/bitnami/charts/issues/26903)

## <small>1.1.4 (2024-06-05)</small>

* [bitnami/grafana-mimir] Bump chart version (#26832) ([61841c6](https://github.com/bitnami/charts/commit/61841c6a1d2e94214c4ccca1303b6009ef3bbe66)), closes [#26832](https://github.com/bitnami/charts/issues/26832)

## <small>1.1.3 (2024-06-05)</small>

* [bitnami/grafana-mimir] Bump chart version (#26774) ([ec0b18c](https://github.com/bitnami/charts/commit/ec0b18c968060db292a7c3abe4b658005e16e002)), closes [#26774](https://github.com/bitnami/charts/issues/26774)

## <small>1.1.2 (2024-06-05)</small>

* [bitnami/grafana-mimir] Release 1.1.2 (#26731) ([db18447](https://github.com/bitnami/charts/commit/db18447898bafcfaf031c4d04940b9cdca29c4f6)), closes [#26731](https://github.com/bitnami/charts/issues/26731)

## <small>1.1.1 (2024-05-23)</small>

* [bitnami/grafana-mimir] Use different liveness/readiness probes (#26350) ([e4cc957](https://github.com/bitnami/charts/commit/e4cc9575527835733af5b4647a5f45a80efebe23)), closes [#26350](https://github.com/bitnami/charts/issues/26350)

## 1.1.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/grafana-mimir] feat: :sparkles: :lock: Add warning when original images are replaced (#2621 ([747eebb](https://github.com/bitnami/charts/commit/747eebbb49caf1baece3398d0fad3e5c1f9adc64)), closes [#26211](https://github.com/bitnami/charts/issues/26211)

## <small>1.0.8 (2024-05-18)</small>

* [bitnami/grafana-mimir] Release 1.0.8 updating components versions (#26019) ([e69d268](https://github.com/bitnami/charts/commit/e69d268f3a9f303f4e6cc9ade6f35b420578df44)), closes [#26019](https://github.com/bitnami/charts/issues/26019)

## <small>1.0.7 (2024-05-17)</small>

* [bitnami/grafana-mimir] PDB review (#25935) ([cb309ce](https://github.com/bitnami/charts/commit/cb309ce738bc2ea264a9f63e3024b933041d2b13)), closes [#25935](https://github.com/bitnami/charts/issues/25935)

## <small>1.0.6 (2024-05-13)</small>

* [bitnami/grafana-mimir] Release 1.0.6 updating components versions (#25766) ([dd02a85](https://github.com/bitnami/charts/commit/dd02a8567e21644bc34921e64a9a3325548521c1)), closes [#25766](https://github.com/bitnami/charts/issues/25766)

## <small>1.0.5 (2024-05-13)</small>

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/grafana-mimir] Release 1.0.5 updating components versions (#25717) ([6eaaaba](https://github.com/bitnami/charts/commit/6eaaaba9f1625f8d89cc826ae500cac42945c2f0)), closes [#25717](https://github.com/bitnami/charts/issues/25717)

## <small>1.0.4 (2024-05-08)</small>

* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/grafana-mimir] Release 1.0.4 updating components versions (#25594) ([763906a](https://github.com/bitnami/charts/commit/763906aeb94e2580d17687ceb588577b946ace92)), closes [#25594](https://github.com/bitnami/charts/issues/25594)

## <small>1.0.3 (2024-05-06)</small>

* [bitnami/grafana-mimir] Remove unicode characters (#25543) ([b6b7c42](https://github.com/bitnami/charts/commit/b6b7c421f8cbdbe7dbda9f901364626cda7add9b)), closes [#25543](https://github.com/bitnami/charts/issues/25543)
* [bitnami/multiple charts] Fix typo: "NetworkPolice" vs "NetworkPolicy" (#25348) ([6970c1b](https://github.com/bitnami/charts/commit/6970c1ba245873506e73d459c6eac1e4919b778f)), closes [#25348](https://github.com/bitnami/charts/issues/25348)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## <small>1.0.2 (2024-04-05)</small>

* [bitnami/grafana-mimir] Release 1.0.2 updating components versions (#25004) ([cf7a1e9](https://github.com/bitnami/charts/commit/cf7a1e9cfa9ea95587725c9c33526dfcbe2b995d)), closes [#25004](https://github.com/bitnami/charts/issues/25004)

## <small>1.0.1 (2024-04-04)</small>

* [bitnami/grafana-mimir] Release 1.0.1 (#24882) ([fc660e4](https://github.com/bitnami/charts/commit/fc660e462b6491d9019e721e6cbe70ccada4ffc8)), closes [#24882](https://github.com/bitnami/charts/issues/24882)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## 1.0.0 (2024-03-18)

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* [bitnami/grafana-mimir] feat!: :lock: :boom: Improve security defaults (#24511) ([b156c9e](https://github.com/bitnami/charts/commit/b156c9ee9da56d149aae815ffc9e84ea6070e5df)), closes [#24511](https://github.com/bitnami/charts/issues/24511)

## <small>0.14.1 (2024-03-06)</small>

* [bitnami/grafana-mimir] Release 0.14.1 updating components versions (#24225) ([ba7aa54](https://github.com/bitnami/charts/commit/ba7aa541c1cfc10929f9ec676e5fa5e3e37385e1)), closes [#24225](https://github.com/bitnami/charts/issues/24225)

## 0.14.0 (2024-03-06)

* [bitnami/grafana-mimir] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v2 ([ce21621](https://github.com/bitnami/charts/commit/ce21621e28a227658f5647888e9df65a5ab30bcc)), closes [#24089](https://github.com/bitnami/charts/issues/24089)

## 0.13.0 (2024-02-27)

* [bitnami/grafana-mimir] feat: :sparkles: :lock: Add readOnlyRootFilesystem support (#23908) ([629f25a](https://github.com/bitnami/charts/commit/629f25a585d177b95d531373d58faad2efe9041b)), closes [#23908](https://github.com/bitnami/charts/issues/23908)

## <small>0.12.2 (2024-02-21)</small>

* [bitnami/grafana-mimir] Release 0.12.2 updating components versions (#23761) ([69cdd90](https://github.com/bitnami/charts/commit/69cdd90d5ab350755626b47ca51a1b480fb4c8dd)), closes [#23761](https://github.com/bitnami/charts/issues/23761)

## <small>0.12.1 (2024-02-21)</small>

* [bitnami/grafana-mimir] Release 0.12.1 updating components versions (#23652) ([af488ff](https://github.com/bitnami/charts/commit/af488ffb6e1bb0ac409eaa5309fba2e7e53330bc)), closes [#23652](https://github.com/bitnami/charts/issues/23652)

## 0.12.0 (2024-02-20)

* [bitnami/grafana-mimir] feat: :sparkles: :lock: Add resource preset support (#23456) ([1e271a7](https://github.com/bitnami/charts/commit/1e271a7d93207ff79857cf03570fc77576d0c316)), closes [#23456](https://github.com/bitnami/charts/issues/23456)

## 0.11.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## 0.10.0 (2024-02-09)

* [bitnami/grafana-mimir] feat: :lock: Enable networkPolicy (#23254) ([5cad7ed](https://github.com/bitnami/charts/commit/5cad7ed7370159f40d6f782580d1870046135ad3)), closes [#23254](https://github.com/bitnami/charts/issues/23254)

## <small>0.9.9 (2024-02-07)</small>

* [bitnami/grafana-mimir] Release 0.9.9 updating components versions (#23290) ([29e185d](https://github.com/bitnami/charts/commit/29e185d3ad43f297e2043fa58537dd94d5408b42)), closes [#23290](https://github.com/bitnami/charts/issues/23290)

## <small>0.9.8 (2024-02-07)</small>

* [bitnami/grafana-mimir] Release 0.9.8 updating components versions (#23231) ([d31e480](https://github.com/bitnami/charts/commit/d31e480dc07e1dc0f10be0a6ab5e60c0be3ae783)), closes [#23231](https://github.com/bitnami/charts/issues/23231)

## <small>0.9.7 (2024-02-05)</small>

* [bitnami/grafana-mimir] Release 0.9.7 updating components versions (#23185) ([a42ea4a](https://github.com/bitnami/charts/commit/a42ea4a289228f2e7a1bef4363d687e34b74efa9)), closes [#23185](https://github.com/bitnami/charts/issues/23185)
* [bitnami/grafana-mimir] Replacing serviceMonitor targetPorts with the right port (#22525) ([a7eaf54](https://github.com/bitnami/charts/commit/a7eaf54636d5faf994422d9edd7589967f4e52ce)), closes [#22525](https://github.com/bitnami/charts/issues/22525)

## <small>0.9.6 (2024-02-02)</small>

* [bitnami/grafana-mimir] Release 0.9.6 updating components versions (#23070) ([b1963af](https://github.com/bitnami/charts/commit/b1963afe91b53235a436700a0b513ae4d5e2306b)), closes [#23070](https://github.com/bitnami/charts/issues/23070)

## <small>0.9.5 (2024-01-30)</small>

* [bitnami/grafana-mimir] Release 0.9.5 updating components versions (#22916) ([446e72b](https://github.com/bitnami/charts/commit/446e72bf3353574d0183f78213f4067b8b9e7bb9)), closes [#22916](https://github.com/bitnami/charts/issues/22916)

## <small>0.9.4 (2024-01-30)</small>

* [bitnami/grafana-mimir] Release 0.9.4 updating components versions (#22861) ([79b276e](https://github.com/bitnami/charts/commit/79b276e553829ebca8db46a1b7f50f6fd34bd152)), closes [#22861](https://github.com/bitnami/charts/issues/22861)

## <small>0.9.3 (2024-01-30)</small>

* [bitnami/grafana-mimir] Release 0.9.3 updating components versions (#22848) ([64787f7](https://github.com/bitnami/charts/commit/64787f79e2a326609a4c98620d1d62de3bd1090d)), closes [#22848](https://github.com/bitnami/charts/issues/22848)

## <small>0.9.2 (2024-01-27)</small>

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/grafana-mimir] Release 0.9.2 updating components versions (#22794) ([2f7d46a](https://github.com/bitnami/charts/commit/2f7d46a2c8a16c5e1a754c5ffdce34fe0ffa2225)), closes [#22794](https://github.com/bitnami/charts/issues/22794)

## <small>0.9.1 (2024-01-24)</small>

* [bitnami/grafana-mimir] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22594) ([75f2fef](https://github.com/bitnami/charts/commit/75f2fef3f25ba2fa47992363d14828e076a235c7)), closes [#22594](https://github.com/bitnami/charts/issues/22594)

## 0.9.0 (2024-01-19)

* [bitnami/grafana-mimir] fix: :lock: Move service-account token auto-mount to pod declaration (#22407 ([d02b7e5](https://github.com/bitnami/charts/commit/d02b7e590fcaed588630a7d9c7e54facf3b6b8ee)), closes [#22407](https://github.com/bitnami/charts/issues/22407)

## <small>0.8.1 (2024-01-18)</small>

* [bitnami/grafana-mimir] Release 0.8.1 updating components versions (#22289) ([0884877](https://github.com/bitnami/charts/commit/08848779c400deb3ffe1e89790f1eb26e0a565ea)), closes [#22289](https://github.com/bitnami/charts/issues/22289)

## 0.8.0 (2024-01-16)

* [bitnami/grafana-mimir] fix: :lock: Improve podSecurityContext and containerSecurityContext with ess ([368af3d](https://github.com/bitnami/charts/commit/368af3d48ff53866277b6f1a550be414fe701d24)), closes [#22125](https://github.com/bitnami/charts/issues/22125)

## <small>0.7.12 (2024-01-15)</small>

* [bitnami/grafana-mimir] fix: :lock: Do not automount the service account token unless necessary (#22 ([202950b](https://github.com/bitnami/charts/commit/202950bff55578164900cffab6a1aebcf0fce907)), closes [#22043](https://github.com/bitnami/charts/issues/22043)

## <small>0.7.11 (2024-01-12)</small>

* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/grafana-mimir] Release 0.7.11 updating components versions (#22009) ([a3b6f81](https://github.com/bitnami/charts/commit/a3b6f8144cf237ccbd9b052f91845e801bf1aec5)), closes [#22009](https://github.com/bitnami/charts/issues/22009)

## <small>0.7.10 (2024-01-10)</small>

* [bitnami/*] Fix docs.bitnami.com broken links (#21901) ([f35506d](https://github.com/bitnami/charts/commit/f35506d2dadee4f097986e7792df1f53ab215b5d)), closes [#21901](https://github.com/bitnami/charts/issues/21901)
* [bitnami/grafana-mimir] Release 0.7.10 updating components versions (#21946) ([fbeeeea](https://github.com/bitnami/charts/commit/fbeeeeac600cfb8d6fec6db2054ea3ed7c22132d)), closes [#21946](https://github.com/bitnami/charts/issues/21946)

## <small>0.7.9 (2024-01-03)</small>

* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)
* [bitnami/grafana-mimir] Release 0.7.9 (#21820) ([73a409f](https://github.com/bitnami/charts/commit/73a409f79d9c3e0235ec67f59423201fa512eca3)), closes [#21820](https://github.com/bitnami/charts/issues/21820)

## <small>0.7.8 (2023-12-12)</small>

* [bitnami/grafana-mimir] Release 0.7.8 updating components versions (#21537) ([083ca54](https://github.com/bitnami/charts/commit/083ca54dcc27ae2961b672b5bfca9e45d2c5f5fe)), closes [#21537](https://github.com/bitnami/charts/issues/21537)

## <small>0.7.7 (2023-12-07)</small>

* [bitnami/grafana-mimir] Release 0.7.7 updating components versions (#21422) ([5b3a618](https://github.com/bitnami/charts/commit/5b3a61872fead2f15ae0ea2cb58f2616bafc6309)), closes [#21422](https://github.com/bitnami/charts/issues/21422)

## <small>0.7.6 (2023-11-25)</small>

* [bitnami/grafana-mimir] Release 0.7.6 updating components versions (#21248) ([22dafeb](https://github.com/bitnami/charts/commit/22dafeb6569379a6fda53f0a4f7cd53920e08174)), closes [#21248](https://github.com/bitnami/charts/issues/21248)

## <small>0.7.5 (2023-11-23)</small>

* [bitnami/grafana-mimir] Release 0.7.5 updating components versions (#21225) ([8f6ea27](https://github.com/bitnami/charts/commit/8f6ea27cfa9dfe27baddd57a13a0debfb07c95f1)), closes [#21225](https://github.com/bitnami/charts/issues/21225)

## <small>0.7.4 (2023-11-21)</small>

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/grafana-mimir] Release 0.7.4 updating components versions (#21117) ([279a03d](https://github.com/bitnami/charts/commit/279a03dccb4c747af10d5449357196f376b6c711)), closes [#21117](https://github.com/bitnami/charts/issues/21117)
* Update readme-generator links (#21043) ([1581eba](https://github.com/bitnami/charts/commit/1581eba8044d730a763c266f279ac2ac782f764d)), closes [#21043](https://github.com/bitnami/charts/issues/21043)

## <small>0.7.3 (2023-11-09)</small>

* [bitnami/grafana-mimir] Release 0.7.3 updating components versions (#20850) ([7c88528](https://github.com/bitnami/charts/commit/7c88528a6a899cf98e16b83236d29b5bf6857be3)), closes [#20850](https://github.com/bitnami/charts/issues/20850)

## <small>0.7.2 (2023-11-09)</small>

* [bitnami/grafana-mimir] Release 0.7.2 updating components versions (#20841) ([58ddb44](https://github.com/bitnami/charts/commit/58ddb443758261f770762c404bf9d1260fd5a2d9)), closes [#20841](https://github.com/bitnami/charts/issues/20841)

## <small>0.7.1 (2023-11-09)</small>

* [bitnami/grafana-mimir] Release 0.7.1 updating components versions (#20752) ([5efde72](https://github.com/bitnami/charts/commit/5efde729953eb7f6f98e841d831f4991ea9d9fff)), closes [#20752](https://github.com/bitnami/charts/issues/20752)

## 0.7.0 (2023-10-31)

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [bitnami/grafana-mimir] feat: :sparkles: Add support for PSA restricted policy (#20444) ([3f03c1a](https://github.com/bitnami/charts/commit/3f03c1a9b7749091729b24774dba7e4419d80461)), closes [#20444](https://github.com/bitnami/charts/issues/20444)

## <small>0.6.11 (2023-10-18)</small>

* [bitnami/grafana-mimir] Release 0.6.11 (#20312) ([6612ebf](https://github.com/bitnami/charts/commit/6612ebff362279263a35745d50332b99a96a6d01)), closes [#20312](https://github.com/bitnami/charts/issues/20312)

## <small>0.6.10 (2023-10-16)</small>

* Fix alertmanager external url (#19825) ([c32bcdb](https://github.com/bitnami/charts/commit/c32bcdb5a8821e3648dd39bec9939e7c177ae802)), closes [#19825](https://github.com/bitnami/charts/issues/19825)

## <small>0.6.9 (2023-10-13)</small>

* [bitnami/grafana-mimir] Release 0.6.9 (#20225) ([7e87810](https://github.com/bitnami/charts/commit/7e8781048be5c4f5a32bc389f1d30fcfcd3bada6)), closes [#20225](https://github.com/bitnami/charts/issues/20225)

## <small>0.6.8 (2023-10-12)</small>

* [bitnami/grafana-mimir] Release 0.6.8 (#20180) ([2f59cb5](https://github.com/bitnami/charts/commit/2f59cb5f81c2ea90796f248636a1fef00a15f647)), closes [#20180](https://github.com/bitnami/charts/issues/20180)

## <small>0.6.7 (2023-10-09)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/grafana-mimir] Release 0.6.7 (#19913) ([6747c1e](https://github.com/bitnami/charts/commit/6747c1e164eb82ccf684804c4af3889d1ec37175)), closes [#19913](https://github.com/bitnami/charts/issues/19913)

## <small>0.6.6 (2023-10-03)</small>

* [bitnami/grafana-mimir] Release 0.6.6 (#19711) ([630ee34](https://github.com/bitnami/charts/commit/630ee34574c57d319ad29d40c2d5a1b3d274cf7c)), closes [#19711](https://github.com/bitnami/charts/issues/19711)

## <small>0.6.5 (2023-09-20)</small>

* [bitnami/grafana-mimir] Use different app.kubernetes.io/version label on subcomponents (#19336) ([3c88b51](https://github.com/bitnami/charts/commit/3c88b511169833c10f45f61154c1326e57fde300)), closes [#19336](https://github.com/bitnami/charts/issues/19336)

## <small>0.6.4 (2023-09-18)</small>

* [bitnami/grafana-mimir] Release 0.6.4 (#19361) ([41a75eb](https://github.com/bitnami/charts/commit/41a75eb9fe24f06a7dfbeb360f04c129309fe35b)), closes [#19361](https://github.com/bitnami/charts/issues/19361)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>0.6.3 (2023-09-14)</small>

* [bitnami/grafana-mimir] Release 0.6.3 (#19288) ([9b45451](https://github.com/bitnami/charts/commit/9b45451b6427ecf42b56eb613cbd3e684f27b3d1)), closes [#19288](https://github.com/bitnami/charts/issues/19288)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)

## <small>0.6.2 (2023-09-08)</small>

* [bitnami/grafana-mimir: Use merge helper]: (#19045) ([f293cfe](https://github.com/bitnami/charts/commit/f293cfe3e91d46e26558df8a4d48234a6d657988)), closes [#19045](https://github.com/bitnami/charts/issues/19045)

## <small>0.6.1 (2023-09-06)</small>

* [bitnami/grafana-mimir] Release 0.6.1 (#19136) ([db0f0cd](https://github.com/bitnami/charts/commit/db0f0cd8e0205a9a389371c218708d747b85bf48)), closes [#19136](https://github.com/bitnami/charts/issues/19136)

## 0.6.0 (2023-08-28)

* [bitnami/grafana-mimir] Support for customizing standard labels (#18488) ([deecf27](https://github.com/bitnami/charts/commit/deecf27c7ff4e59a8e7b22d4643c5e2da7042a06)), closes [#18488](https://github.com/bitnami/charts/issues/18488)

## <small>0.5.8 (2023-08-19)</small>

* [bitnami/grafana-mimir] Release 0.5.8 (#18664) ([4e21622](https://github.com/bitnami/charts/commit/4e216222a5bb705e570b8f719cb2ddefe181b4e5)), closes [#18664](https://github.com/bitnami/charts/issues/18664)

## <small>0.5.7 (2023-08-17)</small>

* [bitnami/grafana-mimir] Release 0.5.7 (#18522) ([80ce6f6](https://github.com/bitnami/charts/commit/80ce6f61b7f149996c4330341030c02dbdfce8a2)), closes [#18522](https://github.com/bitnami/charts/issues/18522)

## <small>0.5.6 (2023-07-25)</small>

* [bitnami/grafana-mimir] Release 0.5.6 (#17891) ([f77e83e](https://github.com/bitnami/charts/commit/f77e83e20cbf8e2d12d02c25fdc4b378dcee6d46)), closes [#17891](https://github.com/bitnami/charts/issues/17891)

## <small>0.5.5 (2023-07-13)</small>

* [bitnami/grafana-mimir] Release 0.5.5 (#17641) ([24501f4](https://github.com/bitnami/charts/commit/24501f4230cb41c962bcef368f0ed2c6ca271138)), closes [#17641](https://github.com/bitnami/charts/issues/17641)
* Use os-shell in tempate and Jaeger runtime params (#17557) ([91a49eb](https://github.com/bitnami/charts/commit/91a49eb1e3c81c7b7c6c28d1bc5d6d6ae698c1e2)), closes [#17557](https://github.com/bitnami/charts/issues/17557)

## <small>0.5.4 (2023-07-06)</small>

* [bitnami/grafana-mimir] Fix helm error when gateway.auth.existingSecret is set (#17469) ([6dcd8cd](https://github.com/bitnami/charts/commit/6dcd8cd210264b63427f0f1b87f75cc4640ce710)), closes [#17469](https://github.com/bitnami/charts/issues/17469)

## <small>0.5.3 (2023-06-30)</small>

* [bitnami/grafana-mimir] Release 0.5.3 (#17422) ([6062eb6](https://github.com/bitnami/charts/commit/6062eb64c750831144c6aeefb8a645282ab86932)), closes [#17422](https://github.com/bitnami/charts/issues/17422)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## <small>0.5.2 (2023-06-20)</small>

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/grafana-mimir] Release 0.5.2 (#17198) ([7b9226f](https://github.com/bitnami/charts/commit/7b9226f165ab754576daa949c973a845cf42f40f)), closes [#17198](https://github.com/bitnami/charts/issues/17198)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)

## <small>0.5.1 (2023-05-21)</small>

* [bitnami/grafana-mimir] Release 0.5.1 (#16766) ([d45f6b4](https://github.com/bitnami/charts/commit/d45f6b4f771edbb2f44121cf1d76d14f28d3ff98)), closes [#16766](https://github.com/bitnami/charts/issues/16766)
* Add wording for enterprise page (#16560) ([8f22774](https://github.com/bitnami/charts/commit/8f2277440b976d52785ba9149762ad8620a73d1f)), closes [#16560](https://github.com/bitnami/charts/issues/16560)

## 0.5.0 (2023-05-09)

* [bitnami/several] Adapt Chart.yaml to set desired OCI annotations (#16546) ([fc9b18f](https://github.com/bitnami/charts/commit/fc9b18f2e98805d4df629acbcde696f44f973344)), closes [#16546](https://github.com/bitnami/charts/issues/16546)

## <small>0.4.4 (2023-05-09)</small>

* [bitnami/grafana-mimir] Release 0.4.4 (#16515) ([831858a](https://github.com/bitnami/charts/commit/831858a1bd4a8a8aa72d809f25dd86b21e7031a4)), closes [#16515](https://github.com/bitnami/charts/issues/16515)

## <small>0.4.3 (2023-05-03)</small>

* [bitnami/grafana-mimir] Release 0.4.3 (#16361) ([6ef2bf9](https://github.com/bitnami/charts/commit/6ef2bf9c8c40acaec0b63c997278e2ac9237e082)), closes [#16361](https://github.com/bitnami/charts/issues/16361)

## <small>0.4.2 (2023-05-03)</small>

* [bitnami/grafana-mimir] Release 0.4.2 (#16357) ([ea6fcda](https://github.com/bitnami/charts/commit/ea6fcdac3d1b4a236a503b9f13bffa1f72c35256)), closes [#16357](https://github.com/bitnami/charts/issues/16357)

## <small>0.4.1 (2023-04-25)</small>

* [bitnami/grafana-mimir] Release 0.4.1 (#16217) ([253fec3](https://github.com/bitnami/charts/commit/253fec3376c9b1a81c8c525adc88df5cc9b015d9)), closes [#16217](https://github.com/bitnami/charts/issues/16217)

## 0.4.0 (2023-04-25)

* [bitnami/several] Revert changes done by mistake in Chart.yaml repo (#16211) ([3a60f4b](https://github.com/bitnami/charts/commit/3a60f4b10d2e02dbf83fcf64906b43edb6725615)), closes [#16211](https://github.com/bitnami/charts/issues/16211)

## <small>0.3.1 (2023-04-20)</small>

* [bitnami/grafana-mimir] Release 0.3.1 (#16150) ([08f1fc2](https://github.com/bitnami/charts/commit/08f1fc249221b94c4699b573e2742379e1a54fdf)), closes [#16150](https://github.com/bitnami/charts/issues/16150)

## 0.3.0 (2023-04-20)

* [bitnami/*] Make Helm charts 100% OCI (#15998) ([8841510](https://github.com/bitnami/charts/commit/884151035efcbf2e1b3206e7def85511073fb57d)), closes [#15998](https://github.com/bitnami/charts/issues/15998)

## <small>0.2.3 (2023-04-01)</small>

* [bitnami/grafana-mimir] Release 0.2.3 (#15865) ([3de82f2](https://github.com/bitnami/charts/commit/3de82f2441d768617c0f030a6982f5df44926c7d)), closes [#15865](https://github.com/bitnami/charts/issues/15865)

## <small>0.2.2 (2023-03-18)</small>

* [bitnami/grafana-mimir] Release 0.2.2 (#15571) ([79bbd22](https://github.com/bitnami/charts/commit/79bbd22718f965c48c3925ba17aae3509abd31a9)), closes [#15571](https://github.com/bitnami/charts/issues/15571)

## <small>0.2.1 (2023-03-15)</small>

* [bitnami/grafana-mimir] Fix #15369, wrong gateway configuration when alertmanager.enabled=true (#155 ([e2d1a61](https://github.com/bitnami/charts/commit/e2d1a61fd06c0d2ce320f326a2d7b2fd16fd66f8)), closes [#15369](https://github.com/bitnami/charts/issues/15369) [#15509](https://github.com/bitnami/charts/issues/15509)

## 0.2.0 (2023-03-10)

* [bitnami/grafana-mimir] Add support for service.headless.annotations (#15430) ([0a37caf](https://github.com/bitnami/charts/commit/0a37cafe42bd180d0b626836e863590da4202e33)), closes [#15430](https://github.com/bitnami/charts/issues/15430)

## <small>0.1.3 (2023-03-10)</small>

* [bitnami/charts] Apply linter to README files (#15357) ([0e29e60](https://github.com/bitnami/charts/commit/0e29e600d3adc8b1b46e506eccb3decfab3b4e63)), closes [#15357](https://github.com/bitnami/charts/issues/15357)
* [bitnami/grafana-mimir] Release 0.1.3 (#15422) ([b52404a](https://github.com/bitnami/charts/commit/b52404a079d393ce4b59d7fbb3ddc3c2996b9926)), closes [#15422](https://github.com/bitnami/charts/issues/15422)

## <small>0.1.2 (2023-03-01)</small>

* [bitnami/grafana-mimir] Release 0.1.2 (#15260) ([a893c52](https://github.com/bitnami/charts/commit/a893c521b25e9c7140c017d99437abf0c31c10bf)), closes [#15260](https://github.com/bitnami/charts/issues/15260)

## <small>0.1.1 (2023-02-24)</small>

* [bitnami/grafana-mimir] Release 0.1.1 (#15139) ([e953034](https://github.com/bitnami/charts/commit/e953034d77859c841977f1707eb88beb7d3bbbf8)), closes [#15139](https://github.com/bitnami/charts/issues/15139)

## 0.1.0 (2023-02-23)

* [bitnami/grafana-mimir] Add grafana-mimir to Bitnami Catalog (#14346) ([44a9669](https://github.com/bitnami/charts/commit/44a96694cc259f65fec4b98641e5b7ad64d70477)), closes [#14346](https://github.com/bitnami/charts/issues/14346)
