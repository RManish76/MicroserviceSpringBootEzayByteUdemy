# Changelog

## 6.0.5 (2025-08-13)

* [bitnami/jaeger] :zap: :arrow_up: Update dependency references ([#35815](https://github.com/bitnami/charts/pull/35815))

## <small>6.0.4 (2025-08-11)</small>

* [bitnami/jaeger] :zap: :arrow_up: Update dependency references (#35734) ([96c65e8](https://github.com/bitnami/charts/commit/96c65e8a37a1f720600c5c5eaae5bb94a76f3e87)), closes [#35734](https://github.com/bitnami/charts/issues/35734)

## <small>6.0.3 (2025-08-07)</small>

* [bitnami/jaeger] :zap: :arrow_up: Update dependency references (#35546) ([2485551](https://github.com/bitnami/charts/commit/2485551d172c8fbf15cd83309451341877801733)), closes [#35546](https://github.com/bitnami/charts/issues/35546)

## <small>6.0.2 (2025-08-07)</small>

* [bitnami/jaeger] :zap: :arrow_up: Update dependency references (#35488) ([f0448ca](https://github.com/bitnami/charts/commit/f0448ca7ee24b56b62c3adec298dc49aea66a4d2)), closes [#35488](https://github.com/bitnami/charts/issues/35488)

## <small>6.0.1 (2025-08-05)</small>

* [bitnami/jaeger] :zap: :arrow_up: Update dependency references (#35420) ([ca8ea7b](https://github.com/bitnami/charts/commit/ca8ea7b4dd18f69c1ccb0aa989129d219b225791)), closes [#35420](https://github.com/bitnami/charts/issues/35420)

## 6.0.0 (2025-08-01)

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/jaeger] Major release: Jaeger v2  (#35352) ([60e46ac](https://github.com/bitnami/charts/commit/60e46accccdd07e81070f8cf30d2ad7b92f72e4b)), closes [#35352](https://github.com/bitnami/charts/issues/35352)

## <small>5.1.24 (2025-07-09)</small>

* [bitnami/jaeger] :zap: :arrow_up: Update dependency references (#34908) ([d016eb3](https://github.com/bitnami/charts/commit/d016eb3d2d5f905a778ed57e4557569abc649e2f)), closes [#34908](https://github.com/bitnami/charts/issues/34908)

## <small>5.1.23 (2025-07-05)</small>

* [bitnami/jaeger] :zap: :arrow_up: Update dependency references (#34810) ([47a3e3b](https://github.com/bitnami/charts/commit/47a3e3bf734817bd046dbcaa3b2029e1efdcf7b7)), closes [#34810](https://github.com/bitnami/charts/issues/34810)

## <small>5.1.22 (2025-06-13)</small>

* [bitnami/jaeger] :zap: :arrow_up: Update dependency references (#34450) ([2067b37](https://github.com/bitnami/charts/commit/2067b37a0b959b5e99efc3c8e0ac76f2d88e7f20)), closes [#34450](https://github.com/bitnami/charts/issues/34450)

## <small>5.1.21 (2025-06-10)</small>

* [bitnami/jaeger] :zap: :arrow_up: Update dependency references (#34326) ([8ef7658](https://github.com/bitnami/charts/commit/8ef765822341afb8ccb641c4e69b52e125d64e06)), closes [#34326](https://github.com/bitnami/charts/issues/34326)

## <small>5.1.20 (2025-06-06)</small>

* [bitnami/jaeger] :zap: :arrow_up: Update dependency references (#34178) ([0db2b66](https://github.com/bitnami/charts/commit/0db2b662159038eae861bee8741bac014fdf8869)), closes [#34178](https://github.com/bitnami/charts/issues/34178)

## <small>5.1.19 (2025-06-03)</small>

* [bitnami/jaeger] :zap: :arrow_up: Update dependency references (#34062) ([e0c4abc](https://github.com/bitnami/charts/commit/e0c4abc82edd265e9e4ac68b4873e06699dbff09)), closes [#34062](https://github.com/bitnami/charts/issues/34062)

## <small>5.1.18 (2025-05-13)</small>

* [bitnami/jaeger] :zap: :arrow_up: Update dependency references (#33626) ([f3ce821](https://github.com/bitnami/charts/commit/f3ce821b21ef692dcea4c908d98abd0d83d43f0e)), closes [#33626](https://github.com/bitnami/charts/issues/33626)
* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)

## <small>5.1.17 (2025-05-08)</small>

* [bitnami/jaeger] :zap: :arrow_up: Update dependency references (#33563) ([b8d13a9](https://github.com/bitnami/charts/commit/b8d13a9b6ad550197fa318ec12e3d812e71c3e72)), closes [#33563](https://github.com/bitnami/charts/issues/33563)

## <small>5.1.16 (2025-05-07)</small>

* [bitnami/jaeger] Release 5.1.16 (#33498) ([6958ffa](https://github.com/bitnami/charts/commit/6958ffa03c00d311c0b6131858903c8016277461)), closes [#33498](https://github.com/bitnami/charts/issues/33498)

## <small>5.1.15 (2025-05-07)</small>

* [bitnami/jaeger] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#33375) ([aa10601](https://github.com/bitnami/charts/commit/aa1060191c244c76b538a46e41c9a276c984298b)), closes [#33375](https://github.com/bitnami/charts/issues/33375)

## <small>5.1.14 (2025-04-15)</small>

* [bitnami/jaeger] Release 5.1.14 (#33010) ([c200116](https://github.com/bitnami/charts/commit/c200116294bcb06831957c334a07580ecba1fc4a)), closes [#33010](https://github.com/bitnami/charts/issues/33010)

## <small>5.1.13 (2025-04-02)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/jaeger] Release 5.1.13 (#32741) ([2466579](https://github.com/bitnami/charts/commit/24665791672ee53d82a226d7a3c7fa150795eaf4)), closes [#32741](https://github.com/bitnami/charts/issues/32741)

## <small>5.1.12 (2025-03-08)</small>

* [bitnami/jaeger] Release 5.1.12 (#32372) ([0c4e213](https://github.com/bitnami/charts/commit/0c4e213f95debcad6d09674ba05e0e87ac5da530)), closes [#32372](https://github.com/bitnami/charts/issues/32372)

## <small>5.1.11 (2025-03-05)</small>

* [bitnami/jaeger] Release 5.1.11 (#32311) ([2ddba1b](https://github.com/bitnami/charts/commit/2ddba1b315b59895bb47401ac339d9081517d2ec)), closes [#32311](https://github.com/bitnami/charts/issues/32311)

## <small>5.1.10 (2025-02-19)</small>

* [bitnami/jaeger] Release 5.1.10 (#32002) ([84c85d3](https://github.com/bitnami/charts/commit/84c85d35b58326f48d492979fabd9ef2a6da67a7)), closes [#32002](https://github.com/bitnami/charts/issues/32002)

## <small>5.1.9 (2025-02-12)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/jaeger] Release 5.1.9 (#31892) ([d7f3794](https://github.com/bitnami/charts/commit/d7f37949bb03a4f47fd0c5ee1ced5c2992320755)), closes [#31892](https://github.com/bitnami/charts/issues/31892)

## <small>5.1.8 (2025-02-10)</small>

* [bitnami/jaeger] Release 5.1.8 (#31848) ([1d98775](https://github.com/bitnami/charts/commit/1d987751f63ba414c9ec360d24be0179b8d11874)), closes [#31848](https://github.com/bitnami/charts/issues/31848)

## <small>5.1.7 (2025-02-07)</small>

* [bitnami/jaeger] Release 5.1.7 (#31834) ([f53468d](https://github.com/bitnami/charts/commit/f53468d8cc664b48a273f17e9b91ed64045bc3a6)), closes [#31834](https://github.com/bitnami/charts/issues/31834)

## <small>5.1.6 (2025-02-04)</small>

* [bitnami/jaeger] Release 5.1.6 (#31760) ([230c8b5](https://github.com/bitnami/charts/commit/230c8b5c991115ea771f786ac795d5ef04a34bcf)), closes [#31760](https://github.com/bitnami/charts/issues/31760)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## <small>5.1.5 (2025-01-24)</small>

* [bitnami/jaeger] Release 5.1.5 (#31560) ([dc8441b](https://github.com/bitnami/charts/commit/dc8441b4737ad2d8769689690e78739e34985a82)), closes [#31560](https://github.com/bitnami/charts/issues/31560)

## <small>5.1.4 (2025-01-21)</small>

*  [bitnami/jaeger] Migration job not using namespace overwrite 31207 (#31405) ([2e7a486](https://github.com/bitnami/charts/commit/2e7a486cda512311b84ad6a5d80d2a6fa90f25ff)), closes [#31405](https://github.com/bitnami/charts/issues/31405)

## <small>5.1.3 (2025-01-08)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/jaeger] Release 5.1.3 (#31251) ([accc2a4](https://github.com/bitnami/charts/commit/accc2a409a6e4c3f52ccc0dd574680c8d645dd4e)), closes [#31251](https://github.com/bitnami/charts/issues/31251)

## <small>5.1.2 (2024-12-12)</small>

* [bitnami/jaeger] Release 5.1.2 (#31021) ([ee3a9bd](https://github.com/bitnami/charts/commit/ee3a9bdcc8437615b82b8033c33be35a397e2689)), closes [#31021](https://github.com/bitnami/charts/issues/31021)

## <small>5.1.1 (2024-12-10)</small>

* [bitnami/jaeger] Fix typo in NOTES.txt (#30909) ([b7f1b92](https://github.com/bitnami/charts/commit/b7f1b926ecabfec95ef6c081d8b12f40d950d30e)), closes [#30909](https://github.com/bitnami/charts/issues/30909)

## 5.1.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/jaeger] Detect non-standard images (#30881) ([4773008](https://github.com/bitnami/charts/commit/47730085e639cddd081ec93d62339322a36b0fc5)), closes [#30881](https://github.com/bitnami/charts/issues/30881)

## <small>5.0.1 (2024-12-04)</small>

* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/jaeger] Release 5.0.1 (#30758) ([1672922](https://github.com/bitnami/charts/commit/16729228545387e22171fe81cb0982202363a1db)), closes [#30758](https://github.com/bitnami/charts/issues/30758)

## 5.0.0 (2024-11-20)

* [bitnami/jaeger] Release 5.0.0 (#30529) ([8e7120e](https://github.com/bitnami/charts/commit/8e7120edd246ee4e5bb6467ffef905446a8b27c3)), closes [#30529](https://github.com/bitnami/charts/issues/30529)

## 4.0.0 (2024-11-13)

* [bitnami/jaeger] chore!: :arrow_up: :fire: :boom: Update Jaeger to 1.63.0 and deprecate jaeger-agent ([ab89e33](https://github.com/bitnami/charts/commit/ab89e33385cf98a4de67c6795d4ab970d16a1f33)), closes [#30439](https://github.com/bitnami/charts/issues/30439)

## <small>3.0.6 (2024-11-08)</small>

* [bitnami/jaeger] Unify seLinuxOptions default value (#30347) ([31165b2](https://github.com/bitnami/charts/commit/31165b20a0d9d22744787b4379ae4f4eb5ec8860)), closes [#30347](https://github.com/bitnami/charts/issues/30347)

## <small>3.0.5 (2024-11-07)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/jaeger] Release 3.0.5 (#30273) ([235579d](https://github.com/bitnami/charts/commit/235579d5e1bcef5c2e192d9e734b29b724b6d8dc)), closes [#30273](https://github.com/bitnami/charts/issues/30273)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## <small>3.0.4 (2024-10-10)</small>

* [bitnami/jaeger] Release 3.0.4 (#29860) ([aabab2a](https://github.com/bitnami/charts/commit/aabab2ab6a76bfd988b03ea54b679cac92143ce8)), closes [#29860](https://github.com/bitnami/charts/issues/29860)

## <small>3.0.3 (2024-10-07)</small>

* [bitnami/jaeger] Release 3.0.3 (#29800) ([f31a3fa](https://github.com/bitnami/charts/commit/f31a3faa2b2849cdc4a68228ce6f4409dad307fc)), closes [#29800](https://github.com/bitnami/charts/issues/29800)

## <small>3.0.2 (2024-10-02)</small>

* [bitnami/jaeger] Release 3.0.2 (#29700) ([4cef175](https://github.com/bitnami/charts/commit/4cef1759fc061799009c72d43a7ddf475cf32071)), closes [#29700](https://github.com/bitnami/charts/issues/29700)

## <small>3.0.1 (2024-09-19)</small>

* [bitnami/jaeger] Release 3.0.1 (#29535) ([4163372](https://github.com/bitnami/charts/commit/4163372fd1cb5cd3dc86353dacea5d0ab705171a)), closes [#29535](https://github.com/bitnami/charts/issues/29535)

## 3.0.0 (2024-09-10)

* [bitnami/jaeger] Upgrade Cassandra to 12.x.x (appVersion 5.0.0) (#29324) ([40b54b0](https://github.com/bitnami/charts/commit/40b54b00a232074ba2b497823ce417c69ed78473)), closes [#29324](https://github.com/bitnami/charts/issues/29324)

## <small>2.5.12 (2024-09-06)</small>

* [bitnami/jaeger] Release 2.5.12 (#29243) ([4251f05](https://github.com/bitnami/charts/commit/4251f057d49681e6d9acc7f7b8fa6a0b07fa0277)), closes [#29243](https://github.com/bitnami/charts/issues/29243)

## <small>2.5.11 (2024-08-27)</small>

* [bitnami/jaeger] Release 2.5.11 (#29053) ([bd6238e](https://github.com/bitnami/charts/commit/bd6238edc4bcf484c54d75d8ac293ac920bc4248)), closes [#29053](https://github.com/bitnami/charts/issues/29053)

## <small>2.5.10 (2024-08-07)</small>

* [bitnami/jaeger] Release 2.5.10 (#28724) ([af0ed90](https://github.com/bitnami/charts/commit/af0ed90ed8da2fc475ef96dfc75082200743ca92)), closes [#28724](https://github.com/bitnami/charts/issues/28724)

## <small>2.5.9 (2024-08-06)</small>

* [bitnami/jaeger] Release 2.5.9 (#28703) ([d7487c1](https://github.com/bitnami/charts/commit/d7487c1a3c7cb06d07a9106e983986b2c175c45e)), closes [#28703](https://github.com/bitnami/charts/issues/28703)

## <small>2.5.8 (2024-07-25)</small>

* [bitnami/jaeger] Release 2.5.8 (#28419) ([edc1cd4](https://github.com/bitnami/charts/commit/edc1cd498f3cc860779116b1100f416642ff9742)), closes [#28419](https://github.com/bitnami/charts/issues/28419)

## <small>2.5.7 (2024-07-24)</small>

* [bitnami/jaeger] Release 2.5.7 (#28290) ([e99f82e](https://github.com/bitnami/charts/commit/e99f82ef8c2889987ca27fcb6022fdb049b5285d)), closes [#28290](https://github.com/bitnami/charts/issues/28290)

## <small>2.5.6 (2024-07-24)</small>

* [bitnami/jaeger] Release 2.5.6 (#28253) ([b955a63](https://github.com/bitnami/charts/commit/b955a63b31a4548d3466451ed79aae61ff761d93)), closes [#28253](https://github.com/bitnami/charts/issues/28253)

## <small>2.5.5 (2024-07-18)</small>

* [bitnami/jaeger] Global StorageClass as default value (#28032) ([13e60dc](https://github.com/bitnami/charts/commit/13e60dc00af1dde0172f3518919c88b46eacb035)), closes [#28032](https://github.com/bitnami/charts/issues/28032)

## <small>2.5.4 (2024-07-15)</small>

* [bitnami/jaeger] Release 2.5.4 (#27973) ([2c4f9ae](https://github.com/bitnami/charts/commit/2c4f9ae71a62018b6d691ab0014318cc4bf85d2b)), closes [#27973](https://github.com/bitnami/charts/issues/27973)

## <small>2.5.3 (2024-07-15)</small>

* [bitnami/jaeger] Release 2.5.3 (#27887) ([e01a53a](https://github.com/bitnami/charts/commit/e01a53ac8b79f09a562a1d3c598d28d2139f55fb)), closes [#27887](https://github.com/bitnami/charts/issues/27887)

## <small>2.5.2 (2024-07-04)</small>

* [bitnami/jaeger] Release 2.5.2 (#27791) ([3edc25b](https://github.com/bitnami/charts/commit/3edc25bff13fe127431031109120adf4dc3d83b1)), closes [#27791](https://github.com/bitnami/charts/issues/27791)

## <small>2.5.1 (2024-07-03)</small>

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/jaeger] Release 2.5.1 (#27654) ([b66430f](https://github.com/bitnami/charts/commit/b66430fa4ecbfc084700db342034a88151ab1279)), closes [#27654](https://github.com/bitnami/charts/issues/27654)

## 2.5.0 (2024-06-25)

* [bitnami/jaeger] Add init containers resources to Jaeger chart (#27462) ([58cb9da](https://github.com/bitnami/charts/commit/58cb9daf49adfee0794376d3616f290c8d56218b)), closes [#27462](https://github.com/bitnami/charts/issues/27462)

## <small>2.4.1 (2024-06-22)</small>

* [bitnami/jaeger] Release 2.4.1 (#27500) ([7dc1439](https://github.com/bitnami/charts/commit/7dc14399f43185a57254bfe91552eb28c3556527)), closes [#27500](https://github.com/bitnami/charts/issues/27500)

## 2.4.0 (2024-06-21)

* [bitnami/jaeger] Add support for cassandra existingSecret (#26563) ([175b933](https://github.com/bitnami/charts/commit/175b933346aaf2cdef7842394806cba75fa8f078)), closes [#26563](https://github.com/bitnami/charts/issues/26563)

## <small>2.3.9 (2024-06-18)</small>

* [bitnami/jaeger] Release 2.3.9 (#27357) ([a11df55](https://github.com/bitnami/charts/commit/a11df5597f3a252e7405f2f2beae81347c0d7d89)), closes [#27357](https://github.com/bitnami/charts/issues/27357)

## <small>2.3.8 (2024-06-17)</small>

* [bitnami/jaeger] Release 2.3.8 (#27231) ([b2b3f5d](https://github.com/bitnami/charts/commit/b2b3f5d8750a9219037a5a4a7abbf0e2d00e2078)), closes [#27231](https://github.com/bitnami/charts/issues/27231)

## <small>2.3.7 (2024-06-17)</small>

* [bitnami/jaeger] Release 2.3.7 (#27192) ([d3f69e6](https://github.com/bitnami/charts/commit/d3f69e6c610f0b560bcfdaf165e43ccb45ae7be6)), closes [#27192](https://github.com/bitnami/charts/issues/27192)

## <small>2.3.6 (2024-06-14)</small>

* [bitnami/jaeger] Update query for check_cassandra_keyspace_schema (#27160) ([ad20b5b](https://github.com/bitnami/charts/commit/ad20b5befc669a241afee5795c2928e37af16f7d)), closes [#27160](https://github.com/bitnami/charts/issues/27160)

## <small>2.3.5 (2024-06-12)</small>

* [bitnami/jaeger] Release 2.3.5 (#27118) ([a6ec3ea](https://github.com/bitnami/charts/commit/a6ec3eaf341ed6bd42874bd896d072ec92d7faf6)), closes [#27118](https://github.com/bitnami/charts/issues/27118)

## <small>2.3.4 (2024-06-06)</small>

* [bitnami/jaeger] Release 2.3.4 (#26959) ([d8e4eb8](https://github.com/bitnami/charts/commit/d8e4eb885d9f68dd0b731d33c0d90ee382f29698)), closes [#26959](https://github.com/bitnami/charts/issues/26959)

## <small>2.3.3 (2024-06-05)</small>

* [bitnami/jaeger] Bump chart version (#26835) ([2d0c1d7](https://github.com/bitnami/charts/commit/2d0c1d7b1599e89a141300f39e29658700958562)), closes [#26835](https://github.com/bitnami/charts/issues/26835)

## <small>2.3.2 (2024-06-05)</small>

* [bitnami/jaeger] Bump chart version (#26777) ([dd25238](https://github.com/bitnami/charts/commit/dd252384d4ffa24ffc9429f557f70e99ab26bed3)), closes [#26777](https://github.com/bitnami/charts/issues/26777)

## <small>2.3.1 (2024-06-05)</small>

* [bitnami/jaeger] Release 2.3.1 (#26735) ([d0f5e2e](https://github.com/bitnami/charts/commit/d0f5e2e0f99d2508cae0cf7dee09c165295650b9)), closes [#26735](https://github.com/bitnami/charts/issues/26735)

## 2.3.0 (2024-06-03)

* [bitnami/jaeger] Enable PodDisruptionBudgets (#26494) ([c8a1142](https://github.com/bitnami/charts/commit/c8a11426b11314f84b5f44154ab696292b2052e4)), closes [#26494](https://github.com/bitnami/charts/issues/26494)

## <small>2.2.1 (2024-05-22)</small>

* [bitnami/jaeger] Use different liveness/readiness probes (#26302) ([4372ff5](https://github.com/bitnami/charts/commit/4372ff5e0eca116f2b3842f5a71b6a93e8fcf7fc)), closes [#26302](https://github.com/bitnami/charts/issues/26302)

## 2.2.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/jaeger] feat: :sparkles: :lock: Add warning when original images are replaced (#26218) ([7f61fc9](https://github.com/bitnami/charts/commit/7f61fc964466c2e8d9fad5564da90f63c0183d12)), closes [#26218](https://github.com/bitnami/charts/issues/26218)

## <small>2.1.5 (2024-05-18)</small>

* [bitnami/jaeger] Release 2.1.5 updating components versions (#26025) ([498e990](https://github.com/bitnami/charts/commit/498e99008062d151d468c9e55bab2f3c1db123bf)), closes [#26025](https://github.com/bitnami/charts/issues/26025)

## <small>2.1.4 (2024-05-14)</small>

* [bitnami/jaeger] Release 2.1.4 updating components versions (#25768) ([40990d9](https://github.com/bitnami/charts/commit/40990d9152390ea1fdcc349eabd5244aec728a0d)), closes [#25768](https://github.com/bitnami/charts/issues/25768)

## <small>2.1.3 (2024-05-08)</small>

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/jaeger] Release 2.1.3 updating components versions (#25634) ([9338486](https://github.com/bitnami/charts/commit/933848621f034cbf1cbbd6d567799485bc959d89)), closes [#25634](https://github.com/bitnami/charts/issues/25634)

## <small>2.1.2 (2024-05-08)</small>

* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/jaeger] Release 2.1.2 updating components versions (#25604) ([a550fd7](https://github.com/bitnami/charts/commit/a550fd77b64f37320bfa1866b1d142b72d791a28)), closes [#25604](https://github.com/bitnami/charts/issues/25604)

## <small>2.1.1 (2024-05-02)</small>

* [bitnami/jaeger] Release 2.1.1 updating components versions (#25504) ([e85a5c8](https://github.com/bitnami/charts/commit/e85a5c8034e83b8578ef194c3530ef5f8bee1199)), closes [#25504](https://github.com/bitnami/charts/issues/25504)
* [bitnami/multiple charts] Fix typo: "NetworkPolice" vs "NetworkPolicy" (#25348) ([6970c1b](https://github.com/bitnami/charts/commit/6970c1ba245873506e73d459c6eac1e4919b778f)), closes [#25348](https://github.com/bitnami/charts/issues/25348)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## 2.1.0 (2024-04-18)

* [bitnami/jaeger] fix: :bug: :lock: Expose missing ports in deployment spec (#25156) ([ac69ddd](https://github.com/bitnami/charts/commit/ac69dddb4a35a6b4f23ed9850f400a8c8a8d4e7e)), closes [#25156](https://github.com/bitnami/charts/issues/25156)

## <small>2.0.1 (2024-04-05)</small>

* [bitnami/jaeger] Release 2.0.1 updating components versions (#24991) ([7e16109](https://github.com/bitnami/charts/commit/7e1610948dcdea16978fbfc3e744c3e9e26594bd)), closes [#24991](https://github.com/bitnami/charts/issues/24991)

## 2.0.0 (2024-04-05)

* [bitnami/jaeger] feat!: :lock: :boom: Improve security defaults (#24649) ([69a3cbd](https://github.com/bitnami/charts/commit/69a3cbd5b8dec5719ba5f2ab52e89f9c8518af63)), closes [#24649](https://github.com/bitnami/charts/issues/24649)

## <small>1.11.3 (2024-04-04)</small>

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* [bitnami/jaeger] Release 1.11.3 (#24888) ([455377a](https://github.com/bitnami/charts/commit/455377ac8573db6b536fdc8240e019fc70522814)), closes [#24888](https://github.com/bitnami/charts/issues/24888)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## <small>1.11.2 (2024-03-07)</small>

* [bitnami/jaeger] Release 1.11.2 updating components versions (#24240) ([6990419](https://github.com/bitnami/charts/commit/6990419261531ee04907b3ec1174b034f2698922)), closes [#24240](https://github.com/bitnami/charts/issues/24240)

## <small>1.11.1 (2024-03-06)</small>

* [bitnami/jaeger] Release 1.11.1 updating components versions (#24208) ([af69082](https://github.com/bitnami/charts/commit/af690826dd9aa51a82129c01ae19aaf61eddffa3)), closes [#24208](https://github.com/bitnami/charts/issues/24208)

## 1.11.0 (2024-03-06)

* [bitnami/jaeger] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v2 SCC (# ([cb47717](https://github.com/bitnami/charts/commit/cb47717309e4c2db94195a9a037c98b00440d128)), closes [#24095](https://github.com/bitnami/charts/issues/24095)

## <small>1.10.2 (2024-02-21)</small>

* [bitnami/jaeger] Release 1.10.2 updating components versions (#23769) ([eea8169](https://github.com/bitnami/charts/commit/eea8169b508a43390642743c4e6eac9a734acfbd)), closes [#23769](https://github.com/bitnami/charts/issues/23769)

## <small>1.10.1 (2024-02-21)</small>

* [bitnami/jaeger] Release 1.10.1 updating components versions (#23662) ([fa8bbb6](https://github.com/bitnami/charts/commit/fa8bbb6934d0ee45cd3a62c7caa1471df809d5d6)), closes [#23662](https://github.com/bitnami/charts/issues/23662)

## 1.10.0 (2024-02-20)

* [bitnami/jaeger] feat: :sparkles: :lock: Add resource preset support (#23463) ([d5e62ae](https://github.com/bitnami/charts/commit/d5e62ae1d2218e5c06e8f206d54981e2805dec1c)), closes [#23463](https://github.com/bitnami/charts/issues/23463)

## 1.9.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## <small>1.8.4 (2024-02-09)</small>

* [bitnami/jaeger] Release 1.8.4 updating components versions (#23373) ([36e7847](https://github.com/bitnami/charts/commit/36e7847fc40cc8b100b0c7f326174bb4b3286d4c)), closes [#23373](https://github.com/bitnami/charts/issues/23373)

## <small>1.8.3 (2024-02-07)</small>

* [bitnami/jaeger] Release 1.8.3 updating components versions (#23294) ([ffca9e9](https://github.com/bitnami/charts/commit/ffca9e98e22b4e06ab16530b8e0a67d7e9d1cdf7)), closes [#23294](https://github.com/bitnami/charts/issues/23294)

## <small>1.8.2 (2024-02-07)</small>

* [bitnami/jaeger] Release 1.8.2 updating components versions (#23275) ([1c2b989](https://github.com/bitnami/charts/commit/1c2b98982584c2145ecb4a0c0993f92fece74835)), closes [#23275](https://github.com/bitnami/charts/issues/23275)

## <small>1.8.1 (2024-02-07)</small>

* [bitnami/jaeger] Release 1.8.1 updating components versions (#23232) ([1dfe4db](https://github.com/bitnami/charts/commit/1dfe4db75cf2bd581030f51c43a3a202f92d15ac)), closes [#23232](https://github.com/bitnami/charts/issues/23232)

## 1.8.0 (2024-02-06)

* [bitnami/jaeger] feat: :lock: Enable networkPolicy (#23202) ([e809554](https://github.com/bitnami/charts/commit/e8095545b1d8c2aa7855ddd52b6899367ec32da3)), closes [#23202](https://github.com/bitnami/charts/issues/23202)

## <small>1.7.5 (2024-02-02)</small>

* [bitnami/jaeger] Release 1.7.5 updating components versions (#23082) ([3dc39cd](https://github.com/bitnami/charts/commit/3dc39cd7450ee77dd9759dd4027070ca8fa1e255)), closes [#23082](https://github.com/bitnami/charts/issues/23082)

## <small>1.7.4 (2024-01-30)</small>

* [bitnami/jaeger] Release 1.7.4 updating components versions (#22931) ([06f9d0a](https://github.com/bitnami/charts/commit/06f9d0a9be45c2191374681d8808bfc3351767be)), closes [#22931](https://github.com/bitnami/charts/issues/22931)

## <small>1.7.3 (2024-01-30)</small>

* [bitnami/jaeger] Release 1.7.3 updating components versions (#22917) ([01d5212](https://github.com/bitnami/charts/commit/01d5212e712e897c4aefd6c00ca2f7746083220c)), closes [#22917](https://github.com/bitnami/charts/issues/22917)

## <small>1.7.2 (2024-01-30)</small>

* [bitnami/jaeger] Release 1.7.2 updating components versions (#22850) ([3a2efeb](https://github.com/bitnami/charts/commit/3a2efebd89b0ff74abf92d3b0ce6a3ab1904af1a)), closes [#22850](https://github.com/bitnami/charts/issues/22850)

## <small>1.7.1 (2024-01-26)</small>

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/jaeger] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22600) ([ebe83b4](https://github.com/bitnami/charts/commit/ebe83b4692d454cbf1b94c2d33ed2f7bf3aa40d0)), closes [#22600](https://github.com/bitnami/charts/issues/22600)

## 1.7.0 (2024-01-22)

* [bitnami/jaeger] fix: :lock: Move service-account token auto-mount to pod declaration (#22484) ([61e0af7](https://github.com/bitnami/charts/commit/61e0af7a7d47c5350e4d4f186e052b65547164d0)), closes [#22484](https://github.com/bitnami/charts/issues/22484)

## <small>1.6.2 (2024-01-19)</small>

* [bitnami/jaeger] Enable readinessProbe by default (#22516) ([3af2fca](https://github.com/bitnami/charts/commit/3af2fcad38e546ec2fb6d9d8743395eed9910561)), closes [#22516](https://github.com/bitnami/charts/issues/22516)

## <small>1.6.1 (2024-01-18)</small>

* [bitnami/jaeger] Release 1.6.1 updating components versions (#22287) ([bea4638](https://github.com/bitnami/charts/commit/bea4638750e6d06824eaf4e9013f3f3754a2bbcf)), closes [#22287](https://github.com/bitnami/charts/issues/22287)

## 1.6.0 (2024-01-17)

* [bitnami/jaeger] fix: :lock: Improve podSecurityContext and containerSecurityContext with essential  ([7348c92](https://github.com/bitnami/charts/commit/7348c92557c720a32ec289a15ac33540dea3d391)), closes [#22131](https://github.com/bitnami/charts/issues/22131)

## <small>1.5.8 (2024-01-12)</small>

* [bitnami/jaeger] fix: :lock: Do not automount the service account token unless necessary (#22046) ([e4f3f1a](https://github.com/bitnami/charts/commit/e4f3f1a1ab97f426bcd255d01d6365133514ffbe)), closes [#22046](https://github.com/bitnami/charts/issues/22046)

## <small>1.5.7 (2024-01-12)</small>

* [bitnami/jaeger] Release 1.5.7 updating components versions (#22033) ([ac8624c](https://github.com/bitnami/charts/commit/ac8624c665cc79b861681e7fd3e77eac8117058f)), closes [#22033](https://github.com/bitnami/charts/issues/22033)

## <small>1.5.6 (2024-01-11)</small>

* [bitnami/jaeger] Release 1.5.6 updating components versions (#21997) ([ea051d1](https://github.com/bitnami/charts/commit/ea051d15bbe8f266671f55e2e83eba925e12fd8c)), closes [#21997](https://github.com/bitnami/charts/issues/21997)

## <small>1.5.5 (2024-01-11)</small>

* [bitnami/*] Fix docs.bitnami.com broken links (#21901) ([f35506d](https://github.com/bitnami/charts/commit/f35506d2dadee4f097986e7792df1f53ab215b5d)), closes [#21901](https://github.com/bitnami/charts/issues/21901)
* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)
* [bitnami/jaeger] Release 1.5.5 (#21894) ([030f7bb](https://github.com/bitnami/charts/commit/030f7bb4830b90872675b0acefc16206464fb0d4)), closes [#21894](https://github.com/bitnami/charts/issues/21894)

## <small>1.5.4 (2023-12-12)</small>

* [bitnami/jaeger] Release 1.5.4 updating components versions (#21525) ([fc04205](https://github.com/bitnami/charts/commit/fc04205bd2767e70e44e5ea810a1b9c1ee70dc16)), closes [#21525](https://github.com/bitnami/charts/issues/21525)

## <small>1.5.3 (2023-12-07)</small>

* [bitnami/jaeger] Release 1.5.3 updating components versions (#21439) ([460af63](https://github.com/bitnami/charts/commit/460af635fb7f7691e0b920228258ec6023b62b39)), closes [#21439](https://github.com/bitnami/charts/issues/21439)

## <small>1.5.2 (2023-12-05)</small>

* [bitnami/jaeger] Replace deprecated pull secret partial (#21375) ([f4b4aec](https://github.com/bitnami/charts/commit/f4b4aeccdb1f1d6639e4a08a0b0153a5b184524d)), closes [#21375](https://github.com/bitnami/charts/issues/21375)

## <small>1.5.1 (2023-11-21)</small>

* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/jaeger] Release 1.5.1 updating components versions (#21121) ([1a10756](https://github.com/bitnami/charts/commit/1a10756996c5a47a5c4f729394f86c87e41a0fc0)), closes [#21121](https://github.com/bitnami/charts/issues/21121)

## 1.5.0 (2023-11-17)

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/jaeger] Chart missing imagePullSecrets and otlp ports (#20544) ([a8ebf5d](https://github.com/bitnami/charts/commit/a8ebf5d42cf5474e7e9f1aca52d825ef32d8ad39)), closes [#20544](https://github.com/bitnami/charts/issues/20544)

## <small>1.4.3 (2023-11-08)</small>

* [bitnami/jaeger] Release 1.4.3 updating components versions (#20808) ([c217bf4](https://github.com/bitnami/charts/commit/c217bf46715ad93a130565ba15170d53b13ddfbc)), closes [#20808](https://github.com/bitnami/charts/issues/20808)

## <small>1.4.2 (2023-11-08)</small>

* [bitnami/jaeger] Release 1.4.2 updating components versions (#20734) ([59e61be](https://github.com/bitnami/charts/commit/59e61be29e917b437b965683d8e1e4e1d56eaa0c)), closes [#20734](https://github.com/bitnami/charts/issues/20734)

## <small>1.4.1 (2023-11-06)</small>

* [bitnami/jaeger] Release 1.4.1 updating components versions (#20637) ([16b9d8c](https://github.com/bitnami/charts/commit/16b9d8ca94e98362eb44fe4dd7cd8ca680099ac9)), closes [#20637](https://github.com/bitnami/charts/issues/20637)

## 1.4.0 (2023-10-31)

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [bitnami/jaeger] feat: :sparkles: Add support for PSA restricted policy (#20453) ([52b2d9a](https://github.com/bitnami/charts/commit/52b2d9ac6cd7de9a2404c597552d43d64a61732a)), closes [#20453](https://github.com/bitnami/charts/issues/20453)

## <small>1.3.5 (2023-10-11)</small>

* [bitnami/jaeger] Release 1.3.5 (#20045) ([9ccd7de](https://github.com/bitnami/charts/commit/9ccd7de5320d7b1268eba9fb92fa978fb9396846)), closes [#20045](https://github.com/bitnami/charts/issues/20045)

## <small>1.3.4 (2023-10-09)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/jaeger] Release 1.3.4 (#19849) ([a6995e7](https://github.com/bitnami/charts/commit/a6995e778ea18aa5445b9469531f0073ecaad59a)), closes [#19849](https://github.com/bitnami/charts/issues/19849)

## <small>1.3.3 (2023-10-04)</small>

* [bitnami/jaeger] Release 1.3.3 (#19717) ([cd18bfd](https://github.com/bitnami/charts/commit/cd18bfd22261b36cf9141fa229f8a35569032f21)), closes [#19717](https://github.com/bitnami/charts/issues/19717)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>1.3.2 (2023-09-08)</small>

* [bitnami/jaeger: Use merge helper]: (#19051) ([9d76922](https://github.com/bitnami/charts/commit/9d769221c1f526752b58298729f3c8ea03d438d9)), closes [#19051](https://github.com/bitnami/charts/issues/19051)

## <small>1.3.1 (2023-09-07)</small>

* [bitnami/jaeger] Release 1.3.1 (#19180) ([4183435](https://github.com/bitnami/charts/commit/4183435f8dc1106a72ea4860ebf76533034da3d9)), closes [#19180](https://github.com/bitnami/charts/issues/19180)

## 1.3.0 (2023-08-25)

* [bitnami/jaeger] Support for customizing standard labels (#18542) ([ea8e3e9](https://github.com/bitnami/charts/commit/ea8e3e9ae27b092d8340f868cc855a5e7e9a372b)), closes [#18542](https://github.com/bitnami/charts/issues/18542)

## <small>1.2.10 (2023-08-23)</small>

* [bitnami/jaeger] Release 1.2.10 (#18818) ([34baae2](https://github.com/bitnami/charts/commit/34baae2805516ac50fb11f5d91971c47d47a64e8)), closes [#18818](https://github.com/bitnami/charts/issues/18818)

## <small>1.2.9 (2023-08-17)</small>

* [bitnami/jaeger] Release 1.2.9 (#18526) ([fbce91f](https://github.com/bitnami/charts/commit/fbce91fc5da87450df636efe97beb91f3a6ccb9e)), closes [#18526](https://github.com/bitnami/charts/issues/18526)

## <small>1.2.8 (2023-07-25)</small>

* [bitnami/jaeger] Release 1.2.8 (#17883) ([145ca92](https://github.com/bitnami/charts/commit/145ca92f9a597b30f9a56c1ce57d7e94fe8eb64a)), closes [#17883](https://github.com/bitnami/charts/issues/17883)

## <small>1.2.7 (2023-07-15)</small>

* [bitnami/jaeger] Release 1.2.7 (#17653) ([98e600a](https://github.com/bitnami/charts/commit/98e600a7cc8b88f62fa7e8ee033cedfb7b798a0d)), closes [#17653](https://github.com/bitnami/charts/issues/17653)

## <small>1.2.6 (2023-07-07)</small>

* [bitnami/jaeger] Release 1.2.6 (#17526) ([742d494](https://github.com/bitnami/charts/commit/742d49443960fb9b74a264e8bb686fcc07edd9ee)), closes [#17526](https://github.com/bitnami/charts/issues/17526)

## <small>1.2.5 (2023-07-05)</small>

* [bitnami/jaeger] Release 1.2.5 updating components versions (#17484) ([5a257c6](https://github.com/bitnami/charts/commit/5a257c63987a68151fe4b5f702ed0e422fe262f5)), closes [#17484](https://github.com/bitnami/charts/issues/17484)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## <small>1.2.4 (2023-06-05)</small>

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/jaeger] Release 1.2.4 (#17018) ([16a9116](https://github.com/bitnami/charts/commit/16a9116a8aaae68daf1858f1f54491183594bb13)), closes [#17018](https://github.com/bitnami/charts/issues/17018)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)

## <small>1.2.3 (2023-05-21)</small>

* [bitnami/jaeger] Release 1.2.3 (#16771) ([fdb188c](https://github.com/bitnami/charts/commit/fdb188cb3f4418715230746669beb78cc61fac92)), closes [#16771](https://github.com/bitnami/charts/issues/16771)

## <small>1.2.2 (2023-05-16)</small>

* [bitnami/jaeger] Release 1.2.2 (#16688) ([a4b45e1](https://github.com/bitnami/charts/commit/a4b45e1f3d153489c81e7b23932a511e37e8c68c)), closes [#16688](https://github.com/bitnami/charts/issues/16688)
* Add wording for enterprise page (#16560) ([8f22774](https://github.com/bitnami/charts/commit/8f2277440b976d52785ba9149762ad8620a73d1f)), closes [#16560](https://github.com/bitnami/charts/issues/16560)

## <small>1.2.1 (2023-05-10)</small>

* [bitnami/jaeger] Release 1.2.1 (#16553) ([b9aa4b6](https://github.com/bitnami/charts/commit/b9aa4b60c9eee0187d4c2baa8cdb9867dbd0222d)), closes [#16553](https://github.com/bitnami/charts/issues/16553)

## 1.2.0 (2023-05-09)

* [bitnami/several] Adapt Chart.yaml to set desired OCI annotations (#16546) ([fc9b18f](https://github.com/bitnami/charts/commit/fc9b18f2e98805d4df629acbcde696f44f973344)), closes [#16546](https://github.com/bitnami/charts/issues/16546)

## 1.1.0 (2023-04-20)

* [bitnami/*] Make Helm charts 100% OCI (#15998) ([8841510](https://github.com/bitnami/charts/commit/884151035efcbf2e1b3206e7def85511073fb57d)), closes [#15998](https://github.com/bitnami/charts/issues/15998)

## <small>1.0.7 (2023-04-11)</small>

* [bitnami/jaeger] Release 1.0.7 (#16007) ([eab4e39](https://github.com/bitnami/charts/commit/eab4e39cb51f758bdaaa6b4e9eb4da300b216127)), closes [#16007](https://github.com/bitnami/charts/issues/16007)

## <small>1.0.6 (2023-04-01)</small>

* [bitnami/jaeger] Release 1.0.6 (#15852) ([767d67c](https://github.com/bitnami/charts/commit/767d67cdbf38b6ff70715c64d863cddfcdf80cfa)), closes [#15852](https://github.com/bitnami/charts/issues/15852)

## <small>1.0.5 (2023-03-19)</small>

* [bitnami/charts] Apply linter to README files (#15357) ([0e29e60](https://github.com/bitnami/charts/commit/0e29e600d3adc8b1b46e506eccb3decfab3b4e63)), closes [#15357](https://github.com/bitnami/charts/issues/15357)
* [bitnami/jaeger] Release 1.0.5 (#15606) ([c042ddf](https://github.com/bitnami/charts/commit/c042ddfbd10ef5ead0ddc1afb1e2c0d44c5d1972)), closes [#15606](https://github.com/bitnami/charts/issues/15606)

## <small>1.0.4 (2023-03-01)</small>

* [bitnami/jaeger] Release 1.0.4 (#15238) ([01c9192](https://github.com/bitnami/charts/commit/01c91925c43e8720d3219548dbb5a16639f24225)), closes [#15238](https://github.com/bitnami/charts/issues/15238)

## <small>1.0.3 (2023-02-17)</small>

* [bitnami/*] Fix markdown linter issues (#14874) ([a51e0e8](https://github.com/bitnami/charts/commit/a51e0e8d35495b907f3e70dd2f8e7c3bcbf4166a)), closes [#14874](https://github.com/bitnami/charts/issues/14874)
* [bitnami/*] Remove unexpected extra spaces (#14873) ([c97c714](https://github.com/bitnami/charts/commit/c97c714887380d47eae7bfeff316bf01595ecd1d)), closes [#14873](https://github.com/bitnami/charts/issues/14873)
* [bitnami/jaeger] Release 1.0.3 (#15017) ([27e319d](https://github.com/bitnami/charts/commit/27e319d75599aea1470508041231e98e8f1f84a4)), closes [#15017](https://github.com/bitnami/charts/issues/15017)

## <small>1.0.2 (2023-02-06)</small>

* [bitnami/*] Change copyright date (#14682) ([add4ec7](https://github.com/bitnami/charts/commit/add4ec701108ac36ed4de2dffbdf407a0d091067)), closes [#14682](https://github.com/bitnami/charts/issues/14682)
* [bitnami/*] Unify READMEs (#14472) ([2064fb8](https://github.com/bitnami/charts/commit/2064fb8dcc78a845cdede8211af8c3cc52551161)), closes [#14472](https://github.com/bitnami/charts/issues/14472)
* [bitnami/jaeger] Release 1.0.2 (#14759) ([647dbcf](https://github.com/bitnami/charts/commit/647dbcf4bc802b804d26b8c8678f8105018d5cc0)), closes [#14759](https://github.com/bitnami/charts/issues/14759)

## <small>1.0.1 (2023-01-19)</small>

* [bitnami/*] Change licenses annotation format (#14377) ([0ab7608](https://github.com/bitnami/charts/commit/0ab760862c660fcc78cffadf8e1d8cdd70881473)), closes [#14377](https://github.com/bitnami/charts/issues/14377)
* [bitnami/jaeger] Release 1.0.1 (#14452) ([348ac92](https://github.com/bitnami/charts/commit/348ac92a9708d82e6619b725a2c6768ce309da29)), closes [#14452](https://github.com/bitnami/charts/issues/14452)

## 1.0.0 (2023-01-13)

* [bitnami/*] Add license annotation and remove obsolete engine parameter (#14293) ([da2a794](https://github.com/bitnami/charts/commit/da2a7943bae95b6e9b5b4ed972c15e990b69fdb0)), closes [#14293](https://github.com/bitnami/charts/issues/14293)
* [bitnami/jaeger] Update dependencies (#14315) ([187dd71](https://github.com/bitnami/charts/commit/187dd710d71f6961eb1044ba8095cc86b445f03e)), closes [#14315](https://github.com/bitnami/charts/issues/14315)

## <small>0.1.3 (2023-01-04)</small>

* [bitnami/jaeger] Release 0.1.3 (#14179) ([0c860ae](https://github.com/bitnami/charts/commit/0c860ae2ee8c5f0f3723d7c1adea2b164abf29bc)), closes [#14179](https://github.com/bitnami/charts/issues/14179)

## <small>0.1.2 (2022-12-21)</small>

* [bitnami/jaeger] Reorder chart dependencies (#14063) ([73a262c](https://github.com/bitnami/charts/commit/73a262c6e4686d805f2b48f36ce7d9242159b891)), closes [#14063](https://github.com/bitnami/charts/issues/14063)

## <small>0.1.1 (2022-12-20)</small>

* [bitnami/jaeger] Release 0.1.1 (#14042) ([516374a](https://github.com/bitnami/charts/commit/516374a9400c1870c67bb28ab82734399520837f)), closes [#14042](https://github.com/bitnami/charts/issues/14042)

## 0.1.0 (2022-12-20)

* [bitnami/jaeger] Add Jaeger chart (#13480) ([73307cd](https://github.com/bitnami/charts/commit/73307cd8e0adcdc39aa54b32afffbd9b6613e159)), closes [#13480](https://github.com/bitnami/charts/issues/13480)
