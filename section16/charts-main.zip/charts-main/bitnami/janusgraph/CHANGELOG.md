# Changelog

## 1.4.10 (2025-08-26)

* [bitnami/janusgraph] :zap: :arrow_up: Update dependency references ([#36187](https://github.com/bitnami/charts/pull/36187))

## <small>1.4.9 (2025-08-07)</small>

* [bitnami/janusgraph] :zap: :arrow_up: Update dependency references (#35612) ([360004a](https://github.com/bitnami/charts/commit/360004a74a99d50f270cab7eea3a0ae3652b4e58)), closes [#35612](https://github.com/bitnami/charts/issues/35612)

## <small>1.4.8 (2025-08-07)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/janusgraph] :zap: :arrow_up: Update dependency references (#35569) ([f3ed528](https://github.com/bitnami/charts/commit/f3ed528c58bf942c7d83772158cd20926d550bb6)), closes [#35569](https://github.com/bitnami/charts/issues/35569)

## <small>1.4.7 (2025-07-15)</small>

* [bitnami/janusgraph] :zap: :arrow_up: Update dependency references (#35103) ([211d286](https://github.com/bitnami/charts/commit/211d28600f80cf612bcf234165234bfeef76660a)), closes [#35103](https://github.com/bitnami/charts/issues/35103)

## <small>1.4.6 (2025-07-10)</small>

* [bitnami/janusgraph] :zap: :arrow_up: Update dependency references (#34989) ([d442055](https://github.com/bitnami/charts/commit/d4420557692d06816f1d31f3909407d4c4df5274)), closes [#34989](https://github.com/bitnami/charts/issues/34989)

## <small>1.4.5 (2025-06-10)</small>

* [bitnami/janusgraph] :zap: :arrow_up: Update dependency references (#34300) ([088d90c](https://github.com/bitnami/charts/commit/088d90c278da6ea1e9a13be30f379f8a63bb8220)), closes [#34300](https://github.com/bitnami/charts/issues/34300)

## <small>1.4.4 (2025-05-16)</small>

* [bitnami/janusgraph] :zap: :arrow_up: Update dependency references (#33759) ([c1a055e](https://github.com/bitnami/charts/commit/c1a055ed9260656305f42c2a6f8730b39b23adac)), closes [#33759](https://github.com/bitnami/charts/issues/33759)
* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)

## <small>1.4.3 (2025-05-06)</small>

* [bitnami/janusgraph] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#33 ([13c6491](https://github.com/bitnami/charts/commit/13c649109e42ad575c7fbe7f52b02e48fd52c123)), closes [#33376](https://github.com/bitnami/charts/issues/33376)

## <small>1.4.2 (2025-04-25)</small>

* [bitnami/janusgraph] Release 1.4.2 (#33174) ([1113c4d](https://github.com/bitnami/charts/commit/1113c4d507d6ce746fe5f773cdd1c7559be359fe)), closes [#33174](https://github.com/bitnami/charts/issues/33174)

## <small>1.4.1 (2025-03-26)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/janusgraph] Release 1.4.1 (#32611) ([04eccb6](https://github.com/bitnami/charts/commit/04eccb60428b949baf2eb572bf823e23e65d8210)), closes [#32611](https://github.com/bitnami/charts/issues/32611)

## 1.4.0 (2025-02-24)

* [bitnami/janusgraph] Set `usePasswordFiles=true` by default (#32107) ([8850cf3](https://github.com/bitnami/charts/commit/8850cf3c6442af4c85b2c0c830c1a8b8c47a6681)), closes [#32107](https://github.com/bitnami/charts/issues/32107)

## <small>1.3.1 (2025-02-24)</small>

* [bitnami/janusgraph] Release 1.3.1 (#32140) ([8cef05e](https://github.com/bitnami/charts/commit/8cef05e10f079ed402adba00a2f849ad472721a9)), closes [#32140](https://github.com/bitnami/charts/issues/32140)

## 1.3.0 (2025-02-20)

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/janusgraph] feat: use new helper for checking API versions (#32050) ([7b30ac8](https://github.com/bitnami/charts/commit/7b30ac8e4c15b963ba52af27f7265b92b852fec3)), closes [#32050](https://github.com/bitnami/charts/issues/32050)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## <small>1.2.3 (2025-01-28)</small>

* [bitnami/janusgraph] Release 1.2.3 (#31623) ([6b46ea1](https://github.com/bitnami/charts/commit/6b46ea1284885a7d18edf92858c10e81fbed384e)), closes [#31623](https://github.com/bitnami/charts/issues/31623)

## <small>1.2.2 (2025-01-28)</small>

* [bitnami/janusgraph] Release 1.2.2 (#31611) ([f3ff98f](https://github.com/bitnami/charts/commit/f3ff98f6008da6920a12a8946b2f10fcfec4fcbe)), closes [#31611](https://github.com/bitnami/charts/issues/31611)

## <small>1.2.1 (2024-12-19)</small>

* [bitnami/janusgraph] Release 1.2.1 (#31098) ([06badcc](https://github.com/bitnami/charts/commit/06badcc25f8b22afec9026f49f4b187cda7d97fe)), closes [#31098](https://github.com/bitnami/charts/issues/31098)

## 1.2.0 (2024-12-18)

* [birtnami/janusgraph] chore(jmx-exporter): Upgrade image and change args (#31090) ([1c6465d](https://github.com/bitnami/charts/commit/1c6465d5502b8298898896c38302e4500bcae4a4)), closes [#31090](https://github.com/bitnami/charts/issues/31090)

## 1.1.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/janusgraph] Detect non-standard images (#30906) ([d4d178a](https://github.com/bitnami/charts/commit/d4d178aaad7845199be64ae58b96c73219c072be)), closes [#30906](https://github.com/bitnami/charts/issues/30906)

## <small>1.0.1 (2024-11-29)</small>

* [bitnami/*] docs: :memo: Add "Prometheus metrics" (batch 3) (#30666) ([82fc7e2](https://github.com/bitnami/charts/commit/82fc7e2fc12e2648ed22069942203c02bf5d4cc6)), closes [#30666](https://github.com/bitnami/charts/issues/30666)
* [bitnami/janusgraph] chore: :bulb: :memo: :rotating_light: Rename prometheus "@section" to avoid lin ([5afb864](https://github.com/bitnami/charts/commit/5afb864a77fdf1069d28bd498e52e36b45c17e1b)), closes [#30684](https://github.com/bitnami/charts/issues/30684)

## 1.0.0 (2024-11-22)

* [bitnami/janusgraph] Remove subchart image from values.yaml (#30590) ([01871b7](https://github.com/bitnami/charts/commit/01871b7fa6479528609a785189a09af0186744a4)), closes [#30590](https://github.com/bitnami/charts/issues/30590)

## <small>0.3.26 (2024-11-09)</small>

* [bitnami/janusgraph] Release 0.3.26 (#30371) ([08aa903](https://github.com/bitnami/charts/commit/08aa90318373c7f80c7c3da009b93bbe5d1728fb)), closes [#30371](https://github.com/bitnami/charts/issues/30371)

## <small>0.3.25 (2024-11-08)</small>

* [bitnami/janusgraph] Release 0.3.25 (#30362) ([f68a5da](https://github.com/bitnami/charts/commit/f68a5da959de807b537f653f42bd1132c59d6bf7)), closes [#30362](https://github.com/bitnami/charts/issues/30362)

## <small>0.3.24 (2024-11-08)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/janusgraph] Unify seLinuxOptions default value (#30342) ([756e580](https://github.com/bitnami/charts/commit/756e580b2ae6e14fe59774583e3e8e87d1984684)), closes [#30342](https://github.com/bitnami/charts/issues/30342)

## <small>0.3.23 (2024-10-18)</small>

* [bitnami/janusgraph] Remove wrong entries from image verification (#29914) ([be16cbf](https://github.com/bitnami/charts/commit/be16cbf0564756887e50ad9a54ceb408a672460f)), closes [#29914](https://github.com/bitnami/charts/issues/29914)

## <small>0.3.22 (2024-10-16)</small>

* [bitnami/janusgraph] Release 0.3.22 (#29951) ([275a6d4](https://github.com/bitnami/charts/commit/275a6d435eeba33f4e4240d7c2c3f6f8829124ba)), closes [#29951](https://github.com/bitnami/charts/issues/29951)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## <small>0.3.21 (2024-09-13)</small>

* [bitnami/janusgraph] Release 0.3.21 (#29395) ([37fcbce](https://github.com/bitnami/charts/commit/37fcbce879573fad85c8661011c20015bd90f311)), closes [#29395](https://github.com/bitnami/charts/issues/29395)

## <small>0.3.20 (2024-09-13)</small>

* [bitnami/janusgraph] Update version of Cassandra's chart (#29383) ([b3e66e2](https://github.com/bitnami/charts/commit/b3e66e27181bde01f3778b584cb03f68c05e95b2)), closes [#29383](https://github.com/bitnami/charts/issues/29383)

## <small>0.3.19 (2024-08-30)</small>

* [bitnami/janusgraph] Release 0.3.19 (#29135) ([8062bfb](https://github.com/bitnami/charts/commit/8062bfb2dd29374c5c4384cd27aec41f6361fd90)), closes [#29135](https://github.com/bitnami/charts/issues/29135)

## <small>0.3.18 (2024-07-25)</small>

* [bitnami/janusgraph] Release 0.3.18 (#28441) ([cd40414](https://github.com/bitnami/charts/commit/cd40414c99f23f50260d4edf175a684ca09fa7d8)), closes [#28441](https://github.com/bitnami/charts/issues/28441)

## <small>0.3.17 (2024-07-24)</small>

* [bitnami/janusgraph] Release 0.3.17 (#28297) ([3714673](https://github.com/bitnami/charts/commit/371467338b1b7a8e0248e9259d7eb81d2873e6c6)), closes [#28297](https://github.com/bitnami/charts/issues/28297)

## <small>0.3.16 (2024-07-24)</small>

* [bitnami/janusgraph] Release 0.3.16 (#28256) ([911c81e](https://github.com/bitnami/charts/commit/911c81e8749f3c24078fb849cf8ce670464f150f)), closes [#28256](https://github.com/bitnami/charts/issues/28256)

## <small>0.3.15 (2024-07-18)</small>

* [bitnami/janusgraph] Global StorageClass as default value (#28033) ([227a2ce](https://github.com/bitnami/charts/commit/227a2ce1da9ccb452635061bd57ca57e737e203d)), closes [#28033](https://github.com/bitnami/charts/issues/28033)

## <small>0.3.14 (2024-07-05)</small>

* [bitnami/janusgraph] Release 0.3.14 (#27812) ([aa66dd1](https://github.com/bitnami/charts/commit/aa66dd1abf1e766bb54cac5d151e816accedc197)), closes [#27812](https://github.com/bitnami/charts/issues/27812)

## <small>0.3.13 (2024-07-03)</small>

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/janusgraph] Release 0.3.13 (#27697) ([b06ce3d](https://github.com/bitnami/charts/commit/b06ce3d9cba0f89a4eeae4852cb4e710349fc72a)), closes [#27697](https://github.com/bitnami/charts/issues/27697)

## <small>0.3.12 (2024-06-21)</small>

* [bitnami/janusgraph] Fix fullname resolution for cassandra subchart (#27151) ([6773447](https://github.com/bitnami/charts/commit/677344797f3ff1a1342c8237182db17f6c09b675)), closes [#27151](https://github.com/bitnami/charts/issues/27151)

## <small>0.3.11 (2024-06-18)</small>

* [bitnami/janusgraph] Release 0.3.11 (#27358) ([da2f1b0](https://github.com/bitnami/charts/commit/da2f1b06d8cb23a1668f1a1a6b848eddfa502fcb)), closes [#27358](https://github.com/bitnami/charts/issues/27358)

## <small>0.3.10 (2024-06-17)</small>

* [bitnami/janusgraph] Release 0.3.10 (#27235) ([b446901](https://github.com/bitnami/charts/commit/b44690149f00ce2915debf8e060ccfe598ba5383)), closes [#27235](https://github.com/bitnami/charts/issues/27235)

## <small>0.3.9 (2024-06-14)</small>

* [bitnami/janusgraph] Release 0.3.9 (#27170) ([38b4c59](https://github.com/bitnami/charts/commit/38b4c598b430d95d1fe5513490321ffcfcbe1721)), closes [#27170](https://github.com/bitnami/charts/issues/27170)

## <small>0.3.8 (2024-06-12)</small>

* [bitnami/janusgraph] Fix storage password secretName helper function (#27074) ([049dc02](https://github.com/bitnami/charts/commit/049dc029ebcb909073aef82189e29aba73746fc9)), closes [#27074](https://github.com/bitnami/charts/issues/27074)

## <small>0.3.7 (2024-06-06)</small>

* [bitnami/janusgraph] Release 0.3.7 (#26963) ([0ee8a5b](https://github.com/bitnami/charts/commit/0ee8a5bac4ea4b18d6828e7fcfa43259d31d48ca)), closes [#26963](https://github.com/bitnami/charts/issues/26963)

## <small>0.3.6 (2024-06-06)</small>

* [bitnami/janusgraph] Release 0.3.6 (#26894) ([b684e36](https://github.com/bitnami/charts/commit/b684e368fbfba2a7987e094a3fd2ee7d844fb303)), closes [#26894](https://github.com/bitnami/charts/issues/26894)

## <small>0.3.5 (2024-06-06)</small>

* [bitnami/janusgraph] Enable PodDisruptionBudgets (#26697) ([0742dc2](https://github.com/bitnami/charts/commit/0742dc22742d22d19411d888ecf1b6f281cb691e)), closes [#26697](https://github.com/bitnami/charts/issues/26697)

## <small>0.3.4 (2024-06-05)</small>

* [bitnami/janusgraph] Bump chart version (#26836) ([fad1148](https://github.com/bitnami/charts/commit/fad114830abbd0ab2319b046a73017707e457a88)), closes [#26836](https://github.com/bitnami/charts/issues/26836)

## <small>0.3.3 (2024-06-05)</small>

* [bitnami/janusgraph] Bump chart version (#26778) ([88021da](https://github.com/bitnami/charts/commit/88021dac6241b2b98c35deed036f845d8b747ebf)), closes [#26778](https://github.com/bitnami/charts/issues/26778)

## <small>0.3.2 (2024-05-28)</small>

* [bitnami/janusgraph] Add chart source URL to sources list (#26493) ([65e4f64](https://github.com/bitnami/charts/commit/65e4f64beaeeb76a48fbd1454815b4228b47213f)), closes [#26493](https://github.com/bitnami/charts/issues/26493)

## <small>0.3.1 (2024-05-23)</small>

* [bitnami/janusgraph] Use different liveness/readiness probes (#26345) ([454f762](https://github.com/bitnami/charts/commit/454f762736ad95ec4eb1515c247ed4bfa127fabf)), closes [#26345](https://github.com/bitnami/charts/issues/26345)

## 0.3.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/janusgraph] feat: :sparkles: :lock: Add warning when original images are replaced (#26219) ([2de41cc](https://github.com/bitnami/charts/commit/2de41cc762de9c750213ebbe4121ef7924b01b97)), closes [#26219](https://github.com/bitnami/charts/issues/26219)

## 0.2.0 (2024-05-20)

* [bitnami/janusgraph] PDB review (#25936) ([15ee760](https://github.com/bitnami/charts/commit/15ee7604a1b1db4b1e5061b19e907194c629108e)), closes [#25936](https://github.com/bitnami/charts/issues/25936)

## <small>0.1.7 (2024-05-18)</small>

* [bitnami/janusgraph] Release 0.1.7 updating components versions (#26026) ([0e800dc](https://github.com/bitnami/charts/commit/0e800dcb83315b4a5cf883ac6486f82707a89e04)), closes [#26026](https://github.com/bitnami/charts/issues/26026)

## <small>0.1.6 (2024-05-14)</small>

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/janusgraph] Release 0.1.6 updating components versions (#25770) ([20c76cb](https://github.com/bitnami/charts/commit/20c76cbf6bc61c2c73a8e6f2b11571e05863a918)), closes [#25770](https://github.com/bitnami/charts/issues/25770)

## <small>0.1.5 (2024-05-02)</small>

* [bitnami/janusgraph] Add metrics port in networkPolicy ingress (#25498) ([1b280b8](https://github.com/bitnami/charts/commit/1b280b80efe645a602cf4b086de90756c4638aa8)), closes [#25498](https://github.com/bitnami/charts/issues/25498)
* [bitnami/janusgraph] Release 0.1.5 updating components versions (#25502) ([76d2a3e](https://github.com/bitnami/charts/commit/76d2a3e5688ba1e69999ebcfd17ed8103f421b00)), closes [#25502](https://github.com/bitnami/charts/issues/25502)

## <small>0.1.4 (2024-05-02)</small>

* [bitnami/janusgraph] Release 0.1.4 updating components versions (#25495) ([b8e7d16](https://github.com/bitnami/charts/commit/b8e7d16ae35a1afe27019c5d5d4c3ab4b646c747)), closes [#25495](https://github.com/bitnami/charts/issues/25495)

## <small>0.1.3 (2024-04-30)</small>

* [bitnami/janusgraph] Add vib-publish role (#25465) ([81bd3f0](https://github.com/bitnami/charts/commit/81bd3f043fd26bfe2ff469eafea439c16ca4ee88)), closes [#25465](https://github.com/bitnami/charts/issues/25465)

## <small>0.1.2 (2024-04-30)</small>

* [bitnami/janusgraph] Release 0.1.2 updating components versions (#25461) ([0de0beb](https://github.com/bitnami/charts/commit/0de0beb72068879297a577d39568e8ccbc231bc9)), closes [#25461](https://github.com/bitnami/charts/issues/25461)

## <small>0.1.1 (2024-04-30)</small>

* [bitnami/janusgraph] Release 0.1.1 updating components versions (#25458) ([352b0c3](https://github.com/bitnami/charts/commit/352b0c3db4ddb7431d3b1c639f528066f5b5821c)), closes [#25458](https://github.com/bitnami/charts/issues/25458)

## 0.1.0 (2024-04-30)

* [bitnami/janusgraph] Add chart (#24621) ([c225e73](https://github.com/bitnami/charts/commit/c225e73a90453163a337c1c518a850e587b5b7ae)), closes [#24621](https://github.com/bitnami/charts/issues/24621)
