# Changelog

## 0.1.23 (2025-08-14)

* [bitnami/kube-arangodb] :zap: :arrow_up: Update dependency references ([#35874](https://github.com/bitnami/charts/pull/35874))

## <small>0.1.22 (2025-08-07)</small>

* [bitnami/kube-arangodb] :zap: :arrow_up: Update dependency references (#35581) ([7377c1b](https://github.com/bitnami/charts/commit/7377c1b9456ac0cc5986297ba55d46031fceff51)), closes [#35581](https://github.com/bitnami/charts/issues/35581)

## <small>0.1.21 (2025-08-07)</small>

* [bitnami/kube-arangodb] :zap: :arrow_up: Update dependency references (#35491) ([db03bbe](https://github.com/bitnami/charts/commit/db03bbe5b14187a44d8d6fd20420a95da0178531)), closes [#35491](https://github.com/bitnami/charts/issues/35491)

## <small>0.1.20 (2025-08-05)</small>

* [bitnami/kube-arangodb] :zap: :arrow_up: Update dependency references (#35430) ([b51c4e0](https://github.com/bitnami/charts/commit/b51c4e0cd3c45e910020d2e30958cabc6ade51ee)), closes [#35430](https://github.com/bitnami/charts/issues/35430)

## <small>0.1.19 (2025-08-05)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/kube-arangodb] :zap: :arrow_up: Update dependency references (#35426) ([e67fe9c](https://github.com/bitnami/charts/commit/e67fe9ca80c4fb4c194df8e19219ea98672b6de6)), closes [#35426](https://github.com/bitnami/charts/issues/35426)

## <small>0.1.18 (2025-07-09)</small>

* [bitnami/kube-arangodb] :zap: :arrow_up: Update dependency references (#34913) ([d40f12c](https://github.com/bitnami/charts/commit/d40f12cad51b3ec2c878f4e888b91e2ebd5374aa)), closes [#34913](https://github.com/bitnami/charts/issues/34913)

## <small>0.1.17 (2025-07-04)</small>

* [bitnami/kube-arangodb] :zap: :arrow_up: Update dependency references (#34799) ([c7cba99](https://github.com/bitnami/charts/commit/c7cba99ab8328d65a6fc8180dfdb801da5ccb388)), closes [#34799](https://github.com/bitnami/charts/issues/34799)

## <small>0.1.16 (2025-06-18)</small>

* [bitnami/kube-arangodb] :zap: :arrow_up: Update dependency references (#34537) ([57aa4d9](https://github.com/bitnami/charts/commit/57aa4d98a64298752ae8498816a938daf0ee42e1)), closes [#34537](https://github.com/bitnami/charts/issues/34537)

## <small>0.1.15 (2025-06-13)</small>

* [bitnami/kube-arangodb] :zap: :arrow_up: Update dependency references (#34459) ([689aae7](https://github.com/bitnami/charts/commit/689aae708fb400a8f381773fda3ece3b3927e3fb)), closes [#34459](https://github.com/bitnami/charts/issues/34459)

## <small>0.1.14 (2025-06-06)</small>

* [bitnami/kube-arangodb] :zap: :arrow_up: Update dependency references (#34181) ([f49a1a2](https://github.com/bitnami/charts/commit/f49a1a20bed62a8edf68b8d5fca2c30236e87268)), closes [#34181](https://github.com/bitnami/charts/issues/34181)

## <small>0.1.13 (2025-05-20)</small>

* [bitnami/kube-arangodb] :zap: :arrow_up: Update dependency references (#33787) ([8c42156](https://github.com/bitnami/charts/commit/8c421566a09cdd63fcbc69f16e596a61df9bf324)), closes [#33787](https://github.com/bitnami/charts/issues/33787)
* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)

## <small>0.1.12 (2025-05-08)</small>

* [bitnami/kube-arangodb] :zap: :arrow_up: Update dependency references (#33564) ([a3dfe62](https://github.com/bitnami/charts/commit/a3dfe62fbefc97ef866fdbc3f2c25472c46db148)), closes [#33564](https://github.com/bitnami/charts/issues/33564)

## <small>0.1.11 (2025-05-07)</small>

* [bitnami/kube-arangodb] Release 0.1.11 (#33517) ([9434d7c](https://github.com/bitnami/charts/commit/9434d7cb5843f53850b6ea9d5809fe8f93f3035c)), closes [#33517](https://github.com/bitnami/charts/issues/33517)

## <small>0.1.10 (2025-05-06)</small>

* [bitnami/kube-arangodb] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references ( ([6132136](https://github.com/bitnami/charts/commit/6132136a1c80de7cf4ac0fa58e6a01114f0dbc59)), closes [#33386](https://github.com/bitnami/charts/issues/33386)

## <small>0.1.9 (2025-05-01)</small>

* [bitnami/kube-arangodb] Release 0.1.9 (#33292) ([c8ac221](https://github.com/bitnami/charts/commit/c8ac221845f2646e59b14111153f78745455dcc4)), closes [#33292](https://github.com/bitnami/charts/issues/33292)

## <small>0.1.8 (2025-04-21)</small>

* [bitnami/kube-arangodb] Release 0.1.7 (#32740) ([cb6e10f](https://github.com/bitnami/charts/commit/cb6e10f445931655265cbef55e4dd6584b833937)), closes [#32740](https://github.com/bitnami/charts/issues/32740)

## <small>0.1.7 (2025-04-08)</small>

* [bitnami/kube-arangodb] Chore/kube arangodb correct typo chaows (#32849) ([30434ab](https://github.com/bitnami/charts/commit/30434ab690cb6b52d248ff1289adff0c9a2d4dcd)), closes [#32849](https://github.com/bitnami/charts/issues/32849)

## <small>0.1.6 (2025-03-28)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/kube-arangodb] Release 0.1.6 updating components versions (#32655) ([00660b2](https://github.com/bitnami/charts/commit/00660b2d4d38484b27e9754fbc0c34fa28b7b75b)), closes [#32655](https://github.com/bitnami/charts/issues/32655)

## <small>0.1.5 (2025-03-05)</small>

* [bitnami/kube-arangodb] Release 0.1.5 (#32298) ([4c9f284](https://github.com/bitnami/charts/commit/4c9f284bbe42918aacab93b6315add30528abe6b)), closes [#32298](https://github.com/bitnami/charts/issues/32298)

## <small>0.1.4 (2025-02-26)</small>

* [bitnami/kube-arangodb] Release 0.1.4 (#32186) ([98789f6](https://github.com/bitnami/charts/commit/98789f6b2c2cffaf7b6c469102fdd81a8e1c5567)), closes [#32186](https://github.com/bitnami/charts/issues/32186)

## <small>0.1.3 (2025-02-26)</small>

* [bitnami/kube-arangodb] test: :white_check_mark: Disable metrics body check ([d47cdbc](https://github.com/bitnami/charts/commit/d47cdbca7dde1b078741fcda0ad8808d942ba7d2))

## <small>0.1.2 (2025-02-26)</small>

* [bitnami/kube-arangodb] test: :white_check_mark: Bump goss timeouts ([f04ba89](https://github.com/bitnami/charts/commit/f04ba89e09d0825f5d153cfbfca3ba3109089ae5))

## <small>0.1.1 (2025-02-26)</small>

* [bitnami/kube-arangodb] Release 0.1.1 (#32180) ([d22fb84](https://github.com/bitnami/charts/commit/d22fb84f8a4ca4775b01b15d8399596f9706ddd4)), closes [#32180](https://github.com/bitnami/charts/issues/32180)

## 0.1.0 (2025-02-26)

* [bitnami/kube-arangodb] feat: :tada: Add chart (#32153) ([cb334b2](https://github.com/bitnami/charts/commit/cb334b2bd4ae4e8da28ccb373200142753421dc7)), closes [#32153](https://github.com/bitnami/charts/issues/32153)
