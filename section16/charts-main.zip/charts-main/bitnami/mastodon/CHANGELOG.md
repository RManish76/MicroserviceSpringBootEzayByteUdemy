# Changelog

## 14.0.0 (2025-08-11)

* [bitnami/mastodon] Upgrade to Redis subchart 22 ([#35721](https://github.com/bitnami/charts/pull/35721))

## <small>13.0.13 (2025-08-08)</small>

* [bitnami/mastodon] :zap: :arrow_up: Update dependency references (#35703) ([81c0893](https://github.com/bitnami/charts/commit/81c089304112a09197f32b434f0de43800515c3e)), closes [#35703](https://github.com/bitnami/charts/issues/35703)

## <small>13.0.12 (2025-08-07)</small>

* [bitnami/mastodon] :zap: :arrow_up: Update dependency references (#35619) ([52a168c](https://github.com/bitnami/charts/commit/52a168cf7984aa0ca26f47f93188af3c876adb0d)), closes [#35619](https://github.com/bitnami/charts/issues/35619)

## <small>13.0.11 (2025-08-07)</small>

* [bitnami/mastodon] :zap: :arrow_up: Update dependency references (#35592) ([148d426](https://github.com/bitnami/charts/commit/148d42603cc31e0c1b31b5161c8ce50f4b95911c)), closes [#35592](https://github.com/bitnami/charts/issues/35592)

## <small>13.0.10 (2025-08-05)</small>

* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/mastodon] :zap: :arrow_up: Update dependency references (#35428) ([daeb6a0](https://github.com/bitnami/charts/commit/daeb6a0dfaa58cbec30b5c2c52b17bcb1915da87)), closes [#35428](https://github.com/bitnami/charts/issues/35428)

## <small>13.0.9 (2025-07-23)</small>

* [bitnami/mastodon] :zap: :arrow_up: Update dependency references (#35269) ([c9bbc3c](https://github.com/bitnami/charts/commit/c9bbc3c02b99fd9df1fc15459e4f70c5873f40f8)), closes [#35269](https://github.com/bitnami/charts/issues/35269)

## <small>13.0.8 (2025-07-17)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/mastodon] :zap: :arrow_up: Update dependency references (#35183) ([328116c](https://github.com/bitnami/charts/commit/328116c05c7c9834d0726a360a277d4c3032afee)), closes [#35183](https://github.com/bitnami/charts/issues/35183)

## <small>13.0.7 (2025-07-15)</small>

* [bitnami/mastodon] :zap: :arrow_up: Update dependency references (#35139) ([419ff09](https://github.com/bitnami/charts/commit/419ff09ba4b51e863621777d0a17c339b4ed8c5c)), closes [#35139](https://github.com/bitnami/charts/issues/35139)

## <small>13.0.6 (2025-07-06)</small>

* [bitnami/mastodon] :zap: :arrow_up: Update dependency references (#34812) ([f43f3c3](https://github.com/bitnami/charts/commit/f43f3c3d133970395d79e54e0167cb5db800db08)), closes [#34812](https://github.com/bitnami/charts/issues/34812)

## <small>13.0.5 (2025-07-02)</small>

* [bitnami/mastodon] :zap: :arrow_up: Update dependency references (#34771) ([6a2aa5d](https://github.com/bitnami/charts/commit/6a2aa5dfcdc7f7ec3de69863e716e17b8e8ba2e6)), closes [#34771](https://github.com/bitnami/charts/issues/34771)

## <small>13.0.4 (2025-06-26)</small>

* [bitnami/mastodon] fix: correct indentation for extraEnvVars in tootctlMediaManagement cronjob defin ([b053acd](https://github.com/bitnami/charts/commit/b053acda4b4f84a8940a9f58973dc60f1850c517)), closes [#33981](https://github.com/bitnami/charts/issues/33981)

## <small>13.0.3 (2025-06-23)</small>

* [bitnami/mastodon] fix broken PDB Label matching (#34566) ([d8270d4](https://github.com/bitnami/charts/commit/d8270d4678b71c0081744873cb64def675bb8e62)), closes [#34566](https://github.com/bitnami/charts/issues/34566) [#34544](https://github.com/bitnami/charts/issues/34544)

## <small>13.0.2 (2025-06-09)</small>

* [bitnami/mastodon] Disable MinIO Console (#34266) ([e3949da](https://github.com/bitnami/charts/commit/e3949daf52445ad142cfa3ff80f218d470dd8539)), closes [#34266](https://github.com/bitnami/charts/issues/34266)

## <small>13.0.1 (2025-06-05)</small>

* [bitnami/mastodon] :zap: :arrow_up: Update dependency references (#34126) ([f5df349](https://github.com/bitnami/charts/commit/f5df349c81da25bad94adeba8561f1b96372ccd7)), closes [#34126](https://github.com/bitnami/charts/issues/34126)

## 13.0.0 (2025-06-04)

* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)
* [bitnami/mastodon] feat: major version due to Minio major bump (#34088) ([0ee5707](https://github.com/bitnami/charts/commit/0ee57073d3245196ded9b8225b932e91ba4338c1)), closes [#34088](https://github.com/bitnami/charts/issues/34088)

## 12.0.0 (2025-05-07)

* [bitnami/mastodon] feat!: :arrow_up: :boom: Bump Redis(R) to 8.0 (#33505) ([8501340](https://github.com/bitnami/charts/commit/8501340dac19dbffe07789f4faae139131a5a091)), closes [#33505](https://github.com/bitnami/charts/issues/33505)

## <small>11.0.2 (2025-05-06)</small>

* [bitnami/mastodon] Release 11.0.2 (#33463) ([336ac7a](https://github.com/bitnami/charts/commit/336ac7a11f3751e2c1570b084530007e68cc708c)), closes [#33463](https://github.com/bitnami/charts/issues/33463)

## <small>11.0.1 (2025-05-06)</small>

* [bitnami/mastodon] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#3339 ([94c9020](https://github.com/bitnami/charts/commit/94c902008f4dda66063d6820e443afadf72fce95)), closes [#33395](https://github.com/bitnami/charts/issues/33395)

## 11.0.0 (2025-04-30)

* [bitnami/mastodon] major: Upgrade elasticsearch subchart to 22.x.x (ES 9.x) (#33264) ([ffb165a](https://github.com/bitnami/charts/commit/ffb165a2535d93a78333d01aaea1a37bb7141490)), closes [#33264](https://github.com/bitnami/charts/issues/33264)

## <small>10.1.1 (2025-04-09)</small>

* [bitnami/mastodon] Release 10.1.1 (#32909) ([42032e2](https://github.com/bitnami/charts/commit/42032e24c96811e5809ba6991bd1b59d43c075fb)), closes [#32909](https://github.com/bitnami/charts/issues/32909)

## 10.1.0 (2025-04-04)

* [bitnami/mastodon] Set `usePasswordFiles=true` by default (#32367) ([410b9a2](https://github.com/bitnami/charts/commit/410b9a27153710a4fae9a1eeb1ca182c63e76118)), closes [#32367](https://github.com/bitnami/charts/issues/32367)

## <small>10.0.1 (2025-04-03)</small>

* [bitnami/mastodon] Release 10.0.1 (#32803) ([41f62c8](https://github.com/bitnami/charts/commit/41f62c8333b88d11169ca08f7f1c8ce9b3a1ed73)), closes [#32803](https://github.com/bitnami/charts/issues/32803)

## 10.0.0 (2025-04-03)

* [bitnami/mastodon] Bump MinIO major version 16.x.x (#32700) ([dfd61a0](https://github.com/bitnami/charts/commit/dfd61a00e9e7ac67251f68b3a273e7b6368e84ff)), closes [#32700](https://github.com/bitnami/charts/issues/32700)

## <small>9.2.9 (2025-04-02)</small>

* [bitnami/mastodon] Release 9.2.9 (#32785) ([14e9623](https://github.com/bitnami/charts/commit/14e96230f82d5a26ae12bd381a43819fd1ec2847)), closes [#32785](https://github.com/bitnami/charts/issues/32785)

## <small>9.2.8 (2025-04-01)</small>

* [bitnami/mastodon] Release 9.2.8 (#32711) ([256efe8](https://github.com/bitnami/charts/commit/256efe8969ab8f46739d15b8d25ccf42988521c2)), closes [#32711](https://github.com/bitnami/charts/issues/32711)

## <small>9.2.7 (2025-03-13)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/mastodon] Release 9.2.7 (#32447) ([9e82185](https://github.com/bitnami/charts/commit/9e8218519bb1197509174b5c88f1dff86e8daea4)), closes [#32447](https://github.com/bitnami/charts/issues/32447)

## <small>9.2.6 (2025-03-10)</small>

* [bitnami/mastodon] Release 9.2.6 (#32380) ([bb410bc](https://github.com/bitnami/charts/commit/bb410bc61d3e15edb683b5c264b8388628968ee0)), closes [#32380](https://github.com/bitnami/charts/issues/32380)

## <small>9.2.5 (2025-02-27)</small>

* [bitnami/mastodon] Release 9.2.5 (#32205) ([d84356d](https://github.com/bitnami/charts/commit/d84356dc0c4fac089b3cfc2c9a189e228e3f7809)), closes [#32205](https://github.com/bitnami/charts/issues/32205)

## <small>9.2.4 (2025-02-27)</small>

* [bitnami/mastodon] Release 9.2.4 (#32199) ([dd96507](https://github.com/bitnami/charts/commit/dd965077cbfcedbb6998d5a56eee410fa6e0e6f3)), closes [#32199](https://github.com/bitnami/charts/issues/32199)

## <small>9.2.3 (2025-02-14)</small>

* [bitnami/mastodon] Release 9.2.3 (#31933) ([82aa57f](https://github.com/bitnami/charts/commit/82aa57ff62a509052831636fad761932a744a678)), closes [#31933](https://github.com/bitnami/charts/issues/31933)

## <small>9.2.2 (2025-02-13)</small>

* [bitnami/mastodon] Release 9.2.2 (#31920) ([7d7cc5b](https://github.com/bitnami/charts/commit/7d7cc5bb02f8d539f3e4e2b32f0f0ec4c59d8631)), closes [#31920](https://github.com/bitnami/charts/issues/31920)

## <small>9.2.1 (2025-02-13)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/mastodon] Release 9.2.1 (#31916) ([27d24fb](https://github.com/bitnami/charts/commit/27d24fbec625ce5c4ca93018e618da004a4df131)), closes [#31916](https://github.com/bitnami/charts/issues/31916)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## 9.2.0 (2025-01-29)

* [bitnami/mastodon] feature(minio): Bump MinIO subchart (#31660) ([fcdd884](https://github.com/bitnami/charts/commit/fcdd88475b946b0a56e1738dc8d4c3d775416dba)), closes [#31660](https://github.com/bitnami/charts/issues/31660)

## <small>9.1.3 (2025-01-16)</small>

* [bitnami/mastodon] Release 9.1.3 (#31400) ([a5b97a0](https://github.com/bitnami/charts/commit/a5b97a0c64ce4cabccde11f94e3a641d63cd125b)), closes [#31400](https://github.com/bitnami/charts/issues/31400)

## <small>9.1.2 (2025-01-12)</small>

* [bitnami/mastodon] Release 9.1.2 (#31308) ([712bf25](https://github.com/bitnami/charts/commit/712bf2565a95cc41b01448f2551d19f40ea12898)), closes [#31308](https://github.com/bitnami/charts/issues/31308)

## <small>9.1.1 (2024-12-30)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/mastodon] Avoid mkdir issue when restarting (#31183) ([3e3b679](https://github.com/bitnami/charts/commit/3e3b6794ef9d0fa28a953d0c7932d46788b6d7a9)), closes [#31183](https://github.com/bitnami/charts/issues/31183)

## 9.1.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/mastodon] Detect non-standard images (#30921) ([eea0814](https://github.com/bitnami/charts/commit/eea08143bfe95dfbd356d5f5fa8eb663b9bf130e)), closes [#30921](https://github.com/bitnami/charts/issues/30921)

## <small>9.0.5 (2024-12-03)</small>

* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/*] docs: :memo: Add "Update Credentials" (batch 2) (#30687) ([c457848](https://github.com/bitnami/charts/commit/c457848b2a111aad59830b98f85ffa1e29918e10)), closes [#30687](https://github.com/bitnami/charts/issues/30687)
* [bitnami/*] docs: :memo: Unify "Securing Traffic using TLS" section (#30707) ([b572333](https://github.com/bitnami/charts/commit/b57233336e4fe9af928ecb4f2a5f334011efb1bc)), closes [#30707](https://github.com/bitnami/charts/issues/30707)
* [bitnami/mastodon] Release 9.0.5 (#30738) ([aec6ca5](https://github.com/bitnami/charts/commit/aec6ca52a4f822a7f7ccfa26187d413e2acb3ffe)), closes [#30738](https://github.com/bitnami/charts/issues/30738)

## <small>9.0.4 (2024-11-09)</small>

* [bitnami/mastodon] Release 9.0.4 (#30383) ([61061fc](https://github.com/bitnami/charts/commit/61061fc59a391e70de4782d64ce5e4a17d2115f1)), closes [#30383](https://github.com/bitnami/charts/issues/30383)

## <small>9.0.3 (2024-11-08)</small>

* [bitnami/mastodon] Unify seLinuxOptions default value (#30344) ([8bdf86a](https://github.com/bitnami/charts/commit/8bdf86acdaef7ebbf4f2f4e5dcac161f24f0209b)), closes [#30344](https://github.com/bitnami/charts/issues/30344)
* [bitnami/mastodon][bitnami/prometheus] Fix README.md files typos (#30194) ([0ef19fb](https://github.com/bitnami/charts/commit/0ef19fb4ac61547d519c9cc029f39b7026ab70e2)), closes [#30194](https://github.com/bitnami/charts/issues/30194)

## <small>9.0.2 (2024-11-04)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/mastodon] Mastodon initjob always tries to create admin on upgrade (#30171) ([14072e2](https://github.com/bitnami/charts/commit/14072e239862772aee311a73fb81538e0e02a377)), closes [#30171](https://github.com/bitnami/charts/issues/30171)

## <small>9.0.1 (2024-10-21)</small>

* [bitnami/mastodon] Release 9.0.1 (#30019) ([3ab0d63](https://github.com/bitnami/charts/commit/3ab0d63af56499b5072e7d82c168ce42b3e55c84)), closes [#30019](https://github.com/bitnami/charts/issues/30019)

## 9.0.0 (2024-10-17)

* [bitnami/mastodon] feat!: :sparkles: :boom: :recycle: Bump appVersion to 4.3 and refactor init conta ([ef3176d](https://github.com/bitnami/charts/commit/ef3176d2a3241029d9e825f2527802144a9ebe0d)), closes [#29900](https://github.com/bitnami/charts/issues/29900)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## 8.0.0 (2024-10-03)

* [bitnami/mastodon] feat!: :arrow_up: :boom: Bump PostgreSQL to 17.x (#29739) ([2be9de6](https://github.com/bitnami/charts/commit/2be9de659f83dc24dcbbffe1d4dd67fd4a4320bb)), closes [#29739](https://github.com/bitnami/charts/issues/29739)

## <small>7.0.6 (2024-09-30)</small>

* [bitnami/mastodon] Release 7.0.6 (#29672) ([dddf994](https://github.com/bitnami/charts/commit/dddf994e3793539769ffe28ec9c7f961a8711a19)), closes [#29672](https://github.com/bitnami/charts/issues/29672)

## <small>7.0.5 (2024-09-19)</small>

* [bitnami/mastodon] Release 7.0.5 (#29524) ([87ff268](https://github.com/bitnami/charts/commit/87ff26881dc0fe0741dd88bb6513834a56c4ad65)), closes [#29524](https://github.com/bitnami/charts/issues/29524)

## <small>7.0.4 (2024-08-23)</small>

* [bitnami/mastodon] Release 7.0.4 (#29009) ([0865037](https://github.com/bitnami/charts/commit/086503709d05f40bf7f881d4f8d55b7248b2e694)), closes [#29009](https://github.com/bitnami/charts/issues/29009)

## <small>7.0.3 (2024-08-22)</small>

* [bitnami/mastodon] Release 7.0.3 (#28973) ([f4c3d49](https://github.com/bitnami/charts/commit/f4c3d494201bb09dd721466fb3ba9d8d66f9eeff)), closes [#28973](https://github.com/bitnami/charts/issues/28973)

## <small>7.0.2 (2024-08-19)</small>

* [bitnami/mastodon] Release 7.0.2 (#28928) ([f89985d](https://github.com/bitnami/charts/commit/f89985d1d5c1c4eacbc1a1e3376f957e5b8db462)), closes [#28928](https://github.com/bitnami/charts/issues/28928)

## <small>7.0.1 (2024-08-16)</small>

* [bitnami/mastodon] Release 7.0.1 (#28907) ([7c6b839](https://github.com/bitnami/charts/commit/7c6b839d9836292330040cb33681345584e08c1c)), closes [#28907](https://github.com/bitnami/charts/issues/28907)

## 7.0.0 (2024-08-13)

* [bitnami/mastodon] Update dependencies (#28855) ([161cd16](https://github.com/bitnami/charts/commit/161cd168cefeb099b85a1a688581b2003c3699cc)), closes [#28855](https://github.com/bitnami/charts/issues/28855)

## <small>6.2.11 (2024-07-30)</small>

* [bitnami/mastodon] Release 6.2.10 (#28479) ([b62efc4](https://github.com/bitnami/charts/commit/b62efc4fa8af8683c3a4f5add735ec1f670ed489)), closes [#28479](https://github.com/bitnami/charts/issues/28479)

## <small>6.2.10 (2024-07-29)</small>

* [bitnami/mastodon] Improve init-job stability (#28553) ([befdf07](https://github.com/bitnami/charts/commit/befdf07bececdf47b43c0b5e0abf9981457e6f3d)), closes [#28553](https://github.com/bitnami/charts/issues/28553)

## <small>6.2.9 (2024-07-22)</small>

* [bitnami/mastodon] Global StorageClass as default value (#28052) ([f3ba3c5](https://github.com/bitnami/charts/commit/f3ba3c5c7a1015f0c60a1d13de63bb2bbc43d786)), closes [#28052](https://github.com/bitnami/charts/issues/28052)

## <small>6.2.8 (2024-07-04)</small>

* [bitnami/mastodon] Release 6.2.8 (#27784) ([6d194a4](https://github.com/bitnami/charts/commit/6d194a4b0befdf6e0ae786db6431cb759253367e)), closes [#27784](https://github.com/bitnami/charts/issues/27784)

## <small>6.2.7 (2024-07-03)</small>

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/mastodon] Release 6.2.7 (#27703) ([2853b4f](https://github.com/bitnami/charts/commit/2853b4f5aa2764d169bf172fa7995ce0b2151d5c)), closes [#27703](https://github.com/bitnami/charts/issues/27703)

## <small>6.2.6 (2024-06-18)</small>

* [bitnami/mastodon] Release 6.2.6 (#27374) ([cdaa431](https://github.com/bitnami/charts/commit/cdaa43156c0d28183ee734604fb081013b0bd6e9)), closes [#27374](https://github.com/bitnami/charts/issues/27374)

## <small>6.2.5 (2024-06-17)</small>

* [bitnami/mastodon] Release 6.2.5 (#27244) ([6b0c126](https://github.com/bitnami/charts/commit/6b0c126c64627fee7ffd27764b9523a56179960c)), closes [#27244](https://github.com/bitnami/charts/issues/27244)

## <small>6.2.4 (2024-06-06)</small>

* [bitnami/mastodon] Release 6.2.4 (#26980) ([33f41e4](https://github.com/bitnami/charts/commit/33f41e4b48d3f002f6bf02df45020476a478c2eb)), closes [#26980](https://github.com/bitnami/charts/issues/26980)

## <small>6.2.3 (2024-06-05)</small>

* [bitnami/mastodon] Bump chart version (#26844) ([cc50d1b](https://github.com/bitnami/charts/commit/cc50d1b1c130a48839550b45abe495d26ce2894f)), closes [#26844](https://github.com/bitnami/charts/issues/26844)

## <small>6.2.2 (2024-06-05)</small>

* [bitnami/mastodon] Bump chart version (#26786) ([f5653a0](https://github.com/bitnami/charts/commit/f5653a0878f5a474cd6c56dd81a90238208f5629)), closes [#26786](https://github.com/bitnami/charts/issues/26786)

## <small>6.2.1 (2024-05-30)</small>

* [bitnami/mastodon] Release 6.2.1 (#26568) ([8abb300](https://github.com/bitnami/charts/commit/8abb300130f09fa8ab372017090e4fca55d36d78)), closes [#26568](https://github.com/bitnami/charts/issues/26568)

## 6.2.0 (2024-05-30)

* [bitnami/mastodon] Enable PodDisruptionBudgets (#26508) ([0b2205a](https://github.com/bitnami/charts/commit/0b2205adbf2199c48a63cd016137fd3b1f4c88b3)), closes [#26508](https://github.com/bitnami/charts/issues/26508)

## <small>6.1.1 (2024-05-22)</small>

* [bitnami/mastodon] Use different liveness/readiness probes (#26126) ([5aa7f5b](https://github.com/bitnami/charts/commit/5aa7f5b959bb9ff0c94950da84b4a48f2e1368ef)), closes [#26126](https://github.com/bitnami/charts/issues/26126)

## 6.1.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/mastodon] feat: :sparkles: :lock: Add warning when original images are replaced (#26238) ([d8f42ab](https://github.com/bitnami/charts/commit/d8f42ab4bf000173581521e1329c8a80c28e9e65)), closes [#26238](https://github.com/bitnami/charts/issues/26238)

## <small>6.0.3 (2024-05-18)</small>

* [bitnami/mastodon] Release 6.0.3 updating components versions (#26042) ([5b3dc21](https://github.com/bitnami/charts/commit/5b3dc216f7360e1e789f645d273a6df46139b1ac)), closes [#26042](https://github.com/bitnami/charts/issues/26042)

## <small>6.0.2 (2024-05-14)</small>

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/mastodon] Release 6.0.2 updating components versions (#25788) ([79c6407](https://github.com/bitnami/charts/commit/79c6407d45d322fb83856fafbae9a961042b2811)), closes [#25788](https://github.com/bitnami/charts/issues/25788)

## <small>6.0.1 (2024-04-26)</small>

* [bitnami/mastodon] Release 6.0.1 updating components versions (#25408) ([529bd50](https://github.com/bitnami/charts/commit/529bd507fe9ce3daeb9bcb174edb4de1d83ff723)), closes [#25408](https://github.com/bitnami/charts/issues/25408)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## 6.0.0 (2024-04-22)

* [bitnami/mastodon] Update dependencies of the chart (#25299) ([6931be6](https://github.com/bitnami/charts/commit/6931be60e6667960245e8f24c88e4e22bf82a159)), closes [#25299](https://github.com/bitnami/charts/issues/25299)

## <small>5.0.1 (2024-04-17)</small>

* [bitnami/*] Readme typos (#24852) ([532fcdc](https://github.com/bitnami/charts/commit/532fcdc499cb67eccf0ade49ff1c02d3deb1d696)), closes [#24852](https://github.com/bitnami/charts/issues/24852)
* [bitnami/mastodon] Release 5.0.1 updating components versions (#25208) ([a3757dc](https://github.com/bitnami/charts/commit/a3757dcb41f0d2007244521fed7edfa5e5a9a440)), closes [#25208](https://github.com/bitnami/charts/issues/25208)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## 5.0.0 (2024-04-01)

* [bitnami/mastodon] feat!: :lock: :boom: Improve security defaults (#24768) ([98c278a](https://github.com/bitnami/charts/commit/98c278adbd66804a449985755b74cac1cfaa48d4)), closes [#24768](https://github.com/bitnami/charts/issues/24768)
* [bitnami/several] Fix comment mentioning Keycloak (#24661) ([641c546](https://github.com/bitnami/charts/commit/641c5468069de826c12d1e7c825807cf68b4ee96)), closes [#24661](https://github.com/bitnami/charts/issues/24661)

## <small>4.7.3 (2024-03-25)</small>

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* [bitnami/mastodon] Fix Sidekiq jobs failing (temp directory detection) (#24407) ([e5b859d](https://github.com/bitnami/charts/commit/e5b859d83dd89e578ebd1530ca3ac1f552cef908)), closes [#24407](https://github.com/bitnami/charts/issues/24407)

## <small>4.7.2 (2024-03-13)</small>

* [bitnami/mastodon] Update chart deps (#24398) ([f0c6421](https://github.com/bitnami/charts/commit/f0c6421e1c90d8d561d501726e712211602a88d1)), closes [#24398](https://github.com/bitnami/charts/issues/24398)

## <small>4.7.1 (2024-03-08)</small>

* [bitnami/mastodon] Release 4.7.1 updating components versions (#24299) ([b958595](https://github.com/bitnami/charts/commit/b958595903fc7020b3b6c557864bb7e093dc74fa)), closes [#24299](https://github.com/bitnami/charts/issues/24299)

## 4.7.0 (2024-03-07)

* [bitnami/mastodon] feat: :sparkles: :lock: Add readOnlyRootFilesystem support (#23968) ([6139cc7](https://github.com/bitnami/charts/commit/6139cc7bdabea75d78640bb50f4e96c95c1d32d8)), closes [#23968](https://github.com/bitnami/charts/issues/23968)

## 4.6.0 (2024-03-06)

* [bitnami/mastodon] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v2 SCC  ([161ccc8](https://github.com/bitnami/charts/commit/161ccc8bad5b34f25b5c636b616bfc93ff0166aa)), closes [#24115](https://github.com/bitnami/charts/issues/24115)

## <small>4.5.4 (2024-03-04)</small>

* [bitnami/mastodon] Release 4.5.4 updating components versions (#24037) ([d51f769](https://github.com/bitnami/charts/commit/d51f769586d99b6534f3ef875060595ac1d5cdd6)), closes [#24037](https://github.com/bitnami/charts/issues/24037)

## <small>4.5.3 (2024-03-01)</small>

* [bitnami/mastodon] Release 4.5.3 updating components versions (#24001) ([90d54e0](https://github.com/bitnami/charts/commit/90d54e0c436b1d5d1efcd05d664e978bdba265a2)), closes [#24001](https://github.com/bitnami/charts/issues/24001)

## <small>4.5.2 (2024-02-22)</small>

* [bitnami/mastodon] Release 4.5.2 updating components versions (#23799) ([7882e6b](https://github.com/bitnami/charts/commit/7882e6b15f713917c662cd6fa25c88e6d198a30a)), closes [#23799](https://github.com/bitnami/charts/issues/23799)

## <small>4.5.1 (2024-02-21)</small>

* [bitnami/mastodon] Release 4.5.1 updating components versions (#23725) ([82c460f](https://github.com/bitnami/charts/commit/82c460feb8decbfaab69e3aa8992c002b8c17098)), closes [#23725](https://github.com/bitnami/charts/issues/23725)

## 4.5.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## 4.4.0 (2024-02-15)

* [bitnami/mastodon] feat: :sparkles: :lock: Add resource preset support (#23482) ([2373452](https://github.com/bitnami/charts/commit/2373452de3a4a106d56570e66125ac5f4a74e109)), closes [#23482](https://github.com/bitnami/charts/issues/23482)

## 4.3.0 (2024-02-07)

* [bitnami/mastodon] feat: :lock: Enable networkPolicy (#23050) ([0e872fb](https://github.com/bitnami/charts/commit/0e872fb17f8be98def8ffbbd1d46c1f463654184)), closes [#23050](https://github.com/bitnami/charts/issues/23050)

## <small>4.2.5 (2024-02-03)</small>

* [bitnami/mastodon] Release 4.2.5 updating components versions (#23105) ([e868135](https://github.com/bitnami/charts/commit/e868135489ef7140c70b5f4bc94c58bca90c15b8)), closes [#23105](https://github.com/bitnami/charts/issues/23105)

## <small>4.2.4 (2024-02-02)</small>

* [bitnami/mastodon]: fix indentation of extraVolumes (#22217) ([0cd94b2](https://github.com/bitnami/charts/commit/0cd94b2327a89c44a269a5a994d784871b2dface)), closes [#22217](https://github.com/bitnami/charts/issues/22217)

## <small>4.2.3 (2024-01-31)</small>

* [bitnami/mastodon] Release 4.2.3 updating components versions (#22939) ([eeaa15b](https://github.com/bitnami/charts/commit/eeaa15baef856243725d205090cba13956a9f057)), closes [#22939](https://github.com/bitnami/charts/issues/22939)

## <small>4.2.2 (2024-01-30)</small>

* [bitnami/mastodon] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22619) ([c8c5eff](https://github.com/bitnami/charts/commit/c8c5eff74a1794183be7aef5d45955ad35dcbd49)), closes [#22619](https://github.com/bitnami/charts/issues/22619)
* [bitnami/mastodon] Release 4.2.2 updating components versions (#22857) ([1eafd3c](https://github.com/bitnami/charts/commit/1eafd3c8a123424073986ed8dbddc652a97a3681)), closes [#22857](https://github.com/bitnami/charts/issues/22857)

## <small>4.2.1 (2024-01-24)</small>

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/mastodon] Release 4.2.1 updating components versions (#22710) ([9fab9f9](https://github.com/bitnami/charts/commit/9fab9f9c645e05d79c31172a36539d2a4fcf9a44)), closes [#22710](https://github.com/bitnami/charts/issues/22710)

## 4.2.0 (2024-01-22)

* [bitnami/mastodon] fix: :lock: Move service-account token auto-mount to pod declaration (#22429) ([fffc63a](https://github.com/bitnami/charts/commit/fffc63adc555d49500e43a48c5fb643edd83bc12)), closes [#22429](https://github.com/bitnami/charts/issues/22429)

## <small>4.1.1 (2024-01-18)</small>

* [bitnami/mastodon] Release 4.1.1 updating components versions (#22301) ([1d98461](https://github.com/bitnami/charts/commit/1d98461487fa63eeced654f5efcbd223841dd567)), closes [#22301](https://github.com/bitnami/charts/issues/22301)

## 4.1.0 (2024-01-16)

* [bitnami/mastodon] fix: :lock: Improve podSecurityContext and containerSecurityContext with essentia ([04536ed](https://github.com/bitnami/charts/commit/04536ed009313dd2c709e5f959e12ef94d955e30)), closes [#22150](https://github.com/bitnami/charts/issues/22150)

## <small>4.0.4 (2024-01-12)</small>

* [bitnami/mastodon] fix: :lock: Do not automount the service account token unless necessary (#22052) ([d5624c6](https://github.com/bitnami/charts/commit/d5624c665088312b6ef895b51ef9a851294a5c43)), closes [#22052](https://github.com/bitnami/charts/issues/22052)

## <small>4.0.3 (2024-01-12)</small>

* [bitnami/*] Fix docs.bitnami.com broken links (#21901) ([f35506d](https://github.com/bitnami/charts/commit/f35506d2dadee4f097986e7792df1f53ab215b5d)), closes [#21901](https://github.com/bitnami/charts/issues/21901)
* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/mastodon] Release 4.0.3 updating components versions (#22012) ([5ac8dcc](https://github.com/bitnami/charts/commit/5ac8dcce9f7f0bee4019d40f4ac982146be8a998)), closes [#22012](https://github.com/bitnami/charts/issues/22012)

## <small>4.0.2 (2024-01-03)</small>

* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)
* [bitnami/mastodon] Release 4.0.2 updating components versions (#21836) ([8466f43](https://github.com/bitnami/charts/commit/8466f43c05bc7b7955fe8a3c12e772affc1de1f6)), closes [#21836](https://github.com/bitnami/charts/issues/21836)

## <small>4.0.1 (2023-12-29)</small>

* [bitnami/mastodon] Release 4.0.1 updating components versions (#21788) ([491ca38](https://github.com/bitnami/charts/commit/491ca3890bb98426ef04e6af82854a5a6350faef)), closes [#21788](https://github.com/bitnami/charts/issues/21788)

## 4.0.0 (2023-12-27)

* [bitnami/mastodon] Update apache subchart (#21766) ([37acfa5](https://github.com/bitnami/charts/commit/37acfa52455903e947d8120ad334a0aec171a7c8)), closes [#21766](https://github.com/bitnami/charts/issues/21766)

## <small>3.2.8 (2023-12-26)</small>

* [bitnami/mastodon] Release 3.2.8 updating components versions (#21761) ([b25a048](https://github.com/bitnami/charts/commit/b25a048c617bb6f62db8c46b08d3e358162d2b9a)), closes [#21761](https://github.com/bitnami/charts/issues/21761)

## <small>3.2.7 (2023-12-05)</small>

* [bitnami/mastodon] Release 3.2.7 updating components versions (#21408) ([33b7921](https://github.com/bitnami/charts/commit/33b79216f6291f3985d44a9aa68f52a6b5725ccb)), closes [#21408](https://github.com/bitnami/charts/issues/21408)

## <small>3.2.6 (2023-12-04)</small>

* [bitnami/mastodon] Fix tootctl media management volume mount (#21118) ([619d74b](https://github.com/bitnami/charts/commit/619d74bf0ad25a4b02fa1311d4fc1de2d834cda6)), closes [#21118](https://github.com/bitnami/charts/issues/21118)
* [bitnami/mastodon] Release 3.2.6 updating components versions (#21400) ([13b6fab](https://github.com/bitnami/charts/commit/13b6fabd62008ecd3f99ee2f6df7f72e726626ce)), closes [#21400](https://github.com/bitnami/charts/issues/21400)

## <small>3.2.5 (2023-11-21)</small>

* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/mastodon] Release 3.2.5 updating components versions (#21149) ([13194da](https://github.com/bitnami/charts/commit/13194da73dd0b9afd2c410fa1d400ab1e9845b29)), closes [#21149](https://github.com/bitnami/charts/issues/21149)

## <small>3.2.4 (2023-11-21)</small>

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/mastodon] fix `extraVolumes` if conditional and indentation for init-job.yaml (#20901) ([571bb92](https://github.com/bitnami/charts/commit/571bb92b75684a2a37ac96a433b055e50aa4d232)), closes [#20901](https://github.com/bitnami/charts/issues/20901)
* [bitnami/mastodon] replace all instances of JupyterHub with Mastodon in values.yaml (#20900) ([9fd797d](https://github.com/bitnami/charts/commit/9fd797d3cb917216c02c02f60e4d4409a12db0df)), closes [#20900](https://github.com/bitnami/charts/issues/20900)

## <small>3.2.3 (2023-11-16)</small>

* [bitnami/mastodon] Release 3.2.3 updating components versions (#20992) ([78551ba](https://github.com/bitnami/charts/commit/78551bae0c6ada929e820f8a968b9af1000d07a3)), closes [#20992](https://github.com/bitnami/charts/issues/20992)

## <small>3.2.2 (2023-11-08)</small>

* [bitnami/mastodon] Release 3.2.2 updating components versions (#20802) ([92c2ffe](https://github.com/bitnami/charts/commit/92c2ffe26ea11f3ede79d31ef9712bdf9d32e050)), closes [#20802](https://github.com/bitnami/charts/issues/20802)

## <small>3.2.1 (2023-11-08)</small>

* [bitnami/mastodon] Release 3.2.1 updating components versions (#20765) ([051c726](https://github.com/bitnami/charts/commit/051c7260ce44a23c5afac582c488551287728612)), closes [#20765](https://github.com/bitnami/charts/issues/20765)

## 3.2.0 (2023-11-02)

* [bitnami/mastodon] Move `defaultConfig` and `defaultSecretConfig` to default-configmap.yaml and defa ([6175b41](https://github.com/bitnami/charts/commit/6175b41a9f95cd887a1e75813fe4c32d6cc59847)), closes [#19179](https://github.com/bitnami/charts/issues/19179)

## 3.1.0 (2023-10-31)

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [bitnami/mastodon] feat: :sparkles: Add support for PSA restricted policy (#20481) ([8b136a8](https://github.com/bitnami/charts/commit/8b136a860d2f68853b08386f7b137dd7e37fd298)), closes [#20481](https://github.com/bitnami/charts/issues/20481)

## <small>3.0.5 (2023-10-12)</small>

* [bitnami/mastodon] Release 3.0.5 (#20151) ([9e4d5f4](https://github.com/bitnami/charts/commit/9e4d5f46de51244ae687f9317bd437d069177579)), closes [#20151](https://github.com/bitnami/charts/issues/20151)

## <small>3.0.4 (2023-10-11)</small>

* [bitnami/mastodon] Release 3.0.4 (#20053) ([ad29bf1](https://github.com/bitnami/charts/commit/ad29bf16a8dad6e0c4c1326be990f7e868014a3b)), closes [#20053](https://github.com/bitnami/charts/issues/20053)

## <small>3.0.3 (2023-10-09)</small>

* [bitnami/mastodon] Release 3.0.3 (#19894) ([79e07b3](https://github.com/bitnami/charts/commit/79e07b3a5d03b8ecd514ee965cd14a23c0946a01)), closes [#19894](https://github.com/bitnami/charts/issues/19894)

## <small>3.0.2 (2023-10-09)</small>

* [bitnami/mastodon] Release 3.0.2 (#19863) ([ba79d54](https://github.com/bitnami/charts/commit/ba79d543017068a8b26b05811988c2ef3b75ec38)), closes [#19863](https://github.com/bitnami/charts/issues/19863)

## <small>3.0.1 (2023-10-09)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/mastodon] Release 3.0.1 (#19794) ([6dbac26](https://github.com/bitnami/charts/commit/6dbac26e73b66a25a5e1fad968d9b67f11972251)), closes [#19794](https://github.com/bitnami/charts/issues/19794)

## 3.0.0 (2023-09-29)

* [bitnami/mastodon] Update dependencies (#19619) ([4235487](https://github.com/bitnami/charts/commit/423548778f0512ba597f87017aba51c450f3ed39)), closes [#19619](https://github.com/bitnami/charts/issues/19619)

## <small>2.1.8 (2023-09-26)</small>

* [bitnami/mastodon] Release 2.1.8 (#19550) ([62054f5](https://github.com/bitnami/charts/commit/62054f5f268405f3b06a0a52ed3a86feab3d1f66)), closes [#19550](https://github.com/bitnami/charts/issues/19550)

## <small>2.1.7 (2023-09-23)</small>

* [bitnami/mastodon] Release 2.1.7 (#19489) ([e0a4e86](https://github.com/bitnami/charts/commit/e0a4e86a4f33af8a30f592a8d935d8c8956de3a5)), closes [#19489](https://github.com/bitnami/charts/issues/19489)

## <small>2.1.6 (2023-09-20)</small>

* [bitnami/mastodon] Release 2.1.6 (#19441) ([a601fda](https://github.com/bitnami/charts/commit/a601fda38126188f06430fbef6d0af60bb569376)), closes [#19441](https://github.com/bitnami/charts/issues/19441)

## <small>2.1.5 (2023-09-19)</small>

* [bitnami/*] Update readme files (#19277) ([e56aeb2](https://github.com/bitnami/charts/commit/e56aeb2fbfbf5b6e42375db48cc7ae1ef1c3a823)), closes [#19277](https://github.com/bitnami/charts/issues/19277)
* [bitnami/mastodon] Release 2.1.5 (#19405) ([a54749c](https://github.com/bitnami/charts/commit/a54749c16258c1aa82ce7e8ea18607fbfebe31bc)), closes [#19405](https://github.com/bitnami/charts/issues/19405)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>2.1.4 (2023-09-15)</small>

* [bitnami/mastodon] Add 'ProxyPreserveHost on' and remove duplicated 'VirtualHost' in apache-configma ([16ababc](https://github.com/bitnami/charts/commit/16ababce29d073d480bad5582383b51ce45f0b9c)), closes [#19214](https://github.com/bitnami/charts/issues/19214)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)

## <small>2.1.3 (2023-09-07)</small>

* [bitnami/mastodon] Release 2.1.3 updating components versions (#19137) ([b9d3e39](https://github.com/bitnami/charts/commit/b9d3e39006b162043203331afab30f4f30498f09)), closes [#19137](https://github.com/bitnami/charts/issues/19137)

## <small>2.1.2 (2023-09-06)</small>

* [bitnami/mastodon: Use merge helper]: (#19067) ([4089246](https://github.com/bitnami/charts/commit/4089246ea95aac18c2d748f1697d1efafb5f85d3)), closes [#19067](https://github.com/bitnami/charts/issues/19067)

## <small>2.1.1 (2023-09-05)</small>

* [bitnami/mastodon] Release 2.1.1 (#19126) ([22ab28a](https://github.com/bitnami/charts/commit/22ab28a2653f76a2fa3eff03fc2ffbe855aee569)), closes [#19126](https://github.com/bitnami/charts/issues/19126)

## 2.1.0 (2023-08-29)

* [bitnami/mastodon] Support for customizing standard labels (#18621) ([09787c7](https://github.com/bitnami/charts/commit/09787c75895ef9c7201262405151f7444e1695aa)), closes [#18621](https://github.com/bitnami/charts/issues/18621)

## 2.0.0 (2023-08-28)

* [bitnami/mastodon] Update Redis' subchart (#18893) ([bff8cce](https://github.com/bitnami/charts/commit/bff8cce9b5b8de4c131d6fa98d3ee550853ed33e)), closes [#18893](https://github.com/bitnami/charts/issues/18893)

## <small>1.5.14 (2023-08-25)</small>

* [bitnami/mastodon] Release 1.5.14 (#18871) ([fece221](https://github.com/bitnami/charts/commit/fece22146462b401095872f96f8bcf7d6a31c927)), closes [#18871](https://github.com/bitnami/charts/issues/18871)

## <small>1.5.13 (2023-08-21)</small>

* [bitnami/mastodon] Release 1.5.13 (#18731) ([642ce06](https://github.com/bitnami/charts/commit/642ce06388520e60082c24fec2b54ce548080ac9)), closes [#18731](https://github.com/bitnami/charts/issues/18731)

## <small>1.5.12 (2023-08-17)</small>

* [bitnami/mastodon] Release 1.5.12 (#18545) ([e33db47](https://github.com/bitnami/charts/commit/e33db47edc972dd402203830745057403eb08981)), closes [#18545](https://github.com/bitnami/charts/issues/18545)

## <small>1.5.11 (2023-08-14)</small>

* [bitnami/mastodon] Release 1.5.11 (#18411) ([65635ce](https://github.com/bitnami/charts/commit/65635cedba99c5c77d4367198af46dd8582e5485)), closes [#18411](https://github.com/bitnami/charts/issues/18411)

## <small>1.5.10 (2023-08-03)</small>

* [bitnami/mastodon] Release 1.5.10 (#18160) ([8d14af6](https://github.com/bitnami/charts/commit/8d14af6c090161cd422949cd0debb6ad0f451310)), closes [#18160](https://github.com/bitnami/charts/issues/18160)

## <small>1.5.9 (2023-08-01)</small>

* [bitnami/mastodon] Release 1.5.9 (#18126) ([a39f24b](https://github.com/bitnami/charts/commit/a39f24b16ab36b8d3d830ebb2a3e20244b45b771)), closes [#18126](https://github.com/bitnami/charts/issues/18126)

## <small>1.5.8 (2023-07-15)</small>

* [bitnami/mastodon] Release 1 updating components versions (#17612) ([d368ea4](https://github.com/bitnami/charts/commit/d368ea406592408b5cd3fe289614df263dabd89d)), closes [#17612](https://github.com/bitnami/charts/issues/17612)

## <small>1.5.7 (2023-07-11)</small>

* [bitnami/mastodon] Release 1.5.7 (#17564) ([62ac466](https://github.com/bitnami/charts/commit/62ac466fc7bcb21e3b089f04b8ce3ec1a8e65abb)), closes [#17564](https://github.com/bitnami/charts/issues/17564)
* Use os-shell in tempate and Jaeger runtime params (#17557) ([91a49eb](https://github.com/bitnami/charts/commit/91a49eb1e3c81c7b7c6c28d1bc5d6d6ae698c1e2)), closes [#17557](https://github.com/bitnami/charts/issues/17557)

## <small>1.5.6 (2023-07-08)</small>

* [bitnami/mastodon] Release 1.5.6 (#17530) ([10b8614](https://github.com/bitnami/charts/commit/10b86144baee743431b7b4be474fb627f9d1171b)), closes [#17530](https://github.com/bitnami/charts/issues/17530)

## <small>1.5.5 (2023-07-06)</small>

* [bitnami/mastodon] Release 1.5.5 (#17510) ([268dd89](https://github.com/bitnami/charts/commit/268dd8955cdca69b03783621ef9ffff479d21201)), closes [#17510](https://github.com/bitnami/charts/issues/17510)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## <small>1.5.4 (2023-06-20)</small>

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/mastodon] Release 1.5.4 (#17246) ([36a7d5f](https://github.com/bitnami/charts/commit/36a7d5f74d210dba3251fc68be836b56399cc48b)), closes [#17246](https://github.com/bitnami/charts/issues/17246)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)

## <small>1.5.3 (2023-05-21)</small>

* [bitnami/mastodon] Release 1.5.3 (#16839) ([c319b0f](https://github.com/bitnami/charts/commit/c319b0f338e2765988623a20e67331611144e8bd)), closes [#16839](https://github.com/bitnami/charts/issues/16839)

## <small>1.5.2 (2023-05-17)</small>

* [bitnami/mastodon] Release 1.5.2 (#16710) ([e4314b5](https://github.com/bitnami/charts/commit/e4314b56035004ed821ae6dbf23bfb9d2646bce3)), closes [#16710](https://github.com/bitnami/charts/issues/16710)

## <small>1.5.1 (2023-05-16)</small>

* [bitnami/mastodon] Release 1.5.1 (#16697) ([ef08339](https://github.com/bitnami/charts/commit/ef08339b6cdc7a5afa34f4ae4e8b1193350f2dfe)), closes [#16697](https://github.com/bitnami/charts/issues/16697)

## 1.5.0 (2023-05-11)

* [bitnami/mastodon] Tootctl media management (#16364) ([1071191](https://github.com/bitnami/charts/commit/10711912ed2c3ab5840f1c8196de1ea413deeccd)), closes [#16364](https://github.com/bitnami/charts/issues/16364)
* Add wording for enterprise page (#16560) ([8f22774](https://github.com/bitnami/charts/commit/8f2277440b976d52785ba9149762ad8620a73d1f)), closes [#16560](https://github.com/bitnami/charts/issues/16560)

## 1.4.0 (2023-05-09)

* [bitnami/several] Adapt Chart.yaml to set desired OCI annotations (#16546) ([fc9b18f](https://github.com/bitnami/charts/commit/fc9b18f2e98805d4df629acbcde696f44f973344)), closes [#16546](https://github.com/bitnami/charts/issues/16546)

## <small>1.3.2 (2023-05-09)</small>

* [bitnami/mastodon] Release 1.3.2 (#16472) ([dd66d22](https://github.com/bitnami/charts/commit/dd66d22c47dfce1000ce2dde4542b4828f7dc6ec)), closes [#16472](https://github.com/bitnami/charts/issues/16472)

## <small>1.3.1 (2023-05-07)</small>

* [bitnami/mastodon] Release 1.3.1 (#16383) ([1bb134a](https://github.com/bitnami/charts/commit/1bb134ac4f0ca6efef2374c99c93aac9663aeabe)), closes [#16383](https://github.com/bitnami/charts/issues/16383)

## 1.3.0 (2023-04-20)

* [bitnami/*] Make Helm charts 100% OCI (#15998) ([8841510](https://github.com/bitnami/charts/commit/884151035efcbf2e1b3206e7def85511073fb57d)), closes [#15998](https://github.com/bitnami/charts/issues/15998)

## 1.2.0 (2023-04-06)

* [bitnami/mastodon] Better s3 tls and wss support cert manager take2 (#15549) ([d4e985d](https://github.com/bitnami/charts/commit/d4e985d67a08b1ac815b443bfacd2ae5a3ecf563)), closes [#15549](https://github.com/bitnami/charts/issues/15549)

## <small>1.1.8 (2023-04-04)</small>

* [bitnami/mastodon] Release 1.1.8 (#15959) ([82f5e84](https://github.com/bitnami/charts/commit/82f5e8424f0381f139c70b70d21fe958c9a8ecd2)), closes [#15959](https://github.com/bitnami/charts/issues/15959)

## <small>1.1.7 (2023-04-01)</small>

* [bitnami/mastodon] Release 1.1.7 (#15903) ([74032de](https://github.com/bitnami/charts/commit/74032de54937874ac6234673f55901c131b78ce8)), closes [#15903](https://github.com/bitnami/charts/issues/15903)

## <small>1.1.6 (2023-03-21)</small>

* [bitnami/mastodon] Release 1.1.6 (#15655) ([a4e04d6](https://github.com/bitnami/charts/commit/a4e04d6ba04827fc3c8e16cfa77b2d8547e0494f)), closes [#15655](https://github.com/bitnami/charts/issues/15655)

## <small>1.1.5 (2023-03-20)</small>

* [bitnami/mastodon] fix volumePermission Init Container (#15540) ([6c6d4bc](https://github.com/bitnami/charts/commit/6c6d4bc39c6d328cabfc9e1885366c7bced6a0ba)), closes [#15540](https://github.com/bitnami/charts/issues/15540)

## <small>1.1.4 (2023-03-19)</small>

* [bitnami/mastodon] Release 1.1.4 (#15587) ([285ea01](https://github.com/bitnami/charts/commit/285ea010ba308a7f4de4cc9e8314316ebbc6bf3e)), closes [#15587](https://github.com/bitnami/charts/issues/15587)
* [bitnami/mastodon] render deployments when a pvc is used (#15473) ([48b4aa0](https://github.com/bitnami/charts/commit/48b4aa006e1c0a00a281e5da3e688cf99b1f2a69)), closes [#15473](https://github.com/bitnami/charts/issues/15473)

## <small>1.1.3 (2023-03-14)</small>

* [bitnami/mastodon] Fix incorrect comment and broken link for Mastodon Chart (#15377) ([fb6ebdc](https://github.com/bitnami/charts/commit/fb6ebdc47fc68dfaf9de7443b9d789cb6a0600fd)), closes [#15377](https://github.com/bitnami/charts/issues/15377)

## <small>1.1.2 (2023-03-10)</small>

* [bitnami/charts] Apply linter to README files (#15357) ([0e29e60](https://github.com/bitnami/charts/commit/0e29e600d3adc8b1b46e506eccb3decfab3b4e63)), closes [#15357](https://github.com/bitnami/charts/issues/15357)
* Fix url links in several charts README.md (#15370) ([f4a5fed](https://github.com/bitnami/charts/commit/f4a5fedc49671cc1514f26612b3e2a592c2c1e94)), closes [#15370](https://github.com/bitnami/charts/issues/15370)
* use mastodon.pvc to generate name for PersistentVolumeClaim (#15452) ([f993daf](https://github.com/bitnami/charts/commit/f993daf97fa12e40a19891883d251df5111e5607)), closes [#15452](https://github.com/bitnami/charts/issues/15452)

## <small>1.1.1 (2023-03-01)</small>

* [bitnami/mastodon] Release 1.1.1 (#15218) ([044ccdb](https://github.com/bitnami/charts/commit/044ccdb318bdee7808b0bc4045010de9ab21665a)), closes [#15218](https://github.com/bitnami/charts/issues/15218)

## 1.1.0 (2023-02-23)

* - Add LOCAL_DOMAIN environment variable, and emphasize that WEB_DOMAIN is an *optional* configuratio ([cf5d4bd](https://github.com/bitnami/charts/commit/cf5d4bd8819098569b0c4ecda4a12bbc3a01ca37)), closes [#15076](https://github.com/bitnami/charts/issues/15076)
* Fixes dead links (#15065) ([9e99fd9](https://github.com/bitnami/charts/commit/9e99fd94d89605c2aa47417ae80eecb86719d904)), closes [#15065](https://github.com/bitnami/charts/issues/15065)

## <small>1.0.3 (2023-02-17)</small>

* [bitnami/*] Fix markdown linter issues (#14874) ([a51e0e8](https://github.com/bitnami/charts/commit/a51e0e8d35495b907f3e70dd2f8e7c3bcbf4166a)), closes [#14874](https://github.com/bitnami/charts/issues/14874)
* [bitnami/*] Fix markdown linter issues 2 (#14890) ([aa96572](https://github.com/bitnami/charts/commit/aa9657237ee8df4a46db0d7fdf8a23230dd6902a)), closes [#14890](https://github.com/bitnami/charts/issues/14890)
* [bitnami/*] Remove unexpected extra spaces (#14873) ([c97c714](https://github.com/bitnami/charts/commit/c97c714887380d47eae7bfeff316bf01595ecd1d)), closes [#14873](https://github.com/bitnami/charts/issues/14873)
* [bitnami/mastodon] Release 1.0.3 (#14991) ([24011ee](https://github.com/bitnami/charts/commit/24011eebf1c43061e8da7f7d94e921266df8322d)), closes [#14991](https://github.com/bitnami/charts/issues/14991)

## <small>1.0.2 (2023-02-12)</small>

* [bitnami/*] Change copyright date (#14682) ([add4ec7](https://github.com/bitnami/charts/commit/add4ec701108ac36ed4de2dffbdf407a0d091067)), closes [#14682](https://github.com/bitnami/charts/issues/14682)
* [bitnami/mastodon] Release 1.0.2 (#14849) ([ab796af](https://github.com/bitnami/charts/commit/ab796af867b9a7f2270f21b9775b784a0a15b1bf)), closes [#14849](https://github.com/bitnami/charts/issues/14849)

## <small>1.0.1 (2023-01-23)</small>

* [bitnami/*] Unify READMEs (#14472) ([2064fb8](https://github.com/bitnami/charts/commit/2064fb8dcc78a845cdede8211af8c3cc52551161)), closes [#14472](https://github.com/bitnami/charts/issues/14472)
* [bitnami/mastodon] Update default Admin email (#14497) ([dcb391e](https://github.com/bitnami/charts/commit/dcb391ea5841aa144623e32f43ec0bd076bffa05)), closes [#14497](https://github.com/bitnami/charts/issues/14497)

## 1.0.0 (2023-01-19)

* [bitnami/mastodon] Update MinIO subchart (#14447) ([8d0252d](https://github.com/bitnami/charts/commit/8d0252d3cc54c39b5b225aef6b1e292ae66f1f93)), closes [#14447](https://github.com/bitnami/charts/issues/14447)

## <small>0.1.3 (2023-01-17)</small>

* [bitnami/*] Add license annotation and remove obsolete engine parameter (#14293) ([da2a794](https://github.com/bitnami/charts/commit/da2a7943bae95b6e9b5b4ed972c15e990b69fdb0)), closes [#14293](https://github.com/bitnami/charts/issues/14293)
* [bitnami/*] Change licenses annotation format (#14377) ([0ab7608](https://github.com/bitnami/charts/commit/0ab760862c660fcc78cffadf8e1d8cdd70881473)), closes [#14377](https://github.com/bitnami/charts/issues/14377)
* [bitnami/mastodon] Release 0.1.3 (#14338) ([0c75e5f](https://github.com/bitnami/charts/commit/0c75e5f8c21f6863a1f643f820ac7504a7b3f3d6)), closes [#14338](https://github.com/bitnami/charts/issues/14338)

## <small>0.1.2 (2022-12-22)</small>

* [bitnami/mastodon]: Fix chart installation (#14067) ([8f5731a](https://github.com/bitnami/charts/commit/8f5731a21bd94333a2a4cf7afda83b924602e8c6)), closes [#14067](https://github.com/bitnami/charts/issues/14067)

## <small>0.1.1 (2022-12-16)</small>

* [bitnami/mastodon] Release 0.1.1 (#13994) ([8afbd04](https://github.com/bitnami/charts/commit/8afbd04fdf4d5ea4f56d254f73d4bb36e028ebb2)), closes [#13994](https://github.com/bitnami/charts/issues/13994)

## 0.1.0 (2022-12-16)

* [bitnami/mastodon] feat: :tada: Add chart (#13976) ([445ec4b](https://github.com/bitnami/charts/commit/445ec4b7de948c0fce71ef686f3d99b10c7ccb63)), closes [#13976](https://github.com/bitnami/charts/issues/13976)
