# Changelog

## 11.0.0 (2025-08-18)

* [bitnami/matomo] Upgrade to MariaDB 12.0 ([#36116](https://github.com/bitnami/charts/pull/36116))

## <small>10.0.25 (2025-08-18)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#36105) ([e1114c4](https://github.com/bitnami/charts/commit/e1114c41eacdbc3817453c3c9072d0b4aa46ed60)), closes [#36105](https://github.com/bitnami/charts/issues/36105)

## <small>10.0.24 (2025-08-16)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#36083) ([ff991ed](https://github.com/bitnami/charts/commit/ff991ed74f151ed42f65f638d8a0720fa87292ae)), closes [#36083](https://github.com/bitnami/charts/issues/36083)

## <small>10.0.23 (2025-08-15)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#36070) ([5542c1a](https://github.com/bitnami/charts/commit/5542c1a99ceead6afc9036d96aa6af8b53f0a822)), closes [#36070](https://github.com/bitnami/charts/issues/36070)

## <small>10.0.22 (2025-08-15)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#36061) ([e2e4b5a](https://github.com/bitnami/charts/commit/e2e4b5aa2b2cc6f71e2cbccfda4d9debbcfde686)), closes [#36061](https://github.com/bitnami/charts/issues/36061)

## <small>10.0.21 (2025-08-15)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#36057) ([a8aef7f](https://github.com/bitnami/charts/commit/a8aef7f7321a96b98fdd24e0a851cbfd5ce1a9bf)), closes [#36057](https://github.com/bitnami/charts/issues/36057)

## <small>10.0.20 (2025-08-15)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#36040) ([831b744](https://github.com/bitnami/charts/commit/831b744788002fed81cd79c62599c94bc29831a7)), closes [#36040](https://github.com/bitnami/charts/issues/36040)

## <small>10.0.19 (2025-08-15)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#36037) ([afcb321](https://github.com/bitnami/charts/commit/afcb32133216703b97e1f9b7216d21cf57cad653)), closes [#36037](https://github.com/bitnami/charts/issues/36037)

## <small>10.0.18 (2025-08-15)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#36032) ([7a9ae07](https://github.com/bitnami/charts/commit/7a9ae072bbdd50742b32e6a5049d5c43e8a1a111)), closes [#36032](https://github.com/bitnami/charts/issues/36032)

## <small>10.0.17 (2025-08-15)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#36020) ([6e0db1d](https://github.com/bitnami/charts/commit/6e0db1db25a4f435e74fea43b4c37984ca0d23ae)), closes [#36020](https://github.com/bitnami/charts/issues/36020)

## <small>10.0.16 (2025-08-15)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#36014) ([70c5d74](https://github.com/bitnami/charts/commit/70c5d745b52ed371a46b707b8174d180aa390fe5)), closes [#36014](https://github.com/bitnami/charts/issues/36014)

## <small>10.0.15 (2025-08-15)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#36003) ([13bd696](https://github.com/bitnami/charts/commit/13bd69613150d2caa79d04a4422c1d11bea9ebdf)), closes [#36003](https://github.com/bitnami/charts/issues/36003)

## <small>10.0.14 (2025-08-15)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#35992) ([29a0609](https://github.com/bitnami/charts/commit/29a0609d8143ad24b46b0c7b2bb05f14cd6d41a0)), closes [#35992](https://github.com/bitnami/charts/issues/35992)

## <small>10.0.13 (2025-08-15)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#35982) ([769c0f3](https://github.com/bitnami/charts/commit/769c0f3613606d7d2f03d7ea7513b7af85b1fb45)), closes [#35982](https://github.com/bitnami/charts/issues/35982)

## <small>10.0.12 (2025-08-14)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#35979) ([780d93b](https://github.com/bitnami/charts/commit/780d93bdfee872efdc2ea1ecb316471680b83cfb)), closes [#35979](https://github.com/bitnami/charts/issues/35979)

## <small>10.0.11 (2025-08-14)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#35968) ([8ce47a8](https://github.com/bitnami/charts/commit/8ce47a8e3d9f861f39863f1216077ed0327b2c47)), closes [#35968](https://github.com/bitnami/charts/issues/35968)

## <small>10.0.10 (2025-08-14)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#35955) ([0625751](https://github.com/bitnami/charts/commit/062575108feadfb8a0f3ffcf9e997c5ab7fbb052)), closes [#35955](https://github.com/bitnami/charts/issues/35955)

## <small>10.0.9 (2025-08-14)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#35946) ([08b948f](https://github.com/bitnami/charts/commit/08b948fc80991c9f4044fab886ee1f35033410eb)), closes [#35946](https://github.com/bitnami/charts/issues/35946)

## <small>10.0.8 (2025-08-14)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#35942) ([400b9c3](https://github.com/bitnami/charts/commit/400b9c33b29e0746cfa0e9757a85a0f70104e8d2)), closes [#35942](https://github.com/bitnami/charts/issues/35942)

## <small>10.0.7 (2025-08-14)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#35933) ([73ac43d](https://github.com/bitnami/charts/commit/73ac43dc1a5f5ef30d9a9fe9fba393c470cb2535)), closes [#35933](https://github.com/bitnami/charts/issues/35933)

## <small>10.0.6 (2025-08-14)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#35901) ([6d7412f](https://github.com/bitnami/charts/commit/6d7412f014ee74363530efa62c61f87b4983ce6a)), closes [#35901](https://github.com/bitnami/charts/issues/35901)

## <small>10.0.5 (2025-08-07)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#35620) ([ea2f681](https://github.com/bitnami/charts/commit/ea2f6818f501638dd427a6eedfb91ee876a157f9)), closes [#35620](https://github.com/bitnami/charts/issues/35620)

## <small>10.0.4 (2025-08-07)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#35593) ([0e7ad11](https://github.com/bitnami/charts/commit/0e7ad11b40e70f80a2b83642e4d7da83e3f8345e)), closes [#35593](https://github.com/bitnami/charts/issues/35593)

## <small>10.0.3 (2025-08-06)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#35449) ([a7cc2ee](https://github.com/bitnami/charts/commit/a7cc2ee824da9e57c8260cbd8f9ac4d34b5f449f)), closes [#35449](https://github.com/bitnami/charts/issues/35449)

## <small>10.0.2 (2025-07-15)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#35108) ([c76b78f](https://github.com/bitnami/charts/commit/c76b78f4eeddfb2f854e64d4922abf0cca6ae0e7)), closes [#35108](https://github.com/bitnami/charts/issues/35108)

## <small>10.0.1 (2025-07-08)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#34863) ([4dcef5e](https://github.com/bitnami/charts/commit/4dcef5e2ade122a4bbe4f4fbed88f48fa9b43e01)), closes [#34863](https://github.com/bitnami/charts/issues/34863)

## 10.0.0 (2025-06-25)

* [bitnami/matomo] Upgrade MariaDB 11.8 (#34634) ([754d473](https://github.com/bitnami/charts/commit/754d473aabe7ffd6b3f1f5e61257ef86be0812d6)), closes [#34634](https://github.com/bitnami/charts/issues/34634)

## <small>9.3.13 (2025-06-13)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#34405) ([cfac833](https://github.com/bitnami/charts/commit/cfac8336a989971936a0ab752d116dae9c9b9626)), closes [#34405](https://github.com/bitnami/charts/issues/34405)

## <small>9.3.12 (2025-06-13)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#34388) ([abb4b57](https://github.com/bitnami/charts/commit/abb4b57324465d646e2e4bace6e1256b4f6d1c1e)), closes [#34388](https://github.com/bitnami/charts/issues/34388)

## <small>9.3.11 (2025-06-09)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#34262) ([6b146ad](https://github.com/bitnami/charts/commit/6b146adb8f262ce155fc4107bb071c0a471f6500)), closes [#34262](https://github.com/bitnami/charts/issues/34262)

## <small>9.3.10 (2025-06-05)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#34137) ([ebdd932](https://github.com/bitnami/charts/commit/ebdd93294fdc454b4f4f9bc155286b6bbe587692)), closes [#34137](https://github.com/bitnami/charts/issues/34137)

## <small>9.3.9 (2025-05-29)</small>

* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#33972) ([c3893bf](https://github.com/bitnami/charts/commit/c3893bf109c29c4408b4f330f2d21a0bc827ddf9)), closes [#33972](https://github.com/bitnami/charts/issues/33972)

## <small>9.3.8 (2025-05-13)</small>

* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)
* [bitnami/matomo] :zap: :arrow_up: Update dependency references (#33637) ([9efe4a6](https://github.com/bitnami/charts/commit/9efe4a68614e249bd6b5361470cb7e08ab8df842)), closes [#33637](https://github.com/bitnami/charts/issues/33637)

## <small>9.3.7 (2025-05-07)</small>

* [bitnami/matomo] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#33396) ([e267482](https://github.com/bitnami/charts/commit/e2674820eb9e6e0a9442e52212c601119ff18ca7)), closes [#33396](https://github.com/bitnami/charts/issues/33396)

## <small>9.3.6 (2025-05-03)</small>

* [bitnami/matomo] Release 9.3.6 (#33314) ([5976be1](https://github.com/bitnami/charts/commit/5976be1ecb807f0fd3a13b8a889da4054d7c84bf)), closes [#33314](https://github.com/bitnami/charts/issues/33314)

## <small>9.3.5 (2025-05-03)</small>

* [bitnami/matomo] Release 9.3.5 (#33313) ([6e5c37f](https://github.com/bitnami/charts/commit/6e5c37f30ab452838d1c3486bc45e69ca598de7c)), closes [#33313](https://github.com/bitnami/charts/issues/33313)

## <small>9.3.4 (2025-04-17)</small>

* [bitnami/matomo] Release 9.3.4 (#33067) ([b471948](https://github.com/bitnami/charts/commit/b4719488b3fcd5037216469b249aaab9ca05d386)), closes [#33067](https://github.com/bitnami/charts/issues/33067)

## <small>9.3.3 (2025-04-17)</small>

* [bitnami/matomo] fix mount path for `matomo-secrets` volume on cronjobs (#32773) ([3d41af6](https://github.com/bitnami/charts/commit/3d41af63611985ef47dc67d28202cc8f2ff2b75c)), closes [#32773](https://github.com/bitnami/charts/issues/32773)

## <small>9.3.2 (2025-04-14)</small>

* [bitnami/matomo] Adds matomo-secrets volume to matomo-archive cronjob (#32924) ([3505304](https://github.com/bitnami/charts/commit/350530478550b5b300b06fee2493fbd64050f9b0)), closes [#32924](https://github.com/bitnami/charts/issues/32924)

## <small>9.3.1 (2025-04-09)</small>

* [bitnami/matomo] Add missing `app.kubernetes.io/component` label to deployment and pdb (#32774) ([eacfbe1](https://github.com/bitnami/charts/commit/eacfbe1d77a27ad59168aef51ddcf7a2c220dea8)), closes [#32774](https://github.com/bitnami/charts/issues/32774)

## 9.3.0 (2025-03-31)

* [bitnami/matomo] Set `usePasswordFiles=true` by default (#32363) ([ceca10c](https://github.com/bitnami/charts/commit/ceca10c0dcd20d46bebf5f3fd9abea9b7a4144ef)), closes [#32363](https://github.com/bitnami/charts/issues/32363)

## <small>9.2.7 (2025-03-24)</small>

* [bitnami/matomo] Fix typo in SMTP authentication value for CRAM-MD5 (#32354) ([3e8ed41](https://github.com/bitnami/charts/commit/3e8ed41b493b1c92d2dea76d09e5e63c39a006e3)), closes [#32354](https://github.com/bitnami/charts/issues/32354)

## <small>9.2.6 (2025-03-18)</small>

* [bitnami/matomo] Release 9.2.6 (#32503) ([1d91b5e](https://github.com/bitnami/charts/commit/1d91b5ec19f2299c60784bc35827cb4c2e2e072e)), closes [#32503](https://github.com/bitnami/charts/issues/32503)

## <small>9.2.5 (2025-03-14)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/matomo] Release 9.2.5 (#32452) ([07c6216](https://github.com/bitnami/charts/commit/07c6216527f19cdf7467a0676a111987d60d251f)), closes [#32452](https://github.com/bitnami/charts/issues/32452)

## <small>9.2.4 (2025-02-23)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/matomo] Release 9.2.4 (#32138) ([a276308](https://github.com/bitnami/charts/commit/a2763082856d2e1eb93f4adc9ed26c36b3e13156)), closes [#32138](https://github.com/bitnami/charts/issues/32138)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## <small>9.2.3 (2025-01-24)</small>

* [bitnami/matomo] Release 9.2.3 (#31589) ([73a1abc](https://github.com/bitnami/charts/commit/73a1abcac62e24a371d1916c960f342a93b8f81b)), closes [#31589](https://github.com/bitnami/charts/issues/31589)

## <small>9.2.2 (2025-01-15)</small>

* [bitnami/matomo] Release 9.2.2 (#31382) ([fdbdfdf](https://github.com/bitnami/charts/commit/fdbdfdfc90f8fa6f2f55569d48359e6c29c67111)), closes [#31382](https://github.com/bitnami/charts/issues/31382)

## <small>9.2.1 (2024-12-23)</small>

* [bitnami/matomo] Release 9.2.1 (#31134) ([c0307c7](https://github.com/bitnami/charts/commit/c0307c7717372da54334ff98d4e8ac1155cb035d)), closes [#31134](https://github.com/bitnami/charts/issues/31134)

## 9.2.0 (2024-12-17)

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/matomo] add initContainers parameter to CronJob pods (#31065) ([27feba9](https://github.com/bitnami/charts/commit/27feba938379638644aae8e61f8f90c30d331b79)), closes [#31065](https://github.com/bitnami/charts/issues/31065)

## <small>9.1.1 (2024-12-12)</small>

* [bitnami/matomo] Release 9.1.1 (#31005) ([a55802f](https://github.com/bitnami/charts/commit/a55802f34fa18246dcc5337c1428033485068e9a)), closes [#31005](https://github.com/bitnami/charts/issues/31005)

## 9.1.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/*] docs: :memo: Add "Prometheus metrics" (batch 4) (#30669) ([a4ec006](https://github.com/bitnami/charts/commit/a4ec00624589023a70a7094fcfb9f12e382bc280)), closes [#30669](https://github.com/bitnami/charts/issues/30669)
* [bitnami/*] docs: :memo: Add "Update Credentials" (batch 2) (#30687) ([c457848](https://github.com/bitnami/charts/commit/c457848b2a111aad59830b98f85ffa1e29918e10)), closes [#30687](https://github.com/bitnami/charts/issues/30687)
* [bitnami/matomo] Detect non-standard images (#30957) ([5d1a731](https://github.com/bitnami/charts/commit/5d1a731a820afcddaf91e9f2596e0e752795e134)), closes [#30957](https://github.com/bitnami/charts/issues/30957)

## 9.0.0 (2024-11-12)

* [bitnami/matomo] chore!: :arrow_up: :boom: Bump MariaDB subchart to 20 (#30354) ([a9c658d](https://github.com/bitnami/charts/commit/a9c658dc5fce8487df2a207fdb75baadd2b976b4)), closes [#30354](https://github.com/bitnami/charts/issues/30354)

## <small>8.0.14 (2024-11-04)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/matomo] Release 8.0.14 (#30207) ([3809c46](https://github.com/bitnami/charts/commit/3809c46ba76d04b054f39c1a8d6857d708f023af)), closes [#30207](https://github.com/bitnami/charts/issues/30207)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## <small>8.0.13 (2024-09-25)</small>

* [bitnami/matomo] Release 8.0.13 (#29605) ([a5a89c9](https://github.com/bitnami/charts/commit/a5a89c9685b585b6ddfecdf4c2e067da163563d0)), closes [#29605](https://github.com/bitnami/charts/issues/29605)

## <small>8.0.12 (2024-09-19)</small>

* [bitnami/matomo] Release 8.0.12 (#29522) ([2f7ff7c](https://github.com/bitnami/charts/commit/2f7ff7c36bf21598bd1d8b6b7843213a21d4df47)), closes [#29522](https://github.com/bitnami/charts/issues/29522)

## <small>8.0.11 (2024-09-04)</small>

* [bitnami/matomo] add serviceAccountName parameter to CronJob pods (#29182) ([dafec18](https://github.com/bitnami/charts/commit/dafec184dcd1c57e48f617306d5f345d61a40fd2)), closes [#29182](https://github.com/bitnami/charts/issues/29182)

## <small>8.0.10 (2024-08-22)</small>

* [bitnami/matomo] Release 8.0.10 (#28972) ([890f055](https://github.com/bitnami/charts/commit/890f055a0c00ef6889c34e25108ecab0ab2c86e3)), closes [#28972](https://github.com/bitnami/charts/issues/28972)

## <small>8.0.9 (2024-08-15)</small>

* [bitnami/matomo] Release 8.0.9 (#28892) ([9ecfcbd](https://github.com/bitnami/charts/commit/9ecfcbd7219a77ddd6583aa8eb35b01b43ede5b8)), closes [#28892](https://github.com/bitnami/charts/issues/28892)

## <small>8.0.8 (2024-08-13)</small>

* [bitnami/matomo] Release 8.0.8 (#28860) ([a341719](https://github.com/bitnami/charts/commit/a341719d9454aa8cfd6f59303aa01bc581a0f3a2)), closes [#28860](https://github.com/bitnami/charts/issues/28860)

## <small>8.0.7 (2024-08-13)</small>

* [bitnami/matomo] Increase readiness probes' initial delay for VIB tests (#28847) ([fc93db0](https://github.com/bitnami/charts/commit/fc93db0404297d794a010c76e80d3ae7e0459128)), closes [#28847](https://github.com/bitnami/charts/issues/28847)

## <small>8.0.6 (2024-08-05)</small>

* [bitnami/matomo] Remove dokuwiki reference (#28661) ([e786767](https://github.com/bitnami/charts/commit/e786767a8aaabefd3dc8d834a5176ca5bde3bbc9)), closes [#28661](https://github.com/bitnami/charts/issues/28661)

## <small>8.0.5 (2024-07-25)</small>

* [bitnami/matomo] Release 8.0.5 (#28484) ([d08a865](https://github.com/bitnami/charts/commit/d08a86525aa160ba1c9595123d2f4913ecb33540)), closes [#28484](https://github.com/bitnami/charts/issues/28484)

## <small>8.0.4 (2024-07-24)</small>

* [bitnami/matomo] Release 8.0.4 (#28319) ([2f1007f](https://github.com/bitnami/charts/commit/2f1007ff57aea8c2cbe82e906fc5899fd82dbef2)), closes [#28319](https://github.com/bitnami/charts/issues/28319)

## <small>8.0.3 (2024-07-23)</small>

* [bitnami/matomo] Release 8.0.3 (#28215) ([649ace7](https://github.com/bitnami/charts/commit/649ace7b2dec277b84fe9c03330e3dd619f7ea04)), closes [#28215](https://github.com/bitnami/charts/issues/28215)

## <small>8.0.2 (2024-07-18)</small>

* [bitnami/matomo] Global StorageClass as default value (#28053) ([a5458d4](https://github.com/bitnami/charts/commit/a5458d432a23c8694bf7505892aef4326800f198)), closes [#28053](https://github.com/bitnami/charts/issues/28053)

## <small>8.0.1 (2024-07-16)</small>

* [bitnami/matomo] Fix wrong initContainers[0].imagePullSecrets value (#28115) ([424d58b](https://github.com/bitnami/charts/commit/424d58bc5bdde3c83a423a939b0493b72a5d0d26)), closes [#28115](https://github.com/bitnami/charts/issues/28115)

## 8.0.0 (2024-07-13)

* [bitnami/matomo] chore!: :arrow_up: :boom: Update mariadb to 11.4 (#27943) ([ee74a7f](https://github.com/bitnami/charts/commit/ee74a7fc02d22cbbdcd1eaec39960ea7215e50c0)), closes [#27943](https://github.com/bitnami/charts/issues/27943)

## <small>7.3.8 (2024-07-12)</small>

* [bitnami/matomo] Fix customCAs usage (#27938) ([91b7632](https://github.com/bitnami/charts/commit/91b763201c8bfff5722071c1d461e2c853407620)), closes [#27938](https://github.com/bitnami/charts/issues/27938)

## <small>7.3.7 (2024-07-03)</small>

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/matomo] Release 7.3.7 (#27700) ([a6d7406](https://github.com/bitnami/charts/commit/a6d74060931be3c6f2944bfacc2f397a9220b75c)), closes [#27700](https://github.com/bitnami/charts/issues/27700)

## <small>7.3.6 (2024-06-19)</small>

* [bitnami/matomo] Release 7.3.6 (#27437) ([1aaac3c](https://github.com/bitnami/charts/commit/1aaac3c652d15fb1709d68eeb7d2bbbe606d80ad)), closes [#27437](https://github.com/bitnami/charts/issues/27437)

## <small>7.3.5 (2024-06-12)</small>

* [bitnami/matomo] Release 7.3.5 (#27122) ([912f116](https://github.com/bitnami/charts/commit/912f116808785950399e785226fa55bd0b8eb654)), closes [#27122](https://github.com/bitnami/charts/issues/27122)

## <small>7.3.4 (2024-06-06)</small>

* [bitnami/matomo] Release 7.3.4 (#26978) ([caa5db4](https://github.com/bitnami/charts/commit/caa5db42df5512717049072b6f988f35d33ae7d1)), closes [#26978](https://github.com/bitnami/charts/issues/26978)

## <small>7.3.3 (2024-06-06)</small>

* [bitnami/matomo] Release 7.3.3 (#26899) ([1c07878](https://github.com/bitnami/charts/commit/1c0787816524209e705f70f3c3fe93959be99402)), closes [#26899](https://github.com/bitnami/charts/issues/26899)

## <small>7.3.2 (2024-06-05)</small>

* [bitnami/matomo] Bump chart version (#26845) ([f40df24](https://github.com/bitnami/charts/commit/f40df24838b6f3aea9b22912c6c08cbf0c8a76b1)), closes [#26845](https://github.com/bitnami/charts/issues/26845)

## <small>7.3.1 (2024-06-05)</small>

* [bitnami/matomo] Bump chart version (#26787) ([80a779a](https://github.com/bitnami/charts/commit/80a779a1453015715a29f4f88fcb437cbeec9a26)), closes [#26787](https://github.com/bitnami/charts/issues/26787)

## 7.3.0 (2024-05-29)

* [bitnami/matomo] Enable PodDisruptionBudgets (#26509) ([5cc452c](https://github.com/bitnami/charts/commit/5cc452c700d93c97c5f0474b1923c0db080a9e6e)), closes [#26509](https://github.com/bitnami/charts/issues/26509)

## 7.2.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/matomo] feat: :sparkles: :lock: Add warning when original images are replaced (#26239) ([2ac8e09](https://github.com/bitnami/charts/commit/2ac8e09d9fcbc33c85abaa946d69289abd51c6f5)), closes [#26239](https://github.com/bitnami/charts/issues/26239)

## <small>7.1.3 (2024-05-20)</small>

* [bitnami/matomo] Use different liveness/readiness probes (#25976) ([a4e6ed0](https://github.com/bitnami/charts/commit/a4e6ed0b8699face838912800963f210319041c0)), closes [#25976](https://github.com/bitnami/charts/issues/25976)

## <small>7.1.2 (2024-05-18)</small>

* [bitnami/matomo] Release 7.1.2 updating components versions (#26041) ([5a1ef25](https://github.com/bitnami/charts/commit/5a1ef25d86e555336cbf908f625b951abd898ed2)), closes [#26041](https://github.com/bitnami/charts/issues/26041)

## <small>7.1.1 (2024-05-14)</small>

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/matomo] Release 7.1.1 updating components versions (#25787) ([0d92e82](https://github.com/bitnami/charts/commit/0d92e8243e368d5dcaf244f8b55fb8a1e11fbabb)), closes [#25787](https://github.com/bitnami/charts/issues/25787)

## 7.1.0 (2024-05-07)

* [bitnami/matomo] Added the ability to specify a nodeSelector and taints for cronjob (#25383) ([1b4d6a1](https://github.com/bitnami/charts/commit/1b4d6a15823e2e8461b9d631761bc5ad9073dc35)), closes [#25383](https://github.com/bitnami/charts/issues/25383)

## <small>7.0.5 (2024-05-07)</small>

* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/matomo] Remove unicode characters (#25545) ([b7aa7a6](https://github.com/bitnami/charts/commit/b7aa7a60eb47e9d78ce90e26d9c8f84353b7abac)), closes [#25545](https://github.com/bitnami/charts/issues/25545)
* [bitnami/multiple charts] Fix typo: "NetworkPolice" vs "NetworkPolicy" (#25348) ([6970c1b](https://github.com/bitnami/charts/commit/6970c1ba245873506e73d459c6eac1e4919b778f)), closes [#25348](https://github.com/bitnami/charts/issues/25348)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## <small>7.0.4 (2024-04-08)</small>

* fix(bitnami/matomo): wrong resources condition (#25032) ([c0d9d94](https://github.com/bitnami/charts/commit/c0d9d94d7dc8bcdd77eb86b3477f2d3ea42e2ce4)), closes [#25032](https://github.com/bitnami/charts/issues/25032)

## <small>7.0.3 (2024-04-05)</small>

* [bitnami/matomo] Release 7.0.3 updating components versions (#24987) ([9c8dd27](https://github.com/bitnami/charts/commit/9c8dd27db5e231cb8da9aedded4dc57303bf8f01)), closes [#24987](https://github.com/bitnami/charts/issues/24987)

## <small>7.0.2 (2024-04-05)</small>

* fix(matomo): wrong property (#24682) ([ed3b094](https://github.com/bitnami/charts/commit/ed3b094b565417bc389d44eb8b7da1d0ccecccca)), closes [#24682](https://github.com/bitnami/charts/issues/24682)

## <small>7.0.1 (2024-04-04)</small>

* [bitnami/matomo] Improve Cypress stability and update resources (#24876) ([c106935](https://github.com/bitnami/charts/commit/c10693579f7e4764665dac639c14ba5d6fde8553)), closes [#24876](https://github.com/bitnami/charts/issues/24876)

## 7.0.0 (2024-04-03)

* [bitnami/matomo] feat!: :lock: :boom: Improve security defaults (#24823) ([d982c38](https://github.com/bitnami/charts/commit/d982c3858cbfa240199e91d6cad41f40e035552f)), closes [#24823](https://github.com/bitnami/charts/issues/24823)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## <small>6.0.1 (2024-04-02)</small>

* [bitnami/matomo] Release 6.0.1 updating components versions (#24788) ([35fcc04](https://github.com/bitnami/charts/commit/35fcc04dde2fa9409d9bf3bf36265a118db65e34)), closes [#24788](https://github.com/bitnami/charts/issues/24788)

## 6.0.0 (2024-03-20)

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* [bitnami/matomo] Separate config for cronjobs (#24339) ([d76c37b](https://github.com/bitnami/charts/commit/d76c37bb4a34de9c7712ac573720d8e6ddd228b8)), closes [#24339](https://github.com/bitnami/charts/issues/24339)

## <small>5.5.1 (2024-03-14)</small>

* [bitnami/matomo] Fix cronjobs.archive.resources backwards compatibility (#24452) ([5d6a4ad](https://github.com/bitnami/charts/commit/5d6a4ad00dfd69066d7c92be1eba3f176f1aaa4e)), closes [#24452](https://github.com/bitnami/charts/issues/24452)

## 5.5.0 (2024-03-14)

* [bitnami/matomo] add independent configuration of cronjob resources (#23903) ([30f64a8](https://github.com/bitnami/charts/commit/30f64a89ba1417e3a9d3a89b98eaccfbaf3e81e7)), closes [#23903](https://github.com/bitnami/charts/issues/23903)

## <small>5.4.1 (2024-03-08)</small>

* [bitnami/matomo] Release 5.4.1 updating components versions (#24265) ([3f53757](https://github.com/bitnami/charts/commit/3f53757c25c90ba9064eb9ce1b71cff907b60936)), closes [#24265](https://github.com/bitnami/charts/issues/24265)

## 5.4.0 (2024-03-06)

* [bitnami/matomo] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v2 SCC (# ([0e0dc6f](https://github.com/bitnami/charts/commit/0e0dc6f949f16814cc1ddc1947df1f49e77f18ed)), closes [#24116](https://github.com/bitnami/charts/issues/24116)

## <small>5.3.2 (2024-02-22)</small>

* [bitnami/matomo] Release 5.3.2 updating components versions (#23801) ([00924ad](https://github.com/bitnami/charts/commit/00924ad92f205c83f834118d1c4ed94d6da308fb)), closes [#23801](https://github.com/bitnami/charts/issues/23801)

## <small>5.3.1 (2024-02-21)</small>

* [bitnami/matomo] Release 5.3.1 updating components versions (#23723) ([e6930c8](https://github.com/bitnami/charts/commit/e6930c89f4513db43bb5fa4aeac04a045d4a06fa)), closes [#23723](https://github.com/bitnami/charts/issues/23723)

## 5.3.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## 5.2.0 (2024-02-20)

* [bitnami/matomo] feat: :sparkles: :lock: Add resource preset support (#23483) ([bbea8b2](https://github.com/bitnami/charts/commit/bbea8b22c1176e5cc48052b0aa77ab93cb16d5f6)), closes [#23483](https://github.com/bitnami/charts/issues/23483)

## <small>5.1.5 (2024-02-12)</small>

* Unify volumeMounts between Deployment and CronJob (#23213) ([7486027](https://github.com/bitnami/charts/commit/7486027f287905e96f8cecb3bb74987168c71f10)), closes [#23213](https://github.com/bitnami/charts/issues/23213)

## <small>5.1.4 (2024-02-05)</small>

* [bitnami/matomo] Release 5.1.4 updating components versions (#23195) ([f1adb23](https://github.com/bitnami/charts/commit/f1adb2390ed25ae30ac9e8a7ead5bc96cf1e2f2d)), closes [#23195](https://github.com/bitnami/charts/issues/23195)

## <small>5.1.3 (2024-02-03)</small>

* [bitnami/matomo] Release 5.1.3 updating components versions (#23103) ([16216f8](https://github.com/bitnami/charts/commit/16216f8d37cac2cbc9766949425563d89fc8052c)), closes [#23103](https://github.com/bitnami/charts/issues/23103)

## <small>5.1.2 (2024-01-31)</small>

* [bitnami/matomo] Release 5.1.2 updating components versions (#22936) ([b3eaad5](https://github.com/bitnami/charts/commit/b3eaad522c07acb41e9b0be2605ee31fecf1f52c)), closes [#22936](https://github.com/bitnami/charts/issues/22936)

## <small>5.1.1 (2024-01-25)</small>

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/matomo] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22620) ([dd4d156](https://github.com/bitnami/charts/commit/dd4d156f4ddfebb6f26c2b3eaa5ae972ef002635)), closes [#22620](https://github.com/bitnami/charts/issues/22620)

## 5.1.0 (2024-01-22)

* [bitnami/matomo] fix: :lock: Move service-account token auto-mount to pod declaration (#22430) ([ee278c8](https://github.com/bitnami/charts/commit/ee278c8da9ec7dbec69fb1f6a0ddad820539f9ce)), closes [#22430](https://github.com/bitnami/charts/issues/22430)

## <small>5.0.1 (2024-01-18)</small>

* [bitnami/matomo] Release 5.0.1 updating components versions (#22308) ([6830a9a](https://github.com/bitnami/charts/commit/6830a9aad3b4a1567af7b74c18b0e41523c7a265)), closes [#22308](https://github.com/bitnami/charts/issues/22308)

## 5.0.0 (2024-01-17)

* [bitnami/matomo] Release 5.0.0 (#22246) ([d8b2c83](https://github.com/bitnami/charts/commit/d8b2c839534806803d9277371fa512d64e73ddd4)), closes [#22246](https://github.com/bitnami/charts/issues/22246)

## 4.1.0 (2024-01-16)

* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/matomo] fix: :lock: Improve podSecurityContext and containerSecurityContext with essential  ([c449255](https://github.com/bitnami/charts/commit/c4492557d63ee7addb0447295fd5fcfc856ddc16)), closes [#22151](https://github.com/bitnami/charts/issues/22151)

## <small>4.0.1 (2024-01-09)</small>

* matomo: make it possible to use ssl connections to database (#21617) ([308e0ef](https://github.com/bitnami/charts/commit/308e0efeca7effff3b3441242f3ec06700d3ded1)), closes [#21617](https://github.com/bitnami/charts/issues/21617)
* [bitnami/*] Fix docs.bitnami.com broken links (#21901) ([f35506d](https://github.com/bitnami/charts/commit/f35506d2dadee4f097986e7792df1f53ab215b5d)), closes [#21901](https://github.com/bitnami/charts/issues/21901)
* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)

## 4.0.0 (2023-12-20)

* [bitnami/matomo] Upgrade MariaDB 11.2 (#21687) ([b8370e9](https://github.com/bitnami/charts/commit/b8370e9bda491be13a9ca5de470b2e23dbd2f660)), closes [#21687](https://github.com/bitnami/charts/issues/21687)

## <small>3.3.1 (2023-12-20)</small>

* [bitnami/matomo] Release 3.3.1 updating components versions (#21673) ([1c784a1](https://github.com/bitnami/charts/commit/1c784a129325eb1c9477dae178c6a65986bb1988)), closes [#21673](https://github.com/bitnami/charts/issues/21673)

## 3.3.0 (2023-12-18)

* [bitnami/matomo] Allow configuring CronJob pods affinity (#21565) ([fe8f176](https://github.com/bitnami/charts/commit/fe8f17639a8b8b56e5f529de16f46ed9e5f43a60)), closes [#21565](https://github.com/bitnami/charts/issues/21565)

## <small>3.2.2 (2023-11-29)</small>

* Bump de chart (#21303) ([e5db594](https://github.com/bitnami/charts/commit/e5db5940885340b87fc3068cbc58c25205bb9ffe)), closes [#21303](https://github.com/bitnami/charts/issues/21303)
* fix(matomo): missing trailing newline (#21268) ([fb93032](https://github.com/bitnami/charts/commit/fb9303244309f3eb8908498361e29e3762d542ff)), closes [#21268](https://github.com/bitnami/charts/issues/21268)

## <small>3.2.1 (2023-11-28)</small>

* [bitnami/matomo] Release 3.2.1 updating components versions (#21290) ([ffb7226](https://github.com/bitnami/charts/commit/ffb722674dfb1734169e25136568ad14099f93de)), closes [#21290](https://github.com/bitnami/charts/issues/21290)

## 3.2.0 (2023-11-24)

* [bitnami/matomo] Deprecates 'cronjobs.enabled' (#21232) ([08ef8c6](https://github.com/bitnami/charts/commit/08ef8c66ec9cc7cbca0d84bbe0c024b454f9f4a3)), closes [#21232](https://github.com/bitnami/charts/issues/21232)

## <small>3.1.4 (2023-11-21)</small>

* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/matomo] Release 3.1.4 updating components versions (#21137) ([6ded36e](https://github.com/bitnami/charts/commit/6ded36edbc832a6df7054e6360956ca6594e825b)), closes [#21137](https://github.com/bitnami/charts/issues/21137)

## <small>3.1.3 (2023-11-20)</small>

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/matomo] taskScheduler cronjob uses wrong suspend value (#21026) ([5b4a132](https://github.com/bitnami/charts/commit/5b4a132ce005fb777f0f84ce6f816d3da927f41f)), closes [#21026](https://github.com/bitnami/charts/issues/21026)

## <small>3.1.2 (2023-11-14)</small>

* [bitnami/matomo] fix wrong indent of extraVolumeMounts in cron job (#20923) ([dbcf568](https://github.com/bitnami/charts/commit/dbcf568d6727f6cf6bdd54df3f955964485d63a3)), closes [#20923](https://github.com/bitnami/charts/issues/20923)

## <small>3.1.1 (2023-11-09)</small>

* [bitnami/matomo] Release 3.1.1 updating components versions (#20754) ([b26559c](https://github.com/bitnami/charts/commit/b26559c031bb60a021c3db4bd7b40b83b9193b45)), closes [#20754](https://github.com/bitnami/charts/issues/20754)

## 3.1.0 (2023-11-07)

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [bitnami/matomo] feat: :sparkles: Add support for PSA restricted policy (#20482) ([9202d41](https://github.com/bitnami/charts/commit/9202d413050e96f380eb670e3628d26c718e4465)), closes [#20482](https://github.com/bitnami/charts/issues/20482)

## <small>3.0.2 (2023-10-17)</small>

* [bitnami/matomo] fix wrong indent of extra volumes (#20271) ([ad1c99b](https://github.com/bitnami/charts/commit/ad1c99b39009211470f4fd849f971778ad64e670)), closes [#20271](https://github.com/bitnami/charts/issues/20271)

## <small>3.0.1 (2023-10-12)</small>

* [bitnami/matomo] Release 3.0.1 (#20152) ([beff189](https://github.com/bitnami/charts/commit/beff1895a747b2dad35cba55d1093bacf3b628fb)), closes [#20152](https://github.com/bitnami/charts/issues/20152)

## 3.0.0 (2023-10-11)

* [bitnami/matomo] Update MariaDB to 14.x.x (#20004) ([be949c2](https://github.com/bitnami/charts/commit/be949c2943d433f329f12c7a5bd9c3ede05c471d)), closes [#20004](https://github.com/bitnami/charts/issues/20004)

## <small>2.3.3 (2023-10-09)</small>

* [bitnami/matomo] Release 2.3.3 (#19920) ([3c07503](https://github.com/bitnami/charts/commit/3c07503aef4f0e7ecad7d3955ffb552a31702d6d)), closes [#19920](https://github.com/bitnami/charts/issues/19920)

## <small>2.3.2 (2023-10-09)</small>

* [bitnami/matomo] Release 2.3.2 (#19865) ([04cfd89](https://github.com/bitnami/charts/commit/04cfd895cdf0bea44f119eea086c03153b7200b0)), closes [#19865](https://github.com/bitnami/charts/issues/19865)

## <small>2.3.1 (2023-10-09)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/matomo] Release 2.3.1 (#19795) ([02df2e9](https://github.com/bitnami/charts/commit/02df2e946fd5b4e97f78b302987ca52ca46f23ef)), closes [#19795](https://github.com/bitnami/charts/issues/19795)

## 2.3.0 (2023-09-29)

* [bitnami/*] Update readme files (#19277) ([e56aeb2](https://github.com/bitnami/charts/commit/e56aeb2fbfbf5b6e42375db48cc7ae1ef1c3a823)), closes [#19277](https://github.com/bitnami/charts/issues/19277)
* [bitnami/matomo] Add cronjobs for archive and scheduled tasks (#18754) ([fce0a66](https://github.com/bitnami/charts/commit/fce0a663991ced893b7472f12dc1a9d345210eea)), closes [#18754](https://github.com/bitnami/charts/issues/18754)

## <small>2.2.3 (2023-09-18)</small>

* [bitnami/matomo] Release 2.2.3 (#19346) ([266b9c7](https://github.com/bitnami/charts/commit/266b9c74a400128439f25ce51f57bd57c0324ea9)), closes [#19346](https://github.com/bitnami/charts/issues/19346)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>2.2.2 (2023-09-15)</small>

* [bitnami/matomo] wrong smtpAuth rendering (#19276) ([711d005](https://github.com/bitnami/charts/commit/711d0056fd19eea4f54dbf282e4ddd0cfeb84a7a)), closes [#19276](https://github.com/bitnami/charts/issues/19276)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)

## <small>2.2.1 (2023-09-07)</small>

* [bitnami/matomo: Use merge helper]: (#19068) ([897f06c](https://github.com/bitnami/charts/commit/897f06cbc061319cb2bb8586306e2e4de692c42e)), closes [#19068](https://github.com/bitnami/charts/issues/19068)

## 2.2.0 (2023-08-29)

* [bitnami/matomo] expand mail configuration (#18911) ([261b793](https://github.com/bitnami/charts/commit/261b793872b63520985e50965bcddf4126a51e68)), closes [#18911](https://github.com/bitnami/charts/issues/18911)

## 2.1.0 (2023-08-24)

* [bitnami/matomo] Support for customizing standard labels (#18622) ([7152f6d](https://github.com/bitnami/charts/commit/7152f6db671f5c595b316b070f465cc0591df35c)), closes [#18622](https://github.com/bitnami/charts/issues/18622)

## <small>2.0.5 (2023-08-20)</small>

* [bitnami/matomo] Release 2.0.5 (#18683) ([97e72ab](https://github.com/bitnami/charts/commit/97e72ab3f57ac9fd7b1739f9991a56550b104113)), closes [#18683](https://github.com/bitnami/charts/issues/18683)

## <small>2.0.4 (2023-08-17)</small>

* [bitnami/matomo] Release 2.0.4 (#18547) ([fcdf22a](https://github.com/bitnami/charts/commit/fcdf22ae4669dd79e4f4cd765aa815dcb3baf348)), closes [#18547](https://github.com/bitnami/charts/issues/18547)

## <small>2.0.3 (2023-08-09)</small>

* [bitnami/matomo] Do not create Secret when an external DB Secret is provided (#18027) (#18037) ([041738f](https://github.com/bitnami/charts/commit/041738fe0c066936b36a631f08a00c22b2525db7)), closes [#18027](https://github.com/bitnami/charts/issues/18027) [#18037](https://github.com/bitnami/charts/issues/18037)

## <small>2.0.2 (2023-08-03)</small>

* [bitnami/matomo] Release 2.0.2 (#18176) ([7910625](https://github.com/bitnami/charts/commit/7910625e34129d7270254310c26a38d3ee245adf)), closes [#18176](https://github.com/bitnami/charts/issues/18176)

## <small>2.0.1 (2023-08-01)</small>

* [bitnami/matomo] Release 2.0.1 (#18132) ([628bcbb](https://github.com/bitnami/charts/commit/628bcbbf0a53514fa48102de18a68b6fc0283f84)), closes [#18132](https://github.com/bitnami/charts/issues/18132)

## 2.0.0 (2023-08-01)

* [bitnami/matomo] Update MariaDB chart to 13.0 (#18108) ([aa26bae](https://github.com/bitnami/charts/commit/aa26bae03a0162855c3adea618844bb13b9fc2cd)), closes [#18108](https://github.com/bitnami/charts/issues/18108)

## <small>1.1.11 (2023-08-01)</small>

* [bitnami/matomo] Release 1.1.11 updating components versions (#18084) ([8942c3f](https://github.com/bitnami/charts/commit/8942c3f2b7797b8e7025be1b001fa35bf8bc18fa)), closes [#18084](https://github.com/bitnami/charts/issues/18084)

## <small>1.1.10 (2023-07-31)</small>

* [bitnami/matomo] Release 1.1.10 (#18064) ([7a711f1](https://github.com/bitnami/charts/commit/7a711f1b7c5dca1bf2d6df2507b2c7ab3c720e55)), closes [#18064](https://github.com/bitnami/charts/issues/18064)

## <small>1.1.9 (2023-07-26)</small>

* [bitnami/matomo] Release 1.1.9 (#17918) ([96c363a](https://github.com/bitnami/charts/commit/96c363a30bec24d83297ffe8f91d26184c63a6cd)), closes [#17918](https://github.com/bitnami/charts/issues/17918)

## <small>1.1.8 (2023-07-15)</small>

* [bitnami/matomo] Release 1 updating components versions (#17621) ([1703389](https://github.com/bitnami/charts/commit/1703389bfdb4200a324bac3c68f9f1255ad86d50)), closes [#17621](https://github.com/bitnami/charts/issues/17621)

## <small>1.1.7 (2023-07-11)</small>

* [bitnami/matomo] Release 1.1.7 (#17558) ([6a65395](https://github.com/bitnami/charts/commit/6a65395b2b8aa85ba133660385d26a94abaeef25)), closes [#17558](https://github.com/bitnami/charts/issues/17558)

## <small>1.1.6 (2023-07-07)</small>

* [bitnami/matomo] Release 1.1.6 (#17516) ([f559fa7](https://github.com/bitnami/charts/commit/f559fa746836bf63e86ae1fe5ddbca4d72d14b68)), closes [#17516](https://github.com/bitnami/charts/issues/17516)

## <small>1.1.5 (2023-06-30)</small>

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/matomo] Release 1.1.5 (#17431) ([9e69f8b](https://github.com/bitnami/charts/commit/9e69f8bcbf337804c3bbc05dbc84c7e60f8cf44a)), closes [#17431](https://github.com/bitnami/charts/issues/17431)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## <small>1.1.4 (2023-05-31)</small>

* [bitnami/matomo] Release 1.1.4 (#16982) ([d7ecf6b](https://github.com/bitnami/charts/commit/d7ecf6b25df4a8625d1b3af390e3260471d089d3)), closes [#16982](https://github.com/bitnami/charts/issues/16982)

## <small>1.1.3 (2023-05-30)</small>

* [bitnami/matomo] Release 1.1.3 (#16960) ([ca94936](https://github.com/bitnami/charts/commit/ca94936bf705768a868d4f47c72a9b733bd143a7)), closes [#16960](https://github.com/bitnami/charts/issues/16960)

## <small>1.1.2 (2023-05-21)</small>

* [bitnami/matomo] Release 1.1.2 (#16789) ([3e77422](https://github.com/bitnami/charts/commit/3e77422435f75722395d8e78e073b214beb46545)), closes [#16789](https://github.com/bitnami/charts/issues/16789)

## <small>1.1.1 (2023-05-11)</small>

* [bitnami/matomo] Release 1.0.1 (#16471) ([1327065](https://github.com/bitnami/charts/commit/1327065c9ae88115d2cbfd42ea332debc62cbe30)), closes [#16471](https://github.com/bitnami/charts/issues/16471)
* Add wording for enterprise page (#16560) ([8f22774](https://github.com/bitnami/charts/commit/8f2277440b976d52785ba9149762ad8620a73d1f)), closes [#16560](https://github.com/bitnami/charts/issues/16560)

## 1.1.0 (2023-05-09)

* [bitnami/several] Adapt Chart.yaml to set desired OCI annotations (#16546) ([fc9b18f](https://github.com/bitnami/charts/commit/fc9b18f2e98805d4df629acbcde696f44f973344)), closes [#16546](https://github.com/bitnami/charts/issues/16546)

## 1.0.0 (2023-04-21)

* [bitnami/matomo] Upgrade MariaDB to version 10.11 (#16170) ([c60b013](https://github.com/bitnami/charts/commit/c60b013fc6b6f7d331881e46443ec833c584653a)), closes [#16170](https://github.com/bitnami/charts/issues/16170)

## 0.3.0 (2023-04-20)

* [bitnami/*] Make Helm charts 100% OCI (#15998) ([8841510](https://github.com/bitnami/charts/commit/884151035efcbf2e1b3206e7def85511073fb57d)), closes [#15998](https://github.com/bitnami/charts/issues/15998)

## <small>0.2.32 (2023-04-19)</small>

* [bitnami/matomo] Release 0.2.32 (#16123) ([a099e64](https://github.com/bitnami/charts/commit/a099e6475c45788c13accf91afcef55535535ccf)), closes [#16123](https://github.com/bitnami/charts/issues/16123)

## <small>0.2.31 (2023-04-14)</small>

* [bitnami/matomo] Fix probe paths (#16043) ([b92052c](https://github.com/bitnami/charts/commit/b92052cd2f676717fe00ae237e4c047f53d908b3)), closes [#16043](https://github.com/bitnami/charts/issues/16043)

## <small>0.2.30 (2023-04-11)</small>

* [bitnami/matomo] Release 0.2.30 (#16014) ([4259b59](https://github.com/bitnami/charts/commit/4259b5975164048113b26227d77e5e052c74296e)), closes [#16014](https://github.com/bitnami/charts/issues/16014)

## <small>0.2.29 (2023-03-21)</small>

* [bitnami/matomo] Release 0.2.29 (#15657) ([07a97e0](https://github.com/bitnami/charts/commit/07a97e06418ce046a79800fb1c0f7c8f24450962)), closes [#15657](https://github.com/bitnami/charts/issues/15657)

## <small>0.2.28 (2023-03-20)</small>

* [bitnami/matomo] Release 0.2.28 (#15645) ([b2f8c43](https://github.com/bitnami/charts/commit/b2f8c432c9dc3c4cb3af4a4298c72198c286bf72)), closes [#15645](https://github.com/bitnami/charts/issues/15645)

## <small>0.2.27 (2023-03-18)</small>

* [bitnami/charts] Apply linter to README files (#15357) ([0e29e60](https://github.com/bitnami/charts/commit/0e29e600d3adc8b1b46e506eccb3decfab3b4e63)), closes [#15357](https://github.com/bitnami/charts/issues/15357)
* [bitnami/matomo] Release 0.2.27 (#15590) ([44f10b1](https://github.com/bitnami/charts/commit/44f10b19e4890d4711f6f9728a700b0200d67183)), closes [#15590](https://github.com/bitnami/charts/issues/15590)

## <small>0.2.26 (2023-03-01)</small>

* [bitnami/matomo] Release 0.2.26 (#15261) ([ab90b91](https://github.com/bitnami/charts/commit/ab90b91f7fd573a2f08f31a45b1c28a707bfdf8e)), closes [#15261](https://github.com/bitnami/charts/issues/15261)

## <small>0.2.25 (2023-02-17)</small>

* [bitnami/*] Fix markdown linter issues 2 (#14890) ([aa96572](https://github.com/bitnami/charts/commit/aa9657237ee8df4a46db0d7fdf8a23230dd6902a)), closes [#14890](https://github.com/bitnami/charts/issues/14890)
* [bitnami/matomo] Release 0.2.25 (#15000) ([8ed39fa](https://github.com/bitnami/charts/commit/8ed39fa503c0039ce0c2c8ee83869767968f301a)), closes [#15000](https://github.com/bitnami/charts/issues/15000)

## <small>0.2.24 (2023-02-14)</small>

* [bitnami/*] Fix markdown linter issues (#14874) ([a51e0e8](https://github.com/bitnami/charts/commit/a51e0e8d35495b907f3e70dd2f8e7c3bcbf4166a)), closes [#14874](https://github.com/bitnami/charts/issues/14874)
* [bitnami/*] Remove unexpected extra spaces (#14873) ([c97c714](https://github.com/bitnami/charts/commit/c97c714887380d47eae7bfeff316bf01595ecd1d)), closes [#14873](https://github.com/bitnami/charts/issues/14873)
* [bitnami/matomo] Release 0.2.24 (#14884) ([4e8667f](https://github.com/bitnami/charts/commit/4e8667f3589cfadde58cf32ccdbc8eb837909434)), closes [#14884](https://github.com/bitnami/charts/issues/14884)

## <small>0.2.23 (2023-02-10)</small>

* [bitnami/matomo] removed specified resources on values.yaml (#14812) ([c6e1059](https://github.com/bitnami/charts/commit/c6e105959a4e80e7acb68558c37fe38ec9737b39)), closes [#14812](https://github.com/bitnami/charts/issues/14812)

## <small>0.2.22 (2023-01-31)</small>

* [bitnami/*] Change copyright date (#14682) ([add4ec7](https://github.com/bitnami/charts/commit/add4ec701108ac36ed4de2dffbdf407a0d091067)), closes [#14682](https://github.com/bitnami/charts/issues/14682)
* [bitnami/matomo] Don't regenerate self-signed certs on upgrade (#14639) ([902e128](https://github.com/bitnami/charts/commit/902e1281fbc085b32924b200fbc8da8f4c92ead8)), closes [#14639](https://github.com/bitnami/charts/issues/14639)

## <small>0.2.21 (2023-01-30)</small>

* [bitnami/matomo] Release 0.2.21 (#14604) ([caeeb16](https://github.com/bitnami/charts/commit/caeeb16daad485e2229e64758853956376395f9f)), closes [#14604](https://github.com/bitnami/charts/issues/14604)

## <small>0.2.20 (2023-01-30)</small>

* [bitnami/matomo] Fix mounting of post init scripts (#14559) ([8731194](https://github.com/bitnami/charts/commit/873119420606f5494958ed18f51991471ad77bb2)), closes [#14559](https://github.com/bitnami/charts/issues/14559)

## <small>0.2.19 (2023-01-26)</small>

* [bitnami/*] Unify READMEs (#14472) ([2064fb8](https://github.com/bitnami/charts/commit/2064fb8dcc78a845cdede8211af8c3cc52551161)), closes [#14472](https://github.com/bitnami/charts/issues/14472)
* [bitnami/matomo] Release 0.2.19 (#14552) ([72db1af](https://github.com/bitnami/charts/commit/72db1af44cc0d95c31c33348db84bb7269c36d8a)), closes [#14552](https://github.com/bitnami/charts/issues/14552)

## <small>0.2.18 (2023-01-19)</small>

* [bitnami/matomo] Release 0.2.18 (#14456) ([be608b9](https://github.com/bitnami/charts/commit/be608b95a94724247276e370936d02fa7c94b288)), closes [#14456](https://github.com/bitnami/charts/issues/14456)

## <small>0.2.17 (2023-01-17)</small>

* [bitnami/*] Add license annotation and remove obsolete engine parameter (#14293) ([da2a794](https://github.com/bitnami/charts/commit/da2a7943bae95b6e9b5b4ed972c15e990b69fdb0)), closes [#14293](https://github.com/bitnami/charts/issues/14293)
* [bitnami/*] Change licenses annotation format (#14377) ([0ab7608](https://github.com/bitnami/charts/commit/0ab760862c660fcc78cffadf8e1d8cdd70881473)), closes [#14377](https://github.com/bitnami/charts/issues/14377)
* [bitnami/matomo] Release 0.2.17 (#14392) ([3a09423](https://github.com/bitnami/charts/commit/3a09423ef04992f8f305a7c91b2e3ca8142534f3)), closes [#14392](https://github.com/bitnami/charts/issues/14392)

## <small>0.2.16 (2023-01-09)</small>

* [bitnami/matomo] Release 0.2.16 (#14234) ([d8a5f63](https://github.com/bitnami/charts/commit/d8a5f63aa65655f819bbd5d31f0be3c6c488e85c)), closes [#14234](https://github.com/bitnami/charts/issues/14234)

## <small>0.2.15 (2022-12-10)</small>

* [bitnami/matomo] Release 0.2.15 (#13905) ([86a6277](https://github.com/bitnami/charts/commit/86a62772b2bbc0a956652956eba7787ea15fb1da)), closes [#13905](https://github.com/bitnami/charts/issues/13905)

## <small>0.2.14 (2022-11-26)</small>

* [bitnami/matomo] Release 0.2.14 (#13703) ([28411ba](https://github.com/bitnami/charts/commit/28411ba58b67be929c8c58a180fa8320d77301ff)), closes [#13703](https://github.com/bitnami/charts/issues/13703)

## <small>0.2.13 (2022-10-27)</small>

* [bitnami/matomo] Release 0.2.13 (#13180) ([85544de](https://github.com/bitnami/charts/commit/85544dea6f2d9539a6b9fd3c3ad10d8fbe7962da)), closes [#13180](https://github.com/bitnami/charts/issues/13180)

## <small>0.2.12 (2022-10-26)</small>

* [bitnami/matomo] optimize annos (#13122) ([6459075](https://github.com/bitnami/charts/commit/64590758b2ced7d24d707ed0ba77f9ee18e4ef1e)), closes [#13122](https://github.com/bitnami/charts/issues/13122)

## <small>0.2.11 (2022-10-21)</small>

* [bitnami/matomo] Release 0.2.11 (#13067) ([227127e](https://github.com/bitnami/charts/commit/227127e54c14ff7842e0dab1335c29e6cfe7a217)), closes [#13067](https://github.com/bitnami/charts/issues/13067)

## <small>0.2.10 (2022-10-20)</small>

* [bitnami/*] Use new default branch name in links (#12943) ([a529e02](https://github.com/bitnami/charts/commit/a529e02597d49d944eba1eb0f190713293247176)), closes [#12943](https://github.com/bitnami/charts/issues/12943)
* [bitnami/matomo] Release 0.2.10 (#13044) ([93e3ca6](https://github.com/bitnami/charts/commit/93e3ca69e7dd30ea964cbeb950aa380c9c593cff)), closes [#13044](https://github.com/bitnami/charts/issues/13044)

## <small>0.2.9 (2022-10-11)</small>

* [bitnami/matomo] Release 0.2.9 (#12912) ([da67b6a](https://github.com/bitnami/charts/commit/da67b6a7fbd86b6ec04ff58de9b87a8e0d4c16d6)), closes [#12912](https://github.com/bitnami/charts/issues/12912)
* Generic README instructions related to the repo (#12792) ([3cf6b10](https://github.com/bitnami/charts/commit/3cf6b10e10e60df4b3e191d6b99aa99a9f597755)), closes [#12792](https://github.com/bitnami/charts/issues/12792)

## <small>0.2.8 (2022-09-30)</small>

* [bitnami/matomo] Release 0.2.8 (#12762) ([847d5bb](https://github.com/bitnami/charts/commit/847d5bb9633fb4029dd3c807d1b9764752496573)), closes [#12762](https://github.com/bitnami/charts/issues/12762)

## <small>0.2.7 (2022-09-29)</small>

* [bitnami/matomo] add service account value (#12252) ([15f844f](https://github.com/bitnami/charts/commit/15f844fe18fd49717b440baec56f73433548c1f5)), closes [#12252](https://github.com/bitnami/charts/issues/12252)

## <small>0.2.6 (2022-09-21)</small>

* [bitnami/matomo] Use custom probes if given (#12522) ([88b93a5](https://github.com/bitnami/charts/commit/88b93a51e7fe05b4e90e78008824f273615d19b3)), closes [#12522](https://github.com/bitnami/charts/issues/12522) [#12354](https://github.com/bitnami/charts/issues/12354)

## <small>0.2.5 (2022-09-14)</small>

* [bitnami/matomo] Release 0.2.5 (#12419) ([227d625](https://github.com/bitnami/charts/commit/227d62556d1a43dfa1b5436fae3fb08ae38f7dcb)), closes [#12419](https://github.com/bitnami/charts/issues/12419)

## <small>0.2.4 (2022-09-13)</small>

* [bitnami/matomo] Release 0.2.4 (#12396) ([52d4df7](https://github.com/bitnami/charts/commit/52d4df765e3a938a1eb81feb5c48477d94f88e33)), closes [#12396](https://github.com/bitnami/charts/issues/12396)

## <small>0.2.3 (2022-09-11)</small>

* [bitnami/matomo] Release 0.2.3 (#12365) ([b0c5625](https://github.com/bitnami/charts/commit/b0c5625707f72df8754e65181083dc1d49b338d5)), closes [#12365](https://github.com/bitnami/charts/issues/12365)

## <small>0.2.2 (2022-08-26)</small>

* [bitnami/matomo] Release 0.1.5 (#11746) ([41b9b53](https://github.com/bitnami/charts/commit/41b9b5399d469ce9590c841d6d53a0c9b2c32f86)), closes [#11746](https://github.com/bitnami/charts/issues/11746)

## <small>0.2.1 (2022-08-23)</small>

* [bitnami/matomo] Update Chart.lock (#12094) ([da7cae8](https://github.com/bitnami/charts/commit/da7cae8cceb191ea4446636acf34e73a27e8071b)), closes [#12094](https://github.com/bitnami/charts/issues/12094)

## 0.2.0 (2022-08-22)

* [bitnami/matomo] Add support for image digest apart from tag (#11920) ([bcfb18e](https://github.com/bitnami/charts/commit/bcfb18ee602abbd5d53fbe18492287bfcd9037ae)), closes [#11920](https://github.com/bitnami/charts/issues/11920)

## <small>0.1.4 (2022-08-03)</small>

* [bitnami/*] Update URLs to point to the new bitnami/containers monorepo (#11352) ([d665af0](https://github.com/bitnami/charts/commit/d665af0c708846192d8d5fb2f5f9ea65dd464ab0)), closes [#11352](https://github.com/bitnami/charts/issues/11352)
* [bitnami/matomo] Release 0.1.4 (#11527) ([cfd428c](https://github.com/bitnami/charts/commit/cfd428c1a68d339023dce4bc01afa7bc3164f14e)), closes [#11527](https://github.com/bitnami/charts/issues/11527)

## <small>0.1.3 (2022-07-12)</small>

* Fix category case in matomo chart (#11143) ([b8c7098](https://github.com/bitnami/charts/commit/b8c7098b6e533e07de58f3ccd9e76f2e5bd94934)), closes [#11143](https://github.com/bitnami/charts/issues/11143)

## <small>0.1.2 (2022-07-12)</small>

* [bitnami/matomo] Release 0.1.2 (#11135) ([c745808](https://github.com/bitnami/charts/commit/c7458080ae5c81d92477cc88fdaade17534e0e46)), closes [#11135](https://github.com/bitnami/charts/issues/11135)

## <small>0.1.1 (2022-07-11)</small>

* [bitnami/matomo] Release 0.1.1 (#11096) ([cc2cef7](https://github.com/bitnami/charts/commit/cc2cef7ca1891246b391197cf1e891a89096267d)), closes [#11096](https://github.com/bitnami/charts/issues/11096)

## 0.1.0 (2022-07-07)

* [bitnami/matomo] Adding the Matomo Helm Chart (#10652) ([4084152](https://github.com/bitnami/charts/commit/4084152a96e6ba433782fe584d4c5c27d9100970)), closes [#10652](https://github.com/bitnami/charts/issues/10652)
