# Changelog

## 2.4.23 (2025-08-13)

* [bitnami/pinniped] :zap: :arrow_up: Update dependency references ([#35822](https://github.com/bitnami/charts/pull/35822))

## <small>2.4.22 (2025-08-07)</small>

* [bitnami/pinniped] :zap: :arrow_up: Update dependency references (#35515) ([f47a177](https://github.com/bitnami/charts/commit/f47a177b6eb5f990192069fa4bf706ac70cbb726)), closes [#35515](https://github.com/bitnami/charts/issues/35515)

## <small>2.4.21 (2025-08-04)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/pinniped] :zap: :arrow_up: Update dependency references (#35403) ([af2a18f](https://github.com/bitnami/charts/commit/af2a18fde8aa76a843a55cc63ccc683cc13867da)), closes [#35403](https://github.com/bitnami/charts/issues/35403)

## <small>2.4.20 (2025-07-09)</small>

* [bitnami/pinniped] :zap: :arrow_up: Update dependency references (#34934) ([e887bcc](https://github.com/bitnami/charts/commit/e887bcc79728767e7df24f998b461d641f54a40a)), closes [#34934](https://github.com/bitnami/charts/issues/34934)

## <small>2.4.19 (2025-06-13)</small>

* [bitnami/pinniped] :zap: :arrow_up: Update dependency references (#34482) ([1ea11c5](https://github.com/bitnami/charts/commit/1ea11c51be41808e893fbc251cb44e47909fede3)), closes [#34482](https://github.com/bitnami/charts/issues/34482)

## <small>2.4.18 (2025-06-06)</small>

* [bitnami/pinniped] :zap: :arrow_up: Update dependency references (#34209) ([bf1e345](https://github.com/bitnami/charts/commit/bf1e345a910a59b4938a435de05f70fce3931997)), closes [#34209](https://github.com/bitnami/charts/issues/34209)

## <small>2.4.17 (2025-05-19)</small>

* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)
* [bitnami/pinniped] :zap: :arrow_up: Update dependency references (#33781) ([d951725](https://github.com/bitnami/charts/commit/d9517253c6f164ec6e572c9c6c1e96e9f1f14a2e)), closes [#33781](https://github.com/bitnami/charts/issues/33781)

## <small>2.4.16 (2025-05-07)</small>

* [bitnami/pinniped] Release 2.4.16 (#33493) ([6265fac](https://github.com/bitnami/charts/commit/6265facd75dc9d81a05efec0d2d12200c5fd716c)), closes [#33493](https://github.com/bitnami/charts/issues/33493)

## <small>2.4.15 (2025-05-06)</small>

* [bitnami/pinniped] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#3342 ([e13f1bc](https://github.com/bitnami/charts/commit/e13f1bc4ee09a47f5b3558dbfd81654b37ee41ec)), closes [#33421](https://github.com/bitnami/charts/issues/33421)

## <small>2.4.14 (2025-04-22)</small>

* [bitnami/pinniped] Release 2.4.14 (#33118) ([c5b0aa0](https://github.com/bitnami/charts/commit/c5b0aa03e762ba34ef1128066a2cd83ad179ae6e)), closes [#33118](https://github.com/bitnami/charts/issues/33118)

## <small>2.4.13 (2025-04-02)</small>

* [bitnami/pinniped] Release 2.4.13 (#32758) ([d9da8e8](https://github.com/bitnami/charts/commit/d9da8e850244ddc5e02e1c68f067e54f43705f3a)), closes [#32758](https://github.com/bitnami/charts/issues/32758)

## <small>2.4.12 (2025-03-19)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/pinniped] Release 2.4.12 (#32523) ([de64aa3](https://github.com/bitnami/charts/commit/de64aa321ea9641e92728a305b5dcb0ceaa08d2d)), closes [#32523](https://github.com/bitnami/charts/issues/32523)

## <small>2.4.11 (2025-03-12)</small>

* Fix pinniped default values type (#32395) ([754d7c2](https://github.com/bitnami/charts/commit/754d7c2495bdee3c456643a594077086ee835fbd)), closes [#32395](https://github.com/bitnami/charts/issues/32395)

## <small>2.4.10 (2025-03-05)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/pinniped] Release 2.4.10 (#32312) ([9671b97](https://github.com/bitnami/charts/commit/9671b978f47d769cf8fc7a400331b014d40758c5)), closes [#32312](https://github.com/bitnami/charts/issues/32312)

## <small>2.4.9 (2025-02-07)</small>

* [bitnami/pinniped] Release 2.4.9 (#31826) ([b8c5f4c](https://github.com/bitnami/charts/commit/b8c5f4cd9232459d8a753aee82080de266debf0f)), closes [#31826](https://github.com/bitnami/charts/issues/31826)

## <small>2.4.8 (2025-02-05)</small>

* [bitnami/pinniped] Release 2.4.8 (#31774) ([d35eec7](https://github.com/bitnami/charts/commit/d35eec7815622f4f0c7ee710ca4fc19a3f4d9c1c)), closes [#31774](https://github.com/bitnami/charts/issues/31774)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## <small>2.4.7 (2025-01-27)</small>

* [bitnami/pinniped] Ensure rbac and networkpolicy is not created for Concierge when disabled (#31564) ([0405f84](https://github.com/bitnami/charts/commit/0405f8474f0b47e7a93cd37c9dddbe5547a72c5f)), closes [#31564](https://github.com/bitnami/charts/issues/31564)

## <small>2.4.6 (2025-01-24)</small>

* [bitnami/pinniped] Release 2.4.6 (#31578) ([bdb886b](https://github.com/bitnami/charts/commit/bdb886b13ad7b43e211f601eccbccb4460c3de00)), closes [#31578](https://github.com/bitnami/charts/issues/31578)

## <small>2.4.5 (2025-01-23)</small>

* [bitnami/pinniped] Ensure rbac and networkpolicy is not created for s… (#31515) ([29d041b](https://github.com/bitnami/charts/commit/29d041b4e34ffa0e6aea5d6f8681db57435372db)), closes [#31515](https://github.com/bitnami/charts/issues/31515)

## <small>2.4.4 (2025-01-17)</small>

* [bitnami/pinniped] Release 2.4.4 (#31440) ([c198f0f](https://github.com/bitnami/charts/commit/c198f0f46df6ceec39eda8f66177fc586a791082)), closes [#31440](https://github.com/bitnami/charts/issues/31440)

## <small>2.4.3 (2025-01-15)</small>

* [bitnami/pinniped] Release 2.4.3 (#31388) ([5431593](https://github.com/bitnami/charts/commit/5431593572ef413843aed94fb50978fce9a77c6a)), closes [#31388](https://github.com/bitnami/charts/issues/31388)

## <small>2.4.2 (2025-01-13)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/pinniped] bugfix: remove deprecated vars to configure OpenLDAP on VIB (#31337) ([e24fab4](https://github.com/bitnami/charts/commit/e24fab4b2cb9d6e5e0c3b4e3b93fd87bca011c2b)), closes [#31337](https://github.com/bitnami/charts/issues/31337)

## <small>2.4.1 (2024-12-10)</small>

* [bitnami/pinniped] Release 2.4.1 (#30975) ([0505a7e](https://github.com/bitnami/charts/commit/0505a7eadfbcd76a857100c0676f36069b03bf79)), closes [#30975](https://github.com/bitnami/charts/issues/30975)

## 2.4.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/pinniped] Detect non-standard images (#30935) ([337fe9c](https://github.com/bitnami/charts/commit/337fe9c6f22c1a3afab25eef28118528d24b3737)), closes [#30935](https://github.com/bitnami/charts/issues/30935)

## <small>2.3.6 (2024-12-04)</small>

* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/pinniped] Release 2.3.6 (#30772) ([ab55671](https://github.com/bitnami/charts/commit/ab556712be6547d1d1f722c9fa612413559659a2)), closes [#30772](https://github.com/bitnami/charts/issues/30772)

## <small>2.3.5 (2024-11-08)</small>

* [bitnami/pinniped] Unify seLinuxOptions default value (#30334) ([06e2318](https://github.com/bitnami/charts/commit/06e2318131efc03e6c67b942d087c94586121925)), closes [#30334](https://github.com/bitnami/charts/issues/30334)

## <small>2.3.4 (2024-11-07)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/pinniped] Release 2.3.4 (#30304) ([d4ac7f8](https://github.com/bitnami/charts/commit/d4ac7f87d05deba5be151dbacb4df8aff62c17b3)), closes [#30304](https://github.com/bitnami/charts/issues/30304)

## <small>2.3.3 (2024-10-17)</small>

* [bitnami/pinniped] Release 2.3.3 (#29959) ([d7c67b9](https://github.com/bitnami/charts/commit/d7c67b926bf3546097193e79677d5601692eb461)), closes [#29959](https://github.com/bitnami/charts/issues/29959)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## <small>2.3.2 (2024-10-02)</small>

* [bitnami/pinniped] Release 2.3.2 (#29714) ([4871f7b](https://github.com/bitnami/charts/commit/4871f7bf11f3641b4700eb161ffb22ca49d7fe60)), closes [#29714](https://github.com/bitnami/charts/issues/29714)

## <small>2.3.1 (2024-09-06)</small>

* [bitnami/pinniped] Release 2.3.1 (#29257) ([cc3ce8e](https://github.com/bitnami/charts/commit/cc3ce8ead7d47a2b84b7e135e6016e9e0cd4e3a8)), closes [#29257](https://github.com/bitnami/charts/issues/29257)

## 2.3.0 (2024-08-14)

* [bitnami/pinniped] chore: :arrow_up: Bump common subchart (#28869) ([bdd9234](https://github.com/bitnami/charts/commit/bdd9234fed458a0a4fd14ee481fb33bf1c598806)), closes [#28869](https://github.com/bitnami/charts/issues/28869)

## <small>2.2.15 (2024-08-12)</small>

* [bitnami/pinniped] Release 2.2.15 (#28779) ([e50f759](https://github.com/bitnami/charts/commit/e50f759a375b74e15bdcb07c1c69361792c0cbef)), closes [#28779](https://github.com/bitnami/charts/issues/28779)

## <small>2.2.14 (2024-08-09)</small>

* [bitnami/pinniped] fix: :bug: Add missing rbac resources (#28804) ([b3d9e4a](https://github.com/bitnami/charts/commit/b3d9e4aef4314a608f98c2f9d6afb470dd37aacd)), closes [#28804](https://github.com/bitnami/charts/issues/28804)

## <small>2.2.13 (2024-08-07)</small>

* [bitnami/pinniped] Release 2.2.13 (#28753) ([5984af4](https://github.com/bitnami/charts/commit/5984af460eebd9a1763528e818d88c359f5298fb)), closes [#28753](https://github.com/bitnami/charts/issues/28753)

## <small>2.2.12 (2024-07-25)</small>

* [bitnami/pinniped] Release 2.2.12 (#28467) ([c0cffd9](https://github.com/bitnami/charts/commit/c0cffd9774a31807ef78abeeae962c4b023f23af)), closes [#28467](https://github.com/bitnami/charts/issues/28467)

## <small>2.2.11 (2024-07-24)</small>

* [bitnami/pinniped] Release 2.2.11 (#28350) ([9a50783](https://github.com/bitnami/charts/commit/9a50783a3d1a12ce80b94f6d30ecdc127cf80b92)), closes [#28350](https://github.com/bitnami/charts/issues/28350)

## <small>2.2.10 (2024-07-16)</small>

* [bitnami/pinniped] Global StorageClass as default value (#28081) ([887f3c3](https://github.com/bitnami/charts/commit/887f3c3091ee17b846fe3a9734d88ba0d7604c0e)), closes [#28081](https://github.com/bitnami/charts/issues/28081)

## <small>2.2.9 (2024-07-04)</small>

* [bitnami/pinniped] Release 2.2.9 (#27775) ([657bff4](https://github.com/bitnami/charts/commit/657bff4c8d68c2b2e512b7527ed50d190ce73a6a)), closes [#27775](https://github.com/bitnami/charts/issues/27775)

## <small>2.2.8 (2024-07-03)</small>

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/pinniped] Release 2.2.8 (#27672) ([2139468](https://github.com/bitnami/charts/commit/2139468c7bee1525af628c721580499216eda5ef)), closes [#27672](https://github.com/bitnami/charts/issues/27672)

## <small>2.2.7 (2024-06-19)</small>

* [bitnami/pinniped] Release 2.2.7 (#27454) ([6b298c9](https://github.com/bitnami/charts/commit/6b298c9c0b5092bfa13713a7b473406157c268d1)), closes [#27454](https://github.com/bitnami/charts/issues/27454)

## <small>2.2.6 (2024-06-18)</small>

* [bitnami/pinniped] Release 2.2.6 (#27399) ([d84210f](https://github.com/bitnami/charts/commit/d84210ffb4a676768471575dd934240778ffe6ea)), closes [#27399](https://github.com/bitnami/charts/issues/27399)

## <small>2.2.5 (2024-06-17)</small>

* [bitnami/pinniped] Release 2.2.5 (#27264) ([c86f9ae](https://github.com/bitnami/charts/commit/c86f9ae85f53c079b5d267c1a0d57f9bb6d1e612)), closes [#27264](https://github.com/bitnami/charts/issues/27264)

## <small>2.2.4 (2024-06-14)</small>

* [bitnami/pinniped] Release 2.2.4 (#27163) ([4b75c1b](https://github.com/bitnami/charts/commit/4b75c1b43460318c613be9d70d1e743d5566005f)), closes [#27163](https://github.com/bitnami/charts/issues/27163)

## <small>2.2.3 (2024-06-06)</small>

* [bitnami/pinniped] Release 2.2.3 (#26999) ([f07cf7e](https://github.com/bitnami/charts/commit/f07cf7e8f83964ea878e22de6cdfd0a21472dfaf)), closes [#26999](https://github.com/bitnami/charts/issues/26999)

## <small>2.2.2 (2024-06-05)</small>

* [bitnami/pinniped] Release 2.2.2 (#26751) ([50cc02f](https://github.com/bitnami/charts/commit/50cc02f29b3121b4708a501cacfc20b2fc03a923)), closes [#26751](https://github.com/bitnami/charts/issues/26751)

## <small>2.2.1 (2024-06-04)</small>

* [bitnami/pinniped] Bump chart version (#26659) ([ae7cb32](https://github.com/bitnami/charts/commit/ae7cb329c94ec9ea245dd1dab4bf25772fb09575)), closes [#26659](https://github.com/bitnami/charts/issues/26659)

## 2.2.0 (2024-05-30)

* [bitnami/pinniped] Enable PodDisruptionBudgets (#26529) ([cd1f2d0](https://github.com/bitnami/charts/commit/cd1f2d035be17553589034a3e7d59b52fc970b29)), closes [#26529](https://github.com/bitnami/charts/issues/26529)

## <small>2.1.1 (2024-05-23)</small>

* [bitnami/pinniped] Use different liveness/readiness probes (#26321) ([67a3201](https://github.com/bitnami/charts/commit/67a3201c43317d82bcfbde01c83ccf9d9ef6da8f)), closes [#26321](https://github.com/bitnami/charts/issues/26321)

## 2.1.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/pinniped] feat: :sparkles: :lock: Add warning when original images are replaced (#26263) ([c061c62](https://github.com/bitnami/charts/commit/c061c62ee2460e5df743fff5b5bfbad869068172)), closes [#26263](https://github.com/bitnami/charts/issues/26263)

## <small>2.0.8 (2024-05-18)</small>

* [bitnami/pinniped] Release 2.0.8 updating components versions (#26063) ([f9ad52e](https://github.com/bitnami/charts/commit/f9ad52e4cfbcca00faaff17f7b347aa8b14c9d74)), closes [#26063](https://github.com/bitnami/charts/issues/26063)

## <small>2.0.7 (2024-05-14)</small>

* [bitnami/pinniped] Release 2.0.7 updating components versions (#25810) ([3ad99f4](https://github.com/bitnami/charts/commit/3ad99f43f6887088d38ace71bd8d99f136a2c134)), closes [#25810](https://github.com/bitnami/charts/issues/25810)

## <small>2.0.6 (2024-05-10)</small>

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/pinniped] Release 2.0.6 (#25666) ([33bf551](https://github.com/bitnami/charts/commit/33bf5515a5955076f93ad8ecdd85d7be7a86d4e7)), closes [#25666](https://github.com/bitnami/charts/issues/25666)

## <small>2.0.5 (2024-05-08)</small>

* [bitnami/*] Set new header/owner (#25558) ([8d1dc11](https://github.com/bitnami/charts/commit/8d1dc11f5fb30db6fba50c43d7af59d2f79deed3)), closes [#25558](https://github.com/bitnami/charts/issues/25558)
* [bitnami/multiple charts] Fix typo: "NetworkPolice" vs "NetworkPolicy" (#25348) ([6970c1b](https://github.com/bitnami/charts/commit/6970c1ba245873506e73d459c6eac1e4919b778f)), closes [#25348](https://github.com/bitnami/charts/issues/25348)
* [bitnami/pinniped] Release 2.0.5 updating components versions (#25616) ([3ad5051](https://github.com/bitnami/charts/commit/3ad5051bb7482ee0bfc2b64fc95c7da9f1099757)), closes [#25616](https://github.com/bitnami/charts/issues/25616)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## <small>2.0.4 (2024-04-05)</small>

* [bitnami/pinniped] Release 2.0.4 updating components versions (#24961) ([2474fc3](https://github.com/bitnami/charts/commit/2474fc3b40962c2c43c702e1fb52f804d346a36d)), closes [#24961](https://github.com/bitnami/charts/issues/24961)

## <small>2.0.3 (2024-04-04)</small>

* [bitnami/pinniped] Release 2.0.3 (#24917) ([60213d0](https://github.com/bitnami/charts/commit/60213d0fe79fd50d4aab10f13fe3cdda70c2068b)), closes [#24917](https://github.com/bitnami/charts/issues/24917)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## <small>2.0.2 (2024-03-27)</small>

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* [bitnami/pinniped] fix: :bug: Add api port to supervisor network policy ingress (#24710) ([31cc245](https://github.com/bitnami/charts/commit/31cc2456db37aa6e1201a0a5ad6a8f49eaf96236)), closes [#24710](https://github.com/bitnami/charts/issues/24710)

## <small>2.0.1 (2024-03-15)</small>

* [bitnami/pinniped] Release 2.0.1 (#24460) ([b3bc604](https://github.com/bitnami/charts/commit/b3bc604e165474b43ad5e0268fff645d1064b730)), closes [#24460](https://github.com/bitnami/charts/issues/24460)

## 2.0.0 (2024-03-12)

* [bitnami/pinniped] feat!: 🔒 💥 Improve security defaults (#24349) ([b0633a8](https://github.com/bitnami/charts/commit/b0633a84f4ce0cb9dfe907272f48373b87e13b06)), closes [#24349](https://github.com/bitnami/charts/issues/24349)

## <small>1.12.1 (2024-03-06)</small>

* [bitnami/pinniped] Release 1.12.1 updating components versions (#24215) ([32a2928](https://github.com/bitnami/charts/commit/32a2928aa37930d7738577aaedf015a5f5cc397f)), closes [#24215](https://github.com/bitnami/charts/issues/24215)

## 1.12.0 (2024-03-06)

* [bitnami/pinniped] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v2 SCC  ([55b0345](https://github.com/bitnami/charts/commit/55b03453b1d8d1bc8e5fa04e60f503859f834bf8)), closes [#24140](https://github.com/bitnami/charts/issues/24140)

## 1.11.0 (2024-02-29)

* [bitnami/pinniped] feat: :sparkles: :lock: Add readOnlyRootFilesystem support (#23991) ([584265c](https://github.com/bitnami/charts/commit/584265cd44f6f1f72932abfb151dc123d637c10c)), closes [#23991](https://github.com/bitnami/charts/issues/23991)

## <small>1.10.2 (2024-02-22)</small>

* [bitnami/pinniped] Release 1.10.2 updating components versions (#23818) ([b20a3f8](https://github.com/bitnami/charts/commit/b20a3f8f63d12f8d37696e191032fef51500d506)), closes [#23818](https://github.com/bitnami/charts/issues/23818)

## <small>1.10.1 (2024-02-21)</small>

* [bitnami/pinniped] Release 1.10.1 updating components versions (#23679) ([b415c7e](https://github.com/bitnami/charts/commit/b415c7eea65959fddc711e87313107ff850f21c4)), closes [#23679](https://github.com/bitnami/charts/issues/23679)

## 1.10.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## 1.9.0 (2024-02-15)

* [bitnami/pinniped] feat: :sparkles: :lock: Add resource preset support (#23508) ([ff5b532](https://github.com/bitnami/charts/commit/ff5b532fe4c29d9973580e119d8aae3b437d70da)), closes [#23508](https://github.com/bitnami/charts/issues/23508)

## <small>1.8.3 (2024-02-08)</small>

* [bitnami/pinniped] Release 1.8.3 updating components versions (#23315) ([b409d49](https://github.com/bitnami/charts/commit/b409d493a4dc8b87beef86da621db148bfc8de52)), closes [#23315](https://github.com/bitnami/charts/issues/23315)

## <small>1.8.2 (2024-02-07)</small>

* [bitnami/pinniped] Release 1.8.2 updating components versions (#23259) ([182130f](https://github.com/bitnami/charts/commit/182130fe7d5d5bbf72c8246a1f95650ffcf614c1)), closes [#23259](https://github.com/bitnami/charts/issues/23259)

## <small>1.8.1 (2024-02-03)</small>

* [bitnami/pinniped] Release 1.8.1 updating components versions (#23127) ([d573d3b](https://github.com/bitnami/charts/commit/d573d3bb4cf73479c00a3c4a5cb66def7ce39c23)), closes [#23127](https://github.com/bitnami/charts/issues/23127)

## 1.8.0 (2024-01-31)

* [bitnami/pinniped] fix: :bug: Add allowExternalEgress to avoid breaking istio (#22961) ([3a8920d](https://github.com/bitnami/charts/commit/3a8920d2b68ef3bbe482efba76517860f219a6c3)), closes [#22961](https://github.com/bitnami/charts/issues/22961)

## <small>1.7.1 (2024-01-31)</small>

* [bitnami/pinniped] Release 1.7.1 updating components versions (#22966) ([300797a](https://github.com/bitnami/charts/commit/300797a5a7e926510580313efcf32acab60126fc)), closes [#22966](https://github.com/bitnami/charts/issues/22966)

## 1.7.0 (2024-01-30)

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/pinniped] feat: :lock: Enable networkPolicy (#22827) ([06ff33b](https://github.com/bitnami/charts/commit/06ff33b39b2ed76884ff7a4c88568f04451aaa32)), closes [#22827](https://github.com/bitnami/charts/issues/22827)

## <small>1.6.1 (2024-01-24)</small>

* [bitnami/pinniped] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22645) ([74cb8b1](https://github.com/bitnami/charts/commit/74cb8b1fdc6a29138dc27035512e1cc395a4fa70)), closes [#22645](https://github.com/bitnami/charts/issues/22645)

## 1.6.0 (2024-01-19)

* [bitnami/pinniped] fix: :lock: Move service-account token auto-mount to pod declaration (#22449) ([9113dbd](https://github.com/bitnami/charts/commit/9113dbd8c3a09e1fccddcbfd541bfff6e2f46149)), closes [#22449](https://github.com/bitnami/charts/issues/22449)

## <small>1.5.2 (2024-01-18)</small>

* [bitnami/pinniped] Update CRDs and add source header (#22378) ([d11b2ed](https://github.com/bitnami/charts/commit/d11b2ed6b62ecf5c6c1c84f9fab498d9a5cc197d)), closes [#22378](https://github.com/bitnami/charts/issues/22378)

## <small>1.5.1 (2024-01-18)</small>

* [bitnami/pinniped] Release 1.5.1 updating components versions (#22320) ([19f27d5](https://github.com/bitnami/charts/commit/19f27d51891cb668cb14b3bdb60e51fca26d4f7b)), closes [#22320](https://github.com/bitnami/charts/issues/22320)

## 1.5.0 (2024-01-17)

* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/pinniped] fix: :lock: Improve podSecurityContext and containerSecurityContext with essentia ([0d85351](https://github.com/bitnami/charts/commit/0d853511d21f2b3a49b3491e2bb2d83b140a1a03)), closes [#22176](https://github.com/bitnami/charts/issues/22176)

## <small>1.4.6 (2024-01-10)</small>

* [bitnami/*] Fix docs.bitnami.com broken links (#21901) ([f35506d](https://github.com/bitnami/charts/commit/f35506d2dadee4f097986e7792df1f53ab215b5d)), closes [#21901](https://github.com/bitnami/charts/issues/21901)
* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)
* [bitnami/pinniped] Release 1.4.6 updating components versions (#21968) ([3839143](https://github.com/bitnami/charts/commit/3839143cd3e9a2e46caf67415ababdc32a60d8c6)), closes [#21968](https://github.com/bitnami/charts/issues/21968)

## <small>1.4.5 (2023-12-27)</small>

* [bitnami/pinniped] Release 1.4.5 (#21600) ([38da69e](https://github.com/bitnami/charts/commit/38da69e3857b30c9e489b70979b2bebdbabda04e)), closes [#21600](https://github.com/bitnami/charts/issues/21600)

## <small>1.4.4 (2023-12-06)</small>

* [bitnami/pinniped] Release 1.4.4 updating components versions (#21434) ([456d6d7](https://github.com/bitnami/charts/commit/456d6d75ea217d92859d4246f87a9800e13c9e13)), closes [#21434](https://github.com/bitnami/charts/issues/21434)

## <small>1.4.3 (2023-11-21)</small>

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/pinniped] Release 1.4.3 updating components versions (#21157) ([6bb57cf](https://github.com/bitnami/charts/commit/6bb57cfaaaec6f1827ce9d4b04074004cd6d0840)), closes [#21157](https://github.com/bitnami/charts/issues/21157)
* Update readme-generator links (#21043) ([1581eba](https://github.com/bitnami/charts/commit/1581eba8044d730a763c266f279ac2ac782f764d)), closes [#21043](https://github.com/bitnami/charts/issues/21043)

## <small>1.4.2 (2023-11-09)</small>

* [bitnami/pinniped] Release 1.4.2 updating components versions (#20855) ([e8752bc](https://github.com/bitnami/charts/commit/e8752bcf7d403234df22cea0c05b563dd5b2dd78)), closes [#20855](https://github.com/bitnami/charts/issues/20855)

## <small>1.4.1 (2023-11-09)</small>

* [bitnami/pinniped] Release 1.4.1 updating components versions (#20777) ([42b59b4](https://github.com/bitnami/charts/commit/42b59b415232052a488608eb605004341f555cdc)), closes [#20777](https://github.com/bitnami/charts/issues/20777)

## 1.4.0 (2023-11-06)

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [bitnami/pinniped] feat: :sparkles: Add support for PSA restricted policy (#20525) ([0642fb2](https://github.com/bitnami/charts/commit/0642fb24f68a05b78c307d1f5702cfb43e059745)), closes [#20525](https://github.com/bitnami/charts/issues/20525)

## <small>1.3.10 (2023-10-16)</small>

* [bitnami/pinniped] test: :white_check_mark: Update to use pinniped-cli (#20257) ([dbf3deb](https://github.com/bitnami/charts/commit/dbf3deb1a1b4e42269dda687babb1a8a747a557e)), closes [#20257](https://github.com/bitnami/charts/issues/20257)

## <small>1.3.9 (2023-10-11)</small>

* [bitnami/pinniped] Release 1.3.9 (#20059) ([b629dd5](https://github.com/bitnami/charts/commit/b629dd57e22fb1c991167eb8a1171c8cc7ee2f70)), closes [#20059](https://github.com/bitnami/charts/issues/20059)

## <small>1.3.8 (2023-10-10)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/pinniped] Release 1.3.8 (#19982) ([98a9df8](https://github.com/bitnami/charts/commit/98a9df83fe816eee922f999ea4ac5506fdd348d4)), closes [#19982](https://github.com/bitnami/charts/issues/19982)

## <small>1.3.7 (2023-10-04)</small>

* [bitnami/pinniped] Bump chart version (missing in #19733) (#19738) ([6c585fb](https://github.com/bitnami/charts/commit/6c585fb34dfd88bee4114ab8d17557ed4207d8fa)), closes [#19733](https://github.com/bitnami/charts/issues/19733) [#19738](https://github.com/bitnami/charts/issues/19738)
* [bitnami/pinniped] Fix issue with kubeCertAgent pullSecrets (#19733) ([387bdce](https://github.com/bitnami/charts/commit/387bdcec7294a1f488f485e8bf4eb6848f016920)), closes [#19733](https://github.com/bitnami/charts/issues/19733)

## <small>1.3.6 (2023-10-04)</small>

* [bitnami/pinniped] Release 1.3.6 (#19734) ([8ecfaf8](https://github.com/bitnami/charts/commit/8ecfaf809e7627bcff86a6612960f7d78f701063)), closes [#19734](https://github.com/bitnami/charts/issues/19734)

## <small>1.3.5 (2023-10-03)</small>

* [bitnami/pinniped] Add kubeCertAgent imagePullSecrets (#19688) ([672e6e3](https://github.com/bitnami/charts/commit/672e6e3b3b0f6acd83e791900efd8fbebd78c1a7)), closes [#19688](https://github.com/bitnami/charts/issues/19688)

## <small>1.3.4 (2023-09-29)</small>

* [bitnami/pinniped] Release 1.3.4 (#19600) ([eafbbe5](https://github.com/bitnami/charts/commit/eafbbe504c3a7f289e167559edaf1ce707652345)), closes [#19600](https://github.com/bitnami/charts/issues/19600)

## <small>1.3.3 (2023-09-19)</small>

* [bitnami/*] Update readme files (#19277) ([e56aeb2](https://github.com/bitnami/charts/commit/e56aeb2fbfbf5b6e42375db48cc7ae1ef1c3a823)), closes [#19277](https://github.com/bitnami/charts/issues/19277)
* [bitnami/pinniped] Release 1.3.3 (#19399) ([bda8296](https://github.com/bitnami/charts/commit/bda829619886e7ce90e3edfaba56f3cb738034c2)), closes [#19399](https://github.com/bitnami/charts/issues/19399)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>1.3.2 (2023-09-08)</small>

* [bitnami/pinniped: Use merge helper]: (#19092) ([77366a9](https://github.com/bitnami/charts/commit/77366a92a72f08019d875e8986c4ba0caf91ef67)), closes [#19092](https://github.com/bitnami/charts/issues/19092)

## <small>1.3.1 (2023-08-23)</small>

* [bitnami/pinniped]: fix ingress annotations (#18804) ([8e569db](https://github.com/bitnami/charts/commit/8e569db24f106ba503fbdcd2ade14e5643da91e3)), closes [#18804](https://github.com/bitnami/charts/issues/18804)

## 1.3.0 (2023-08-22)

* [bitnami/pinniped] Support for customizing standard labels (#18406) ([de650bf](https://github.com/bitnami/charts/commit/de650bf64697d4563d7e28b1bfa616e83f58103d)), closes [#18406](https://github.com/bitnami/charts/issues/18406)

## <small>1.2.11 (2023-08-20)</small>

* [bitnami/pinniped] Release 1.2.11 (#18702) ([8b955eb](https://github.com/bitnami/charts/commit/8b955eb342630921c5250f42d674659e2e6a223d)), closes [#18702](https://github.com/bitnami/charts/issues/18702)

## <small>1.2.10 (2023-08-17)</small>

* [bitnami/pinniped] Release 1.2.10 (#18491) ([dbd27db](https://github.com/bitnami/charts/commit/dbd27dbfd488c9ae362de332ab3072375fb8d541)), closes [#18491](https://github.com/bitnami/charts/issues/18491)

## <small>1.2.9 (2023-08-10)</small>

* [bitnami/pinniped] Release 1.2.9 (#18341) ([8b1fc1b](https://github.com/bitnami/charts/commit/8b1fc1b975c005b74cf6107a7e54bdc7aa2b0c85)), closes [#18341](https://github.com/bitnami/charts/issues/18341)

## <small>1.2.8 (2023-08-08)</small>

* [bitnami/pinniped] chore: :page_facing_up: Remove license in CRDs (#18267) ([882a49e](https://github.com/bitnami/charts/commit/882a49e01d9ce63f8e32330c0d85c9bfe7552ac4)), closes [#18267](https://github.com/bitnami/charts/issues/18267)

## <small>1.2.7 (2023-08-03)</small>

* [bitnami/pinniped] Release 1.2.7 (#18149) ([bc586bb](https://github.com/bitnami/charts/commit/bc586bbca9ca93e22036bc2afd9eac96f1ccfc7d)), closes [#18149](https://github.com/bitnami/charts/issues/18149)

## <small>1.2.6 (2023-07-31)</small>

* [bitnami/pinniped] Allow array for loadBalancerSourceRanges (#18017) ([411009f](https://github.com/bitnami/charts/commit/411009fa45afd43cbd3a85de0378c2b01ea7b748)), closes [#18017](https://github.com/bitnami/charts/issues/18017)
* [bitnami/pinniped] fix: deploy credentialissuer only for concierge (#17737) ([da45f03](https://github.com/bitnami/charts/commit/da45f03512302c16508924b259bdfde82083c653)), closes [#17737](https://github.com/bitnami/charts/issues/17737)

## <small>1.2.5 (2023-07-17)</small>

* [bitnami/pinniped] Release 1.2.5 (#17739) ([83bfb7c](https://github.com/bitnami/charts/commit/83bfb7c2bcb8eacf87c049409c8e442847d7a03d)), closes [#17739](https://github.com/bitnami/charts/issues/17739)

## <small>1.2.4 (2023-07-13)</small>

* [bitnami/pinniped] Release 1.2.4 (#17694) ([2ebd777](https://github.com/bitnami/charts/commit/2ebd7778a12299afaebb65c065cafc4f05d0c923)), closes [#17694](https://github.com/bitnami/charts/issues/17694)

## <small>1.2.3 (2023-06-30)</small>

* [bitnami/pinniped] Release 1.2.3 (#17416) ([b6516fa](https://github.com/bitnami/charts/commit/b6516fa0be55ecc664c56149e6c1f157673ac5a7)), closes [#17416](https://github.com/bitnami/charts/issues/17416)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## <small>1.2.2 (2023-06-14)</small>

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/pinniped] Release 1.2.2 (#17121) ([7f42993](https://github.com/bitnami/charts/commit/7f429932d9688f2b1cc76f8550fbeaac58a1efb7)), closes [#17121](https://github.com/bitnami/charts/issues/17121)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)

## <small>1.2.1 (2023-05-21)</small>

* [bitnami/pinniped] Release 1.2.1 (#16791) ([d49db16](https://github.com/bitnami/charts/commit/d49db1614cd3427597f3e86ddc2fb0d21e442e02)), closes [#16791](https://github.com/bitnami/charts/issues/16791)
* Add wording for enterprise page (#16560) ([8f22774](https://github.com/bitnami/charts/commit/8f2277440b976d52785ba9149762ad8620a73d1f)), closes [#16560](https://github.com/bitnami/charts/issues/16560)

## 1.2.0 (2023-05-09)

* [bitnami/several] Adapt Chart.yaml to set desired OCI annotations (#16546) ([fc9b18f](https://github.com/bitnami/charts/commit/fc9b18f2e98805d4df629acbcde696f44f973344)), closes [#16546](https://github.com/bitnami/charts/issues/16546)

## <small>1.1.2 (2023-05-09)</small>

* [bitnami/pinniped] Release 1.1.2 (#16533) ([71b0f25](https://github.com/bitnami/charts/commit/71b0f2564f404588e98f8f22cb453b4bac84a895)), closes [#16533](https://github.com/bitnami/charts/issues/16533)

## <small>1.1.1 (2023-05-07)</small>

* [bitnami/pinniped] Release 1.1.1 (#16422) ([7fb48fc](https://github.com/bitnami/charts/commit/7fb48fc6de099470c980658f38e05465ed735a12)), closes [#16422](https://github.com/bitnami/charts/issues/16422)

## 1.1.0 (2023-04-20)

* [bitnami/*] Make Helm charts 100% OCI (#15998) ([8841510](https://github.com/bitnami/charts/commit/884151035efcbf2e1b3206e7def85511073fb57d)), closes [#15998](https://github.com/bitnami/charts/issues/15998)

## <small>1.0.10 (2023-04-05)</small>

* [bitnami/pinniped] Release 1.0.10 (#15965) ([b257acd](https://github.com/bitnami/charts/commit/b257acd3e581970e652bd7fb18fd5b877c613aa6)), closes [#15965](https://github.com/bitnami/charts/issues/15965)

## <small>1.0.9 (2023-04-01)</small>

* [bitnami/pinniped] Release 1.0.9 (#15918) ([cb46887](https://github.com/bitnami/charts/commit/cb46887b633ee559526fb07c5b13f4a7436ff26c)), closes [#15918](https://github.com/bitnami/charts/issues/15918)

## <small>1.0.8 (2023-03-22)</small>

* [bitnami/charts] Apply linter to README files (#15357) ([0e29e60](https://github.com/bitnami/charts/commit/0e29e600d3adc8b1b46e506eccb3decfab3b4e63)), closes [#15357](https://github.com/bitnami/charts/issues/15357)
* [bitnami/pinniped] Release 1.0.8 (#15671) ([eb19787](https://github.com/bitnami/charts/commit/eb19787538f399169bf682684e6f654fd9cace3e)), closes [#15671](https://github.com/bitnami/charts/issues/15671)
* Fix url links in several charts README.md (#15370) ([f4a5fed](https://github.com/bitnami/charts/commit/f4a5fedc49671cc1514f26612b3e2a592c2c1e94)), closes [#15370](https://github.com/bitnami/charts/issues/15370)

## <small>1.0.7 (2023-03-01)</small>

* [bitnami/pinniped] Release 1.0.7 (#15279) ([307f6dd](https://github.com/bitnami/charts/commit/307f6dd01922d655ef32e197ca3e75cb5c5669aa)), closes [#15279](https://github.com/bitnami/charts/issues/15279)
* Fixes dead links (#15065) ([9e99fd9](https://github.com/bitnami/charts/commit/9e99fd94d89605c2aa47417ae80eecb86719d904)), closes [#15065](https://github.com/bitnami/charts/issues/15065)

## <small>1.0.6 (2023-02-17)</small>

* [bitnami/*] Change copyright date (#14682) ([add4ec7](https://github.com/bitnami/charts/commit/add4ec701108ac36ed4de2dffbdf407a0d091067)), closes [#14682](https://github.com/bitnami/charts/issues/14682)
* [bitnami/*] Fix markdown linter issues (#14874) ([a51e0e8](https://github.com/bitnami/charts/commit/a51e0e8d35495b907f3e70dd2f8e7c3bcbf4166a)), closes [#14874](https://github.com/bitnami/charts/issues/14874)
* [bitnami/*] Fix markdown linter issues 2 (#14890) ([aa96572](https://github.com/bitnami/charts/commit/aa9657237ee8df4a46db0d7fdf8a23230dd6902a)), closes [#14890](https://github.com/bitnami/charts/issues/14890)
* [bitnami/pinniped] Release 1.0.6 (#15004) ([585423f](https://github.com/bitnami/charts/commit/585423f596349918162d31f9acbda57a75013ff2)), closes [#15004](https://github.com/bitnami/charts/issues/15004)

## <small>1.0.5 (2023-01-31)</small>

* [bitnami/pinniped] Don't regenerate self-signed certs on upgrade (#14650) ([d6a16bd](https://github.com/bitnami/charts/commit/d6a16bde0459dc5138aaa612cd1c7ec113b8f4d7)), closes [#14650](https://github.com/bitnami/charts/issues/14650)

## <small>1.0.4 (2023-01-27)</small>

* [bitnami/pinniped] update pinniped supervisor CRDs for v0.22.0 (#14567) ([5fa9c02](https://github.com/bitnami/charts/commit/5fa9c025be79c543b25bbc12befd2da2d9ff665b)), closes [#14567](https://github.com/bitnami/charts/issues/14567)

## <small>1.0.3 (2023-01-24)</small>

* [bitnami/*] Unify READMEs (#14472) ([2064fb8](https://github.com/bitnami/charts/commit/2064fb8dcc78a845cdede8211af8c3cc52551161)), closes [#14472](https://github.com/bitnami/charts/issues/14472)
* [bitnami/pinniped] Impersonation proxy fix (#14278) ([30f2069](https://github.com/bitnami/charts/commit/30f2069e0b8ce5331987d06dc744b6d1bc1f04ec)), closes [#14278](https://github.com/bitnami/charts/issues/14278)

## <small>1.0.2 (2023-01-20)</small>

* [bitnami/*] Add license annotation and remove obsolete engine parameter (#14293) ([da2a794](https://github.com/bitnami/charts/commit/da2a7943bae95b6e9b5b4ed972c15e990b69fdb0)), closes [#14293](https://github.com/bitnami/charts/issues/14293)
* [bitnami/*] Change licenses annotation format (#14377) ([0ab7608](https://github.com/bitnami/charts/commit/0ab760862c660fcc78cffadf8e1d8cdd70881473)), closes [#14377](https://github.com/bitnami/charts/issues/14377)
* [bitnami/pinniped] Release 1.0.2 (#14462) ([21dbd37](https://github.com/bitnami/charts/commit/21dbd37cbcb4da5c4cbf0d1214a2e8fe5688113a)), closes [#14462](https://github.com/bitnami/charts/issues/14462)

## <small>1.0.1 (2023-01-11)</small>

* [bitnami/pinniped] Bump version chart to force new publish (#14289) ([906f25d](https://github.com/bitnami/charts/commit/906f25dbeb058b76e225f82ec23c64575dea57a5)), closes [#14289](https://github.com/bitnami/charts/issues/14289)

## 1.0.0 (2023-01-11)

* [bitnami/pinniped] Separate service configuration for supervisor api and aggregator server (#13876) ([4db2a46](https://github.com/bitnami/charts/commit/4db2a46e74ae32edaaf5cc3567455001ea0151ab)), closes [#13876](https://github.com/bitnami/charts/issues/13876)

## <small>0.4.7 (2022-12-21)</small>

* [bitnami/pinniped] Release 0.4.7 (#14062) ([c38ba07](https://github.com/bitnami/charts/commit/c38ba0709f59cfaec6a09e7283abd8865aab8783)), closes [#14062](https://github.com/bitnami/charts/issues/14062)

## <small>0.4.6 (2022-12-03)</small>

* [bitnami/pinniped] Release 0.4.6 (#13823) ([138d70f](https://github.com/bitnami/charts/commit/138d70f5668a1377cc02704282055f59490735ed)), closes [#13823](https://github.com/bitnami/charts/issues/13823)

## <small>0.4.5 (2022-11-23)</small>

* [bitnami/pinniped] fix apiversion hardcode ClusterRoleBinding (#13628) ([05840f1](https://github.com/bitnami/charts/commit/05840f12d07eb8edbd50ed708f600599aa905f61)), closes [#13628](https://github.com/bitnami/charts/issues/13628)

## <small>0.4.4 (2022-11-03)</small>

* [bitnami/pinniped] Release 0.4.4 (#13332) ([98e58cc](https://github.com/bitnami/charts/commit/98e58ccab59867d1746687553d79e68a9a670b94)), closes [#13332](https://github.com/bitnami/charts/issues/13332)

## <small>0.4.3 (2022-10-28)</small>

* [bitnami/pinniped] Fix serviceaccount and apiserver object name (#13224) ([7d5498c](https://github.com/bitnami/charts/commit/7d5498c14b3ac2e3b12e88fd062f26c74d88062a)), closes [#13224](https://github.com/bitnami/charts/issues/13224)

## <small>0.4.2 (2022-10-17)</small>

* [bitnami/*] Use new default branch name in links (#12943) ([a529e02](https://github.com/bitnami/charts/commit/a529e02597d49d944eba1eb0f190713293247176)), closes [#12943](https://github.com/bitnami/charts/issues/12943)
* [bitnami/pinniped] create svc for listener serving aggregated api service (#12951) ([f6ee6ae](https://github.com/bitnami/charts/commit/f6ee6aea326d4869ec5f6e8f240f6c0f4578d872)), closes [#12951](https://github.com/bitnami/charts/issues/12951)

## <small>0.4.1 (2022-10-13)</small>

* bitnami/pinniped fix pinniped-supervisor CRD labels (#12911) ([4ed62ad](https://github.com/bitnami/charts/commit/4ed62adcc07d62ce5644fba7ae4c4893774b08b0)), closes [#12911](https://github.com/bitnami/charts/issues/12911)

## 0.4.0 (2022-10-11)

* bitnami/pinniped release 0.3.3 (#12894) ([f99d5e4](https://github.com/bitnami/charts/commit/f99d5e4544a3f85ce85e19978c69a44688c8d158)), closes [#12894](https://github.com/bitnami/charts/issues/12894)
* Generic README instructions related to the repo (#12792) ([3cf6b10](https://github.com/bitnami/charts/commit/3cf6b10e10e60df4b3e191d6b99aa99a9f597755)), closes [#12792](https://github.com/bitnami/charts/issues/12792)

## <small>0.3.2 (2022-09-23)</small>

* [bitnami/pinniped] Use custom probes if given (#12547) ([fea3250](https://github.com/bitnami/charts/commit/fea3250f6a50833205c63cadabdabfbc29d82a21)), closes [#12547](https://github.com/bitnami/charts/issues/12547) [#12354](https://github.com/bitnami/charts/issues/12354)

## <small>0.3.1 (2022-09-14)</small>

* [bitnami/pinniped] Fix ingerss supervisor (#11850) ([ddba459](https://github.com/bitnami/charts/commit/ddba45929427de6466e8f1da807d97b5cfdce346)), closes [#11850](https://github.com/bitnami/charts/issues/11850)

## 0.3.0 (2022-09-02)

* [bitnami/pinniped] add support for hostNetwork (#11247) ([3658a88](https://github.com/bitnami/charts/commit/3658a88553960692275069494f42f55834137c44)), closes [#11247](https://github.com/bitnami/charts/issues/11247)

## <small>0.2.2 (2022-08-29)</small>

* [bitnami/pinniped] Release 0.2.2 (#12191) ([2fe82e7](https://github.com/bitnami/charts/commit/2fe82e75825445acf17e24e8f571a61e05124820)), closes [#12191](https://github.com/bitnami/charts/issues/12191)

## <small>0.2.1 (2022-08-23)</small>

* [bitnami/pinniped] Update Chart.lock (#12075) ([aa15884](https://github.com/bitnami/charts/commit/aa15884faf3a1f5e10d06fe59895a364825ad694)), closes [#12075](https://github.com/bitnami/charts/issues/12075)

## 0.2.0 (2022-08-22)

* [bitnami/pinniped] Add support for image digest apart from tag (#11944) ([1784352](https://github.com/bitnami/charts/commit/17843521a921a126f06a8934264f3c5c552a824a)), closes [#11944](https://github.com/bitnami/charts/issues/11944)

## <small>0.1.8 (2022-08-18)</small>

* [bitnami/pinniped] Release 0.1.8 (#11646) ([3e57843](https://github.com/bitnami/charts/commit/3e57843218873458b14442a6a6bbf544cbcb9f9d)), closes [#11646](https://github.com/bitnami/charts/issues/11646)

## <small>0.1.7 (2022-08-04)</small>

* [bitnami/pinniped] Release 0.1.7 (#11568) ([42ed7cb](https://github.com/bitnami/charts/commit/42ed7cb9ec7eb60e5db3ae3e00b14c076bebe126)), closes [#11568](https://github.com/bitnami/charts/issues/11568)

## <small>0.1.6 (2022-07-30)</small>

* [bitnami/*] Update URLs to point to the new bitnami/containers monorepo (#11352) ([d665af0](https://github.com/bitnami/charts/commit/d665af0c708846192d8d5fb2f5f9ea65dd464ab0)), closes [#11352](https://github.com/bitnami/charts/issues/11352)
* [bitnami/pinniped] Release 0.1.6 (#11428) ([2f750f5](https://github.com/bitnami/charts/commit/2f750f52dc36638015d5049b71e5d91d9723f0db)), closes [#11428](https://github.com/bitnami/charts/issues/11428)

## <small>0.1.5 (2022-06-30)</small>

* [bitnami/pinniped] Release 0.1.5 (#10932) ([2b63fae](https://github.com/bitnami/charts/commit/2b63fae53d37779e9a5c8d465654ba9b7acc9106)), closes [#10932](https://github.com/bitnami/charts/issues/10932)

## <small>0.1.4 (2022-06-21)</small>

* [bitnami/pinniped] Change maintainers (#10838) ([c3f9e2a](https://github.com/bitnami/charts/commit/c3f9e2aa2cc90b7695fdb4c48c4155ebbd168d0b)), closes [#10838](https://github.com/bitnami/charts/issues/10838)

## <small>0.1.3 (2022-06-14)</small>

* [bitnami/pinniped] Release 0.1.3 (#10766) ([68cf2d6](https://github.com/bitnami/charts/commit/68cf2d613c7012b72eb18aab0f7132d37bec41aa)), closes [#10766](https://github.com/bitnami/charts/issues/10766)

## <small>0.1.2 (2022-06-14)</small>

* [bitnami/pinniped] fix: :bug: Use proper type for sidecars and init containers (#10755) ([d8d380f](https://github.com/bitnami/charts/commit/d8d380fea9cdac4d5b19d27b61dbf115148591da)), closes [#10755](https://github.com/bitnami/charts/issues/10755)

## <small>0.1.1 (2022-06-14)</small>

* [bitnami/pinniped] fix: :bug: Allow long release names (#10740) ([2ccba77](https://github.com/bitnami/charts/commit/2ccba77b08bed7ba0bf7436606cb9652f061e0e2)), closes [#10740](https://github.com/bitnami/charts/issues/10740)

## 0.1.0 (2022-06-14)

* [bitnami/pinniped] feat: :tada: Add chart (#10569) ([cd7ccca](https://github.com/bitnami/charts/commit/cd7cccabbae6bf3899116489078204ab13e92cc4)), closes [#10569](https://github.com/bitnami/charts/issues/10569)
