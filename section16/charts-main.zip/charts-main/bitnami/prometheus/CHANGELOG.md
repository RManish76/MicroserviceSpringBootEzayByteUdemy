# Changelog

## 2.2.1 (2025-12-27)

* [bitnami/prometheus] send alert to all alertmanagers ([#36421](https://github.com/bitnami/charts/pull/36421))

## <small>2.1.23 (2025-08-14)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#35906) ([d46a611](https://github.com/bitnami/charts/commit/d46a611f405d19df65a0007ba287d7fa12d27d2a)), closes [#35906](https://github.com/bitnami/charts/issues/35906)

## <small>2.1.22 (2025-08-14)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#35869) ([f9af14d](https://github.com/bitnami/charts/commit/f9af14de5dbc262093d0a5786c697c036062093c)), closes [#35869](https://github.com/bitnami/charts/issues/35869)

## <small>2.1.21 (2025-08-13)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#35835) ([eab8b44](https://github.com/bitnami/charts/commit/eab8b44ed08baa24662a9b3a26133d327121da3f)), closes [#35835](https://github.com/bitnami/charts/issues/35835)

## <small>2.1.20 (2025-08-07)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#35633) ([eb68c8c](https://github.com/bitnami/charts/commit/eb68c8ccbb324862f01c03917d6f93f7d35a1b76)), closes [#35633](https://github.com/bitnami/charts/issues/35633)

## <small>2.1.19 (2025-08-07)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#35532) ([b2fb8cb](https://github.com/bitnami/charts/commit/b2fb8cba31b746367b04136a53f9ceb851b71dfb)), closes [#35532](https://github.com/bitnami/charts/issues/35532)

## <small>2.1.18 (2025-08-07)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#35520) ([0773251](https://github.com/bitnami/charts/commit/077325143ffb259822daa4b51adb7e308b122c44)), closes [#35520](https://github.com/bitnami/charts/issues/35520)

## <small>2.1.17 (2025-08-06)</small>

* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#35444) ([00f989e](https://github.com/bitnami/charts/commit/00f989e7915fe5a7b68b76f3f90db320239c11b9)), closes [#35444](https://github.com/bitnami/charts/issues/35444)

## <small>2.1.16 (2025-07-21)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#35225) ([c4472d2](https://github.com/bitnami/charts/commit/c4472d23e7bd22fb9d7b5655c0a7979784357668)), closes [#35225](https://github.com/bitnami/charts/issues/35225)

## <small>2.1.15 (2025-07-15)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#35123) ([f53082e](https://github.com/bitnami/charts/commit/f53082e070ad97c174956a49e73fb160c5ab6a2c)), closes [#35123](https://github.com/bitnami/charts/issues/35123)

## <small>2.1.14 (2025-07-14)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#35049) ([12bc5d3](https://github.com/bitnami/charts/commit/12bc5d360ce975ec1d30e15344ed2cf97638c338)), closes [#35049](https://github.com/bitnami/charts/issues/35049)

## <small>2.1.13 (2025-07-09)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#34955) ([ce463b5](https://github.com/bitnami/charts/commit/ce463b5f0546f91efa6c1907f353ea4c26c17969)), closes [#34955](https://github.com/bitnami/charts/issues/34955)

## <small>2.1.12 (2025-07-09)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#34945) ([1b70d72](https://github.com/bitnami/charts/commit/1b70d72d9342e5e22cbc4e8b15545776b12308ad)), closes [#34945](https://github.com/bitnami/charts/issues/34945)

## <small>2.1.11 (2025-07-08)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#34869) ([e8734f8](https://github.com/bitnami/charts/commit/e8734f8a1012be1acda640c2b4193b8322754cd1)), closes [#34869](https://github.com/bitnami/charts/issues/34869)

## <small>2.1.10 (2025-07-01)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#34745) ([14c9cd3](https://github.com/bitnami/charts/commit/14c9cd3e0f11dcf646a056cad0bb10d304d00567)), closes [#34745](https://github.com/bitnami/charts/issues/34745)

## <small>2.1.9 (2025-06-26)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#34683) ([d1b7145](https://github.com/bitnami/charts/commit/d1b71453707480b933119aecb3654e15c447ead2)), closes [#34683](https://github.com/bitnami/charts/issues/34683)

## <small>2.1.8 (2025-06-25)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#34623) ([12f7083](https://github.com/bitnami/charts/commit/12f7083f6d519941e297a2e1017190019eb52396)), closes [#34623](https://github.com/bitnami/charts/issues/34623)

## <small>2.1.7 (2025-06-13)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#34495) ([53841b0](https://github.com/bitnami/charts/commit/53841b064ad6043099c4f896ac836f2409957db7)), closes [#34495](https://github.com/bitnami/charts/issues/34495)

## <small>2.1.6 (2025-06-13)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#34489) ([6f037ee](https://github.com/bitnami/charts/commit/6f037ee360e32101925bc748665b6f3b73565a27)), closes [#34489](https://github.com/bitnami/charts/issues/34489)

## <small>2.1.5 (2025-06-13)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#34387) ([01ea69e](https://github.com/bitnami/charts/commit/01ea69e530d0b62882f9930a8d793ee697574b45)), closes [#34387](https://github.com/bitnami/charts/issues/34387)

## <small>2.1.4 (2025-06-06)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#34224) ([93011ec](https://github.com/bitnami/charts/commit/93011ec3f0680aed3d8e25098813b4657d7ffa18)), closes [#34224](https://github.com/bitnami/charts/issues/34224)

## <small>2.1.3 (2025-06-05)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#34130) ([8892f2b](https://github.com/bitnami/charts/commit/8892f2b12a367fb0a2cefbc77c27cdeaa03e44f1)), closes [#34130](https://github.com/bitnami/charts/issues/34130)

## <small>2.1.2 (2025-05-31)</small>

* [bitname/prometheus] add cluster port to networkpolicy (#33927) ([a4627ad](https://github.com/bitnami/charts/commit/a4627adf9d50c517c6131a4d3ee1a27c09ac5e46)), closes [#33927](https://github.com/bitnami/charts/issues/33927)
* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#34020) ([0887dda](https://github.com/bitnami/charts/commit/0887dda9df2638e76af0689d13e728ffa9025d78)), closes [#34020](https://github.com/bitnami/charts/issues/34020)
* [bitnami/prometheus] Allowing to disable the scraping of prometheus and alertmanager hosts with new  ([bae4289](https://github.com/bitnami/charts/commit/bae4289bdb77c4acf14224f8c2818648bc28c6f5)), closes [#33777](https://github.com/bitnami/charts/issues/33777)

## <small>2.0.8 (2025-05-19)</small>

* [bitnami/prometheus] Added variable whether to include the default cluster role rules in rbac (#3372 ([cd9a26e](https://github.com/bitnami/charts/commit/cd9a26e5119370b678e18aa05582bc46dc22850f)), closes [#33722](https://github.com/bitnami/charts/issues/33722)

## <small>2.0.7 (2025-05-17)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#33764) ([df99230](https://github.com/bitnami/charts/commit/df992300dad78b876d90f9dd597796ea80b2c2d7)), closes [#33764](https://github.com/bitnami/charts/issues/33764)

## <small>2.0.6 (2025-05-12)</small>

* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)
* [bitnami/prometheus] Allow tpl for ingress hostnames and allow ingress annotations to be both map ob ([ed61248](https://github.com/bitnami/charts/commit/ed61248fa488374a95716a98775ba4de813bb215)), closes [#33525](https://github.com/bitnami/charts/issues/33525)

## <small>2.0.5 (2025-05-08)</small>

* [bitnami/prometheus] :zap: :arrow_up: Update dependency references (#33570) ([4e3ea1e](https://github.com/bitnami/charts/commit/4e3ea1ed5d632e3b82904d6a77f672fd50139831)), closes [#33570](https://github.com/bitnami/charts/issues/33570)

## <small>2.0.4 (2025-05-07)</small>

* [bitnami/prometheus] Release 2.0.4 (#33515) ([39c09bf](https://github.com/bitnami/charts/commit/39c09bf5150bef220d06b059195e16d1b40c65df)), closes [#33515](https://github.com/bitnami/charts/issues/33515)

## <small>2.0.3 (2025-05-06)</small>

* [bitnami/prometheus] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references (#33 ([7d7df6c](https://github.com/bitnami/charts/commit/7d7df6ceef66dcef17177b54154c7bad85e3adb7)), closes [#33424](https://github.com/bitnami/charts/issues/33424)

## <small>2.0.2 (2025-05-02)</small>

* [bitnami/prometheus] Release 2.0.0 (#33240) ([123eb4e](https://github.com/bitnami/charts/commit/123eb4e36bb3852dc166ebfa53738cf0be581058)), closes [#33240](https://github.com/bitnami/charts/issues/33240)
* [bitnami/prometheus] Release 2.0.1 (#33311) ([4e0c474](https://github.com/bitnami/charts/commit/4e0c474059d9f1ee163f9e315df0874978c9768e)), closes [#33311](https://github.com/bitnami/charts/issues/33311)
* [bitnami/prometheus] Release 2.0.2 (#33312) ([a62fc07](https://github.com/bitnami/charts/commit/a62fc075b2e7428c8624cf2725180deeef12099a)), closes [#33312](https://github.com/bitnami/charts/issues/33312)

## <small>1.4.10 (2025-04-02)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/prometheus] Release 1.4.10 (#32760) ([7e61b38](https://github.com/bitnami/charts/commit/7e61b38f61e3fa35e6b86b7319e9c1c4c7bba88e)), closes [#32760](https://github.com/bitnami/charts/issues/32760)

## <small>1.4.9 (2025-03-10)</small>

* [bitnami/prometheus] Fix RBAC for Prometheus endpointslices role (#31924) ([79b584d](https://github.com/bitnami/charts/commit/79b584d0f2447fafce69fb2643e54732156d91cb)), closes [#31924](https://github.com/bitnami/charts/issues/31924)

## <small>1.4.8 (2025-03-05)</small>

* [bitnami/prometheus] Release 1.4.8 (#32314) ([13fdecf](https://github.com/bitnami/charts/commit/13fdecf57b33168f4d07b5e6185b40c23931ea3e)), closes [#32314](https://github.com/bitnami/charts/issues/32314)

## <small>1.4.7 (2025-02-20)</small>

* [bitnami/prometheus] Release 1.4.7 (#32031) ([03acf9e](https://github.com/bitnami/charts/commit/03acf9e455bbd0acd679fa0714e3727a68a79245)), closes [#32031](https://github.com/bitnami/charts/issues/32031)

## <small>1.4.6 (2025-02-12)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/prometheus] Release 1.4.6 (#31900) ([89f7e53](https://github.com/bitnami/charts/commit/89f7e53a19af293a4ce2fcd1261abcb5c0803feb)), closes [#31900](https://github.com/bitnami/charts/issues/31900)

## <small>1.4.5 (2025-02-05)</small>

* [bitnami/prometheus] Release 1.4.5 (#31776) ([8d72f34](https://github.com/bitnami/charts/commit/8d72f34addc80047ac7fdf2dc5035b74f8f1d51d)), closes [#31776](https://github.com/bitnami/charts/issues/31776)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## <small>1.4.4 (2025-01-24)</small>

* [bitnami/prometheus] Release 1.4.4 (#31580) ([67f0ae3](https://github.com/bitnami/charts/commit/67f0ae3dc65683ccd661c84a66177d0839cc65b0)), closes [#31580](https://github.com/bitnami/charts/issues/31580)

## <small>1.4.3 (2025-01-22)</small>

* [bitnami/prometheus] Remove GOSS duplicated command (#31513) ([433437c](https://github.com/bitnami/charts/commit/433437cf7c5dca688668de467173382963febe1c)), closes [#31513](https://github.com/bitnami/charts/issues/31513)

## <small>1.4.2 (2025-01-17)</small>

* [bitnami/prometheus] Release 1.4.2 (#31446) ([8d5a3a8](https://github.com/bitnami/charts/commit/8d5a3a81abd654712bdddeec3f7263890dabe9b8)), closes [#31446](https://github.com/bitnami/charts/issues/31446)

## <small>1.4.1 (2025-01-13)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/prometheus] Release 1.4.1 (#31324) ([074a131](https://github.com/bitnami/charts/commit/074a1318cbcb9063e83927d585e12475431cc93c)), closes [#31324](https://github.com/bitnami/charts/issues/31324)

## 1.4.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/prometheus] Detect non-standard images (#30938) ([492b79e](https://github.com/bitnami/charts/commit/492b79e3b1e75d12d57d7d4881faf01c682a4ec8)), closes [#30938](https://github.com/bitnami/charts/issues/30938)

## <small>1.3.29 (2024-12-04)</small>

* [bitnami/*] docs: :memo: Add "Backup & Restore" section (#30711) ([35ab536](https://github.com/bitnami/charts/commit/35ab5363741e7548f4076f04da6e62d10153c60c)), closes [#30711](https://github.com/bitnami/charts/issues/30711)
* [bitnami/prometheus] Release 1.3.29 (#30774) ([f1b557c](https://github.com/bitnami/charts/commit/f1b557c5e48a6a6195353d2827922638f91cd250)), closes [#30774](https://github.com/bitnami/charts/issues/30774)

## <small>1.3.28 (2024-11-19)</small>

* [bitnami/prometheus] Release 1.3.28 (#30518) ([8a90ea8](https://github.com/bitnami/charts/commit/8a90ea87706d89c78bcaa0bb08ca6a0d96512b5c)), closes [#30518](https://github.com/bitnami/charts/issues/30518)

## <small>1.3.27 (2024-11-08)</small>

* [bitnami/prometheus] Unify seLinuxOptions default value (#30330) ([09074d0](https://github.com/bitnami/charts/commit/09074d09e43535326e7c71d2d4c461d620bce784)), closes [#30330](https://github.com/bitnami/charts/issues/30330)

## <small>1.3.26 (2024-11-07)</small>

* [bitnami/mastodon][bitnami/prometheus] Fix README.md files typos (#30194) ([0ef19fb](https://github.com/bitnami/charts/commit/0ef19fb4ac61547d519c9cc029f39b7026ab70e2)), closes [#30194](https://github.com/bitnami/charts/issues/30194)
* [bitnami/prometheus] Release 1.3.26 (#30289) ([ab4ecb0](https://github.com/bitnami/charts/commit/ab4ecb03466c1be4498052b9b7a3fbb1e743e36d)), closes [#30289](https://github.com/bitnami/charts/issues/30289)

## <small>1.3.25 (2024-11-06)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/prometheus] Release 1.3.25 (#30239) ([0409456](https://github.com/bitnami/charts/commit/0409456f78ef40e4a4b60114db902a31244b3157)), closes [#30239](https://github.com/bitnami/charts/issues/30239)

## <small>1.3.24 (2024-10-22)</small>

* [bitnami/prometheus] Release 1.3.24 (#30045) ([a08faca](https://github.com/bitnami/charts/commit/a08facaa0f3050b722e4c8160c5e667eb28b5f7d)), closes [#30045](https://github.com/bitnami/charts/issues/30045)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## <small>1.3.23 (2024-10-02)</small>

* [bitnami/prometheus] Release 1.3.23 (#29716) ([b7bd1ad](https://github.com/bitnami/charts/commit/b7bd1ad379e8735003f5d180fc0c79bf773f9ea6)), closes [#29716](https://github.com/bitnami/charts/issues/29716)

## <small>1.3.22 (2024-09-11)</small>

* [bitnami/prometheus] Allow rendering resources values (#29342) ([c1d1852](https://github.com/bitnami/charts/commit/c1d185295aeaf8880d2b16c654026e78fefb4cf7)), closes [#29342](https://github.com/bitnami/charts/issues/29342)

## <small>1.3.21 (2024-09-09)</small>

* [bitnami/prometheus] fix: add apiVersion and kind to volumeClaimTemplates (#29290) ([af223db](https://github.com/bitnami/charts/commit/af223dbfd5a3a0294f1df6730048222390e3b7c7)), closes [#29290](https://github.com/bitnami/charts/issues/29290)

## <small>1.3.20 (2024-09-06)</small>

* [bitnami/prometheus] Release 1.3.20 (#29263) ([c09f49a](https://github.com/bitnami/charts/commit/c09f49a1761a29b200314f28cea1cbbfd70ebee1)), closes [#29263](https://github.com/bitnami/charts/issues/29263)

## <small>1.3.19 (2024-08-27)</small>

* [bitnami/prometheus] Release 1.3.19 (#29062) ([9a60dba](https://github.com/bitnami/charts/commit/9a60dbae90aa9e2d6914cab10505dd0471d100dc)), closes [#29062](https://github.com/bitnami/charts/issues/29062)

## <small>1.3.18 (2024-08-27)</small>

* [bitnami/prometheus] Release 1.3.18 (#29043) ([6ec28b5](https://github.com/bitnami/charts/commit/6ec28b530b6ef3809cd3ed23fff9b24261f9ee95)), closes [#29043](https://github.com/bitnami/charts/issues/29043)

## <small>1.3.17 (2024-08-09)</small>

* [bitnami/prometheus] Release 1.3.17 (#28815) ([4354020](https://github.com/bitnami/charts/commit/435402018ffa89024902fdc5501c1e26158f6780)), closes [#28815](https://github.com/bitnami/charts/issues/28815)

## <small>1.3.16 (2024-08-08)</small>

* bitnami/prometheus- Disable server configmap when existingConfigMap is provided (#28532) ([5092ebd](https://github.com/bitnami/charts/commit/5092ebdc3a61fe9abdb6fe7ae7fff473a9d0fd8a)), closes [#28532](https://github.com/bitnami/charts/issues/28532)

## <small>1.3.15 (2024-08-07)</small>

* [bitnami/prometheus] Release 1.3.15 (#28758) ([31f9583](https://github.com/bitnami/charts/commit/31f958309d2b0dab404b43dce079c4bad7f72b5f)), closes [#28758](https://github.com/bitnami/charts/issues/28758)

## <small>1.3.14 (2024-07-25)</small>

* [bitnami/prometheus] Release 1.3.14 (#28513) ([b065f40](https://github.com/bitnami/charts/commit/b065f4025f5d296f673d9bdb4da9bc5efe6a9e41)), closes [#28513](https://github.com/bitnami/charts/issues/28513)

## <small>1.3.13 (2024-07-24)</small>

* [bitnami/prometheus] Release 1.3.13 (#28353) ([553547c](https://github.com/bitnami/charts/commit/553547cd6c62a7b03807a7cd835ce024398dc9ad)), closes [#28353](https://github.com/bitnami/charts/issues/28353)

## <small>1.3.12 (2024-07-18)</small>

* [bitnami/prometheus] Global StorageClass as default value (#28085) ([39e4b8a](https://github.com/bitnami/charts/commit/39e4b8a0c2dc8c44db7b2330c825dfea7b595bce)), closes [#28085](https://github.com/bitnami/charts/issues/28085)

## <small>1.3.11 (2024-07-10)</small>

* [bitnami/prometheus] Release 1.3.11 (#27880) ([2472a61](https://github.com/bitnami/charts/commit/2472a61fe95344bf2c7545d4d28c629c5bb468e2)), closes [#27880](https://github.com/bitnami/charts/issues/27880)

## <small>1.3.10 (2024-07-04)</small>

* [bitnami/prometheus] Release 1.3.10 (#27780) ([efffcf0](https://github.com/bitnami/charts/commit/efffcf0dd6596305ee8fd22b7bda470a6d50c7b9)), closes [#27780](https://github.com/bitnami/charts/issues/27780)

## <small>1.3.9 (2024-07-03)</small>

* [bitnami/*] Update README changing TAC wording (#27530) ([52dfed6](https://github.com/bitnami/charts/commit/52dfed6bac44d791efabfaf06f15daddc4fefb0c)), closes [#27530](https://github.com/bitnami/charts/issues/27530)
* [bitnami/prometheus] Release 1.3.9 (#27675) ([c8053a0](https://github.com/bitnami/charts/commit/c8053a0af773e1ce64c875500cd4d2269b5f6eee)), closes [#27675](https://github.com/bitnami/charts/issues/27675)

## <small>1.3.8 (2024-06-19)</small>

* [bitnami/prometheus] Release 1.3.8 (#27445) ([71dae51](https://github.com/bitnami/charts/commit/71dae51ed04ea9ae723929f886ace043c7d54a66)), closes [#27445](https://github.com/bitnami/charts/issues/27445)

## <small>1.3.7 (2024-06-18)</small>

* [bitnami/prometheus] Release 1.3.7 (#27406) ([483a9f9](https://github.com/bitnami/charts/commit/483a9f96f311b9984b5d2aee5d341b7922c2d1d2)), closes [#27406](https://github.com/bitnami/charts/issues/27406)

## <small>1.3.6 (2024-06-17)</small>

* [bitnami/prometheus] Release 1.3.6 (#27272) ([8b24bdb](https://github.com/bitnami/charts/commit/8b24bdb4093444d9cdd01592e25582eb46e6b15c)), closes [#27272](https://github.com/bitnami/charts/issues/27272)

## <small>1.3.5 (2024-06-06)</small>

* [bitnami/prometheus] Release 1.3.5 (#27009) ([0003767](https://github.com/bitnami/charts/commit/0003767ecfaf276289fbd147cd98c99602b08a09)), closes [#27009](https://github.com/bitnami/charts/issues/27009)

## <small>1.3.4 (2024-06-05)</small>

* [bitnami/prometheus] Release 1.3.4 (#26750) ([96ee635](https://github.com/bitnami/charts/commit/96ee635008de6c1072fe58f0fbcbfa6f6cca9de2)), closes [#26750](https://github.com/bitnami/charts/issues/26750)

## <small>1.3.3 (2024-06-04)</small>

* [bitnami/prometheus] Bump chart version (#26662) ([85af9c8](https://github.com/bitnami/charts/commit/85af9c8e645767977d8e2c8f639ecd4812119b93)), closes [#26662](https://github.com/bitnami/charts/issues/26662)

## <small>1.3.2 (2024-05-30)</small>

* [bitnami/prometheus] Release 1.3.2 (#26569) ([aea5efe](https://github.com/bitnami/charts/commit/aea5efe2a561a277fd335f94fbe59ab6b65cdca5)), closes [#26569](https://github.com/bitnami/charts/issues/26569)

## <small>1.3.1 (2024-05-28)</small>

* [bitnami/prometheus] Add chart source URL to sources list (#26487) ([ee8dc41](https://github.com/bitnami/charts/commit/ee8dc416fdbf7562a1992835629b5d6583c0e59d)), closes [#26487](https://github.com/bitnami/charts/issues/26487)

## 1.3.0 (2024-05-24)

* [bitnami/prometheus] Enable PodDisruptionBudgets (#26215) ([bca3d85](https://github.com/bitnami/charts/commit/bca3d855e95823d10028ff27a3cd6f65b4204dff)), closes [#26215](https://github.com/bitnami/charts/issues/26215)

## 1.2.0 (2024-05-22)

* [bitnami/prometheus] Network policy review (#25902) ([e37834c](https://github.com/bitnami/charts/commit/e37834c831892cc130160cedbf4826a892b31292)), closes [#25902](https://github.com/bitnami/charts/issues/25902) [#25519](https://github.com/bitnami/charts/issues/25519)

## 1.1.0 (2024-05-21)

* [bitnami/*] ci: :construction_worker: Add tag and changelog support (#25359) ([91c707c](https://github.com/bitnami/charts/commit/91c707c9e4e574725a09505d2d313fb93f1b4c0a)), closes [#25359](https://github.com/bitnami/charts/issues/25359)
* [bitnami/prometheus] feat: :sparkles: :lock: Add warning when original images are replaced (#26267) ([5ec42f2](https://github.com/bitnami/charts/commit/5ec42f21186c9cbb621f2695cd099dce5655c355)), closes [#26267](https://github.com/bitnami/charts/issues/26267)

## <small>1.0.13 (2024-05-18)</small>

* [bitnami/prometheus] Release 1.0.13 updating components versions (#26068) ([0aa454e](https://github.com/bitnami/charts/commit/0aa454e540016207873577ac80b6756c68e2e8db)), closes [#26068](https://github.com/bitnami/charts/issues/26068)

## <small>1.0.12 (2024-05-15)</small>

* Updated prometheus server local cluster address, as it pointed to the wrong service name. (#25878) ([befcc55](https://github.com/bitnami/charts/commit/befcc554f14916d289fb07f029603678c8d5f0a4)), closes [#25878](https://github.com/bitnami/charts/issues/25878)

## <small>1.0.11 (2024-05-14)</small>

* [bitnami/prometheus] Release 1.0.11 updating components versions (#25815) ([3168e7f](https://github.com/bitnami/charts/commit/3168e7f258c912b013f2392aa9a136d02b7a79b2)), closes [#25815](https://github.com/bitnami/charts/issues/25815)

## <small>1.0.10 (2024-05-13)</small>

* [bitnami/prometheus] Release 1.0.10 updating components versions (#25724) ([56d1e1d](https://github.com/bitnami/charts/commit/56d1e1d185220b5d6ac377237e956e376678983e)), closes [#25724](https://github.com/bitnami/charts/issues/25724)

## <small>1.0.9 (2024-05-09)</small>

* [bitnami/*] Change non-root and rolling-tags doc URLs (#25628) ([b067c94](https://github.com/bitnami/charts/commit/b067c94f6bcde427863c197fd355f0b5ba12ff5b)), closes [#25628](https://github.com/bitnami/charts/issues/25628)
* [bitnami/prometheus] Release 1.0.9 updating components versions (#25657) ([06373e1](https://github.com/bitnami/charts/commit/06373e1c0862f57ef72cb731ba319443f0efb303)), closes [#25657](https://github.com/bitnami/charts/issues/25657)

## <small>1.0.8 (2024-05-08)</small>

* [bitnami/prometheus] Release 1.0.8 updating components versions (#25620) ([1e328b8](https://github.com/bitnami/charts/commit/1e328b878ca69dccd83f7847649f362a0754df4f)), closes [#25620](https://github.com/bitnami/charts/issues/25620)

## <small>1.0.7 (2024-05-06)</small>

* [bitnami/multiple charts] Fix typo: "NetworkPolice" vs "NetworkPolicy" (#25348) ([6970c1b](https://github.com/bitnami/charts/commit/6970c1ba245873506e73d459c6eac1e4919b778f)), closes [#25348](https://github.com/bitnami/charts/issues/25348)
* [bitnami/prometheus] Remove unicode characters (#25547) ([1416bae](https://github.com/bitnami/charts/commit/1416bae35192d343427a2eacf1fca6b46010baca)), closes [#25547](https://github.com/bitnami/charts/issues/25547)
* Replace VMware by Broadcom copyright text (#25306) ([a5e4bd0](https://github.com/bitnami/charts/commit/a5e4bd0e35e419203793976a78d9d0a13de92c76)), closes [#25306](https://github.com/bitnami/charts/issues/25306)

## <small>1.0.6 (2024-04-10)</small>

* [bitnami/prometheus] Release 1.0.6 updating components versions (#25115) ([0731062](https://github.com/bitnami/charts/commit/0731062fc16bfd2e1fd3871f6528b3d5b2be3e31)), closes [#25115](https://github.com/bitnami/charts/issues/25115)

## <small>1.0.5 (2024-04-09)</small>

* [bitnami/prometheus] Don't create NetworkPolicy for AlertManager if AlertManager is disabled (#25037 ([6b4d966](https://github.com/bitnami/charts/commit/6b4d966680ba706e52c34157eac141ca715e656d)), closes [#25037](https://github.com/bitnami/charts/issues/25037)

## <small>1.0.4 (2024-04-05)</small>

* [bitnami/prometheus] Release 1.0.4 updating components versions (#24976) ([181fc2d](https://github.com/bitnami/charts/commit/181fc2d42f34499fbf90ddb17f8a3636f56533d6)), closes [#24976](https://github.com/bitnami/charts/issues/24976)

## <small>1.0.3 (2024-04-04)</small>

* [bitnami/*] Readme typos (#24852) ([532fcdc](https://github.com/bitnami/charts/commit/532fcdc499cb67eccf0ade49ff1c02d3deb1d696)), closes [#24852](https://github.com/bitnami/charts/issues/24852)
* [bitnami/prometheus] Release 1.0.3 updating components versions (#24914) ([e868871](https://github.com/bitnami/charts/commit/e8688711457fd7b9fe6b60918ab00be1d7508a19)), closes [#24914](https://github.com/bitnami/charts/issues/24914)
* Update resourcesPreset comments (#24467) ([92e3e8a](https://github.com/bitnami/charts/commit/92e3e8a507326d2a20a8f10ab3e7746a2ec5c554)), closes [#24467](https://github.com/bitnami/charts/issues/24467)

## <small>1.0.2 (2024-03-28)</small>

* [bitnami/prometheus] Release 1.0.2 updating components versions (#24739) ([81563e8](https://github.com/bitnami/charts/commit/81563e8f1e577fe61c5c3790c94d3e0bbd83d134)), closes [#24739](https://github.com/bitnami/charts/issues/24739)

## <small>1.0.1 (2024-03-19)</small>

* [bitnami/*] Reorder Chart sections (#24455) ([0cf4048](https://github.com/bitnami/charts/commit/0cf4048e8743f70a9753d460655bd030cbff6824)), closes [#24455](https://github.com/bitnami/charts/issues/24455)
* [bitnami/prometheus] Release 1.0.1 updating components versions (#24546) ([8edf559](https://github.com/bitnami/charts/commit/8edf559ce9db3515aad61f5c8cb261b1c19bc93a)), closes [#24546](https://github.com/bitnami/charts/issues/24546)

## 1.0.0 (2024-03-15)

* [bitnami/prometheus] feat!: 🔒 💥 Improve security defaults (#24338) ([4c1a23f](https://github.com/bitnami/charts/commit/4c1a23f1512858c14abc796252a06864e653fa1d)), closes [#24338](https://github.com/bitnami/charts/issues/24338)

## <small>0.12.1 (2024-03-06)</small>

* [bitnami/prometheus] feat: :sparkles: :lock: Add automatic adaptation for Openshift restricted-v2 SC ([7f23e2b](https://github.com/bitnami/charts/commit/7f23e2bc1a73ecfa7a80e05bc343143f250c91ca)), closes [#24144](https://github.com/bitnami/charts/issues/24144)
* [bitnami/prometheus] Release 0.12.1 updating components versions (#24218) ([86df296](https://github.com/bitnami/charts/commit/86df29692db650daaf6bd64b8cb6c80583f0d0f3)), closes [#24218](https://github.com/bitnami/charts/issues/24218)

## 0.12.0 (2024-03-06)

* [bitnami/prometheus] feat: :sparkles: :lock: Add readOnlyRootFilesystem support (#23990) ([bdf0d79](https://github.com/bitnami/charts/commit/bdf0d79f3a1e84c0178bc25b840f64849574996f)), closes [#23990](https://github.com/bitnami/charts/issues/23990)

## <small>0.11.4 (2024-02-26)</small>

* [bitnami/prometheus] Release 0.11.4 updating components versions (#23918) ([55a9c73](https://github.com/bitnami/charts/commit/55a9c73362734866a87363f22eb651297bcdd921)), closes [#23918](https://github.com/bitnami/charts/issues/23918)

## <small>0.11.3 (2024-02-22)</small>

* [bitnami/prometheus] Release 0.11.3 updating components versions (#23858) ([09586e5](https://github.com/bitnami/charts/commit/09586e50dc01c2f3bb44cf473fe24ae3b03c0dc2)), closes [#23858](https://github.com/bitnami/charts/issues/23858)

## <small>0.11.2 (2024-02-22)</small>

* [bitnami/prometheus] Release 0.11.2 updating components versions (#23823) ([f0edd9a](https://github.com/bitnami/charts/commit/f0edd9afeba5f818432b8f01bbf3808d6bea2eb4)), closes [#23823](https://github.com/bitnami/charts/issues/23823)

## <small>0.11.1 (2024-02-21)</small>

* [bitnami/prometheus] Release 0.11.1 updating components versions (#23685) ([5fd77a8](https://github.com/bitnami/charts/commit/5fd77a8607ddc9ff1ad17a5387d626ea63f37b5c)), closes [#23685](https://github.com/bitnami/charts/issues/23685)

## 0.11.0 (2024-02-20)

* [bitnami/*] Bump all versions (#23602) ([b70ee2a](https://github.com/bitnami/charts/commit/b70ee2a30e4dc256bf0ac52928fb2fa7a70f049b)), closes [#23602](https://github.com/bitnami/charts/issues/23602)

## 0.10.0 (2024-02-15)

* [bitnami/prometheus] feat: :sparkles: :lock: Add resource preset support (#23512) ([0109ba1](https://github.com/bitnami/charts/commit/0109ba1f8b05b6e9e8949b3c190432d19f88ecb5)), closes [#23512](https://github.com/bitnami/charts/issues/23512)

## <small>0.9.4 (2024-02-08)</small>

* [bitnami/prometheus] Release 0.9.4 updating components versions (#23317) ([00b0ea9](https://github.com/bitnami/charts/commit/00b0ea9d26f0c09ca0b91eb442fb5e0d6b1ff3f3)), closes [#23317](https://github.com/bitnami/charts/issues/23317)

## <small>0.9.3 (2024-02-07)</small>

* [bitnami/prometheus] Release 0.9.3 updating components versions (#23258) ([5c7d030](https://github.com/bitnami/charts/commit/5c7d030713f73f1f18b6aedccfae95bcff895829)), closes [#23258](https://github.com/bitnami/charts/issues/23258)

## <small>0.9.2 (2024-02-03)</small>

* [bitnami/prometheus] Release 0.9.2 updating components versions (#23133) ([ac18d51](https://github.com/bitnami/charts/commit/ac18d51afc8657450f7494fcd2a7d815a33c59e7)), closes [#23133](https://github.com/bitnami/charts/issues/23133)

## <small>0.9.1 (2024-02-02)</small>

* [bitnami/prometheus] Release 0.9.1 updating components versions (#23045) ([91bb356](https://github.com/bitnami/charts/commit/91bb356d1b638444d2d3becd42bc74c2e7210fff)), closes [#23045](https://github.com/bitnami/charts/issues/23045)

## 0.9.0 (2024-02-01)

* [bitnami/prometheus] feat: :sparkles: Add allowExternalEgress (#22965) ([abb63b6](https://github.com/bitnami/charts/commit/abb63b6da3c967011bc3714fb21807ef21ec752a)), closes [#22965](https://github.com/bitnami/charts/issues/22965)

## <small>0.8.1 (2024-02-01)</small>

* [bitnami/prometheus] Release 0.8.1 updating components versions (#23007) ([8d4a033](https://github.com/bitnami/charts/commit/8d4a033409f2ca0f44f8b6b8eac15b3e95217494)), closes [#23007](https://github.com/bitnami/charts/issues/23007)

## 0.8.0 (2024-01-30)

* [bitnami/prometheus] feat: :lock: Enable networkPolicy (#22745) ([94ef9a9](https://github.com/bitnami/charts/commit/94ef9a94343a7ef0537cf8679443736642370972)), closes [#22745](https://github.com/bitnami/charts/issues/22745)

## <small>0.7.1 (2024-01-25)</small>

* [bitnami/*] Move documentation sections from docs.bitnami.com back to the README (#22203) ([7564f36](https://github.com/bitnami/charts/commit/7564f36ca1e95ff30ee686652b7ab8690561a707)), closes [#22203](https://github.com/bitnami/charts/issues/22203)
* [bitnami/prometheus] fix: :bug: Set seLinuxOptions to null for Openshift compatibility (#22649) ([0b17cfb](https://github.com/bitnami/charts/commit/0b17cfbadd3327cc8461f4ef8c81f58cb8adb4e4)), closes [#22649](https://github.com/bitnami/charts/issues/22649)

## 0.7.0 (2024-01-22)

* [bitnami/prometheus] fix: :lock: Move service-account token auto-mount to pod declaration (#22452) ([10dd0a5](https://github.com/bitnami/charts/commit/10dd0a5d054a0170954980b24839966ba1073e66)), closes [#22452](https://github.com/bitnami/charts/issues/22452)

## <small>0.6.1 (2024-01-18)</small>

* [bitnami/prometheus] Release 0.6.1 updating components versions (#22358) ([1e68235](https://github.com/bitnami/charts/commit/1e68235c2e580de704d86d897acbe2e96df141b2)), closes [#22358](https://github.com/bitnami/charts/issues/22358)

## 0.6.0 (2024-01-17)

* [bitnami/prometheus] fix: :lock: Improve podSecurityContext and containerSecurityContext with essent ([253cfd7](https://github.com/bitnami/charts/commit/253cfd7b6e94181fbdf32ebfcb613edaf247d6a6)), closes [#22180](https://github.com/bitnami/charts/issues/22180)

## <small>0.5.5 (2024-01-15)</small>

* [bitnami/prometheus] Release 0.5.5 updating components versions (#22209) ([947458b](https://github.com/bitnami/charts/commit/947458bc7c22d489a506306ba48782d38b906450)), closes [#22209](https://github.com/bitnami/charts/issues/22209)

## <small>0.5.4 (2024-01-15)</small>

* [bitnami/prometheus] Release 0.5.4 updating components versions (#22204) ([b001198](https://github.com/bitnami/charts/commit/b00119884455dec9591c94b91c7f17c778edeef9)), closes [#22204](https://github.com/bitnami/charts/issues/22204)

## <small>0.5.3 (2024-01-15)</small>

* [bitnami/*] Fix ref links (in comments) (#21822) ([e4fa296](https://github.com/bitnami/charts/commit/e4fa296106b225cf8c82445727c675c7c725e380)), closes [#21822](https://github.com/bitnami/charts/issues/21822)
* [bitnami/prometheus] fix: :lock: Do not automount the service account token unless necessary (#22060 ([ad3684e](https://github.com/bitnami/charts/commit/ad3684ecde5dad93d7a3ad8526020c90a4567d8c)), closes [#22060](https://github.com/bitnami/charts/issues/22060)

## <small>0.5.2 (2024-01-10)</small>

* [bitnami/*] Fix docs.bitnami.com broken links (#21901) ([f35506d](https://github.com/bitnami/charts/commit/f35506d2dadee4f097986e7792df1f53ab215b5d)), closes [#21901](https://github.com/bitnami/charts/issues/21901)
* [bitnami/*] Update copyright: Year and company (#21815) ([6c4bf75](https://github.com/bitnami/charts/commit/6c4bf75dec58fc7c9aee9f089777b1a858c17d5b)), closes [#21815](https://github.com/bitnami/charts/issues/21815)
* [bitnami/prometheus] Release 0.5.2 updating components versions (#21979) ([6d786ea](https://github.com/bitnami/charts/commit/6d786eaf1287e974dd7b7e1bab704226602de8c0)), closes [#21979](https://github.com/bitnami/charts/issues/21979)

## <small>0.5.1 (2023-12-12)</small>

* [bitnami/prometheus] Release 0.5.1 updating components versions (#21527) ([db794ed](https://github.com/bitnami/charts/commit/db794ed667608b95ce800c18d7d277697c97cce3)), closes [#21527](https://github.com/bitnami/charts/issues/21527)

## 0.5.0 (2023-12-12)

* Honor rbac config when creating prometheus ClusterRoleBinding (#21348) ([7db427e](https://github.com/bitnami/charts/commit/7db427e2db183e5da291c53a37202b84c11ebab4)), closes [#21348](https://github.com/bitnami/charts/issues/21348) [#21347](https://github.com/bitnami/charts/issues/21347)

## <small>0.4.7 (2023-12-07)</small>

* [bitnami/prometheus] Release 0.4.7 updating components versions (#21463) ([b3b0b3a](https://github.com/bitnami/charts/commit/b3b0b3aff96d5e793349561d8e50f77416052249)), closes [#21463](https://github.com/bitnami/charts/issues/21463)

## <small>0.4.6 (2023-12-05)</small>

* [bitnami/prometheus] Replace deprecated pull secret partial (#21394) ([27e60f3](https://github.com/bitnami/charts/commit/27e60f39c9f8e67f888a98d1d8304a06449f24c8)), closes [#21394](https://github.com/bitnami/charts/issues/21394)

## <small>0.4.5 (2023-11-21)</small>

* [bitnami/*] Remove relative links to non-README sections, add verification for that and update TL;DR ([1103633](https://github.com/bitnami/charts/commit/11036334d82df0490aa4abdb591543cab6cf7d7f)), closes [#20967](https://github.com/bitnami/charts/issues/20967)
* [bitnami/*] Rename solutions to "Bitnami package for ..." (#21038) ([b82f979](https://github.com/bitnami/charts/commit/b82f979e4fb63423fe6e2192c946d09d79c944fc)), closes [#21038](https://github.com/bitnami/charts/issues/21038)
* [bitnami/prometheus] Release 0.4.5 updating components versions (#21167) ([7e402ec](https://github.com/bitnami/charts/commit/7e402ec981b4d763656594513dc51543089c46a6)), closes [#21167](https://github.com/bitnami/charts/issues/21167)

## <small>0.4.4 (2023-11-16)</small>

* [bitnami/prometheus] Release 0.4.4 updating components versions (#21000) ([ecc2e40](https://github.com/bitnami/charts/commit/ecc2e40ab5c0d934540f94ec622e47f5ff5e1cbf)), closes [#21000](https://github.com/bitnami/charts/issues/21000)

## <small>0.4.3 (2023-11-09)</small>

* [bitnami/prometheus] Release 0.4.3 updating components versions (#20858) ([3b5fd64](https://github.com/bitnami/charts/commit/3b5fd64f1b0a1e1d977f84fa14424259f1226ffb)), closes [#20858](https://github.com/bitnami/charts/issues/20858)

## <small>0.4.2 (2023-11-09)</small>

* [bitnami/prometheus] Release 0.4.2 updating components versions (#20836) ([a805ad7](https://github.com/bitnami/charts/commit/a805ad7acdfed966dfc9855d33298da321588018)), closes [#20836](https://github.com/bitnami/charts/issues/20836)

## <small>0.4.1 (2023-11-08)</small>

* [bitnami/prometheus] Release 0.4.1 updating components versions (#20783) ([ec5855f](https://github.com/bitnami/charts/commit/ec5855f216e0a1a4badde2c554150d0c2e219211)), closes [#20783](https://github.com/bitnami/charts/issues/20783)

## 0.4.0 (2023-11-07)

* [bitnami/*] Rename VMware Application Catalog (#20361) ([3acc734](https://github.com/bitnami/charts/commit/3acc73472beb6fb56c4d99f929061001205bc57e)), closes [#20361](https://github.com/bitnami/charts/issues/20361)
* [bitnami/*] Skip image's tag in the README files of the Bitnami Charts (#19841) ([bb9a01b](https://github.com/bitnami/charts/commit/bb9a01b65911c87e48318db922cc05eb42785e42)), closes [#19841](https://github.com/bitnami/charts/issues/19841)
* [bitnami/*] Standardize documentation (#19835) ([af5f753](https://github.com/bitnami/charts/commit/af5f7530c1bc8c5ded53a6c4f7b8f384ac1804f2)), closes [#19835](https://github.com/bitnami/charts/issues/19835)
* [bitnami/prometheus] feat: :sparkles: Add support for PSA restricted policy (#20530) ([4f10416](https://github.com/bitnami/charts/commit/4f10416320afcbc2d103a2e0d8399156e1c64b82)), closes [#20530](https://github.com/bitnami/charts/issues/20530)

## <small>0.3.6 (2023-10-13)</small>

* [bitnami/prometheus] Release 0.3.6 (#20221) ([deb00f1](https://github.com/bitnami/charts/commit/deb00f16794dae6f4546f68a6ab13844bb7e3fd1)), closes [#20221](https://github.com/bitnami/charts/issues/20221)

## <small>0.3.5 (2023-10-11)</small>

* [bitnami/prometheus] Release 0.3.5 (#20062) ([f38a971](https://github.com/bitnami/charts/commit/f38a971e0d397f2c1e65066a9aa5c75abb1a79dd)), closes [#20062](https://github.com/bitnami/charts/issues/20062)

## <small>0.3.4 (2023-10-09)</small>

* [bitnami/prometheus] Release 0.3.4 (#19933) ([8963a79](https://github.com/bitnami/charts/commit/8963a79a3b5b8731f0980594ebe254fd4edbb5b3)), closes [#19933](https://github.com/bitnami/charts/issues/19933)

## <small>0.3.3 (2023-10-09)</small>

* [bitnami/*] Update Helm charts prerequisites (#19745) ([eb755dd](https://github.com/bitnami/charts/commit/eb755dd36a4dd3cf6635be8e0598f9a7f4c4a554)), closes [#19745](https://github.com/bitnami/charts/issues/19745)
* [bitnami/prometheus] Release 0.3.3 (#19888) ([fec53c9](https://github.com/bitnami/charts/commit/fec53c9010ab7c9bc88acb9ce1444d19c5258857)), closes [#19888](https://github.com/bitnami/charts/issues/19888)

## <small>0.3.2 (2023-10-04)</small>

* [bitnami/prometheus] Release 0.3.2 (#19751) ([312277c](https://github.com/bitnami/charts/commit/312277cc254526b98194af6a19725628db91076b)), closes [#19751](https://github.com/bitnami/charts/issues/19751)

## <small>0.3.1 (2023-10-04)</small>

* [bitnami/prometheus] Release 0.3.1 (#19736) ([ffcd3c3](https://github.com/bitnami/charts/commit/ffcd3c3e1261c14e81dd68eca055365c9467d6db)), closes [#19736](https://github.com/bitnami/charts/issues/19736)

## 0.3.0 (2023-09-25)

* Allow loadBalancerClass in prometheus charts (#19420) ([e23097e](https://github.com/bitnami/charts/commit/e23097e0a6c727ea31438fc2f5c00e9e3d9db739)), closes [#19420](https://github.com/bitnami/charts/issues/19420)

## <small>0.2.3 (2023-09-21)</small>

* [bitnami/prometheus] Use different app.kubernetes.io/version label on subcomponents (#19352) ([03ad39e](https://github.com/bitnami/charts/commit/03ad39ea9a8ce90ace517292a1b337bf2ffffb0e)), closes [#19352](https://github.com/bitnami/charts/issues/19352)
* Autogenerate schema files (#19194) ([a2c2090](https://github.com/bitnami/charts/commit/a2c2090b5ac97f47b745c8028c6452bf99739772)), closes [#19194](https://github.com/bitnami/charts/issues/19194)
* Revert "Autogenerate schema files (#19194)" (#19335) ([73d80be](https://github.com/bitnami/charts/commit/73d80be525c88fb4b8a54451a55acd506e337062)), closes [#19194](https://github.com/bitnami/charts/issues/19194) [#19335](https://github.com/bitnami/charts/issues/19335)

## <small>0.2.2 (2023-09-07)</small>

* [bitnami/prometheus: Use merge helper]: (#19096) ([a23eaae](https://github.com/bitnami/charts/commit/a23eaae09a049e08b4afa83c1e427d378bad4e37)), closes [#19096](https://github.com/bitnami/charts/issues/19096)

## <small>0.2.1 (2023-09-06)</small>

* [bitnami/prometheus] Release 0.2.1 (#19144) ([49d1cb2](https://github.com/bitnami/charts/commit/49d1cb253a4b55efeeaf9f2c9b959d0eb35819b0)), closes [#19144](https://github.com/bitnami/charts/issues/19144)

## 0.2.0 (2023-08-22)

* [bitnami/prometheus] Support for customizing standard labels (#18414) ([3cf5b2d](https://github.com/bitnami/charts/commit/3cf5b2db55bd83681a057132ee2b0a70acdbff7f)), closes [#18414](https://github.com/bitnami/charts/issues/18414)

## <small>0.1.12 (2023-08-20)</small>

* [bitnami/prometheus] Release 0.1.12 (#18708) ([459b035](https://github.com/bitnami/charts/commit/459b03501bc171659b02c4cfa5abd2db0c2db119)), closes [#18708](https://github.com/bitnami/charts/issues/18708)

## <small>0.1.11 (2023-08-17)</small>

* [bitnami/prometheus] Release 0.1.11 (#18584) ([bcc7f83](https://github.com/bitnami/charts/commit/bcc7f8337e4fc6ffdfae96505a545b844e52d144)), closes [#18584](https://github.com/bitnami/charts/issues/18584)

## <small>0.1.10 (2023-08-15)</small>

* bitnami/prometheus: Changes Ingress backend to match services (#18391) ([d0ab702](https://github.com/bitnami/charts/commit/d0ab7023a9ce18478e6fd0ec7a09f919d0d1cfc8)), closes [#18391](https://github.com/bitnami/charts/issues/18391)

## <small>0.1.9 (2023-07-26)</small>

* [bitnami/prometheus] Release 0.1.9 (#17953) ([0997c1b](https://github.com/bitnami/charts/commit/0997c1bf4bc20b5874c742a6e992c6768b5e1984)), closes [#17953](https://github.com/bitnami/charts/issues/17953)

## <small>0.1.8 (2023-07-26)</small>

* [bitnami/prometheus] Release 0.1.8 (#17951) ([3c61896](https://github.com/bitnami/charts/commit/3c618962fd2d71b1b7c550245413d89f912101da)), closes [#17951](https://github.com/bitnami/charts/issues/17951)

## <small>0.1.7 (2023-07-15)</small>

* [bitnami/prometheus] Release 0.1.7 (#17664) ([ac09e74](https://github.com/bitnami/charts/commit/ac09e74cdf7ffda1eb2a55879138297d9419ea0e)), closes [#17664](https://github.com/bitnami/charts/issues/17664)
* Use os-shell in tempate and Jaeger runtime params (#17557) ([91a49eb](https://github.com/bitnami/charts/commit/91a49eb1e3c81c7b7c6c28d1bc5d6d6ae698c1e2)), closes [#17557](https://github.com/bitnami/charts/issues/17557)

## <small>0.1.6 (2023-06-27)</small>

* [bitnami/prometheus] Release 0.1.6 (#17360) ([a119af2](https://github.com/bitnami/charts/commit/a119af2d922826911736eef1f0c6013158056437)), closes [#17360](https://github.com/bitnami/charts/issues/17360)
* Add copyright header (#17300) ([da68be8](https://github.com/bitnami/charts/commit/da68be8e951225133c7dfb572d5101ca3d61c5ae)), closes [#17300](https://github.com/bitnami/charts/issues/17300)

## <small>0.1.5 (2023-06-23)</small>

* [bitnami/prometheus] Release 0.1.5 (#17323) ([e167d7e](https://github.com/bitnami/charts/commit/e167d7e3e28f81cd6f4ea49115a546b292fbea76)), closes [#17323](https://github.com/bitnami/charts/issues/17323)
* Update charts readme (#17217) ([31b3c0a](https://github.com/bitnami/charts/commit/31b3c0afd968ff4429107e34101f7509e6a0e913)), closes [#17217](https://github.com/bitnami/charts/issues/17217)

## <small>0.1.4 (2023-06-06)</small>

* [bitnami/*] Change copyright section in READMEs (#17006) ([ef986a1](https://github.com/bitnami/charts/commit/ef986a1605241102b3dcafe9fd8089e6fc1201ad)), closes [#17006](https://github.com/bitnami/charts/issues/17006)
* [bitnami/prometheus] Release 0.1.4 (#17044) ([a439ad1](https://github.com/bitnami/charts/commit/a439ad1bce7cdea350bd995b81a6117c7ca6dca8)), closes [#17044](https://github.com/bitnami/charts/issues/17044)
* [bitnami/several] Change copyright section in READMEs (#16989) ([5b6a5cf](https://github.com/bitnami/charts/commit/5b6a5cfb7625a751848a2e5cd796bd7278f406ca)), closes [#16989](https://github.com/bitnami/charts/issues/16989)

## <small>0.1.3 (2023-05-26)</small>

* [bitnami/prometheus] Release 0.1.3 (#16923) ([3f6ff35](https://github.com/bitnami/charts/commit/3f6ff35e0b33a025c12e830910b6df17223ab99e)), closes [#16923](https://github.com/bitnami/charts/issues/16923)

## <small>0.1.2 (2023-05-25)</small>

* [bitnami/prometheus] Use FQDN for cluster.peers in alertmanager (#16903) ([44d90f9](https://github.com/bitnami/charts/commit/44d90f95b4fb212dbffb01156e577f3fe3ee661c)), closes [#16903](https://github.com/bitnami/charts/issues/16903)

## <small>0.1.1 (2023-05-23)</small>

* [bitnami/prometheus] Release 0.1.1 (#16883) ([be0226b](https://github.com/bitnami/charts/commit/be0226bae6500d14594b5acc05bb978549db5093)), closes [#16883](https://github.com/bitnami/charts/issues/16883)

## 0.1.0 (2023-05-16)

* [bitnami/prometheus] Add chart (#15543) ([aec435b](https://github.com/bitnami/charts/commit/aec435b2dddcc1967e03e7395c1eca82c25ec528)), closes [#15543](https://github.com/bitnami/charts/issues/15543)
