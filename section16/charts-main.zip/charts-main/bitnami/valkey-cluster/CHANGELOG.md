# Changelog

## 3.0.24 (2025-08-23)

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references ([#36175](https://github.com/bitnami/charts/pull/36175))

## <small>3.0.23 (2025-08-13)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#35838) ([2cb9432](https://github.com/bitnami/charts/commit/2cb9432669ca09e7cf037ad8ba5103cdd6f5630a)), closes [#35838](https://github.com/bitnami/charts/issues/35838)

## <small>3.0.22 (2025-08-09)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#35715) ([447d817](https://github.com/bitnami/charts/commit/447d8173548a37a9715e45c899976f988e87d6c6)), closes [#35715](https://github.com/bitnami/charts/issues/35715)

## <small>3.0.21 (2025-08-07)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#35682) ([aaa19b2](https://github.com/bitnami/charts/commit/aaa19b243f636f44749edfbc5f43185a6f6f2247)), closes [#35682](https://github.com/bitnami/charts/issues/35682)

## <small>3.0.20 (2025-08-07)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#35659) ([2621d41](https://github.com/bitnami/charts/commit/2621d4169dc615816b1f18e21a1f629096f4c05b)), closes [#35659](https://github.com/bitnami/charts/issues/35659)

## <small>3.0.19 (2025-08-07)</small>

* [bitnami/*] Adapt main README and change ascii (#35173) ([73d15e0](https://github.com/bitnami/charts/commit/73d15e03e04647efa902a1d14a09ea8657429cd0)), closes [#35173](https://github.com/bitnami/charts/issues/35173)
* [bitnami/*] Adapt welcome message to BSI (#35170) ([e1c8146](https://github.com/bitnami/charts/commit/e1c8146831516fb35de736a6f3fd10e5e7a44286)), closes [#35170](https://github.com/bitnami/charts/issues/35170)
* [bitnami/*] Add BSI to charts' READMEs (#35174) ([4973fd0](https://github.com/bitnami/charts/commit/4973fd08dd7e95398ddcc4054538023b542e19f2)), closes [#35174](https://github.com/bitnami/charts/issues/35174)
* [bitnami/*] docs: update BSI warning on charts' notes (#35340) ([07483a5](https://github.com/bitnami/charts/commit/07483a5ed964b409266dc025e4b55bf2eb0f621c)), closes [#35340](https://github.com/bitnami/charts/issues/35340)
* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#35525) ([669d628](https://github.com/bitnami/charts/commit/669d6282c00afaa5508081a1c2259cdb5fa20fff)), closes [#35525](https://github.com/bitnami/charts/issues/35525)

## <small>3.0.18 (2025-07-15)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#35132) ([f8cbeb2](https://github.com/bitnami/charts/commit/f8cbeb2cfbb6b0dcdf67edc536bbe075a16f7cef)), closes [#35132](https://github.com/bitnami/charts/issues/35132)

## <small>3.0.17 (2025-07-09)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#34951) ([4ca888c](https://github.com/bitnami/charts/commit/4ca888c636f6078e508ccb39adb1753c24454899)), closes [#34951](https://github.com/bitnami/charts/issues/34951)

## <small>3.0.16 (2025-07-08)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#34848) ([db08207](https://github.com/bitnami/charts/commit/db08207a95e1670f3b0de576ec3a256e56083cd1)), closes [#34848](https://github.com/bitnami/charts/issues/34848)

## <small>3.0.15 (2025-07-07)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#34832) ([c68166d](https://github.com/bitnami/charts/commit/c68166d44581e57f1407ac7e507471f11bbd5781)), closes [#34832](https://github.com/bitnami/charts/issues/34832)

## <small>3.0.14 (2025-06-13)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#34488) ([9a78845](https://github.com/bitnami/charts/commit/9a78845214c304deff27f07f487d47ca74937245)), closes [#34488](https://github.com/bitnami/charts/issues/34488)

## <small>3.0.13 (2025-06-11)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#34362) ([df7362e](https://github.com/bitnami/charts/commit/df7362ef25b67f3705690b532d7c9cd4046f6a83)), closes [#34362](https://github.com/bitnami/charts/issues/34362)

## <small>3.0.12 (2025-06-08)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#34252) ([6592a44](https://github.com/bitnami/charts/commit/6592a4411503f98468add9c4760197d094c8ba68)), closes [#34252](https://github.com/bitnami/charts/issues/34252)

## <small>3.0.11 (2025-06-06)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#34216) ([c4d9bfb](https://github.com/bitnami/charts/commit/c4d9bfb0df2690b31c2461f7f7e5f1ea3971b58e)), closes [#34216](https://github.com/bitnami/charts/issues/34216)

## <small>3.0.10 (2025-05-22)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#33826) ([a248d00](https://github.com/bitnami/charts/commit/a248d00d8a4dc7ba4fb53f6259f7d01a93c8c6a1)), closes [#33826](https://github.com/bitnami/charts/issues/33826)

## <small>3.0.9 (2025-05-18)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#33768) ([e0389ac](https://github.com/bitnami/charts/commit/e0389acd8d7a2fe8b1822c2a19cdd2cdfad7eeea)), closes [#33768](https://github.com/bitnami/charts/issues/33768)

## <small>3.0.8 (2025-05-16)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#33748) ([4a2d739](https://github.com/bitnami/charts/commit/4a2d739e2ace2c50ffb8961ce02b77549c34dd28)), closes [#33748](https://github.com/bitnami/charts/issues/33748)

## <small>3.0.7 (2025-05-15)</small>

* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#33712) ([97270b5](https://github.com/bitnami/charts/commit/97270b5e120cff1148bc48056e2e2fed42a89edb)), closes [#33712](https://github.com/bitnami/charts/issues/33712)

## <small>3.0.6 (2025-05-13)</small>

* [bitnami/kubeapps] Deprecation followup (#33579) ([77e312c](https://github.com/bitnami/charts/commit/77e312c1772d4d7c4dc5d3ac0e80f4e452e3a062)), closes [#33579](https://github.com/bitnami/charts/issues/33579)
* [bitnami/valkey-cluster] :zap: :arrow_up: Update dependency references (#33648) ([0b5a55e](https://github.com/bitnami/charts/commit/0b5a55e4c0d1c5ab60d246be1d70c2a087b71a30)), closes [#33648](https://github.com/bitnami/charts/issues/33648)

## <small>3.0.5 (2025-05-07)</small>

* [bitnami/valkey-cluster] chore: :recycle: :arrow_up: Update common and remove k8s < 1.23 references  ([1e19c13](https://github.com/bitnami/charts/commit/1e19c1350f7663fec99ba6d6aa899442272f577d)), closes [#33444](https://github.com/bitnami/charts/issues/33444)

## <small>3.0.4 (2025-05-05)</small>

* [bitnami/valkey-cluster] only use password files if auth is enabled (#33239) ([ce60ab6](https://github.com/bitnami/charts/commit/ce60ab65a82c5429d488eaf9fdb805915fd4af0a)), closes [#33239](https://github.com/bitnami/charts/issues/33239)

## <small>3.0.3 (2025-04-23)</small>

* [bitnami/valkey-cluster] Release 3.0.3 (#33149) ([20426a5](https://github.com/bitnami/charts/commit/20426a51276475f4e7c6844ccb86044e35cbcf61)), closes [#33149](https://github.com/bitnami/charts/issues/33149)

## <small>3.0.2 (2025-04-09)</small>

* [bitnami/valkey-cluster] Release 3.0.2 (#32937) ([04a7a8d](https://github.com/bitnami/charts/commit/04a7a8d9014726e23b189bdd8bbc8a52b696920f)), closes [#32937](https://github.com/bitnami/charts/issues/32937)

## <small>3.0.1 (2025-04-09)</small>

* [bitnami/valkey-cluster] Release 3.0.1 (#32935) ([eae8e95](https://github.com/bitnami/charts/commit/eae8e95db651adfe54d3ec3929387bc1a9167f82)), closes [#32935](https://github.com/bitnami/charts/issues/32935)

## 3.0.0 (2025-04-09)

* [bitnami/valkey-cluster] Release 3.0.0 (#32934) ([7b1a034](https://github.com/bitnami/charts/commit/7b1a03414cce9425fb364332f5f669dc0bda348d)), closes [#32934](https://github.com/bitnami/charts/issues/32934)

## <small>2.2.1 (2025-03-28)</small>

* [bitnami/*] Add tanzuCategory annotation (#32409) ([a8fba5c](https://github.com/bitnami/charts/commit/a8fba5cb01f6f4464ca7f69c50b0fbe97d837a95)), closes [#32409](https://github.com/bitnami/charts/issues/32409)
* [bitnami/valkey-cluster] Release 2.2.1 (#32564) ([1c23328](https://github.com/bitnami/charts/commit/1c23328f1e9cb6d076adb8e7b548a40b341f3c0c)), closes [#32564](https://github.com/bitnami/charts/issues/32564)

## 2.2.0 (2025-02-24)

* [bitnami/valkey-cluster] Set `usePasswordFiles=true` by default (#32122) ([c46b8f0](https://github.com/bitnami/charts/commit/c46b8f0029226245c04a3fed93225e82a9ab3e57)), closes [#32122](https://github.com/bitnami/charts/issues/32122)

## <small>2.1.3 (2025-02-20)</small>

* [bitnami/valkey-cluster] Release 2.1.3 (#32066) ([6d565b3](https://github.com/bitnami/charts/commit/6d565b3a18fd2efee3764e826503fdb29b91e75b)), closes [#32066](https://github.com/bitnami/charts/issues/32066)

## <small>2.1.2 (2025-02-17)</small>

* [bitnami/*] Use CDN url for the Bitnami Application Icons (#31881) ([d9bb11a](https://github.com/bitnami/charts/commit/d9bb11a9076b9bfdcc70ea022c25ef50e9713657)), closes [#31881](https://github.com/bitnami/charts/issues/31881)
* [bitnami/valkey-cluster] Release 2.1.2 (#31945) ([c94c869](https://github.com/bitnami/charts/commit/c94c869389a1a09e6e1e8cda2175c3adce4aa776)), closes [#31945](https://github.com/bitnami/charts/issues/31945)
* Update copyright year (#31682) ([e9f02f5](https://github.com/bitnami/charts/commit/e9f02f5007068751f7eb2270fece811e685c99b6)), closes [#31682](https://github.com/bitnami/charts/issues/31682)

## <small>2.1.1 (2025-01-08)</small>

* [bitnami/*] Fix typo in README (#31052) ([b41a51d](https://github.com/bitnami/charts/commit/b41a51d1bd04841fc108b78d3b8357a5292771c8)), closes [#31052](https://github.com/bitnami/charts/issues/31052)
* [bitnami/valkey-cluster] Release 2.1.1 (#31247) ([d49d243](https://github.com/bitnami/charts/commit/d49d2432841a1042c4a750763a5ba65317302604)), closes [#31247](https://github.com/bitnami/charts/issues/31247)

## 2.1.0 (2024-12-10)

* [bitnami/*] Add Bitnami Premium to NOTES.txt (#30854) ([3dfc003](https://github.com/bitnami/charts/commit/3dfc00376df6631f0ce54b8d440d477f6caa6186)), closes [#30854](https://github.com/bitnami/charts/issues/30854)
* [bitnami/*] docs: :memo: Add "Update Credentials" (batch 3) (#30688) ([10a49f9](https://github.com/bitnami/charts/commit/10a49f9ff2db1d9d11a6edd1c40a9f61803241bc)), closes [#30688](https://github.com/bitnami/charts/issues/30688)
* [bitnami/valkey-cluster] Detect non-standard images (#30951) ([82e7a6a](https://github.com/bitnami/charts/commit/82e7a6aedc9a3534b7fa4f46f968a74623858bae)), closes [#30951](https://github.com/bitnami/charts/issues/30951)

## <small>2.0.2 (2024-12-01)</small>

* [bitnami/*] docs: :memo: Add "Prometheus metrics" (batch 6) (#30675) ([7b9cd04](https://github.com/bitnami/charts/commit/7b9cd04c2ffc730a0d62da787f2d4967c0ede47c)), closes [#30675](https://github.com/bitnami/charts/issues/30675)
* [bitnami/valkey-cluster] Release 2.0.2 (#30702) ([7b5eadf](https://github.com/bitnami/charts/commit/7b5eadf41da24bf85355b688876b7c022f35ae3e)), closes [#30702](https://github.com/bitnami/charts/issues/30702)

## <small>2.0.1 (2024-11-08)</small>

* [bitnami/*] Remove wrong comment about imagePullPolicy (#30107) ([a51f9e4](https://github.com/bitnami/charts/commit/a51f9e4bb0fbf77199512d35de7ac8abe055d026)), closes [#30107](https://github.com/bitnami/charts/issues/30107)
* [bitnami/valkey-cluster] Unify seLinuxOptions default value (#30322) ([ec4be59](https://github.com/bitnami/charts/commit/ec4be591f3f0fcc52ddd9c4f0cf6d0ddc19f9db7)), closes [#30322](https://github.com/bitnami/charts/issues/30322)

## 2.0.0 (2024-10-23)

* [bitnami/valkey-cluster] Update all the references from  to master/slave to primary/replica (#30025) ([e273ef7](https://github.com/bitnami/charts/commit/e273ef7b416321d485e586b9f69ddf12f5964fcb)), closes [#30025](https://github.com/bitnami/charts/issues/30025)

## <small>1.0.3 (2024-10-22)</small>

* [bitnami/valkey-cluster] Release 1.0.3 (#30047) ([66979a1](https://github.com/bitnami/charts/commit/66979a1de5d865b84e614737f9a0c6955d3cccc0)), closes [#30047](https://github.com/bitnami/charts/issues/30047)
* Update documentation links to techdocs.broadcom.com (#29931) ([f0d9ad7](https://github.com/bitnami/charts/commit/f0d9ad78f39f633d275fc576d32eae78ded4d0b8)), closes [#29931](https://github.com/bitnami/charts/issues/29931)

## <small>1.0.2 (2024-10-03)</small>

* [bitnami/valkey-cluster] Release 1.0.2 (#29769) ([6d4a548](https://github.com/bitnami/charts/commit/6d4a5487c8b744fe4219bbf4acec6698939ca885)), closes [#29769](https://github.com/bitnami/charts/issues/29769)

## <small>1.0.1 (2024-09-26)</small>

* [bitnami/valkey-cluster] the redis_url for redis_exporter should use rediss/redis scheme, not valkey ([ab5bc91](https://github.com/bitnami/charts/commit/ab5bc9156d158b0808ead47d7d67cf5704ed37ec)), closes [#29589](https://github.com/bitnami/charts/issues/29589)

## 1.0.0 (2024-09-16)

* [bitnami/valkey-cluster] Release 1.0.0 (#29450) ([a6c84c2](https://github.com/bitnami/charts/commit/a6c84c2362b2577ce78ead825292e6037e1a2c13)), closes [#29450](https://github.com/bitnami/charts/issues/29450)

## <small>0.1.11 (2024-09-09)</small>

* [bitnami/valkey-cluster] Release 0.1.11 (#29314) ([237b54e](https://github.com/bitnami/charts/commit/237b54eeb8fe80287e0b7a3749dac88db79b7733)), closes [#29314](https://github.com/bitnami/charts/issues/29314)

## <small>0.1.10 (2024-08-28)</small>

* [bitnami/valkey-cluster] test: :white_check_mark: Improve ginkgo tests reliability (#29080) ([8d4a3ba](https://github.com/bitnami/charts/commit/8d4a3baa33536661caa577bf32219823e937018b)), closes [#29080](https://github.com/bitnami/charts/issues/29080)

## <small>0.1.9 (2024-08-19)</small>

* [bitnami/valkey-cluster] Fix env-vars for metrics container (#28885) ([1df2599](https://github.com/bitnami/charts/commit/1df2599056ee021039b91c7e6af3f37f086ebc27)), closes [#28885](https://github.com/bitnami/charts/issues/28885)

## <small>0.1.8 (2024-07-31)</small>

* [bitnami/valkey-cluster] Release 0.1.8 (#28609) ([449f0fc](https://github.com/bitnami/charts/commit/449f0fcc372bd0a5e0eff5fb36acf34956143fd9)), closes [#28609](https://github.com/bitnami/charts/issues/28609)

## <small>0.1.7 (2024-07-29)</small>

* [bitnami/valkey-cluster] update metrics-svc template name format (#27993) ([b350773](https://github.com/bitnami/charts/commit/b350773e5bbae8ed23560b5b8529630d9c5fddcc)), closes [#27993](https://github.com/bitnami/charts/issues/27993)

## <small>0.1.6 (2024-07-25)</small>

* [bitnami/valkey-cluster] Release 0.1.6 (#28492) ([979a50b](https://github.com/bitnami/charts/commit/979a50b707efbfee186c31b84fc91c839b116768)), closes [#28492](https://github.com/bitnami/charts/issues/28492)

## <small>0.1.5 (2024-07-24)</small>

* [bitnami/valkey-cluster] Release 0.1.5 (#28377) ([463a4ec](https://github.com/bitnami/charts/commit/463a4ecb66163eea70aea9cdcd85907360c7bf2c)), closes [#28377](https://github.com/bitnami/charts/issues/28377)

## <small>0.1.4 (2024-07-22)</small>

* [bitanami/valkey-cluster] fix name generation loop in the external access template (#28163) ([0acace4](https://github.com/bitnami/charts/commit/0acace4851bcfee9ff90935194a9d3acf371f9dc)), closes [#28163](https://github.com/bitnami/charts/issues/28163)

## <small>0.1.3 (2024-07-18)</small>

* [bitnami/valkey-cluster] Global StorageClass as default value (#28106) ([47318eb](https://github.com/bitnami/charts/commit/47318eb3fad504d94ad0e4450dcb7cb36380e0c1)), closes [#28106](https://github.com/bitnami/charts/issues/28106)

## <small>0.1.2 (2024-07-11)</small>

* [bitnami/valkey-cluster] Release 0.1.2 (#27904) ([4f7d453](https://github.com/bitnami/charts/commit/4f7d453085b9a481f65227b6f9edc7ae068b45b5)), closes [#27904](https://github.com/bitnami/charts/issues/27904)

## <small>0.1.1 (2024-07-08)</small>

* [bitnami/valkey-cluster] Release 0.1.1 (#27838) ([066c4d3](https://github.com/bitnami/charts/commit/066c4d37a75f9091a16d89f6daf90e80c7c68ea1)), closes [#27838](https://github.com/bitnami/charts/issues/27838)

## 0.1.0 (2024-07-08)

* [bitnami/valkey-cluster] Add valkey cluster chart (#27737) ([c167147](https://github.com/bitnami/charts/commit/c167147e254022c81745b4110d58b62babd23a7d)), closes [#27737](https://github.com/bitnami/charts/issues/27737)
